(function() {
  "use strict";
  const HOST_ID = "scoopbus-results-scraper-overlay";
  let root = null;
  function ensureRoot() {
    if (root) return root;
    const host = document.createElement("div");
    host.id = HOST_ID;
    host.style.cssText = "position:fixed;top:16px;right:16px;z-index:2147483647;width:320px;";
    document.documentElement.appendChild(host);
    root = host.attachShadow({ mode: "open" });
    root.innerHTML = `
		<style>
			:host { all: initial; }
			.panel {
				font: 13px/1.45 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
				background: #2b2118;
				color: #f4ece1;
				border: 2px solid #8a6f52;
				border-radius: 8px;
				box-shadow: 0 8px 28px rgba(0,0,0,.45);
				overflow: hidden;
			}
			.head {
				display: flex; align-items: center; gap: 8px;
				padding: 9px 12px;
				background: #3b2c20;
				font-weight: 700; font-size: 12px;
				text-transform: uppercase; letter-spacing: .06em;
			}
			.head .dot {
				width: 8px; height: 8px; border-radius: 50%;
				background: #8fbf6a; flex: 0 0 auto;
			}
			.head .dot.blocked { background: #e2b23c; }
			.head .dot.error { background: #d9534f; }
			.head .dot.done { background: #6aa9bf; }
			.body { padding: 10px 12px 12px; }
			.count { font-size: 12px; opacity: .75; margin-bottom: 8px; }
			.bar {
				height: 6px; border-radius: 3px; background: rgba(255,255,255,.14);
				overflow: hidden; margin-bottom: 10px;
			}
			.bar > i { display: block; height: 100%; background: #8fbf6a; transition: width .25s; }
			.current { font-weight: 700; margin-bottom: 2px; }
			.detail { font-size: 12px; opacity: .8; }
			.detail.blocked { color: #f0c860; }
			.notice {
				margin-top: 10px; padding: 8px 10px;
				background: rgba(226,178,60,.14);
				border: 1px solid rgba(226,178,60,.5);
				border-radius: 5px; font-size: 12px;
			}
			.actions { margin-top: 12px; display: flex; gap: 8px; }
			button {
				font: inherit; font-size: 12px; font-weight: 700;
				padding: 5px 12px; border-radius: 5px; cursor: pointer;
				background: rgba(255,255,255,.1); color: #f4ece1;
				border: 1px solid rgba(255,255,255,.28);
			}
			button:hover { background: rgba(255,255,255,.18); }
			.hidden { display: none; }
		</style>
		<div class="panel">
			<div class="head"><span class="dot"></span><span class="title">Scraping parkrun</span></div>
			<div class="body">
				<div class="count"></div>
				<div class="bar"><i style="width:0%"></i></div>
				<div class="current"></div>
				<div class="detail"></div>
				<div class="notice hidden"></div>
				<div class="actions">
					<button class="retry hidden">Retry</button>
					<button class="skip hidden">Skip</button>
					<button class="cancel">Cancel</button>
				</div>
			</div>
		</div>
	`;
    for (const action of ["cancel", "retry", "skip"]) {
      root.querySelector(`.${action}`)?.addEventListener("click", () => {
        void chrome.runtime.sendMessage({ type: action }).catch(() => void 0);
      });
    }
    return root;
  }
  function render(state) {
    if (state.status === "idle" || state.items.length === 0) {
      document.getElementById(HOST_ID)?.remove();
      root = null;
      return;
    }
    const shadow = ensureRoot();
    const done = state.items.filter(
      (i) => i.status === "captured" || i.status === "failed" || i.status === "skipped"
    ).length;
    const current = state.items.find((i) => i.key === state.currentKey);
    const blocked = current?.status === "blocked";
    const dot = shadow.querySelector(".dot");
    dot.className = `dot${state.status === "error" ? " error" : state.status === "done" ? " done" : blocked ? " blocked" : ""}`;
    setText(shadow, ".title", titleFor(state, blocked));
    setText(shadow, ".count", `${done} of ${state.items.length} pages`);
    setText(shadow, ".current", current?.label ?? "");
    const detail = shadow.querySelector(".detail");
    detail.textContent = current?.detail ?? "";
    detail.className = `detail${blocked ? " blocked" : ""}`;
    const bar = shadow.querySelector(".bar > i");
    bar.style.width = `${Math.round(done / state.items.length * 100)}%`;
    const notice = shadow.querySelector(".notice");
    if (blocked) {
      notice.textContent = current?.awaitUser ? "Solve the check on this page and the scrape carries on by itself. Nothing will reload while you work — take as long as you need." : "Waiting on parkrun. Retrying automatically.";
      notice.classList.remove("hidden");
    } else if (state.message && state.status !== "running") {
      notice.textContent = state.message;
      notice.classList.remove("hidden");
    } else {
      notice.classList.add("hidden");
    }
    const running = state.status === "running";
    toggle(shadow, ".cancel", !running);
    toggle(shadow, ".retry", !blocked || !!current?.awaitUser);
    toggle(shadow, ".skip", !blocked);
  }
  function titleFor(state, blocked) {
    if (state.status === "done") return "Scrape complete";
    if (state.status === "cancelled") return "Scrape cancelled";
    if (state.status === "error") return "Scrape failed";
    return blocked ? "Waiting for you" : "Scraping parkrun";
  }
  function toggle(shadow, selector, hidden) {
    shadow.querySelector(selector)?.classList.toggle("hidden", hidden);
  }
  function setText(shadow, selector, text) {
    const node = shadow.querySelector(selector);
    if (node) node.textContent = text;
  }
  chrome.runtime.onMessage.addListener((message) => {
    const typed = message;
    if (typed.type === "state" || typed.type === "finished") render(typed.state);
    return void 0;
  });
  void (async () => {
    try {
      const reply = await chrome.runtime.sendMessage({ type: "state?" });
      if (reply?.type === "state") render(reply.state);
    } catch {
    }
  })();
})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3ZlcmxheS5qcyIsInNvdXJjZXMiOlsiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL292ZXJsYXkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBUaGUgZmxvYXRpbmcgcHJvZ3Jlc3MgcGFuZWwsIGluamVjdGVkIGludG8gZXZlcnkgcGFnZSBiZWluZyBzY3JhcGVkLlxuICpcbiAqIFlvdSdsbCBiZSBsb29raW5nIGF0IHRoZSBzY3JhcGUgdGFiIHdoZW4gYSBib3QgY2hlY2sgYXBwZWFycywgc28gcHJvZ3Jlc3MgYW5kXG4gKiBhIHdheSBvdXQgaGF2ZSB0byBiZSB0aGVyZSwgbm90IG9ubHkgYmFjayBvbiB0aGUgYWRtaW4gcGFnZS5cbiAqXG4gKiBSZW5kZXJlZCBpbnRvIGEgc2hhZG93IHJvb3Qgc28gcGFya3J1bidzIHN0eWxlc2hlZXRzIGNhbid0IHJlYWNoIGl0IGFuZCBvdXJzXG4gKiBjYW4ndCBsZWFrIG91dC5cbiAqL1xuaW1wb3J0IHR5cGUgeyBFeHRlbnNpb25NZXNzYWdlLCBSdW5TdGF0ZSB9IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcblxuY29uc3QgSE9TVF9JRCA9ICdzY29vcGJ1cy1yZXN1bHRzLXNjcmFwZXItb3ZlcmxheSdcblxubGV0IHJvb3Q6IFNoYWRvd1Jvb3QgfCBudWxsID0gbnVsbFxuXG5mdW5jdGlvbiBlbnN1cmVSb290KCk6IFNoYWRvd1Jvb3Qge1xuXHRpZiAocm9vdCkgcmV0dXJuIHJvb3RcblxuXHRjb25zdCBob3N0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0aG9zdC5pZCA9IEhPU1RfSURcblx0aG9zdC5zdHlsZS5jc3NUZXh0ID1cblx0XHQncG9zaXRpb246Zml4ZWQ7dG9wOjE2cHg7cmlnaHQ6MTZweDt6LWluZGV4OjIxNDc0ODM2NDc7d2lkdGg6MzIwcHg7J1xuXHRkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuYXBwZW5kQ2hpbGQoaG9zdClcblxuXHRyb290ID0gaG9zdC5hdHRhY2hTaGFkb3coeyBtb2RlOiAnb3BlbicgfSlcblx0cm9vdC5pbm5lckhUTUwgPSBgXG5cdFx0PHN0eWxlPlxuXHRcdFx0Omhvc3QgeyBhbGw6IGluaXRpYWw7IH1cblx0XHRcdC5wYW5lbCB7XG5cdFx0XHRcdGZvbnQ6IDEzcHgvMS40NSAtYXBwbGUtc3lzdGVtLCBCbGlua01hY1N5c3RlbUZvbnQsIFwiU2Vnb2UgVUlcIiwgc2Fucy1zZXJpZjtcblx0XHRcdFx0YmFja2dyb3VuZDogIzJiMjExODtcblx0XHRcdFx0Y29sb3I6ICNmNGVjZTE7XG5cdFx0XHRcdGJvcmRlcjogMnB4IHNvbGlkICM4YTZmNTI7XG5cdFx0XHRcdGJvcmRlci1yYWRpdXM6IDhweDtcblx0XHRcdFx0Ym94LXNoYWRvdzogMCA4cHggMjhweCByZ2JhKDAsMCwwLC40NSk7XG5cdFx0XHRcdG92ZXJmbG93OiBoaWRkZW47XG5cdFx0XHR9XG5cdFx0XHQuaGVhZCB7XG5cdFx0XHRcdGRpc3BsYXk6IGZsZXg7IGFsaWduLWl0ZW1zOiBjZW50ZXI7IGdhcDogOHB4O1xuXHRcdFx0XHRwYWRkaW5nOiA5cHggMTJweDtcblx0XHRcdFx0YmFja2dyb3VuZDogIzNiMmMyMDtcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IDcwMDsgZm9udC1zaXplOiAxMnB4O1xuXHRcdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlOyBsZXR0ZXItc3BhY2luZzogLjA2ZW07XG5cdFx0XHR9XG5cdFx0XHQuaGVhZCAuZG90IHtcblx0XHRcdFx0d2lkdGg6IDhweDsgaGVpZ2h0OiA4cHg7IGJvcmRlci1yYWRpdXM6IDUwJTtcblx0XHRcdFx0YmFja2dyb3VuZDogIzhmYmY2YTsgZmxleDogMCAwIGF1dG87XG5cdFx0XHR9XG5cdFx0XHQuaGVhZCAuZG90LmJsb2NrZWQgeyBiYWNrZ3JvdW5kOiAjZTJiMjNjOyB9XG5cdFx0XHQuaGVhZCAuZG90LmVycm9yIHsgYmFja2dyb3VuZDogI2Q5NTM0ZjsgfVxuXHRcdFx0LmhlYWQgLmRvdC5kb25lIHsgYmFja2dyb3VuZDogIzZhYTliZjsgfVxuXHRcdFx0LmJvZHkgeyBwYWRkaW5nOiAxMHB4IDEycHggMTJweDsgfVxuXHRcdFx0LmNvdW50IHsgZm9udC1zaXplOiAxMnB4OyBvcGFjaXR5OiAuNzU7IG1hcmdpbi1ib3R0b206IDhweDsgfVxuXHRcdFx0LmJhciB7XG5cdFx0XHRcdGhlaWdodDogNnB4OyBib3JkZXItcmFkaXVzOiAzcHg7IGJhY2tncm91bmQ6IHJnYmEoMjU1LDI1NSwyNTUsLjE0KTtcblx0XHRcdFx0b3ZlcmZsb3c6IGhpZGRlbjsgbWFyZ2luLWJvdHRvbTogMTBweDtcblx0XHRcdH1cblx0XHRcdC5iYXIgPiBpIHsgZGlzcGxheTogYmxvY2s7IGhlaWdodDogMTAwJTsgYmFja2dyb3VuZDogIzhmYmY2YTsgdHJhbnNpdGlvbjogd2lkdGggLjI1czsgfVxuXHRcdFx0LmN1cnJlbnQgeyBmb250LXdlaWdodDogNzAwOyBtYXJnaW4tYm90dG9tOiAycHg7IH1cblx0XHRcdC5kZXRhaWwgeyBmb250LXNpemU6IDEycHg7IG9wYWNpdHk6IC44OyB9XG5cdFx0XHQuZGV0YWlsLmJsb2NrZWQgeyBjb2xvcjogI2YwYzg2MDsgfVxuXHRcdFx0Lm5vdGljZSB7XG5cdFx0XHRcdG1hcmdpbi10b3A6IDEwcHg7IHBhZGRpbmc6IDhweCAxMHB4O1xuXHRcdFx0XHRiYWNrZ3JvdW5kOiByZ2JhKDIyNiwxNzgsNjAsLjE0KTtcblx0XHRcdFx0Ym9yZGVyOiAxcHggc29saWQgcmdiYSgyMjYsMTc4LDYwLC41KTtcblx0XHRcdFx0Ym9yZGVyLXJhZGl1czogNXB4OyBmb250LXNpemU6IDEycHg7XG5cdFx0XHR9XG5cdFx0XHQuYWN0aW9ucyB7IG1hcmdpbi10b3A6IDEycHg7IGRpc3BsYXk6IGZsZXg7IGdhcDogOHB4OyB9XG5cdFx0XHRidXR0b24ge1xuXHRcdFx0XHRmb250OiBpbmhlcml0OyBmb250LXNpemU6IDEycHg7IGZvbnQtd2VpZ2h0OiA3MDA7XG5cdFx0XHRcdHBhZGRpbmc6IDVweCAxMnB4OyBib3JkZXItcmFkaXVzOiA1cHg7IGN1cnNvcjogcG9pbnRlcjtcblx0XHRcdFx0YmFja2dyb3VuZDogcmdiYSgyNTUsMjU1LDI1NSwuMSk7IGNvbG9yOiAjZjRlY2UxO1xuXHRcdFx0XHRib3JkZXI6IDFweCBzb2xpZCByZ2JhKDI1NSwyNTUsMjU1LC4yOCk7XG5cdFx0XHR9XG5cdFx0XHRidXR0b246aG92ZXIgeyBiYWNrZ3JvdW5kOiByZ2JhKDI1NSwyNTUsMjU1LC4xOCk7IH1cblx0XHRcdC5oaWRkZW4geyBkaXNwbGF5OiBub25lOyB9XG5cdFx0PC9zdHlsZT5cblx0XHQ8ZGl2IGNsYXNzPVwicGFuZWxcIj5cblx0XHRcdDxkaXYgY2xhc3M9XCJoZWFkXCI+PHNwYW4gY2xhc3M9XCJkb3RcIj48L3NwYW4+PHNwYW4gY2xhc3M9XCJ0aXRsZVwiPlNjcmFwaW5nIHBhcmtydW48L3NwYW4+PC9kaXY+XG5cdFx0XHQ8ZGl2IGNsYXNzPVwiYm9keVwiPlxuXHRcdFx0XHQ8ZGl2IGNsYXNzPVwiY291bnRcIj48L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzcz1cImJhclwiPjxpIHN0eWxlPVwid2lkdGg6MCVcIj48L2k+PC9kaXY+XG5cdFx0XHRcdDxkaXYgY2xhc3M9XCJjdXJyZW50XCI+PC9kaXY+XG5cdFx0XHRcdDxkaXYgY2xhc3M9XCJkZXRhaWxcIj48L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzcz1cIm5vdGljZSBoaWRkZW5cIj48L2Rpdj5cblx0XHRcdFx0PGRpdiBjbGFzcz1cImFjdGlvbnNcIj5cblx0XHRcdFx0XHQ8YnV0dG9uIGNsYXNzPVwicmV0cnkgaGlkZGVuXCI+UmV0cnk8L2J1dHRvbj5cblx0XHRcdFx0XHQ8YnV0dG9uIGNsYXNzPVwic2tpcCBoaWRkZW5cIj5Ta2lwPC9idXR0b24+XG5cdFx0XHRcdFx0PGJ1dHRvbiBjbGFzcz1cImNhbmNlbFwiPkNhbmNlbDwvYnV0dG9uPlxuXHRcdFx0XHQ8L2Rpdj5cblx0XHRcdDwvZGl2PlxuXHRcdDwvZGl2PlxuXHRgXG5cblx0Zm9yIChjb25zdCBhY3Rpb24gb2YgWydjYW5jZWwnLCAncmV0cnknLCAnc2tpcCddIGFzIGNvbnN0KSB7XG5cdFx0cm9vdC5xdWVyeVNlbGVjdG9yKGAuJHthY3Rpb259YCk/LmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKCkgPT4ge1xuXHRcdFx0Ly8gQWx3YXlzIGhhbmRsZSB0aGUgcmVqZWN0aW9uOiBhbiB1bmFuc3dlcmVkIHNlbmRNZXNzYWdlIG90aGVyd2lzZSBzaG93c1xuXHRcdFx0Ly8gdXAgYXMgXCJVbmNoZWNrZWQgcnVudGltZS5sYXN0RXJyb3JcIiBpbiB0aGUgY29uc29sZS5cblx0XHRcdHZvaWQgY2hyb21lLnJ1bnRpbWUuc2VuZE1lc3NhZ2UoeyB0eXBlOiBhY3Rpb24gfSkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKVxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gcm9vdFxufVxuXG5mdW5jdGlvbiByZW5kZXIoc3RhdGU6IFJ1blN0YXRlKTogdm9pZCB7XG5cdC8vIE5vdGhpbmcgdG8gc2hvdyB1bmxlc3MgYSBydW4gaXMgbGl2ZTsgZG9uJ3QgbGl0dGVyIHBhZ2VzIG90aGVyd2lzZS5cblx0aWYgKHN0YXRlLnN0YXR1cyA9PT0gJ2lkbGUnIHx8IHN0YXRlLml0ZW1zLmxlbmd0aCA9PT0gMCkge1xuXHRcdGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKEhPU1RfSUQpPy5yZW1vdmUoKVxuXHRcdHJvb3QgPSBudWxsXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBzaGFkb3cgPSBlbnN1cmVSb290KClcblx0Y29uc3QgZG9uZSA9IHN0YXRlLml0ZW1zLmZpbHRlcihcblx0XHQoaSkgPT5cblx0XHRcdGkuc3RhdHVzID09PSAnY2FwdHVyZWQnIHx8XG5cdFx0XHRpLnN0YXR1cyA9PT0gJ2ZhaWxlZCcgfHxcblx0XHRcdGkuc3RhdHVzID09PSAnc2tpcHBlZCcsXG5cdCkubGVuZ3RoXG5cdGNvbnN0IGN1cnJlbnQgPSBzdGF0ZS5pdGVtcy5maW5kKChpKSA9PiBpLmtleSA9PT0gc3RhdGUuY3VycmVudEtleSlcblx0Y29uc3QgYmxvY2tlZCA9IGN1cnJlbnQ/LnN0YXR1cyA9PT0gJ2Jsb2NrZWQnXG5cblx0Y29uc3QgZG90ID0gc2hhZG93LnF1ZXJ5U2VsZWN0b3IoJy5kb3QnKSBhcyBIVE1MRWxlbWVudFxuXHRkb3QuY2xhc3NOYW1lID0gYGRvdCR7XG5cdFx0c3RhdGUuc3RhdHVzID09PSAnZXJyb3InXG5cdFx0XHQ/ICcgZXJyb3InXG5cdFx0XHQ6IHN0YXRlLnN0YXR1cyA9PT0gJ2RvbmUnXG5cdFx0XHRcdD8gJyBkb25lJ1xuXHRcdFx0XHQ6IGJsb2NrZWRcblx0XHRcdFx0XHQ/ICcgYmxvY2tlZCdcblx0XHRcdFx0XHQ6ICcnXG5cdH1gXG5cblx0c2V0VGV4dChzaGFkb3csICcudGl0bGUnLCB0aXRsZUZvcihzdGF0ZSwgYmxvY2tlZCkpXG5cdHNldFRleHQoc2hhZG93LCAnLmNvdW50JywgYCR7ZG9uZX0gb2YgJHtzdGF0ZS5pdGVtcy5sZW5ndGh9IHBhZ2VzYClcblx0c2V0VGV4dChzaGFkb3csICcuY3VycmVudCcsIGN1cnJlbnQ/LmxhYmVsID8/ICcnKVxuXHRjb25zdCBkZXRhaWwgPSBzaGFkb3cucXVlcnlTZWxlY3RvcignLmRldGFpbCcpIGFzIEhUTUxFbGVtZW50XG5cdGRldGFpbC50ZXh0Q29udGVudCA9IGN1cnJlbnQ/LmRldGFpbCA/PyAnJ1xuXHRkZXRhaWwuY2xhc3NOYW1lID0gYGRldGFpbCR7YmxvY2tlZCA/ICcgYmxvY2tlZCcgOiAnJ31gXG5cblx0Y29uc3QgYmFyID0gc2hhZG93LnF1ZXJ5U2VsZWN0b3IoJy5iYXIgPiBpJykgYXMgSFRNTEVsZW1lbnRcblx0YmFyLnN0eWxlLndpZHRoID0gYCR7TWF0aC5yb3VuZCgoZG9uZSAvIHN0YXRlLml0ZW1zLmxlbmd0aCkgKiAxMDApfSVgXG5cblx0Y29uc3Qgbm90aWNlID0gc2hhZG93LnF1ZXJ5U2VsZWN0b3IoJy5ub3RpY2UnKSBhcyBIVE1MRWxlbWVudFxuXHRpZiAoYmxvY2tlZCkge1xuXHRcdG5vdGljZS50ZXh0Q29udGVudCA9IGN1cnJlbnQ/LmF3YWl0VXNlclxuXHRcdFx0PyAnU29sdmUgdGhlIGNoZWNrIG9uIHRoaXMgcGFnZSBhbmQgdGhlIHNjcmFwZSBjYXJyaWVzIG9uIGJ5IGl0c2VsZi4gTm90aGluZyB3aWxsIHJlbG9hZCB3aGlsZSB5b3Ugd29yayDigJQgdGFrZSBhcyBsb25nIGFzIHlvdSBuZWVkLidcblx0XHRcdDogJ1dhaXRpbmcgb24gcGFya3J1bi4gUmV0cnlpbmcgYXV0b21hdGljYWxseS4nXG5cdFx0bm90aWNlLmNsYXNzTGlzdC5yZW1vdmUoJ2hpZGRlbicpXG5cdH0gZWxzZSBpZiAoc3RhdGUubWVzc2FnZSAmJiBzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykge1xuXHRcdG5vdGljZS50ZXh0Q29udGVudCA9IHN0YXRlLm1lc3NhZ2Vcblx0XHRub3RpY2UuY2xhc3NMaXN0LnJlbW92ZSgnaGlkZGVuJylcblx0fSBlbHNlIHtcblx0XHRub3RpY2UuY2xhc3NMaXN0LmFkZCgnaGlkZGVuJylcblx0fVxuXG5cdGNvbnN0IHJ1bm5pbmcgPSBzdGF0ZS5zdGF0dXMgPT09ICdydW5uaW5nJ1xuXHR0b2dnbGUoc2hhZG93LCAnLmNhbmNlbCcsICFydW5uaW5nKVxuXHQvLyBPbmx5IG9mZmVyZWQgd2hlbiBzdHVjay4gUmV0cnkgaXMgaGlkZGVuIG1pZC1jYXB0Y2hhIOKAlCByZWxvYWRpbmcgd291bGQgdGhyb3dcblx0Ly8gYXdheSB3aGF0ZXZlciB0aGUgdXNlciBoYXMgYWxyZWFkeSBjbGlja2VkIHRocm91Z2guXG5cdHRvZ2dsZShzaGFkb3csICcucmV0cnknLCAhYmxvY2tlZCB8fCAhIWN1cnJlbnQ/LmF3YWl0VXNlcilcblx0dG9nZ2xlKHNoYWRvdywgJy5za2lwJywgIWJsb2NrZWQpXG59XG5cbmZ1bmN0aW9uIHRpdGxlRm9yKHN0YXRlOiBSdW5TdGF0ZSwgYmxvY2tlZDogYm9vbGVhbik6IHN0cmluZyB7XG5cdGlmIChzdGF0ZS5zdGF0dXMgPT09ICdkb25lJykgcmV0dXJuICdTY3JhcGUgY29tcGxldGUnXG5cdGlmIChzdGF0ZS5zdGF0dXMgPT09ICdjYW5jZWxsZWQnKSByZXR1cm4gJ1NjcmFwZSBjYW5jZWxsZWQnXG5cdGlmIChzdGF0ZS5zdGF0dXMgPT09ICdlcnJvcicpIHJldHVybiAnU2NyYXBlIGZhaWxlZCdcblx0cmV0dXJuIGJsb2NrZWQgPyAnV2FpdGluZyBmb3IgeW91JyA6ICdTY3JhcGluZyBwYXJrcnVuJ1xufVxuXG5mdW5jdGlvbiB0b2dnbGUoc2hhZG93OiBTaGFkb3dSb290LCBzZWxlY3Rvcjogc3RyaW5nLCBoaWRkZW46IGJvb2xlYW4pOiB2b2lkIHtcblx0c2hhZG93LnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpPy5jbGFzc0xpc3QudG9nZ2xlKCdoaWRkZW4nLCBoaWRkZW4pXG59XG5cbmZ1bmN0aW9uIHNldFRleHQoc2hhZG93OiBTaGFkb3dSb290LCBzZWxlY3Rvcjogc3RyaW5nLCB0ZXh0OiBzdHJpbmcpOiB2b2lkIHtcblx0Y29uc3Qgbm9kZSA9IHNoYWRvdy5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKVxuXHRpZiAobm9kZSkgbm9kZS50ZXh0Q29udGVudCA9IHRleHRcbn1cblxuLy8gLS0tIFdpcmluZyAtLS1cblxuY2hyb21lLnJ1bnRpbWUub25NZXNzYWdlLmFkZExpc3RlbmVyKChtZXNzYWdlKSA9PiB7XG5cdGNvbnN0IHR5cGVkID0gbWVzc2FnZSBhcyBFeHRlbnNpb25NZXNzYWdlXG5cdGlmICh0eXBlZC50eXBlID09PSAnc3RhdGUnIHx8IHR5cGVkLnR5cGUgPT09ICdmaW5pc2hlZCcpIHJlbmRlcih0eXBlZC5zdGF0ZSlcblx0cmV0dXJuIHVuZGVmaW5lZFxufSlcblxuLy8gQSBmcmVzaCBuYXZpZ2F0aW9uIG1lYW5zIGEgZnJlc2ggY29udGVudCBzY3JpcHQsIHNvIGFzayBmb3IgY3VycmVudCBzdGF0ZS5cbnZvaWQgKGFzeW5jICgpID0+IHtcblx0dHJ5IHtcblx0XHRjb25zdCByZXBseSA9IGF3YWl0IGNocm9tZS5ydW50aW1lLnNlbmRNZXNzYWdlPFxuXHRcdFx0eyB0eXBlOiBzdHJpbmcgfSxcblx0XHRcdEV4dGVuc2lvbk1lc3NhZ2Vcblx0XHQ+KHsgdHlwZTogJ3N0YXRlPycgfSlcblx0XHRpZiAocmVwbHk/LnR5cGUgPT09ICdzdGF0ZScpIHJlbmRlcihyZXBseS5zdGF0ZSlcblx0fSBjYXRjaCB7XG5cdFx0Ly8gRXh0ZW5zaW9uIHJlbG9hZGluZyDigJQgbm90aGluZyB0byBkcmF3LlxuXHR9XG59KSgpXG4iXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFXQSxRQUFNLFVBQVU7QUFFaEIsTUFBSSxPQUEwQjtBQUU5QixXQUFTLGFBQXlCO0FBQ2pDLFFBQUksS0FBTSxRQUFPO0FBRWpCLFVBQU0sT0FBTyxTQUFTLGNBQWMsS0FBSztBQUN6QyxTQUFLLEtBQUs7QUFDVixTQUFLLE1BQU0sVUFDVjtBQUNELGFBQVMsZ0JBQWdCLFlBQVksSUFBSTtBQUV6QyxXQUFPLEtBQUssYUFBYSxFQUFFLE1BQU0sUUFBUTtBQUN6QyxTQUFLLFlBQVk7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXFFakIsZUFBVyxVQUFVLENBQUMsVUFBVSxTQUFTLE1BQU0sR0FBWTtBQUMxRCxXQUFLLGNBQWMsSUFBSSxNQUFNLEVBQUUsR0FBRyxpQkFBaUIsU0FBUyxNQUFNO0FBR2pFLGFBQUssT0FBTyxRQUFRLFlBQVksRUFBRSxNQUFNLFFBQVEsRUFBRSxNQUFNLE1BQU0sTUFBUztBQUFBLE1BQ3hFLENBQUM7QUFBQSxJQUNGO0FBRUEsV0FBTztBQUFBLEVBQ1I7QUFFQSxXQUFTLE9BQU8sT0FBdUI7QUFFdEMsUUFBSSxNQUFNLFdBQVcsVUFBVSxNQUFNLE1BQU0sV0FBVyxHQUFHO0FBQ3hELGVBQVMsZUFBZSxPQUFPLEdBQUcsT0FBQTtBQUNsQyxhQUFPO0FBQ1A7QUFBQSxJQUNEO0FBRUEsVUFBTSxTQUFTLFdBQUE7QUFDZixVQUFNLE9BQU8sTUFBTSxNQUFNO0FBQUEsTUFDeEIsQ0FBQyxNQUNBLEVBQUUsV0FBVyxjQUNiLEVBQUUsV0FBVyxZQUNiLEVBQUUsV0FBVztBQUFBLElBQUEsRUFDYjtBQUNGLFVBQU0sVUFBVSxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUNsRSxVQUFNLFVBQVUsU0FBUyxXQUFXO0FBRXBDLFVBQU0sTUFBTSxPQUFPLGNBQWMsTUFBTTtBQUN2QyxRQUFJLFlBQVksTUFDZixNQUFNLFdBQVcsVUFDZCxXQUNBLE1BQU0sV0FBVyxTQUNoQixVQUNBLFVBQ0MsYUFDQSxFQUNOO0FBRUEsWUFBUSxRQUFRLFVBQVUsU0FBUyxPQUFPLE9BQU8sQ0FBQztBQUNsRCxZQUFRLFFBQVEsVUFBVSxHQUFHLElBQUksT0FBTyxNQUFNLE1BQU0sTUFBTSxRQUFRO0FBQ2xFLFlBQVEsUUFBUSxZQUFZLFNBQVMsU0FBUyxFQUFFO0FBQ2hELFVBQU0sU0FBUyxPQUFPLGNBQWMsU0FBUztBQUM3QyxXQUFPLGNBQWMsU0FBUyxVQUFVO0FBQ3hDLFdBQU8sWUFBWSxTQUFTLFVBQVUsYUFBYSxFQUFFO0FBRXJELFVBQU0sTUFBTSxPQUFPLGNBQWMsVUFBVTtBQUMzQyxRQUFJLE1BQU0sUUFBUSxHQUFHLEtBQUssTUFBTyxPQUFPLE1BQU0sTUFBTSxTQUFVLEdBQUcsQ0FBQztBQUVsRSxVQUFNLFNBQVMsT0FBTyxjQUFjLFNBQVM7QUFDN0MsUUFBSSxTQUFTO0FBQ1osYUFBTyxjQUFjLFNBQVMsWUFDM0IscUlBQ0E7QUFDSCxhQUFPLFVBQVUsT0FBTyxRQUFRO0FBQUEsSUFDakMsV0FBVyxNQUFNLFdBQVcsTUFBTSxXQUFXLFdBQVc7QUFDdkQsYUFBTyxjQUFjLE1BQU07QUFDM0IsYUFBTyxVQUFVLE9BQU8sUUFBUTtBQUFBLElBQ2pDLE9BQU87QUFDTixhQUFPLFVBQVUsSUFBSSxRQUFRO0FBQUEsSUFDOUI7QUFFQSxVQUFNLFVBQVUsTUFBTSxXQUFXO0FBQ2pDLFdBQU8sUUFBUSxXQUFXLENBQUMsT0FBTztBQUdsQyxXQUFPLFFBQVEsVUFBVSxDQUFDLFdBQVcsQ0FBQyxDQUFDLFNBQVMsU0FBUztBQUN6RCxXQUFPLFFBQVEsU0FBUyxDQUFDLE9BQU87QUFBQSxFQUNqQztBQUVBLFdBQVMsU0FBUyxPQUFpQixTQUEwQjtBQUM1RCxRQUFJLE1BQU0sV0FBVyxPQUFRLFFBQU87QUFDcEMsUUFBSSxNQUFNLFdBQVcsWUFBYSxRQUFPO0FBQ3pDLFFBQUksTUFBTSxXQUFXLFFBQVMsUUFBTztBQUNyQyxXQUFPLFVBQVUsb0JBQW9CO0FBQUEsRUFDdEM7QUFFQSxXQUFTLE9BQU8sUUFBb0IsVUFBa0IsUUFBdUI7QUFDNUUsV0FBTyxjQUFjLFFBQVEsR0FBRyxVQUFVLE9BQU8sVUFBVSxNQUFNO0FBQUEsRUFDbEU7QUFFQSxXQUFTLFFBQVEsUUFBb0IsVUFBa0IsTUFBb0I7QUFDMUUsVUFBTSxPQUFPLE9BQU8sY0FBYyxRQUFRO0FBQzFDLFFBQUksV0FBVyxjQUFjO0FBQUEsRUFDOUI7QUFJQSxTQUFPLFFBQVEsVUFBVSxZQUFZLENBQUMsWUFBWTtBQUNqRCxVQUFNLFFBQVE7QUFDZCxRQUFJLE1BQU0sU0FBUyxXQUFXLE1BQU0sU0FBUyxXQUFZLFFBQU8sTUFBTSxLQUFLO0FBQzNFLFdBQU87QUFBQSxFQUNSLENBQUM7QUFHRCxRQUFNLFlBQVk7QUFDakIsUUFBSTtBQUNILFlBQU0sUUFBUSxNQUFNLE9BQU8sUUFBUSxZQUdqQyxFQUFFLE1BQU0sVUFBVTtBQUNwQixVQUFJLE9BQU8sU0FBUyxRQUFTLFFBQU8sTUFBTSxLQUFLO0FBQUEsSUFDaEQsUUFBUTtBQUFBLElBRVI7QUFBQSxFQUNELEdBQUE7OyJ9
