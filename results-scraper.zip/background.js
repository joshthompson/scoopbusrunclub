const SCRAPER_PROTOCOL_VERSION = 2;
function readPastEventKey(key) {
  const match = key.match(/^([^#]+)#(\d+)$/);
  if (!match) return null;
  return { eventId: match[1], eventNumber: Number.parseInt(match[2], 10) };
}
function emptyRunState() {
  return { status: "idle", items: [] };
}
const DEBUGGER_VERSION = "1.3";
const DOC_KEY = "lastDocument";
async function attach(tabId) {
  try {
    await chrome.debugger.attach({ tabId }, DEBUGGER_VERSION);
  } catch (error) {
    if (!/already attached/i.test(describeError(error))) throw error;
  }
  await chrome.debugger.sendCommand({ tabId }, "Network.enable");
}
async function detach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}
async function ensureAttached(tabId) {
  try {
    await attach(tabId);
  } catch (error) {
    throw new Error(
      `Couldn't attach the debugger to the scrape tab: ${describeError(error)}. If DevTools is open on it, close them and press Scrape again.`
    );
  }
}
async function noteDocumentResponse(tabId, params) {
  if (params.type !== "Document") return;
  const response = params.response;
  const requestId = params.requestId;
  if (!requestId || !response?.url) return;
  if (params.loaderId && params.loaderId !== requestId) return;
  await setLastDocument(tabId, {
    requestId,
    url: response.url,
    status: response.status ?? 0,
    finished: false
  });
}
async function noteLoadingFinished(tabId, params) {
  const last = await getLastDocument(tabId);
  if (!last || last.requestId !== params.requestId) return null;
  const finished = { ...last, finished: true };
  await setLastDocument(tabId, finished);
  return finished;
}
function isBodyNotReady(error) {
  return /no resource with given identifier|no data found/i.test(
    describeError(error)
  );
}
async function getLastDocument(tabId) {
  const stored = await chrome.storage.local.get(`${DOC_KEY}:${tabId}`);
  return stored[`${DOC_KEY}:${tabId}`] ?? null;
}
async function setLastDocument(tabId, value) {
  await chrome.storage.local.set({ [`${DOC_KEY}:${tabId}`]: value });
}
async function markDocumentConsumed(tabId, document) {
  await setLastDocument(tabId, { ...document, consumed: true });
}
async function clearLastDocument(tabId) {
  await chrome.storage.local.remove(`${DOC_KEY}:${tabId}`);
}
async function readBody(tabId, document) {
  const result = await chrome.debugger.sendCommand({ tabId }, "Network.getResponseBody", { requestId: document.requestId });
  return {
    url: document.url,
    status: document.status,
    body: result.base64Encoded ? decodeBase64(result.body) : result.body,
    base64Encoded: result.base64Encoded
  };
}
function decodeBase64(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}
function describeError(error) {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return JSON.stringify(error);
}
const ORIGIN_KEY = "lastAdminOrigin";
const PAGE_PATH = "/admin/process-results";
function isFromAdminPage(message) {
  return typeof message === "object" && message !== null && message.fromAdminPage === true;
}
const FALLBACK_ORIGINS = ["https://scoopbus.run", "http://localhost:3005"];
async function rememberAdminOrigin(senderUrl) {
  if (!senderUrl) return;
  try {
    const { origin } = new URL(senderUrl);
    await chrome.storage.local.set({ [ORIGIN_KEY]: origin });
  } catch {
  }
}
async function knownAdminOrigin() {
  const stored = await chrome.storage.local.get(
    ORIGIN_KEY
  );
  return stored.lastAdminOrigin ?? null;
}
async function openAdminPage() {
  const origins = [await knownAdminOrigin(), ...FALLBACK_ORIGINS].filter(
    (origin2) => !!origin2
  );
  for (const origin2 of origins) {
    const existing = await chrome.tabs.query({ url: `${origin2}${PAGE_PATH}*` }).catch(() => []);
    const tab = existing.find((candidate) => candidate.id !== void 0);
    if (tab?.id !== void 0) {
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId !== void 0) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }
      return;
    }
  }
  const origin = origins[0];
  await chrome.tabs.create({ url: `${origin}${PAGE_PATH}`, active: true });
}
const NAMIBIA_EVENTS = /* @__PURE__ */ new Set(["walvisbay", "windhoek", "swakopmund"]);
const DOMAIN_TO_COUNTRY = {
  "parkrun.com.au": "AU",
  "parkrun.co.at": "AT",
  "parkrun.ca": "CA",
  "parkrun.dk": "DK",
  "parkrun.fi": "FI",
  "parkrun.com.de": "DE",
  "parkrun.ie": "IE",
  "parkrun.it": "IT",
  "parkrun.jp": "JP",
  "parkrun.lt": "LT",
  "parkrun.my": "MY",
  "parkrun.co.nl": "NL",
  "parkrun.co.nz": "NZ",
  "parkrun.no": "NO",
  "parkrun.pl": "PL",
  "parkrun.sg": "SG",
  "parkrun.co.za": "ZA",
  "parkrun.se": "SE",
  "parkrun.org.uk": "UK",
  "parkrun.us": "US"
};
function getCountryFromUrl(url, eventId) {
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, "");
    if (hostname === "parkrun.co.za" && NAMIBIA_EVENTS.has(eventId)) {
      return "NA";
    }
    return DOMAIN_TO_COUNTRY[hostname] ?? "??";
  } catch {
    return "??";
  }
}
function extractEvents(runResults) {
  const seen = /* @__PURE__ */ new Map();
  for (const result of runResults) {
    if (!result.eventUrl || !result.event) continue;
    if (seen.has(result.event)) continue;
    const urlMatch = result.eventUrl.match(
      /^(https?:\/\/[^/]+\/[^/]+)\/results\/?\d*\/?$/
    );
    if (!urlMatch) continue;
    const baseUrl = `${urlMatch[1]}/`;
    seen.set(result.event, {
      eventId: result.event,
      name: result.eventName,
      url: baseUrl,
      country: getCountryFromUrl(result.eventUrl, result.event)
    });
  }
  return Array.from(seen.values());
}
function stripTags(html) {
  return html.replace(/<[^>]*>/g, "").trim();
}
const ENTITIES = {
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&quot;": '"',
  "&#039;": "'",
  "&apos;": "'",
  "&nbsp;": " "
};
function decodeEntities(text) {
  return text.replace(/&(?:amp|lt|gt|quot|#039|apos|nbsp);/g, (m) => ENTITIES[m] ?? m).replace(
    /&#(\d+);/g,
    (_, code) => String.fromCodePoint(Number.parseInt(code, 10))
  ).replace(/\u00a0/g, " ");
}
function parseRunnerData(html) {
  const heading = html.match(/<h2>([\s\S]*?)<\/h2>/)?.[1] ?? "";
  const idMatch = heading.match(/\(\s*A?(\d+)\s*\)/);
  const headingName = decodeEntities(stripTags(heading)).replace(/\(\s*A?\d+\s*\)/, "").trim();
  const name = idMatch && headingName ? headingName : "Unknown";
  const totalMatch = html.match(
    /<h3>\s*(\d+)\s*parkruns?\s*(?:&amp;|&)?\s*(?:(\d+)\s*junior\s*parkruns?\s*)?total/i
  );
  const totalRuns = totalMatch ? Number.parseInt(totalMatch[1], 10) : 0;
  const totalJuniorRuns = totalMatch?.[2] ? Number.parseInt(totalMatch[2], 10) : 0;
  return {
    name,
    parkrunId: idMatch ? idMatch[1] : "",
    totalRuns,
    totalJuniorRuns
  };
}
function findResultTbodies(html) {
  const candidates = [];
  const captionMatch = html.match(
    /All\s+Results\s*<\/caption>[\s\S]*?<tbody[^>]*>([\s\S]*?)<\/tbody>/i
  );
  if (captionMatch) candidates.push(captionMatch[1]);
  const tables = [
    ...html.matchAll(/<table[^>]*id="results"[^>]*>([\s\S]*?)<\/table>/gi)
  ];
  for (const table of tables.reverse()) {
    const tbody = table[1].match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i);
    candidates.push(tbody ? tbody[1] : table[1]);
  }
  return candidates;
}
function parseRunResults(html) {
  for (const tbody of findResultTbodies(html)) {
    const results = parseResultRows(tbody);
    if (results.length > 0) return results;
  }
  return [];
}
function parseResultRows(tbody) {
  const results = [];
  const rowRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  for (const rowMatch of tbody.matchAll(rowRegex)) {
    const row = rowMatch[1];
    const cellRegex = /<td[^>]*>([\s\S]*?)<\/td>/gi;
    const cells = [];
    for (const cellMatch of row.matchAll(cellRegex)) {
      cells.push(cellMatch[1]);
    }
    if (cells.length < 6) continue;
    const eventLinkMatch = cells[0].match(
      /<a\s+href="([^"]+)"[^>]*>([^<]+)<\/a>/
    );
    const eventUrl = eventLinkMatch ? eventLinkMatch[1].trim() : "";
    const eventName = eventLinkMatch ? decodeEntities(eventLinkMatch[2]).trim() : decodeEntities(stripTags(cells[0]));
    if (!/\/results\//.test(eventUrl)) continue;
    const eventIdMatch = eventUrl.match(/\/([^/]+)\/results\//);
    const event = eventIdMatch ? eventIdMatch[1] : eventName.toLowerCase().replace(/[^a-z0-9]/g, "");
    const date = parseResultDate(cells[1]);
    const eventNumber = Number.parseInt(stripTags(cells[2]), 10) || 0;
    const position = Number.parseInt(stripTags(cells[3]), 10) || 0;
    const time = stripTags(cells[4]);
    const ageGrade = stripTags(cells[5]);
    if (eventName && time) {
      results.push({
        event,
        eventName,
        eventUrl,
        eventNumber,
        position,
        time,
        ageGrade,
        date
      });
    }
  }
  return results;
}
function parseResultDate(cell) {
  const dmy = cell.match(/>(\d{2})\/(\d{2})\/(\d{4})</);
  if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`;
  const iso = cell.match(/>(\d{4}-\d{2}-\d{2})</);
  if (iso) return iso[1];
  return stripTags(cell);
}
function parseLargestClubs(html) {
  const entries = [];
  const tableMatch = html.match(
    /<table[^>]*id="results"[^>]*>[\s\S]*?<tbody[^>]*>([\s\S]*?)<\/tbody>/i
  );
  if (!tableMatch) return entries;
  const tbody = tableMatch[1];
  for (const rowMatch of tbody.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = [];
    for (const cellMatch of rowMatch[1].matchAll(
      /<td[^>]*>([\s\S]*?)<\/td>/gi
    )) {
      cells.push(cellMatch[1]);
    }
    if (cells.length < 4) continue;
    const name = decodeEntities(stripTags(cells[0]));
    if (!name) continue;
    const clubIdMatch = cells[0].match(/#featureClub=(\d+)/);
    const members = Number.parseInt(stripTags(cells[2]), 10);
    const events = Number.parseInt(stripTags(cells[3]), 10);
    if (Number.isNaN(members) || Number.isNaN(events)) continue;
    entries.push({
      clubId: clubIdMatch ? clubIdMatch[1] : void 0,
      name,
      members,
      events
    });
  }
  return entries;
}
function parseEventDate(html) {
  const match = html.match(
    /<span\s+class="format-date">(\d{4}-\d{2}-\d{2})<\/span>/
  );
  return match ? match[1] : "";
}
function parseEventPageMeta(html) {
  const title = decodeEntities(
    stripTags(html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/)?.[1] ?? "")
  );
  const eventId = html.match(/href="\/([^/"]+)\/parkrunner\//)?.[1] ?? "";
  const numberMatch = html.match(/<span>\s*#(\d+)\s*<\/span>/);
  return {
    eventId,
    title,
    eventNumber: numberMatch ? Number.parseInt(numberMatch[1], 10) : 0,
    date: parseEventDate(html)
  };
}
function coursePageUrl(eventBaseUrl) {
  return `${trimSlash(eventBaseUrl)}/course/`;
}
function courseKmzUrl(mid) {
  return `https://www.google.com/maps/d/kml?mid=${mid}`;
}
function trimSlash(url) {
  return url.replace(/\/$/, "");
}
Object.keys(DOMAIN_TO_COUNTRY).flatMap(
  (domain) => [`*://${domain}/*`, `*://*.${domain}/*`]
);
const PING_INTERVAL_MS = 2e4;
let timer = null;
function startKeepalive() {
  if (timer) return;
  timer = setInterval(() => {
    void chrome.runtime.getPlatformInfo().catch(() => void 0);
  }, PING_INTERVAL_MS);
}
function stopKeepalive() {
  if (!timer) return;
  clearInterval(timer);
  timer = null;
}
const RUN_KEY = "run";
const SESSION_KEY = "session";
const FILE_INDEX_KEY = "fileKeys";
const LEGACY_FILES_KEY = "files";
function emptySession() {
  return {
    knownCourseEventIds: [],
    discoveredEvents: {},
    coursesQueued: false,
    skipCourses: false,
    attempts: 0
  };
}
async function getRunState() {
  const stored = await chrome.storage.local.get(RUN_KEY);
  return stored.run ?? emptyRunState();
}
async function setRunState(state) {
  await chrome.storage.local.set({ [RUN_KEY]: state });
}
async function updateRunState(change) {
  const next = change(await getRunState());
  await setRunState(next);
  return next;
}
async function setItemStatus(key, status, detail, attempts) {
  return updateRunState((state) => ({
    ...state,
    items: state.items.map(
      (item) => item.key === key ? {
        ...item,
        status,
        detail,
        attempts: attempts ?? item.attempts,
        updatedAt: Date.now()
      } : item
    )
  }));
}
async function appendItems(items) {
  return updateRunState((state) => ({
    ...state,
    items: [...state.items, ...items]
  }));
}
async function getSession() {
  const stored = await chrome.storage.local.get(
    SESSION_KEY
  );
  return stored.session ?? emptySession();
}
async function setSession(session) {
  await chrome.storage.local.set({ [SESSION_KEY]: session });
}
async function updateSession(change) {
  const next = change(await getSession());
  await setSession(next);
  return next;
}
function fileStorageKey(file) {
  return `file:${file.kind}:${file.key}`;
}
async function getFileIndex() {
  const stored = await chrome.storage.local.get(
    FILE_INDEX_KEY
  );
  return stored.fileKeys ?? [];
}
async function getFiles() {
  const index = await getFileIndex();
  if (index.length === 0) return [];
  const stored = await chrome.storage.local.get(
    index
  );
  return index.flatMap((key) => stored[key] ?? []);
}
async function putFile(file) {
  const storageKey = fileStorageKey(file);
  await chrome.storage.local.set({ [storageKey]: file });
  const index = await getFileIndex();
  if (!index.includes(storageKey)) {
    await chrome.storage.local.set({ [FILE_INDEX_KEY]: [...index, storageKey] });
  }
}
async function resetAll() {
  await chrome.storage.local.remove([
    RUN_KEY,
    SESSION_KEY,
    FILE_INDEX_KEY,
    LEGACY_FILES_KEY,
    ...await getFileIndex()
  ]);
}
async function notifyState(state) {
  const session = await getSession();
  const message = { type: "state", state };
  for (const tabId of [session.adminTabId, session.scrapeTabId]) {
    if (tabId === void 0) continue;
    await chrome.tabs.sendMessage(tabId, message).catch(() => {
    });
  }
}
async function notifyFile(file) {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  await chrome.tabs.sendMessage(adminTabId, { type: "file", file }).catch(() => {
  });
}
const CHALLENGE_MARKERS = [
  "/cdn-cgi/challenge-platform",
  "confirm you are human",
  "verify you are human",
  "are you a robot",
  "captcha",
  "turnstile",
  "cf_chl",
  "cf-challenge",
  "checking your browser",
  "just a moment"
];
function looksLikeChallenge(html) {
  const haystack = html.slice(0, 2e5).toLowerCase();
  return CHALLENGE_MARKERS.some((marker) => haystack.includes(marker));
}
function validate(kind, key, status, html) {
  if (status >= 400) {
    const challenge = looksLikeChallenge(html);
    return {
      outcome: "blocked",
      awaitUser: challenge,
      detail: challenge ? `parkrun replied ${status} and is asking you to prove you're human — solve it in the scrape tab and the run carries on.` : `parkrun replied ${status} — retrying.`
    };
  }
  if (looksLikeChallenge(html) && !parsesAsRealPage(kind, key, html)) {
    return {
      outcome: "blocked",
      awaitUser: true,
      detail: "parkrun is asking you to prove you're human — solve it in the scrape tab and the run carries on."
    };
  }
  switch (kind) {
    case "athlete":
      return validateAthlete(key, html);
    case "event":
      return validateEvent(key, html);
    case "pastEvent":
      return validatePastEvent(key, html);
    case "clubs":
      return validateClubs(html);
    case "course":
      return validateCourse(html);
  }
}
function parsesAsRealPage(kind, key, html) {
  switch (kind) {
    case "athlete":
      return parseRunResults(html).length > 0;
    case "event":
    case "pastEvent":
      return parseEventPageMeta(html).eventNumber > 0;
    case "clubs":
      return parseLargestClubs(html).length > 0;
    case "course":
      return extractMapMid(html) !== null;
  }
}
function validateAthlete(parkrunId, html) {
  const runner = parseRunnerData(html);
  const results = parseRunResults(html);
  if (runner.name === "Unknown" && results.length === 0) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the page — it may be a bot check. Retrying."
    };
  }
  if (runner.parkrunId && runner.parkrunId !== parkrunId) {
    return {
      outcome: "unusable",
      detail: `Page is for athlete ${runner.parkrunId}, expected ${parkrunId}.`
    };
  }
  if (results.length === 0) {
    return { outcome: "unusable", detail: "No run results found on the page." };
  }
  return {
    outcome: "ok",
    detail: `${runner.name} · ${results.length} results`
  };
}
function validateEvent(eventId, html) {
  const meta = parseEventPageMeta(html);
  if (!meta.eventNumber || !meta.date) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the event number or date — it may be a bot check."
    };
  }
  if (meta.eventId && meta.eventId !== eventId) {
    return {
      outcome: "unusable",
      detail: `Page is for "${meta.eventId}", expected "${eventId}".`
    };
  }
  return { outcome: "ok", detail: `#${meta.eventNumber} · ${meta.date}` };
}
function validatePastEvent(key, html) {
  const expected = readPastEventKey(key);
  if (!expected) {
    return { outcome: "unusable", detail: `Bad work item key "${key}".` };
  }
  const verdict = validateEvent(expected.eventId, html);
  if (verdict.outcome !== "ok") return verdict;
  const { eventNumber } = parseEventPageMeta(html);
  if (eventNumber !== expected.eventNumber) {
    return {
      outcome: "unusable",
      detail: `Page is event #${eventNumber}, expected #${expected.eventNumber}.`
    };
  }
  return verdict;
}
function validateClubs(html) {
  const clubs = parseLargestClubs(html);
  if (clubs.length === 0) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the league table — it may be a bot check."
    };
  }
  return { outcome: "ok", detail: `${clubs.length} clubs` };
}
function extractMapMid(html) {
  const match = html.match(
    /src="https:\/\/www\.google\.com\/maps\/d\/[^"]*?[?&]mid=([^&"]+)/
  );
  return match ? match[1] : null;
}
function validateCourse(html) {
  if (extractMapMid(html)) {
    return { outcome: "ok", detail: "Found the embedded map" };
  }
  const looksLikeParkrun = /parkrun/i.test(html) && html.length > 2e4;
  return looksLikeParkrun ? {
    outcome: "unusable",
    detail: "No Google map embedded on this course page."
  } : {
    outcome: "blocked",
    detail: "Couldn't read the course page — it may be a bot check."
  };
}
const MAX_ATTEMPTS = 8;
const STALL_TIMEOUT_MS = 2e4;
const WATCHDOG_ALARM = "watchdog";
const WATCHDOG_PERIOD_MINUTES = 0.5;
function log(...args) {
  console.log("[results-scraper]", ...args);
}
const RETRY_ALARM = "retry-blocked";
const RETRY_DELAY_MINUTES = 1;
async function scheduleRetry() {
  await chrome.alarms.create(RETRY_ALARM, { delayInMinutes: RETRY_DELAY_MINUTES }).catch(() => {
  });
}
async function cancelScheduledRetry() {
  await chrome.alarms.clear(RETRY_ALARM).catch(() => {
  });
}
async function retryCurrent() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return state;
  const item = state.items.find((i) => i.key === state.currentKey);
  const session = await getSession();
  if (!item || session.scrapeTabId === void 0) return state;
  await cancelScheduledRetry();
  await clearLastDocument(session.scrapeTabId);
  try {
    await ensureAttached(session.scrapeTabId);
    await chrome.tabs.update(session.scrapeTabId, { url: item.url });
  } catch (error) {
    return failRun(describeError(error));
  }
  return state;
}
async function skipCurrent() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return state;
  await cancelScheduledRetry();
  await setItemStatus(state.currentKey, "skipped", "Skipped.");
  await notifyState(await getRunState());
  return advance();
}
async function recoverMissedCapture(tabId) {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "active") return;
  const document = await getLastDocument(tabId);
  if (document && !document.consumed) return;
  const attempts = (item.attempts ?? 0) + 1;
  if (attempts > MAX_ATTEMPTS) {
    await setItemStatus(
      item.key,
      "failed",
      `Page loaded but its response was never captured, after ${attempts} attempts.`,
      attempts
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  log(
    `${item.label}: loaded but no response captured — reloading (attempt ${attempts})`
  );
  await setItemStatus(
    item.key,
    "active",
    "Page loaded but the capture was missed — reloading.",
    attempts
  );
  await notifyState(await getRunState());
  await retryCurrent();
}
async function retryIfStillBlocked() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "blocked") return;
  if (item.awaitUser) {
    log(`${item.label}: still waiting for the user; not reloading`);
    return;
  }
  const session = await getSession();
  if (session.attempts >= MAX_ATTEMPTS) {
    await setItemStatus(
      item.key,
      "failed",
      `${item.detail ?? "Blocked."} Gave up after ${session.attempts} attempts.`
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  await retryCurrent();
}
async function startRun(request, adminTabId) {
  await resetAll();
  const items = request.items.map((item) => ({
    ...item,
    status: "pending"
  }));
  if (items.length === 0) {
    const state2 = {
      status: "error",
      items: [],
      message: "Nothing to scrape."
    };
    await setRunState(state2);
    return state2;
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open a scrape tab");
  await setSession({
    adminTabId,
    scrapeTabId: tab.id,
    knownCourseEventIds: request.knownCourseEventIds,
    discoveredEvents: {},
    coursesQueued: false,
    skipCourses: request.skipCourses ?? false,
    attempts: 0,
    pauseMs: request.pauseMs
  });
  const state = {
    status: "running",
    items,
    startedAt: Date.now()
  };
  await setRunState(state);
  try {
    await ensureAttached(tab.id);
  } catch (error) {
    return failRun(describeError(error));
  }
  await setBadge("…");
  startKeepalive();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MINUTES }).catch(() => {
  });
  log(`run started: ${items.length} items, scrape tab ${tab.id}`);
  return advance();
}
async function checkForStall() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "active") return;
  const age = Date.now() - (item.updatedAt ?? 0);
  if (age < STALL_TIMEOUT_MS) return;
  const attempts = (item.attempts ?? 0) + 1;
  if (attempts > MAX_ATTEMPTS) {
    log(`giving up on ${item.label} after ${attempts} attempts`);
    await setItemStatus(
      item.key,
      "failed",
      `No response after ${attempts} attempts — page never finished loading.`,
      attempts
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  log(
    `${item.label} stalled for ${Math.round(age / 1e3)}s — reloading (attempt ${attempts})`
  );
  await setItemStatus(
    item.key,
    "active",
    `No response after ${Math.round(age / 1e3)}s — reloading (attempt ${attempts}).`,
    attempts
  );
  await notifyState(await getRunState());
  await retryCurrent();
}
async function forgetRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const session = await getSession();
  if (session.scrapeTabId !== void 0) {
    await detach(session.scrapeTabId);
    await clearLastDocument(session.scrapeTabId);
  }
  await resetAll();
  await setBadge("");
  log("run cleared");
}
async function resumeRun(adminTabId) {
  const previous = await getRunState();
  if (previous.items.length === 0) {
    return failRun("There is no run to resume.");
  }
  const items = previous.items.map(
    (item) => item.status === "captured" || item.status === "skipped" ? item : {
      ...item,
      status: "pending",
      detail: void 0,
      attempts: 0,
      awaitUser: void 0,
      updatedAt: Date.now()
    }
  );
  const outstanding = items.filter((item) => item.status === "pending").length;
  if (outstanding === 0) {
    return failRun("Every page in that run is already captured or skipped.");
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open a scrape tab");
  await updateSession((session) => ({
    ...session,
    adminTabId,
    scrapeTabId: tab.id,
    attempts: 0
  }));
  await setRunState({
    ...previous,
    status: "running",
    currentKey: void 0,
    items,
    message: void 0,
    finishedAt: void 0
  });
  try {
    await ensureAttached(tab.id);
  } catch (error) {
    return failRun(describeError(error));
  }
  await setBadge("…");
  startKeepalive();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MINUTES }).catch(() => {
  });
  log(`resuming: ${outstanding} of ${items.length} pages still needed`);
  return advance();
}
async function cancelRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const state = await getRunState();
  const cancelled = {
    ...state,
    status: "cancelled",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: "Cancelled."
  };
  await setRunState(cancelled);
  await closeScrapeTab();
  await setBadge("");
  await focusAdminTab();
  await notifyState(cancelled);
  return cancelled;
}
async function failRun(message) {
  stopKeepalive();
  const state = await getRunState();
  const failed = {
    ...state,
    status: "error",
    currentKey: void 0,
    finishedAt: Date.now(),
    message
  };
  await setRunState(failed);
  await setBadge("!");
  await notifyState(failed);
  return failed;
}
async function advance() {
  await pauseBetweenPages();
  const state = await getRunState();
  if (state.status !== "running") return state;
  const next = state.items.find((item) => item.status === "pending");
  if (!next) {
    const queued = await queueNewCourses();
    if (queued) return advance();
    return finishRun();
  }
  const session = await getSession();
  if (session.scrapeTabId === void 0) {
    return failRun("The scrape tab is gone.");
  }
  await cancelScheduledRetry();
  await updateSession((s) => ({ ...s, attempts: 0 }));
  await clearLastDocument(session.scrapeTabId);
  const running = {
    ...state,
    currentKey: next.key,
    items: state.items.map(
      (item) => item.key === next.key ? {
        ...item,
        status: "active",
        detail: "Loading…",
        attempts: 0,
        updatedAt: Date.now()
      } : item
    ),
    message: void 0
  };
  await setRunState(running);
  await notifyState(running);
  log(`→ ${next.label}: ${next.url}`);
  try {
    await ensureAttached(session.scrapeTabId);
    await chrome.tabs.update(session.scrapeTabId, { url: next.url });
  } catch (error) {
    return failRun(describeError(error));
  }
  return running;
}
async function pauseBetweenPages() {
  const { pauseMs } = await getSession();
  if (!pauseMs) return;
  const state = await getRunState();
  if (state.status !== "running") return;
  const started = state.items.some((item) => item.status !== "pending");
  const remaining = state.items.some((item) => item.status === "pending");
  if (!started || !remaining) return;
  const wait = Math.round(pauseMs * (0.5 + Math.random()));
  await new Promise((resolve) => setTimeout(resolve, wait));
}
async function handleDocumentLoaded(tabId) {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const session = await getSession();
  if (session.scrapeTabId !== tabId) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (!item) return;
  const document = await getLastDocument(tabId);
  if (!document || document.consumed) return;
  let captured;
  try {
    captured = await readBody(tabId, document);
  } catch (error) {
    if (isBodyNotReady(error)) return;
    const attempts2 = (await updateSession((s) => ({ ...s, attempts: s.attempts + 1 }))).attempts;
    log(`${item.label}: could not read body — ${describeError(error)}`);
    if (attempts2 >= MAX_ATTEMPTS) {
      await setItemStatus(item.key, "failed", describeError(error), attempts2);
      await notifyState(await getRunState());
      await advance();
    }
    return;
  }
  const attempts = (await updateSession((s) => ({ ...s, attempts: s.attempts + 1 }))).attempts;
  const verdict = validate(item.kind, item.key, captured.status, captured.body);
  log(
    `${item.label}: HTTP ${captured.status}, ${captured.body.length} bytes → ${verdict.outcome} (${verdict.detail})`
  );
  if (verdict.outcome === "blocked") {
    if (verdict.awaitUser) {
      log(`${item.label}: waiting for the user to clear a challenge`);
      await cancelScheduledRetry();
      await updateRunState((current) => ({
        ...current,
        items: current.items.map(
          (i) => i.key === item.key ? {
            ...i,
            status: "blocked",
            detail: verdict.detail,
            attempts,
            awaitUser: true,
            updatedAt: Date.now()
          } : i
        )
      }));
      await notifyState(await getRunState());
      return;
    }
    if (attempts >= MAX_ATTEMPTS) {
      await setItemStatus(
        item.key,
        "failed",
        `${verdict.detail} Gave up after ${attempts} attempts.`
      );
      await notifyState(await getRunState());
      await advance();
      return;
    }
    await setItemStatus(
      item.key,
      "blocked",
      `${verdict.detail} (attempt ${attempts} of ${MAX_ATTEMPTS}; retrying automatically)`,
      attempts
    );
    await notifyState(await getRunState());
    await scheduleRetry();
    return;
  }
  if (verdict.outcome === "unusable") {
    await setItemStatus(item.key, "failed", verdict.detail);
    await notifyState(await getRunState());
    await advance();
    return;
  }
  await markDocumentConsumed(tabId, document);
  if (item.kind === "course") {
    await handleCoursePage(item, captured.body);
  } else {
    await deliver({
      kind: item.kind,
      key: item.key,
      name: fileNameFor(item.kind, item.key),
      text: captured.body
    });
    if (item.kind === "athlete") await recordEvents(captured.body);
    await setItemStatus(item.key, "captured", verdict.detail);
  }
  await notifyState(await getRunState());
  await advance();
}
async function handleCoursePage(item, html) {
  const mid = extractMapMid(html);
  if (!mid) {
    await setItemStatus(item.key, "failed", "No map id on the course page.");
    return;
  }
  try {
    const response = await fetch(courseKmzUrl(mid));
    if (!response.ok) throw new Error(`Google replied ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes[0] !== 80 || bytes[1] !== 75) {
      throw new Error("Downloaded file is not a KMZ archive");
    }
    await deliver({
      kind: "course",
      key: item.key,
      name: `${item.key}.kmz`,
      base64: toBase64(bytes)
    });
    await setItemStatus(
      item.key,
      "captured",
      `KMZ downloaded (${Math.round(bytes.length / 1024)} KB)`
    );
  } catch (error) {
    await setItemStatus(
      item.key,
      "failed",
      `Couldn't download the KMZ: ${describeError(error)}`
    );
  }
}
async function recordEvents(html) {
  const events = extractEvents(parseRunResults(html));
  if (events.length === 0) return;
  await updateSession((session) => {
    const discovered = { ...session.discoveredEvents };
    for (const event of events) {
      if (!discovered[event.eventId]) {
        discovered[event.eventId] = { name: event.name, url: event.url };
      }
    }
    return { ...session, discoveredEvents: discovered };
  });
}
async function queueNewCourses() {
  const session = await getSession();
  if (session.coursesQueued || session.skipCourses) return false;
  await updateSession((s) => ({ ...s, coursesQueued: true }));
  const known = new Set(session.knownCourseEventIds);
  const state = await getRunState();
  const alreadyQueued = new Set(
    state.items.filter((i) => i.kind === "course").map((i) => i.key)
  );
  const items = Object.entries(session.discoveredEvents).filter(([eventId]) => !known.has(eventId) && !alreadyQueued.has(eventId)).map(([eventId, event]) => ({
    kind: "course",
    key: eventId,
    label: `${event.name} course map`,
    url: coursePageUrl(event.url),
    status: "pending"
  })).sort((a, b) => a.label.localeCompare(b.label));
  if (items.length === 0) return false;
  const next = await appendItems(items);
  await notifyState(next);
  return true;
}
async function finishRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const settled = await updateRunState((current) => ({
    ...current,
    items: current.items.map(
      (item) => item.status === "captured" || item.status === "failed" || item.status === "skipped" ? item : {
        ...item,
        status: "failed",
        detail: item.detail ?? "Never completed."
      }
    )
  }));
  const state = settled;
  const captured = state.items.filter((i) => i.status === "captured").length;
  const failed = state.items.filter((i) => i.status === "failed").length;
  const done = {
    ...state,
    status: "done",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: failed ? `Captured ${captured} of ${state.items.length}; ${failed} failed.` : `Captured all ${captured} pages.`
  };
  await setRunState(done);
  await closeScrapeTab();
  await setBadge(failed ? String(failed) : "");
  await focusAdminTab();
  await notifyState(done);
  await notifyFinished(done);
  return done;
}
async function closeScrapeTab() {
  const { scrapeTabId } = await getSession();
  if (scrapeTabId === void 0) return;
  await detach(scrapeTabId);
  await clearLastDocument(scrapeTabId);
  await chrome.tabs.remove(scrapeTabId).catch(() => {
  });
  await updateSession((session) => ({ ...session, scrapeTabId: void 0 }));
}
async function focusAdminTab() {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  try {
    const tab = await chrome.tabs.get(adminTabId);
    await chrome.tabs.update(adminTabId, { active: true });
    if (tab.windowId !== void 0) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
  } catch {
  }
}
async function notifyFinished(state) {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  await chrome.tabs.sendMessage(adminTabId, { type: "finished", state }).catch(() => {
  });
}
async function deliver(file) {
  await putFile(file);
  await notifyFile(file);
}
async function resendFiles() {
  for (const file of await getFiles()) await notifyFile(file);
}
function fileNameFor(kind, key) {
  switch (kind) {
    case "athlete":
      return `athlete-${key}.html`;
    case "event":
      return `${key}-latest-results.html`;
    case "pastEvent": {
      const page = readPastEventKey(key);
      return page ? `${page.eventId}-${page.eventNumber}-results.html` : `${key}-results.html`;
    }
    case "clubs":
      return "largest-clubs.html";
    default:
      return `${key}.kmz`;
  }
}
function toBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(binary);
}
async function setBadge(text) {
  await chrome.action.setBadgeText({ text }).catch(() => {
  });
}
let chain = Promise.resolve();
function serial(work) {
  const next = chain.then(work, work);
  chain = next.catch(() => void 0);
  return next;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (isFromAdminPage(message)) {
    void rememberAdminOrigin(sender.url ?? sender.origin);
  }
  handleMessage(message, sender).then(sendResponse).catch((error) => sendResponse({ error: String(error) }));
  return true;
});
async function handleMessage(message, sender) {
  switch (message.type) {
    case "ping":
      return {
        type: "hello",
        version: SCRAPER_PROTOCOL_VERSION,
        state: await getRunState()
      };
    /**
     * Asked by the overlay, which is injected into every parkrun page — but
     * only the scrape tab is part of a run. A run's state outlives the run
     * (the admin page can still ask for its files), so answering every tab
     * meant a page opened by hand days later still got "Scrape complete".
     */
    case "state?": {
      const { scrapeTabId } = await getSession();
      const inScrapeTab = sender.tab?.id !== void 0 && sender.tab.id === scrapeTabId;
      return {
        type: "state",
        state: inScrapeTab ? await getRunState() : emptyRunState()
      };
    }
    case "start": {
      const adminTabId = sender.tab?.id;
      if (adminTabId === void 0) return { error: "No calling tab" };
      const request = message.request;
      const state = await startRun(request, adminTabId);
      return { type: "state", state };
    }
    case "resume": {
      const adminTabId = sender.tab?.id;
      if (adminTabId === void 0) return { error: "No calling tab" };
      return { type: "state", state: await resumeRun(adminTabId) };
    }
    case "cancel":
      return { type: "state", state: await cancelRun() };
    case "retry":
      return { type: "state", state: await retryCurrent() };
    case "skip":
      return { type: "state", state: await skipCurrent() };
    case "resend":
      await resendFiles();
      return { type: "state", state: await getRunState() };
    case "clear":
      await forgetRun();
      return { type: "state", state: await getRunState() };
    default:
      return { error: `Unknown message: ${message.type}` };
  }
}
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (source.tabId === void 0 || !params) return;
  const tabId = source.tabId;
  void serial(() => handleDebuggerEvent(tabId, method, params)).catch(
    (error) => {
      console.error("[results-scraper] event handling failed", method, error);
    }
  );
});
async function handleDebuggerEvent(tabId, method, params) {
  if (method === "Network.responseReceived") {
    await noteDocumentResponse(tabId, params);
    return;
  }
  if (method === "Network.loadingFinished") {
    const document = await noteLoadingFinished(tabId, params);
    if (document) await handleDocumentLoaded(tabId);
  }
}
chrome.debugger.onDetach.addListener((source, reason) => {
  void handleDetach(source.tabId, reason);
});
async function handleDetach(tabId, reason) {
  const session = await getSession();
  if (session.scrapeTabId !== tabId) return;
  const state = await getRunState();
  if (state.status !== "running") return;
  await setRunState({
    ...state,
    status: "error",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: `Lost the debugger connection (${reason}).`
  });
  await chrome.action.setBadgeText({ text: "!" }).catch(() => {
  });
}
chrome.tabs.onRemoved.addListener((tabId) => {
  void serial(() => handleTabRemoved(tabId));
});
async function handleTabRemoved(tabId) {
  const session = await getSession();
  const state = await getRunState();
  if (state.status !== "running") return;
  if (session.scrapeTabId === tabId) {
    await detach(tabId);
    await setRunState({
      ...state,
      status: "cancelled",
      currentKey: void 0,
      finishedAt: Date.now(),
      message: "The scrape tab was closed."
    });
    await chrome.action.setBadgeText({ text: "" }).catch(() => {
    });
  }
}
chrome.runtime.onStartup.addListener(() => {
  void (async () => {
    const state = await getRunState();
    if (state.status !== "running") return;
    await setRunState({
      ...state,
      status: "cancelled",
      currentKey: void 0,
      message: "Interrupted when the browser closed."
    });
  })();
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== "complete") return;
  void (async () => {
    const state = await getRunState();
    if (state.status !== "running") return;
    const session = await getSession();
    if (session.scrapeTabId !== tabId) return;
    if (!state.currentKey) {
      await serial(() => advance());
      return;
    }
    await serial(() => handleDocumentLoaded(tabId));
    await serial(() => recoverMissedCapture(tabId));
  })();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "retry-blocked") {
    void serial(() => retryIfStillBlocked());
    return;
  }
  if (alarm.name === "watchdog") {
    void serial(() => checkForStall());
  }
});
chrome.action.onClicked.addListener(() => {
  void openAdminPage();
});
chrome.action.setBadgeBackgroundColor({ color: "#3f6d3a" }).catch(() => {
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vbGlicy9zaGFyZWQvc2NyYXBlci1wcm90b2NvbC50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9jYXB0dXJlLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL29wZW5BZG1pbi50cyIsIi4uLy4uL2xpYnMvc2hhcmVkL3BhcmtydW4tcGFyc2Vycy50cyIsIi4uLy4uL2xpYnMvc2hhcmVkL3BhcmtydW4tdXJscy50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9rZWVwYWxpdmUudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvc3RhdGUudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvbWVzc2FnaW5nLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL3ZhbGlkYXRlLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL3J1bi50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9zZXJpYWwudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvYmFja2dyb3VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFRoZSBjb250cmFjdCBiZXR3ZWVuIHRoZSBQcm9jZXNzIFJlc3VsdHMgYWRtaW4gcGFnZSBhbmQgdGhlIHJlc3VsdHMtc2NyYXBlclxuICogQ2hyb21lIGV4dGVuc2lvbi5cbiAqXG4gKiBUaGUgcGFnZSBpcyB0aGUgYnJhaW46IGl0IGtub3dzIHdobyB3ZSB0cmFjaywgd2hpY2ggcGFnZXMgYXJlIG5lZWRlZCBhbmQgd2hpY2hcbiAqIGNvdXJzZXMgd2UgYWxyZWFkeSBoYXZlLCBhbmQgaXQgYnVpbGRzIHRoZSB3b3JrIGxpc3QuIFRoZSBleHRlbnNpb24gaXMgdGhlXG4gKiBleGVjdXRvcjogaXQgbmF2aWdhdGVzLCBjYXB0dXJlcyByYXcgSFRNTCwgYW5kIHN0cmVhbXMgZmlsZXMgYmFjay4gTmVpdGhlclxuICogc2lkZSBoYXJkY29kZXMgdGhlIG90aGVyJ3Mga25vd2xlZGdlLCBzbyBhZGRpbmcgYSBydW5uZXIgb3IgYW4gZXZlbnQgbmVlZHMgbm9cbiAqIGV4dGVuc2lvbiBjaGFuZ2UuXG4gKlxuICogTWVzc2FnZXMgdHJhdmVsIHBhZ2Ug4oaUIGNvbnRlbnQgc2NyaXB0IGJ5IHdpbmRvdy5wb3N0TWVzc2FnZSAod3JhcHBlZCBpbiBhblxuICogZW52ZWxvcGUgc28gd2UgaWdub3JlIGV2ZXJ5dGhpbmcgZWxzZSBvbiB0aGUgY2hhbm5lbCkgYW5kIGNvbnRlbnQgc2NyaXB0IOKGlFxuICogc2VydmljZSB3b3JrZXIgYnkgY2hyb21lLnJ1bnRpbWUgbWVzc2FnaW5nLlxuICovXG5cbmV4cG9ydCBjb25zdCBTQ1JBUEVSX1BST1RPQ09MX1ZFUlNJT04gPSAyXG5cbi8qKlxuICogVGhlIGZpcnN0IHZlcnNpb24gdGhhdCB1bmRlcnN0YW5kcyBgcGFzdEV2ZW50YCBpdGVtcy4gQW4gb2xkZXIgZXh0ZW5zaW9uIGhhc1xuICogbm8gdmFsaWRhdG9yIGZvciB0aGVtIGFuZCB3b3VsZCB3ZWRnZSBvbiB0aGUgZmlyc3QgcGFnZSwgc28gdGhlIHBhZ2UgY2hlY2tzXG4gKiBiZWZvcmUgb2ZmZXJpbmcgYSBiYWNrZmlsbC5cbiAqL1xuZXhwb3J0IGNvbnN0IFBBU1RfRVZFTlRTX1BST1RPQ09MX1ZFUlNJT04gPSAyXG5cbi8qKiBFbnZlbG9wZSBtYXJrZXIsIHNvIHBvc3RNZXNzYWdlIHRyYWZmaWMgZnJvbSBhbnl0aGluZyBlbHNlIGlzIGlnbm9yZWQuICovXG5leHBvcnQgY29uc3QgU0NSQVBFUl9FTlZFTE9QRSA9ICdzY29vcGJ1cy1yZXN1bHRzLXNjcmFwZXInXG5cbi8vIOKUgOKUgCBXb3JrIGxpc3Qg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogV2hpY2ggdXBsb2FkIGZpZWxkIGEgY2FwdHVyZWQgZmlsZSBiZWxvbmdzIHRvLlxuICpcbiAqIGBldmVudGAgaXMgYW4gZXZlbnQncyBsYXRlc3QgcmVzdWx0cywga2V5ZWQgYnkgZXZlbnRJZC4gYHBhc3RFdmVudGAgaXMgb25lXG4gKiBudW1iZXJlZCByZXN1bHRzIHBhZ2UsIGZvciBiYWNrZmlsbGluZyB2b2x1bnRlZXIgaGlzdG9yeSwga2V5ZWQgYnlcbiAqIGBwYXN0RXZlbnRLZXkoKWAgc28gYSBydW4gY2FuIGhvbGQgaHVuZHJlZHMgb2YgdGhlbS5cbiAqL1xuZXhwb3J0IHR5cGUgQ2FwdHVyZUtpbmQgPSAnYXRobGV0ZScgfCAnZXZlbnQnIHwgJ2NsdWJzJyB8ICdjb3Vyc2UnIHwgJ3Bhc3RFdmVudCdcblxuLyoqIFRoZSBzaW5nbGUgZm9ybSBzbG90IHRoYXQgaG9sZHMgdGhlIGxhcmdlc3QtY2x1YnMgcGFnZS4gKi9cbmV4cG9ydCBjb25zdCBDTFVCU19LRVkgPSAnY2x1YnMnXG5cbi8qKiBLZXkgZm9yIGEgbnVtYmVyZWQgZXZlbnQgcGFnZSwgZS5nLiBcImh1ZGRpbmdlIzEyXCIuICovXG5leHBvcnQgZnVuY3Rpb24gcGFzdEV2ZW50S2V5KGV2ZW50SWQ6IHN0cmluZywgZXZlbnROdW1iZXI6IG51bWJlcik6IHN0cmluZyB7XG5cdHJldHVybiBgJHtldmVudElkfSMke2V2ZW50TnVtYmVyfWBcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlYWRQYXN0RXZlbnRLZXkoXG5cdGtleTogc3RyaW5nLFxuKTogeyBldmVudElkOiBzdHJpbmc7IGV2ZW50TnVtYmVyOiBudW1iZXIgfSB8IG51bGwge1xuXHRjb25zdCBtYXRjaCA9IGtleS5tYXRjaCgvXihbXiNdKykjKFxcZCspJC8pXG5cdGlmICghbWF0Y2gpIHJldHVybiBudWxsXG5cdHJldHVybiB7IGV2ZW50SWQ6IG1hdGNoWzFdLCBldmVudE51bWJlcjogTnVtYmVyLnBhcnNlSW50KG1hdGNoWzJdLCAxMCkgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFdvcmtJdGVtIHtcblx0a2luZDogQ2FwdHVyZUtpbmRcblx0LyoqIE1hdGNoZXMgdGhlIGZvcm0gc2xvdDogcGFya3J1bklkLCBldmVudElkLCBvciBDTFVCU19LRVkuICovXG5cdGtleTogc3RyaW5nXG5cdC8qKiBIdW1hbiBsYWJlbCBmb3IgdGhlIHByb2dyZXNzIFVJLCBlLmcuIFwiSm9zaFwiIG9yIFwiSGFnYSBGdWxsIFJlc3VsdHNcIi4gKi9cblx0bGFiZWw6IHN0cmluZ1xuXHR1cmw6IHN0cmluZ1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJ1blJlcXVlc3Qge1xuXHRpdGVtczogV29ya0l0ZW1bXVxuXHQvKipcblx0ICogRXZlbnQgSURzIHRoYXQgYWxyZWFkeSBoYXZlIGNvdXJzZSBkYXRhLiBBbnl0aGluZyBhbiBhdGhsZXRlIHBhZ2UgdHVybnMgdXBcblx0ICogdGhhdCBpc24ndCBpbiBoZXJlIGdldHMgaXRzIGNvdXJzZSBwYWdlIHF1ZXVlZCBtaWQtcnVuLlxuXHQgKi9cblx0a25vd25Db3Vyc2VFdmVudElkczogc3RyaW5nW11cblx0LyoqIFNraXAgdGhlIG1pZC1ydW4gaHVudCBmb3IgbmV3IGNvdXJzZSBtYXBzLiAqL1xuXHRza2lwQ291cnNlcz86IGJvb2xlYW5cblx0LyoqXG5cdCAqIFdhaXQgYWJvdXQgdGhpcyBsb25nIGJldHdlZW4gcGFnZXMuIEEgYmFja2ZpbGwgaXMgaHVuZHJlZHMgb2YgbG9hZHMsIGFuZFxuXHQgKiBmaXJpbmcgdGhlbSBiYWNrIHRvIGJhY2sgaXMgdGhlIHF1aWNrZXN0IHdheSB0byBnZXQgcGFya3J1biBibG9ja2luZyB1cy5cblx0ICovXG5cdHBhdXNlTXM/OiBudW1iZXJcbn1cblxuLy8g4pSA4pSAIFJ1biBzdGF0ZSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IHR5cGUgSXRlbVN0YXR1cyA9XG5cdHwgJ3BlbmRpbmcnXG5cdHwgJ2FjdGl2ZSdcblx0LyoqIExvYWRlZCwgYnV0IGJsb2NrZWQg4oCUIHVzdWFsbHkgYSBjYXB0Y2hhIG9yIGJvdCBjaGVjayBhd2FpdGluZyB0aGUgdXNlci4gKi9cblx0fCAnYmxvY2tlZCdcblx0fCAnY2FwdHVyZWQnXG5cdHwgJ2ZhaWxlZCdcblx0fCAnc2tpcHBlZCdcblxuZXhwb3J0IGludGVyZmFjZSBJdGVtU3RhdGUgZXh0ZW5kcyBXb3JrSXRlbSB7XG5cdHN0YXR1czogSXRlbVN0YXR1c1xuXHQvKiogT25lLWxpbmUgZGV0YWlsIGZvciB0aGUgVUk6IHdoYXQgd2FzIHBhcnNlZCwgb3Igd2h5IGl0IGZhaWxlZC4gKi9cblx0ZGV0YWlsPzogc3RyaW5nXG5cdC8qKiBIb3cgbWFueSB0aW1lcyB0aGlzIHBhZ2UgaGFzIGJlZW4gbG9hZGVkLCBmb3Igc3RhbGxzIGFuZCByZXRyaWVzLiAqL1xuXHRhdHRlbXB0cz86IG51bWJlclxuXHQvKiogRXBvY2ggbXMgd2hlbiB0aGlzIGl0ZW0gbGFzdCBjaGFuZ2VkLCBzbyBhIHdhdGNoZG9nIGNhbiBzcG90IGEgc3RhbGwuICovXG5cdHVwZGF0ZWRBdD86IG51bWJlclxuXHQvKipcblx0ICogVGhlcmUncyBhbiBpbnRlcmFjdGl2ZSBjaGFsbGVuZ2Ugb24gc2NyZWVuLiBOb3RoaW5nIG1heSByZWxvYWQgdGhlIHBhZ2Ugb3Jcblx0ICogdGltZSB0aGUgaXRlbSBvdXQgd2hpbGUgdGhpcyBpcyBzZXQg4oCUIHRoZSBwZXJzb24gaXMgbWlkLWNhcHRjaGEuXG5cdCAqL1xuXHRhd2FpdFVzZXI/OiBib29sZWFuXG59XG5cbmV4cG9ydCB0eXBlIFJ1blN0YXR1cyA9ICdpZGxlJyB8ICdydW5uaW5nJyB8ICdkb25lJyB8ICdjYW5jZWxsZWQnIHwgJ2Vycm9yJ1xuXG5leHBvcnQgaW50ZXJmYWNlIFJ1blN0YXRlIHtcblx0c3RhdHVzOiBSdW5TdGF0dXNcblx0aXRlbXM6IEl0ZW1TdGF0ZVtdXG5cdC8qKiBLZXkgb2YgdGhlIGl0ZW0gYmVpbmcgd29ya2VkIG9uLCBpZiBhbnkuICovXG5cdGN1cnJlbnRLZXk/OiBzdHJpbmdcblx0bWVzc2FnZT86IHN0cmluZ1xuXHRzdGFydGVkQXQ/OiBudW1iZXJcblx0ZmluaXNoZWRBdD86IG51bWJlclxufVxuXG5leHBvcnQgZnVuY3Rpb24gZW1wdHlSdW5TdGF0ZSgpOiBSdW5TdGF0ZSB7XG5cdHJldHVybiB7IHN0YXR1czogJ2lkbGUnLCBpdGVtczogW10gfVxufVxuXG4vLyDilIDilIAgQ2FwdHVyZWQgZmlsZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2FwdHVyZWRGaWxlIHtcblx0a2luZDogQ2FwdHVyZUtpbmRcblx0a2V5OiBzdHJpbmdcblx0LyoqIEZpbGVuYW1lIGhhbmRlZCB0byB0aGUgZm9ybSwgc28gaXQgcmVhZHMgbGlrZSBhIG5vcm1hbCB1cGxvYWQuICovXG5cdG5hbWU6IHN0cmluZ1xuXHQvKiogVVRGLTggdGV4dCBmb3IgSFRNTCBwYWdlcy4gKi9cblx0dGV4dD86IHN0cmluZ1xuXHQvKiogQmFzZTY0IGZvciBiaW5hcnkgcGF5bG9hZHMgKEtNWikuICovXG5cdGJhc2U2ND86IHN0cmluZ1xufVxuXG4vLyDilIDilIAgTWVzc2FnZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCB0eXBlIFBhZ2VNZXNzYWdlID1cblx0LyoqIElzIHRoZSBleHRlbnNpb24gaW5zdGFsbGVkPyAqL1xuXHR8IHsgdHlwZTogJ3BpbmcnIH1cblx0fCB7IHR5cGU6ICdzdGFydCc7IHJlcXVlc3Q6IFJ1blJlcXVlc3QgfVxuXHR8IHsgdHlwZTogJ2NhbmNlbCcgfVxuXHQvKipcblx0ICogUGljayBhbiBpbnRlcnJ1cHRlZCBydW4gYmFjayB1cC4gRXZlcnl0aGluZyBhbHJlYWR5IGNhcHR1cmVkIGlzIGtlcHQ7IG9ubHlcblx0ICogdGhlIHBhZ2VzIHRoYXQgbmV2ZXIgbGFuZGVkIGFyZSBxdWV1ZWQgYWdhaW4uXG5cdCAqL1xuXHR8IHsgdHlwZTogJ3Jlc3VtZScgfVxuXHQvKiogUmVsb2FkIHRoZSBwYWdlIHdlJ3JlIHN0dWNrIG9uLiAqL1xuXHR8IHsgdHlwZTogJ3JldHJ5JyB9XG5cdC8qKiBHaXZlIHVwIG9uIHRoZSBjdXJyZW50IHBhZ2UgYW5kIG1vdmUgdG8gdGhlIG5leHQuICovXG5cdHwgeyB0eXBlOiAnc2tpcCcgfVxuXHQvKiogUmUtZGVsaXZlciBldmVyeXRoaW5nIGNhcHR1cmVkIHNvIGZhciAoYWZ0ZXIgYSBwYWdlIHJlbG9hZCkuICovXG5cdHwgeyB0eXBlOiAncmVzZW5kJyB9XG5cdC8qKlxuXHQgKiBUaHJvdyB0aGUgcnVuIGF3YXkuIFNlbnQgb25jZSBhbiB1cGxvYWQgaGFzIGxhbmRlZCwgc28gYSByZWxvYWQgZG9lc24ndFxuXHQgKiByZXN1cnJlY3QgYSBzY3JhcGUgd2hvc2UgZGF0YSBpcyBhbHJlYWR5IGluIHRoZSBkYXRhYmFzZS5cblx0ICovXG5cdHwgeyB0eXBlOiAnY2xlYXInIH1cblxuZXhwb3J0IHR5cGUgRXh0ZW5zaW9uTWVzc2FnZSA9XG5cdHwgeyB0eXBlOiAnaGVsbG8nOyB2ZXJzaW9uOiBudW1iZXI7IHN0YXRlOiBSdW5TdGF0ZSB9XG5cdHwgeyB0eXBlOiAnc3RhdGUnOyBzdGF0ZTogUnVuU3RhdGUgfVxuXHR8IHsgdHlwZTogJ2ZpbGUnOyBmaWxlOiBDYXB0dXJlZEZpbGUgfVxuXHR8IHsgdHlwZTogJ2ZpbmlzaGVkJzsgc3RhdGU6IFJ1blN0YXRlIH1cblxuLyoqXG4gKiBFdmVyeSBtZXNzYWdlIHRoZSBwYWdlIG1heSBzZW5kLCBhcyBhIHJ1bnRpbWUgbGlzdC5cbiAqXG4gKiBUaGUgYnJpZGdlIGNvbnRlbnQgc2NyaXB0IGZvcndhcmRzIG9ubHkgdGhlc2UsIHNvIGl0IG5lZWRzIHRoZSBzZXQgYXQgcnVudGltZVxuICog4oCUIGFuZCBpdCB1c2VkIHRvIGtlZXAgaXRzIG93biBjb3B5LCB3aGljaCBzaWxlbnRseSBmZWxsIGJlaGluZCBhcyBtZXNzYWdlc1xuICogd2VyZSBhZGRlZDogYHJldHJ5YCwgYHNraXBgLCBgcmVzdW1lYCBhbmQgYGNsZWFyYCB3ZXJlIGFsbCBiZWluZyBkcm9wcGVkXG4gKiB3aXRob3V0IGEgdHJhY2UuIFRoZSBleGhhdXN0aXZlbmVzcyBjaGVjayBiZWxvdyBtYWtlcyBsZWF2aW5nIG9uZSBvdXQgYVxuICogY29tcGlsZSBlcnJvciBpbnN0ZWFkLlxuICovXG5leHBvcnQgY29uc3QgUEFHRV9NRVNTQUdFX1RZUEVTID0gW1xuXHQncGluZycsXG5cdCdzdGFydCcsXG5cdCdyZXN1bWUnLFxuXHQncmV0cnknLFxuXHQnc2tpcCcsXG5cdCdjYW5jZWwnLFxuXHQncmVzZW5kJyxcblx0J2NsZWFyJyxcbl0gYXMgY29uc3RcblxuZXhwb3J0IHR5cGUgUGFnZU1lc3NhZ2VUeXBlID0gKHR5cGVvZiBQQUdFX01FU1NBR0VfVFlQRVMpW251bWJlcl1cblxuLyoqIEZhaWxzIHRvIGNvbXBpbGUgaWYgUEFHRV9NRVNTQUdFX1RZUEVTIGFuZCBQYWdlTWVzc2FnZSBkcmlmdCBhcGFydC4gKi9cbnR5cGUgQXNzZXJ0U2FtZU1lc3NhZ2VUeXBlcyA9IFBhZ2VNZXNzYWdlWyd0eXBlJ10gZXh0ZW5kcyBQYWdlTWVzc2FnZVR5cGVcblx0PyBQYWdlTWVzc2FnZVR5cGUgZXh0ZW5kcyBQYWdlTWVzc2FnZVsndHlwZSddXG5cdFx0PyB0cnVlXG5cdFx0OiBuZXZlclxuXHQ6IG5ldmVyXG5jb25zdCBfbWVzc2FnZVR5cGVzTWF0Y2g6IEFzc2VydFNhbWVNZXNzYWdlVHlwZXMgPSB0cnVlXG52b2lkIF9tZXNzYWdlVHlwZXNNYXRjaFxuXG5leHBvcnQgZnVuY3Rpb24gaXNQYWdlTWVzc2FnZVR5cGUodmFsdWU6IHN0cmluZyk6IHZhbHVlIGlzIFBhZ2VNZXNzYWdlVHlwZSB7XG5cdHJldHVybiAoUEFHRV9NRVNTQUdFX1RZUEVTIGFzIHJlYWRvbmx5IHN0cmluZ1tdKS5pbmNsdWRlcyh2YWx1ZSlcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTY3JhcGVyRW52ZWxvcGU8VD4ge1xuXHRjaGFubmVsOiB0eXBlb2YgU0NSQVBFUl9FTlZFTE9QRVxuXHRkaXJlY3Rpb246ICd0by1leHRlbnNpb24nIHwgJ3RvLXBhZ2UnXG5cdHBheWxvYWQ6IFRcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHdyYXBGb3JFeHRlbnNpb24oXG5cdHBheWxvYWQ6IFBhZ2VNZXNzYWdlLFxuKTogU2NyYXBlckVudmVsb3BlPFBhZ2VNZXNzYWdlPiB7XG5cdHJldHVybiB7IGNoYW5uZWw6IFNDUkFQRVJfRU5WRUxPUEUsIGRpcmVjdGlvbjogJ3RvLWV4dGVuc2lvbicsIHBheWxvYWQgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gd3JhcEZvclBhZ2UoXG5cdHBheWxvYWQ6IEV4dGVuc2lvbk1lc3NhZ2UsXG4pOiBTY3JhcGVyRW52ZWxvcGU8RXh0ZW5zaW9uTWVzc2FnZT4ge1xuXHRyZXR1cm4geyBjaGFubmVsOiBTQ1JBUEVSX0VOVkVMT1BFLCBkaXJlY3Rpb246ICd0by1wYWdlJywgcGF5bG9hZCB9XG59XG5cbmZ1bmN0aW9uIGlzRW52ZWxvcGUoZGF0YTogdW5rbm93bik6IGRhdGEgaXMgU2NyYXBlckVudmVsb3BlPHVua25vd24+IHtcblx0cmV0dXJuIChcblx0XHR0eXBlb2YgZGF0YSA9PT0gJ29iamVjdCcgJiZcblx0XHRkYXRhICE9PSBudWxsICYmXG5cdFx0KGRhdGEgYXMgeyBjaGFubmVsPzogdW5rbm93biB9KS5jaGFubmVsID09PSBTQ1JBUEVSX0VOVkVMT1BFXG5cdClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHJlYWRQYWdlTWVzc2FnZShkYXRhOiB1bmtub3duKTogUGFnZU1lc3NhZ2UgfCBudWxsIHtcblx0aWYgKCFpc0VudmVsb3BlKGRhdGEpIHx8IGRhdGEuZGlyZWN0aW9uICE9PSAndG8tZXh0ZW5zaW9uJykgcmV0dXJuIG51bGxcblx0cmV0dXJuIGRhdGEucGF5bG9hZCBhcyBQYWdlTWVzc2FnZVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVhZEV4dGVuc2lvbk1lc3NhZ2UoZGF0YTogdW5rbm93bik6IEV4dGVuc2lvbk1lc3NhZ2UgfCBudWxsIHtcblx0aWYgKCFpc0VudmVsb3BlKGRhdGEpIHx8IGRhdGEuZGlyZWN0aW9uICE9PSAndG8tcGFnZScpIHJldHVybiBudWxsXG5cdHJldHVybiBkYXRhLnBheWxvYWQgYXMgRXh0ZW5zaW9uTWVzc2FnZVxufVxuIiwiLyoqXG4gKiBSYXcgcmVzcG9uc2UtYm9keSBjYXB0dXJlIHZpYSBjaHJvbWUuZGVidWdnZXIuXG4gKlxuICogVGhpcyBpcyB0aGUgb25seSB3YXkgYW4gTVYzIGV4dGVuc2lvbiBjYW4gcmVhZCBhIG5hdmlnYXRpb24ncyAqcmF3KiBIVE1MLlxuICogSXQgbWF0dGVycyBiZWNhdXNlIHBhcmtydW4ncyBjb29raWUtY29uc2VudCBzY3JpcHQgcmV3cml0ZXMgdGhlIERPTTogY291cnNlXG4gKiBwYWdlcyBsb3NlIHRoZSBHb29nbGUgTWFwcyBpZnJhbWUgZW50aXJlbHksIHNvIGEgRE9NIHNjcmFwZSBoYXMgbm8gbWFwIGlkIHRvXG4gKiBmaW5kIChzZWUgYXBwcy9hcGkvbGliL21hcC1zY3JhcGVyLnRzKS4gQXRobGV0ZSBhbmQgZXZlbnQgcGFnZXMgcGFyc2UgZWl0aGVyXG4gKiB3YXksIGJ1dCB0aGVyZSdzIG5vIHJlYXNvbiB0byBoYXZlIHR3byBjb2RlIHBhdGhzLlxuICpcbiAqIFRoaW5ncyB0aGF0IHdlcmUgdHJpZWQgYW5kIGRvbid0IHdvcms6XG4gKiAgLSBgUGFnZS5nZXRSZXNvdXJjZUNvbnRlbnRgIOKGkiBcIkNvbnRlbnQgdW5hdmFpbGFibGUuIFJlc291cmNlIHdhcyBub3QgY2FjaGVkXCIsXG4gKiAgICBldmVuIHdpdGggdGhlIE5ldHdvcmsgZG9tYWluIGVuYWJsZWQuXG4gKiAgLSBOYXZpZ2F0aW5nIHRvIGEgYHZpZXctc291cmNlOmAgVVJMIOKGkiB0aGUgdGFiIGRvZXMgbG9hZCwgYnV0IHNjcmlwdFxuICogICAgaW5qZWN0aW9uIGludG8gaXQgaGFuZ3MgZm9yZXZlciwgc28gdGhlIHRleHQgY2FuIG5ldmVyIGJlIHJlYWQgYmFjay5cbiAqXG4gKiBXaGF0IGRvZXMgd29yayBpcyB3YXRjaGluZyBOZXR3b3JrIGV2ZW50cyBmb3IgdGhlIG1haW4tZnJhbWUgZG9jdW1lbnQgYW5kXG4gKiBhc2tpbmcgZm9yIGl0cyBib2R5IG9uY2UgaXQgZmluaXNoZXMgbG9hZGluZy4gRG9jdW1lbnQgcmVxdWVzdCBJRHMgYXJlIHdyaXR0ZW5cbiAqIHRvIHN0b3JhZ2UgYXMgdGhleSdyZSBzZWVuLCBzbyBhIGJvZHkgY2FuIHN0aWxsIGJlIGZldGNoZWQgYWZ0ZXIgdGhlIHNlcnZpY2VcbiAqIHdvcmtlciBoYXMgYmVlbiByZXN0YXJ0ZWQuXG4gKi9cblxuY29uc3QgREVCVUdHRVJfVkVSU0lPTiA9ICcxLjMnXG5cbmNvbnN0IERPQ19LRVkgPSAnbGFzdERvY3VtZW50J1xuXG5leHBvcnQgaW50ZXJmYWNlIERvY3VtZW50UmVzcG9uc2Uge1xuXHRyZXF1ZXN0SWQ6IHN0cmluZ1xuXHR1cmw6IHN0cmluZ1xuXHRzdGF0dXM6IG51bWJlclxuXHQvKiogVHJ1ZSBvbmNlIGxvYWRpbmdGaW5pc2hlZCBoYXMgYmVlbiBzZWVuLCBpLmUuIHRoZSBib2R5IGlzIGF2YWlsYWJsZS4gKi9cblx0ZmluaXNoZWQ6IGJvb2xlYW5cblx0LyoqXG5cdCAqIFNldCBvbmNlIHRoaXMgcmVzcG9uc2UgaGFzIGJlZW4gY2FwdHVyZWQuIEJvdGggY2FwdHVyZSB0cmlnZ2VycyBjYW4gZmlyZSBmb3Jcblx0ICogdGhlIHNhbWUgbG9hZDsgd2l0aG91dCB0aGlzIHRoZSBwYWdlIGlzIGNhcHR1cmVkIHR3aWNlIGFuZCB0aGUgcXVldWUgaXNcblx0ICogYWR2YW5jZWQgdHdpY2UsIHdoaWNoIHNraXBzIHRoZSBuZXh0IGl0ZW0uXG5cdCAqL1xuXHRjb25zdW1lZD86IGJvb2xlYW5cbn1cblxuZXhwb3J0IGludGVyZmFjZSBDYXB0dXJlZEJvZHkge1xuXHR1cmw6IHN0cmluZ1xuXHRzdGF0dXM6IG51bWJlclxuXHRib2R5OiBzdHJpbmdcblx0YmFzZTY0RW5jb2RlZDogYm9vbGVhblxufVxuXG4vLyDilIDilIAgQXR0YWNoIC8gZGV0YWNoIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIEF0dGFjaCBhbmQgZW5hYmxlIHRoZSBOZXR3b3JrIGRvbWFpbiwgaWRlbXBvdGVudGx5LlxuICpcbiAqIERlbGliZXJhdGVseSBkb2VzICpub3QqIGNvbnN1bHQgYGNocm9tZS5kZWJ1Z2dlci5nZXRUYXJnZXRzKClgIHRvIGRlY2lkZVxuICogd2hldGhlciB0byBhdHRhY2g6IGl0cyBgYXR0YWNoZWRgIGZsYWcgaXMgdHJ1ZSB3aGVuICphbnkqIENEUCBjbGllbnQgaXNcbiAqIGNvbm5lY3RlZCwgaW5jbHVkaW5nIHRoZSB1c2VyJ3MgRGV2VG9vbHMgYW5kIGFueSBhdXRvbWF0aW9uIGRyaXZpbmcgdGhlXG4gKiBicm93c2VyLiBUcnVzdGluZyBpdCBtZWFucyBzaWxlbnRseSBza2lwcGluZyBvdXIgb3duIGF0dGFjaCBhbmQgdGhlbiBjYXB0dXJpbmdcbiAqIG5vdGhpbmcuIEluc3RlYWQgd2UgYWx3YXlzIHRyeSwgYW5kIGxldCB0aGUgZm9sbG93LXVwIGNvbW1hbmQgdGVsbCB1cyB3aGV0aGVyXG4gKiB3ZSByZWFsbHkgaG9sZCB0aGUgc2Vzc2lvbiDigJQgaWYgc29tZW9uZSBlbHNlIGRvZXMsIGBOZXR3b3JrLmVuYWJsZWAgZmFpbHMgYW5kXG4gKiB0aGUgZXJyb3Igc3VyZmFjZXMuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhdHRhY2godGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuXHR0cnkge1xuXHRcdGF3YWl0IGNocm9tZS5kZWJ1Z2dlci5hdHRhY2goeyB0YWJJZCB9LCBERUJVR0dFUl9WRVJTSU9OKVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdC8vIFwiQWxyZWFkeSBhdHRhY2hlZFwiIGlzIGV4cGVjdGVkIHdoZW4gaXQncyBvdXIgb3duIHNlc3Npb24gYmVpbmcgcmV1c2VkLlxuXHRcdGlmICghL2FscmVhZHkgYXR0YWNoZWQvaS50ZXN0KGRlc2NyaWJlRXJyb3IoZXJyb3IpKSkgdGhyb3cgZXJyb3Jcblx0fVxuXG5cdC8vIE5ldHdvcmsgbXVzdCBiZSBlbmFibGVkIGZvciByZXNwb25zZSBib2RpZXMgdG8gYmUgcmV0YWluZWQgYXQgYWxsLiBUaGlzIGlzXG5cdC8vIGFsc28gdGhlIHJlYWwgdGVzdCBvZiB3aGV0aGVyIHRoZSBzZXNzaW9uIGlzIG91cnMuXG5cdGF3YWl0IGNocm9tZS5kZWJ1Z2dlci5zZW5kQ29tbWFuZCh7IHRhYklkIH0sICdOZXR3b3JrLmVuYWJsZScpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBkZXRhY2godGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuXHR0cnkge1xuXHRcdGF3YWl0IGNocm9tZS5kZWJ1Z2dlci5kZXRhY2goeyB0YWJJZCB9KVxuXHR9IGNhdGNoIHtcblx0XHQvLyBBbHJlYWR5IGdvbmUg4oCUIHRoZSB0YWIgd2FzIGNsb3NlZCwgb3IgQ2hyb21lIGRldGFjaGVkIHVzLlxuXHR9XG59XG5cbi8qKiBSZS1hdHRhY2ggaWYgYSBzZXJ2aWNlIHdvcmtlciByZXN0YXJ0IG9yIGEgZGV0YWNoIGxvc3QgdGhlIHNlc3Npb24uICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZW5zdXJlQXR0YWNoZWQodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuXHR0cnkge1xuXHRcdGF3YWl0IGF0dGFjaCh0YWJJZClcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoXG5cdFx0XHRgQ291bGRuJ3QgYXR0YWNoIHRoZSBkZWJ1Z2dlciB0byB0aGUgc2NyYXBlIHRhYjogJHtkZXNjcmliZUVycm9yKGVycm9yKX0uIElmIERldlRvb2xzIGlzIG9wZW4gb24gaXQsIGNsb3NlIHRoZW0gYW5kIHByZXNzIFNjcmFwZSBhZ2Fpbi5gLFxuXHRcdClcblx0fVxufVxuXG4vLyDilIDilIAgVHJhY2tpbmcgdGhlIG1haW4tZnJhbWUgZG9jdW1lbnQg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogTm90ZSBhIG1haW4tZnJhbWUgZG9jdW1lbnQgcmVzcG9uc2UuIFJlZGlyZWN0IGNoYWlucyBwcm9kdWNlIHNldmVyYWwsIHNvIHRoZVxuICogbW9zdCByZWNlbnQgb25lIHdpbnMuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBub3RlRG9jdW1lbnRSZXNwb25zZShcblx0dGFiSWQ6IG51bWJlcixcblx0cGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbik6IFByb21pc2U8dm9pZD4ge1xuXHRpZiAocGFyYW1zLnR5cGUgIT09ICdEb2N1bWVudCcpIHJldHVyblxuXG5cdGNvbnN0IHJlc3BvbnNlID0gcGFyYW1zLnJlc3BvbnNlIGFzIHsgdXJsPzogc3RyaW5nOyBzdGF0dXM/OiBudW1iZXIgfVxuXHRjb25zdCByZXF1ZXN0SWQgPSBwYXJhbXMucmVxdWVzdElkIGFzIHN0cmluZ1xuXHRpZiAoIXJlcXVlc3RJZCB8fCAhcmVzcG9uc2U/LnVybCkgcmV0dXJuXG5cblx0Ly8gU3ViZnJhbWUgZG9jdW1lbnRzIChhZHMsIGVtYmVkcykgYWxzbyBhcnJpdmUgaGVyZTsgb25seSB0aGUgbWFpbiBmcmFtZSdzXG5cdC8vIGRvY3VtZW50IGhhcyBhIGZyYW1lSWQgbWF0Y2hpbmcgdGhlIHRhYidzIG93biB0b3AgZnJhbWUuIGBmcmFtZUlkYCBpc1xuXHQvLyBwcmVzZW50IG9uIHJlc3BvbnNlUmVjZWl2ZWQsIGFuZCB0aGUgbWFpbiBmcmFtZSdzIGlkIGVxdWFscyB0aGUgdGFiIHRhcmdldCxcblx0Ly8gd2hpY2ggd2UgY2FuJ3QgY29tcGFyZSBkaXJlY3RseSDigJQgc28gZmlsdGVyIG9uIHRoZSBsb2FkZXJJZCBpbnN0ZWFkOiB0aGVcblx0Ly8gbWFpbi1mcmFtZSBuYXZpZ2F0aW9uIGlzIHRoZSBvbmUgd2hvc2UgbG9hZGVySWQgbWF0Y2hlcyBpdHMgb3duIHJlcXVlc3RJZC5cblx0Ly8gQ2hyb21lIHNldHMgdGhlc2UgZXF1YWwgZm9yIG1haW4tZnJhbWUgZG9jdW1lbnQgcmVxdWVzdHMuXG5cdGlmIChwYXJhbXMubG9hZGVySWQgJiYgcGFyYW1zLmxvYWRlcklkICE9PSByZXF1ZXN0SWQpIHJldHVyblxuXG5cdGF3YWl0IHNldExhc3REb2N1bWVudCh0YWJJZCwge1xuXHRcdHJlcXVlc3RJZCxcblx0XHR1cmw6IHJlc3BvbnNlLnVybCxcblx0XHRzdGF0dXM6IHJlc3BvbnNlLnN0YXR1cyA/PyAwLFxuXHRcdGZpbmlzaGVkOiBmYWxzZSxcblx0fSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5vdGVMb2FkaW5nRmluaXNoZWQoXG5cdHRhYklkOiBudW1iZXIsXG5cdHBhcmFtczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4pOiBQcm9taXNlPERvY3VtZW50UmVzcG9uc2UgfCBudWxsPiB7XG5cdGNvbnN0IGxhc3QgPSBhd2FpdCBnZXRMYXN0RG9jdW1lbnQodGFiSWQpXG5cdGlmICghbGFzdCB8fCBsYXN0LnJlcXVlc3RJZCAhPT0gcGFyYW1zLnJlcXVlc3RJZCkgcmV0dXJuIG51bGxcblxuXHRjb25zdCBmaW5pc2hlZCA9IHsgLi4ubGFzdCwgZmluaXNoZWQ6IHRydWUgfVxuXHRhd2FpdCBzZXRMYXN0RG9jdW1lbnQodGFiSWQsIGZpbmlzaGVkKVxuXHRyZXR1cm4gZmluaXNoZWRcbn1cblxuLyoqXG4gKiBUcnVlIHdoZW4gYE5ldHdvcmsuZ2V0UmVzcG9uc2VCb2R5YCBmYWlsZWQgb25seSBiZWNhdXNlIHRoZSBib2R5IGlzbid0IHRoZXJlXG4gKiB5ZXQsIGFzIG9wcG9zZWQgdG8gYmVpbmcgZ29uZSBmb3IgZ29vZC5cbiAqXG4gKiBXb3J0aCBkaXN0aW5ndWlzaGluZyBiZWNhdXNlIHdlIGFsc28gdHJ5IHRvIHJlYWQgYm9kaWVzIG9mZiBgdGFicy5vblVwZGF0ZWRgLFxuICogd2hpY2ggY2FuIGxhbmQgbWFyZ2luYWxseSBiZWZvcmUgdGhlIGJvZHkgaXMgYXZhaWxhYmxlLiBBIFwibm90IHJlYWR5XCIgaXNcbiAqIHNvbWV0aGluZyB0byB3YWl0IG91dDsgYW55dGhpbmcgZWxzZSBtZWFucyB0aGlzIGF0dGVtcHQgaXMgc3BlbnQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0JvZHlOb3RSZWFkeShlcnJvcjogdW5rbm93bik6IGJvb2xlYW4ge1xuXHRyZXR1cm4gL25vIHJlc291cmNlIHdpdGggZ2l2ZW4gaWRlbnRpZmllcnxubyBkYXRhIGZvdW5kL2kudGVzdChcblx0XHRkZXNjcmliZUVycm9yKGVycm9yKSxcblx0KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0TGFzdERvY3VtZW50KFxuXHR0YWJJZDogbnVtYmVyLFxuKTogUHJvbWlzZTxEb2N1bWVudFJlc3BvbnNlIHwgbnVsbD4ge1xuXHRjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQ8XG5cdFx0UmVjb3JkPHN0cmluZywgRG9jdW1lbnRSZXNwb25zZT5cblx0PihgJHtET0NfS0VZfToke3RhYklkfWApXG5cdHJldHVybiBzdG9yZWRbYCR7RE9DX0tFWX06JHt0YWJJZH1gXSA/PyBudWxsXG59XG5cbmFzeW5jIGZ1bmN0aW9uIHNldExhc3REb2N1bWVudChcblx0dGFiSWQ6IG51bWJlcixcblx0dmFsdWU6IERvY3VtZW50UmVzcG9uc2UsXG4pOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW2Ake0RPQ19LRVl9OiR7dGFiSWR9YF06IHZhbHVlIH0pXG59XG5cbi8qKiBNYXJrIHRoZSBjdXJyZW50IGRvY3VtZW50IGFzIGNhcHR1cmVkLCBzbyBhIHNlY29uZCB0cmlnZ2VyIGlzIGEgbm8tb3AuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbWFya0RvY3VtZW50Q29uc3VtZWQoXG5cdHRhYklkOiBudW1iZXIsXG5cdGRvY3VtZW50OiBEb2N1bWVudFJlc3BvbnNlLFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IHNldExhc3REb2N1bWVudCh0YWJJZCwgeyAuLi5kb2N1bWVudCwgY29uc3VtZWQ6IHRydWUgfSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNsZWFyTGFzdERvY3VtZW50KHRhYklkOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKGAke0RPQ19LRVl9OiR7dGFiSWR9YClcbn1cblxuLy8g4pSA4pSAIFJlYWRpbmcgdGhlIGJvZHkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWFkQm9keShcblx0dGFiSWQ6IG51bWJlcixcblx0ZG9jdW1lbnQ6IERvY3VtZW50UmVzcG9uc2UsXG4pOiBQcm9taXNlPENhcHR1cmVkQm9keT4ge1xuXHRjb25zdCByZXN1bHQgPSBhd2FpdCBjaHJvbWUuZGVidWdnZXIuc2VuZENvbW1hbmQ8e1xuXHRcdGJvZHk6IHN0cmluZ1xuXHRcdGJhc2U2NEVuY29kZWQ6IGJvb2xlYW5cblx0fT4oeyB0YWJJZCB9LCAnTmV0d29yay5nZXRSZXNwb25zZUJvZHknLCB7IHJlcXVlc3RJZDogZG9jdW1lbnQucmVxdWVzdElkIH0pXG5cblx0cmV0dXJuIHtcblx0XHR1cmw6IGRvY3VtZW50LnVybCxcblx0XHRzdGF0dXM6IGRvY3VtZW50LnN0YXR1cyxcblx0XHRib2R5OiByZXN1bHQuYmFzZTY0RW5jb2RlZCA/IGRlY29kZUJhc2U2NChyZXN1bHQuYm9keSkgOiByZXN1bHQuYm9keSxcblx0XHRiYXNlNjRFbmNvZGVkOiByZXN1bHQuYmFzZTY0RW5jb2RlZCxcblx0fVxufVxuXG4vKiogQ2hyb21lIGhhbmRzIGJhY2sgYmFzZTY0IGZvciBhbnl0aGluZyBpdCBkb2Vzbid0IGNvbnNpZGVyIHRleHQuICovXG5mdW5jdGlvbiBkZWNvZGVCYXNlNjQoYmFzZTY0OiBzdHJpbmcpOiBzdHJpbmcge1xuXHRjb25zdCBiaW5hcnkgPSBhdG9iKGJhc2U2NClcblx0Y29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShiaW5hcnkubGVuZ3RoKVxuXHRmb3IgKGxldCBpID0gMDsgaSA8IGJpbmFyeS5sZW5ndGg7IGkrKykgYnl0ZXNbaV0gPSBiaW5hcnkuY2hhckNvZGVBdChpKVxuXHRyZXR1cm4gbmV3IFRleHREZWNvZGVyKCkuZGVjb2RlKGJ5dGVzKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gZGVzY3JpYmVFcnJvcihlcnJvcjogdW5rbm93bik6IHN0cmluZyB7XG5cdGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKSByZXR1cm4gZXJyb3IubWVzc2FnZVxuXHRpZiAodHlwZW9mIGVycm9yID09PSAnc3RyaW5nJykgcmV0dXJuIGVycm9yXG5cdHJldHVybiBKU09OLnN0cmluZ2lmeShlcnJvcilcbn1cbiIsIi8qKlxuICogQ2xpY2tpbmcgdGhlIHRvb2xiYXIgaWNvbiBvcGVucyB0aGUgUHJvY2VzcyBSZXN1bHRzIHBhZ2UuXG4gKlxuICogV2hpY2ggb3JpZ2luIHRoYXQgaXMgZGVwZW5kcyBvbiB3aGVyZSB0aGUgc2l0ZSBpcyBiZWluZyBzZXJ2ZWQg4oCUIGxvY2FsaG9zdCBpblxuICogZGV2ZWxvcG1lbnQsIHNjb29wYnVzLnJ1biBpbiBwcm9kdWN0aW9uIOKAlCBzbyB0aGUgYnJpZGdlIHJlY29yZHMgdGhlIG9yaWdpbiBpdFxuICogbGFzdCB0YWxrZWQgdG8gYW5kIHRoYXQncyB3aGF0IGdldHMgb3BlbmVkLiBGYWxsaW5nIGJhY2sgdG8gYSBndWVzcyBvbmx5IHdoZW5cbiAqIHdlJ3ZlIG5ldmVyIHNlZW4gb25lLlxuICovXG5cbmNvbnN0IE9SSUdJTl9LRVkgPSAnbGFzdEFkbWluT3JpZ2luJ1xuY29uc3QgUEFHRV9QQVRIID0gJy9hZG1pbi9wcm9jZXNzLXJlc3VsdHMnXG5cbi8qKiBGaWVsZCB0aGUgYnJpZGdlIGFkZHMgdG8gc2F5IGEgbWVzc2FnZSBjYW1lIGZyb20gYW4gYWRtaW4gcGFnZS4gKi9cbmludGVyZmFjZSBBZG1pblBhZ2VUYWcge1xuXHRmcm9tQWRtaW5QYWdlPzogdHJ1ZVxufVxuXG4vKipcbiAqIFRhZyBhIG1lc3NhZ2UgYXMgY29taW5nIGZyb20gdGhlIGFkbWluIHBhZ2UuIENhbGxlZCBieSB0aGUgYnJpZGdlIG9ubHkuXG4gKlxuICogVGhlIG92ZXJsYXkgY29udGVudCBzY3JpcHQgc2VuZHMgYGNhbmNlbGAsIGByZXRyeWAgYW5kIGBza2lwYCB0b28g4oCUIHRoZSBzYW1lXG4gKiB0eXBlcyB0aGUgYWRtaW4gcGFnZSBzZW5kcyDigJQgc28gYSBtZXNzYWdlJ3MgdHlwZSBzYXlzIG5vdGhpbmcgYWJvdXQgd2hlcmUgaXRcbiAqIGNhbWUgZnJvbSwgYW5kIHJlbWVtYmVyaW5nIHRoZSBzZW5kZXIgb2YgKmFueSogbWVzc2FnZSBtZWFudCB0aGUgaWNvblxuICogXCJsZWFybmVkXCIgcGFya3J1bi5vcmcudWsgdGhlIG1vbWVudCBhIHNjcmFwZSBzdGFydGVkLiBUaGUgYnJpZGdlIHJ1bnMgb24gYWRtaW5cbiAqIG9yaWdpbnMgYW5kIG5vd2hlcmUgZWxzZSwgc28gaXRzIG93biB0YWcgaXMgdGhlIGRlcGVuZGFibGUgc2lnbmFsLlxuICpcbiAqIFNwcmVhZCBmaXJzdCBzbyBhIHBhZ2UgdGhhdCBwdXRzIGBmcm9tQWRtaW5QYWdlYCBpbiBpdHMgb3duIG1lc3NhZ2UgY2FuJ3RcbiAqIHVuc2V0IGl0LlxuICovXG5leHBvcnQgZnVuY3Rpb24gdGFnRnJvbUFkbWluUGFnZTxUIGV4dGVuZHMgb2JqZWN0Pihcblx0bWVzc2FnZTogVCxcbik6IFQgJiBBZG1pblBhZ2VUYWcge1xuXHRyZXR1cm4geyAuLi5tZXNzYWdlLCBmcm9tQWRtaW5QYWdlOiB0cnVlIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGlzRnJvbUFkbWluUGFnZShtZXNzYWdlOiB1bmtub3duKTogYm9vbGVhbiB7XG5cdHJldHVybiAoXG5cdFx0dHlwZW9mIG1lc3NhZ2UgPT09ICdvYmplY3QnICYmXG5cdFx0bWVzc2FnZSAhPT0gbnVsbCAmJlxuXHRcdChtZXNzYWdlIGFzIEFkbWluUGFnZVRhZykuZnJvbUFkbWluUGFnZSA9PT0gdHJ1ZVxuXHQpXG59XG5cbi8qKlxuICogVXNlZCBvbmx5IGJlZm9yZSB0aGUgYnJpZGdlIGhhcyBldmVyIGFubm91bmNlZCBpdHNlbGYgZnJvbSBhIHJlYWwgcGFnZS5cbiAqXG4gKiBQcm9kdWN0aW9uIGZpcnN0OiBvbiBhIGZyZXNoIGluc3RhbGwgdGhlIGxpdmUgc2l0ZSBpcyB0aGUgc2FmZSBndWVzcywgYW5kIGFcbiAqIGRldiB3aWxsIGhhdmUgbG9hZGVkIGxvY2FsaG9zdCB3aXRoaW4gc2Vjb25kcywgYWZ0ZXIgd2hpY2ggdGhlIHJlbWVtYmVyZWRcbiAqIG9yaWdpbiB0YWtlcyBvdmVyLiBPbmUgYnVpbGQgc2VydmVzIGJvdGgg4oCUIHRoZSBtYW5pZmVzdCBncmFudHMgYm90aCBvcmlnaW5zLlxuICovXG5jb25zdCBGQUxMQkFDS19PUklHSU5TID0gWydodHRwczovL3Njb29wYnVzLnJ1bicsICdodHRwOi8vbG9jYWxob3N0OjMwMDUnXVxuXG4vKipcbiAqIFJlbWVtYmVyIHdoZXJlIHRoZSBhZG1pbiBwYWdlIGxpdmVzLCBmcm9tIGFueSBtZXNzYWdlIHRoZSBicmlkZ2Ugc2VuZHMuXG4gKlxuICogRXZlcnkgYWRtaW4gcGFnZSBhbm5vdW5jZXMgaXRzZWxmIHdpdGggYSBgcGluZ2Agb24gbG9hZCwgc28gc2ltcGx5IG9wZW5pbmdcbiAqIGxvY2FsaG9zdDozMDA1IGlzIGVub3VnaCB0byBwb2ludCB0aGUgaWNvbiB0aGVyZSwgYW5kIG9wZW5pbmcgdGhlIGxpdmUgc2l0ZVxuICogcG9pbnRzIGl0IGJhY2suXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZW1lbWJlckFkbWluT3JpZ2luKFxuXHRzZW5kZXJVcmw6IHN0cmluZyB8IHVuZGVmaW5lZCxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRpZiAoIXNlbmRlclVybCkgcmV0dXJuXG5cdHRyeSB7XG5cdFx0Y29uc3QgeyBvcmlnaW4gfSA9IG5ldyBVUkwoc2VuZGVyVXJsKVxuXHRcdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtPUklHSU5fS0VZXTogb3JpZ2luIH0pXG5cdH0gY2F0Y2gge1xuXHRcdC8vIE5vdCBhIFVSTCB3ZSBjYW4gdXNlOyBrZWVwIHdoYXRldmVyIHdlIGhhZC5cblx0fVxufVxuXG5hc3luYyBmdW5jdGlvbiBrbm93bkFkbWluT3JpZ2luKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuXHRjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQ8eyBsYXN0QWRtaW5PcmlnaW4/OiBzdHJpbmcgfT4oXG5cdFx0T1JJR0lOX0tFWSxcblx0KVxuXHRyZXR1cm4gc3RvcmVkLmxhc3RBZG1pbk9yaWdpbiA/PyBudWxsXG59XG5cbi8qKlxuICogRm9jdXMgYW4gZXhpc3RpbmcgUHJvY2VzcyBSZXN1bHRzIHRhYiBpZiB0aGVyZSBpcyBvbmUsIG90aGVyd2lzZSBvcGVuIGl0LlxuICpcbiAqIFJldXNpbmcgdGhlIHRhYiBtYXR0ZXJzOiBhIHNjcmFwZSdzIGNhcHR1cmVkIGZpbGVzIGFyZSBoZWxkIGJ5IHRoZSBwYWdlLCBzb1xuICogb3BlbmluZyBhIHNlY29uZCBjb3B5IHdvdWxkIHNob3cgYW4gZW1wdHkgb25lIG5leHQgdG8gdGhlIG9uZSBkb2luZyB0aGUgd29yay5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG9wZW5BZG1pblBhZ2UoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IG9yaWdpbnMgPSBbYXdhaXQga25vd25BZG1pbk9yaWdpbigpLCAuLi5GQUxMQkFDS19PUklHSU5TXS5maWx0ZXIoXG5cdFx0KG9yaWdpbik6IG9yaWdpbiBpcyBzdHJpbmcgPT4gISFvcmlnaW4sXG5cdClcblxuXHRmb3IgKGNvbnN0IG9yaWdpbiBvZiBvcmlnaW5zKSB7XG5cdFx0Y29uc3QgZXhpc3RpbmcgPSBhd2FpdCBjaHJvbWUudGFic1xuXHRcdFx0LnF1ZXJ5KHsgdXJsOiBgJHtvcmlnaW59JHtQQUdFX1BBVEh9KmAgfSlcblx0XHRcdC5jYXRjaCgoKSA9PiBbXSlcblxuXHRcdGNvbnN0IHRhYiA9IGV4aXN0aW5nLmZpbmQoKGNhbmRpZGF0ZSkgPT4gY2FuZGlkYXRlLmlkICE9PSB1bmRlZmluZWQpXG5cdFx0aWYgKHRhYj8uaWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0YXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKHRhYi5pZCwgeyBhY3RpdmU6IHRydWUgfSlcblx0XHRcdGlmICh0YWIud2luZG93SWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0XHRhd2FpdCBjaHJvbWUud2luZG93cy51cGRhdGUodGFiLndpbmRvd0lkLCB7IGZvY3VzZWQ6IHRydWUgfSlcblx0XHRcdH1cblx0XHRcdHJldHVyblxuXHRcdH1cblx0fVxuXG5cdGNvbnN0IG9yaWdpbiA9IG9yaWdpbnNbMF1cblx0YXdhaXQgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiBgJHtvcmlnaW59JHtQQUdFX1BBVEh9YCwgYWN0aXZlOiB0cnVlIH0pXG59XG4iLCIvLyBTaGFyZWQgUGFya3J1biBIVE1MIHBhcnNpbmcgbG9naWMuXG4vLyBVc2VkIGJ5IHRoZSBzY3JhcGluZyBzY3JpcHRzIChhcHBzL2FwaS9zY3JpcHRzKSBhbmQgYnkgdGhlIFByb2Nlc3MgUmVzdWx0c1xuLy8gYWRtaW4gcGFnZSwgd2hpY2ggcnVucyB0aGVzZSBzYW1lIHBhcnNlcnMgb3ZlciBoYW5kLWRvd25sb2FkZWQgcGFnZXMuXG4vL1xuLy8gUGFyc2VzOiAvcGFya3J1bm5lci97aWR9L2FsbC8g4oaSIHJ1bm5lciBpbmZvICsgYWxsIHJ1biByZXN1bHRzXG4vL1xuLy8gVHdvIGZsYXZvdXJzIG9mIEhUTUwgcmVhY2ggdGhlc2UgcGFyc2VyczogdGhlIERPTSBzZXJpYWxpc2VkIGJ5IFBsYXl3cmlnaHRcbi8vIChlbnRpdGllcyBsaWtlICZuYnNwOywgRW5nbGlzaCBVSSB3aGVuIGZldGNoZWQgZnJvbSBwYXJrcnVuLm9yZy51aykgYW5kIHBhZ2Vcbi8vIHNvdXJjZSBzYXZlZCBzdHJhaWdodCBmcm9tIGEgYnJvd3NlciAobGl0ZXJhbCBub24tYnJlYWtpbmcgc3BhY2VzLCBhbmQgYW55XG4vLyBwYXJrcnVuIGxvY2FsZSdzIFVJIHRleHQpLiBFdmVyeXRoaW5nIGhlcmUga2V5cyBvZmYgc3RydWN0dXJlIHJhdGhlciB0aGFuXG4vLyB3b3JkaW5nIHNvIGJvdGggd29yay5cblxuLy8gLS0tIFR5cGVzIC0tLVxuXG5leHBvcnQgaW50ZXJmYWNlIFJ1bm5lckluZm8ge1xuXHRuYW1lOiBzdHJpbmdcblx0LyoqIEF0aGxldGUgSUQgcmVhZCBiYWNrIG9mZiB0aGUgcGFnZSwgZS5nLiBcIjgwNzA4MjFcIi4gRW1wdHkgaWYgbm90IGZvdW5kLiAqL1xuXHRwYXJrcnVuSWQ6IHN0cmluZ1xuXHR0b3RhbFJ1bnM6IG51bWJlclxuXHR0b3RhbEp1bmlvclJ1bnM6IG51bWJlclxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJ1blJlc3VsdCB7XG5cdGV2ZW50OiBzdHJpbmcgLy8gZXZlbnRJZCwgZS5nLiBcImhhZ2FcIlxuXHRldmVudE5hbWU6IHN0cmluZyAvLyBkaXNwbGF5IG5hbWUsIGUuZy4gXCJIYWdhXCIgKHVzZWQgYnkgZXh0cmFjdEV2ZW50cywgbm90IHN0b3JlZCBpbiBydW5SZXN1bHRzKVxuXHRldmVudFVybDogc3RyaW5nIC8vIGUuZy4gXCJodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvcmVzdWx0cy8zOTQvXCJcblx0ZXZlbnROdW1iZXI6IG51bWJlclxuXHRwb3NpdGlvbjogbnVtYmVyXG5cdHRpbWU6IHN0cmluZ1xuXHRhZ2VHcmFkZTogc3RyaW5nXG5cdGRhdGU6IHN0cmluZyAvLyBZWVlZLU1NLUREXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgRXZlbnRJbmZvIHtcblx0ZXZlbnRJZDogc3RyaW5nIC8vIGUuZy4gXCJoYWdhXCJcblx0bmFtZTogc3RyaW5nIC8vIGUuZy4gXCJIYWdhXCJcblx0dXJsOiBzdHJpbmcgLy8gZS5nLiBcImh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzL1wiXG5cdGNvdW50cnk6IHN0cmluZyAvLyBlLmcuIFwiU0VcIlxufVxuXG4vLyAtLS0gQ291bnRyeSBjb2RlIG1hcHBpbmcgZnJvbSBwYXJrcnVuIGRvbWFpbiAtLS1cblxuY29uc3QgTkFNSUJJQV9FVkVOVFMgPSBuZXcgU2V0KFsnd2FsdmlzYmF5JywgJ3dpbmRob2VrJywgJ3N3YWtvcG11bmQnXSlcblxuZXhwb3J0IGNvbnN0IERPTUFJTl9UT19DT1VOVFJZOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuXHQncGFya3J1bi5jb20uYXUnOiAnQVUnLFxuXHQncGFya3J1bi5jby5hdCc6ICdBVCcsXG5cdCdwYXJrcnVuLmNhJzogJ0NBJyxcblx0J3BhcmtydW4uZGsnOiAnREsnLFxuXHQncGFya3J1bi5maSc6ICdGSScsXG5cdCdwYXJrcnVuLmNvbS5kZSc6ICdERScsXG5cdCdwYXJrcnVuLmllJzogJ0lFJyxcblx0J3BhcmtydW4uaXQnOiAnSVQnLFxuXHQncGFya3J1bi5qcCc6ICdKUCcsXG5cdCdwYXJrcnVuLmx0JzogJ0xUJyxcblx0J3BhcmtydW4ubXknOiAnTVknLFxuXHQncGFya3J1bi5jby5ubCc6ICdOTCcsXG5cdCdwYXJrcnVuLmNvLm56JzogJ05aJyxcblx0J3BhcmtydW4ubm8nOiAnTk8nLFxuXHQncGFya3J1bi5wbCc6ICdQTCcsXG5cdCdwYXJrcnVuLnNnJzogJ1NHJyxcblx0J3BhcmtydW4uY28uemEnOiAnWkEnLFxuXHQncGFya3J1bi5zZSc6ICdTRScsXG5cdCdwYXJrcnVuLm9yZy51ayc6ICdVSycsXG5cdCdwYXJrcnVuLnVzJzogJ1VTJyxcbn1cblxuZnVuY3Rpb24gZ2V0Q291bnRyeUZyb21VcmwodXJsOiBzdHJpbmcsIGV2ZW50SWQ6IHN0cmluZyk6IHN0cmluZyB7XG5cdHRyeSB7XG5cdFx0Y29uc3QgaG9zdG5hbWUgPSBuZXcgVVJMKHVybCkuaG9zdG5hbWUucmVwbGFjZSgvXnd3d1xcLi8sICcnKVxuXHRcdGlmIChob3N0bmFtZSA9PT0gJ3BhcmtydW4uY28uemEnICYmIE5BTUlCSUFfRVZFTlRTLmhhcyhldmVudElkKSkge1xuXHRcdFx0cmV0dXJuICdOQSdcblx0XHR9XG5cdFx0cmV0dXJuIERPTUFJTl9UT19DT1VOVFJZW2hvc3RuYW1lXSA/PyAnPz8nXG5cdH0gY2F0Y2gge1xuXHRcdHJldHVybiAnPz8nXG5cdH1cbn1cblxuLyoqXG4gKiBFeHRyYWN0IHVuaXF1ZSBldmVudCBpbmZvIGZyb20gcGFyc2VkIHJ1biByZXN1bHRzLlxuICogRGVyaXZlcyBldmVudElkLCBuYW1lLCBiYXNlIFVSTCwgYW5kIGNvdW50cnkgZnJvbSB0aGUgcmVzdWx0IFVSTHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0RXZlbnRzKHJ1blJlc3VsdHM6IFJ1blJlc3VsdFtdKTogRXZlbnRJbmZvW10ge1xuXHRjb25zdCBzZWVuID0gbmV3IE1hcDxzdHJpbmcsIEV2ZW50SW5mbz4oKVxuXG5cdGZvciAoY29uc3QgcmVzdWx0IG9mIHJ1blJlc3VsdHMpIHtcblx0XHRpZiAoIXJlc3VsdC5ldmVudFVybCB8fCAhcmVzdWx0LmV2ZW50KSBjb250aW51ZVxuXHRcdGlmIChzZWVuLmhhcyhyZXN1bHQuZXZlbnQpKSBjb250aW51ZVxuXG5cdFx0Ly8gVVJMIGxvb2tzIGxpa2UgaHR0cHM6Ly93d3cucGFya3J1bi5zZS9oYWdhL3Jlc3VsdHMvMzk0L1xuXHRcdC8vIFdlIHdhbnQgYmFzZTogaHR0cHM6Ly93d3cucGFya3J1bi5zZS9oYWdhL1xuXHRcdGNvbnN0IHVybE1hdGNoID0gcmVzdWx0LmV2ZW50VXJsLm1hdGNoKFxuXHRcdFx0L14oaHR0cHM/OlxcL1xcL1teL10rXFwvW14vXSspXFwvcmVzdWx0c1xcLz9cXGQqXFwvPyQvLFxuXHRcdClcblx0XHRpZiAoIXVybE1hdGNoKSBjb250aW51ZVxuXG5cdFx0Y29uc3QgYmFzZVVybCA9IGAke3VybE1hdGNoWzFdfS9gXG5cblx0XHRzZWVuLnNldChyZXN1bHQuZXZlbnQsIHtcblx0XHRcdGV2ZW50SWQ6IHJlc3VsdC5ldmVudCxcblx0XHRcdG5hbWU6IHJlc3VsdC5ldmVudE5hbWUsXG5cdFx0XHR1cmw6IGJhc2VVcmwsXG5cdFx0XHRjb3VudHJ5OiBnZXRDb3VudHJ5RnJvbVVybChyZXN1bHQuZXZlbnRVcmwsIHJlc3VsdC5ldmVudCksXG5cdFx0fSlcblx0fVxuXG5cdHJldHVybiBBcnJheS5mcm9tKHNlZW4udmFsdWVzKCkpXG59XG5cbi8vIC0tLSBIZWxwZXI6IHN0cmlwIEhUTUwgdGFncyAtLS1cblxuZnVuY3Rpb24gc3RyaXBUYWdzKGh0bWw6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiBodG1sLnJlcGxhY2UoLzxbXj5dKj4vZywgJycpLnRyaW0oKVxufVxuXG4vLyAtLS0gSGVscGVyOiBkZWNvZGUgdGhlIGhhbmRmdWwgb2YgZW50aXRpZXMgcGFya3J1biBlbWl0cyBpbiBjbHViIG5hbWVzIC0tLVxuXG5jb25zdCBFTlRJVElFUzogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcblx0JyZhbXA7JzogJyYnLFxuXHQnJmx0Oyc6ICc8Jyxcblx0JyZndDsnOiAnPicsXG5cdCcmcXVvdDsnOiAnXCInLFxuXHQnJiMwMzk7JzogXCInXCIsXG5cdCcmYXBvczsnOiBcIidcIixcblx0JyZuYnNwOyc6ICcgJyxcbn1cblxuZnVuY3Rpb24gZGVjb2RlRW50aXRpZXModGV4dDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIHRleHRcblx0XHQucmVwbGFjZSgvJig/OmFtcHxsdHxndHxxdW90fCMwMzl8YXBvc3xuYnNwKTsvZywgKG0pID0+IEVOVElUSUVTW21dID8/IG0pXG5cdFx0LnJlcGxhY2UoLyYjKFxcZCspOy9nLCAoXywgY29kZSkgPT5cblx0XHRcdFN0cmluZy5mcm9tQ29kZVBvaW50KE51bWJlci5wYXJzZUludChjb2RlLCAxMCkpLFxuXHRcdClcblx0XHQucmVwbGFjZSgvXFx1MDBhMC9nLCAnICcpXG59XG5cbi8vIC0tLSBQYXJzZSBydW5uZXIgaW5mbyBmcm9tIHRoZSAvYWxsLyBwYWdlIC0tLVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VSdW5uZXJEYXRhKGh0bWw6IHN0cmluZyk6IFJ1bm5lckluZm8ge1xuXHQvLyBOYW1lOiA8aDI+Sm9zaCBUSE9NUFNPTiZuYnNwOzxzcGFuIHRpdGxlPVwicGFya3J1biBJRFwiPihBODA3MDgyMSk8L3NwYW4+PC9oMj5cblx0Ly8gVGhlIElEIHNwYW4gaGFzIHRvIGJlIHRoZXJlIGZvciB1cyB0byB0cnVzdCB0aGUgaGVhZGluZyDigJQgYSBibG9ja2VkIG9yXG5cdC8vIGVycm9yIHBhZ2UgY2FuIGNhcnJ5IGFuIHVucmVsYXRlZCA8aDI+LCBhbmQgY2FsbGVycyB1c2UgdGhlIFwiVW5rbm93blwiXG5cdC8vIG5hbWUgYXMgdGhlaXIgc2lnbmFsIHRvIHJldHJ5LlxuXHRjb25zdCBoZWFkaW5nID0gaHRtbC5tYXRjaCgvPGgyPihbXFxzXFxTXSo/KTxcXC9oMj4vKT8uWzFdID8/ICcnXG5cdGNvbnN0IGlkTWF0Y2ggPSBoZWFkaW5nLm1hdGNoKC9cXChcXHMqQT8oXFxkKylcXHMqXFwpLylcblx0Y29uc3QgaGVhZGluZ05hbWUgPSBkZWNvZGVFbnRpdGllcyhzdHJpcFRhZ3MoaGVhZGluZykpXG5cdFx0LnJlcGxhY2UoL1xcKFxccypBP1xcZCtcXHMqXFwpLywgJycpXG5cdFx0LnRyaW0oKVxuXHRjb25zdCBuYW1lID0gaWRNYXRjaCAmJiBoZWFkaW5nTmFtZSA/IGhlYWRpbmdOYW1lIDogJ1Vua25vd24nXG5cblx0Ly8gVG90YWwgcnVuczogPGgzPjEzNiBwYXJrcnVucyB0b3RhbDwvaDM+ICBvciAgPGgzPlxcbiAgMTM2IHBhcmtydW5zIHRvdGFsdFxcbjwvaDM+XG5cdC8vIFdpdGgganVuaW9yIHBhcmtydW5zOiA8aDM+MTAgcGFya3J1bnMgJmFtcDsgNCBqdW5pb3IgcGFya3J1bnMgdG90YWx0PC9oMz5cblx0Y29uc3QgdG90YWxNYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0LzxoMz5cXHMqKFxcZCspXFxzKnBhcmtydW5zP1xccyooPzomYW1wO3wmKT9cXHMqKD86KFxcZCspXFxzKmp1bmlvclxccypwYXJrcnVucz9cXHMqKT90b3RhbC9pLFxuXHQpXG5cdGNvbnN0IHRvdGFsUnVucyA9IHRvdGFsTWF0Y2ggPyBOdW1iZXIucGFyc2VJbnQodG90YWxNYXRjaFsxXSwgMTApIDogMFxuXHRjb25zdCB0b3RhbEp1bmlvclJ1bnMgPSB0b3RhbE1hdGNoPy5bMl1cblx0XHQ/IE51bWJlci5wYXJzZUludCh0b3RhbE1hdGNoWzJdLCAxMClcblx0XHQ6IDBcblxuXHRyZXR1cm4ge1xuXHRcdG5hbWUsXG5cdFx0cGFya3J1bklkOiBpZE1hdGNoID8gaWRNYXRjaFsxXSA6ICcnLFxuXHRcdHRvdGFsUnVucyxcblx0XHR0b3RhbEp1bmlvclJ1bnMsXG5cdH1cbn1cblxuLy8gLS0tIFBhcnNlIGFsbCBydW4gcmVzdWx0cyBmcm9tIHRoZSAvYWxsLyBwYWdlIC0tLVxuXG4vKipcbiAqIFRoZSBgPHRib2R5PmAgYmxvY2tzIHRoYXQgY291bGQgaG9sZCB0aGUgYWxsLXJlc3VsdHMgdGFibGUsIGJlc3QgY2FuZGlkYXRlXG4gKiBmaXJzdC4gVGhlIHBhZ2UgYWxzbyBjYXJyaWVzIGEgc3VtbWFyeS1zdGF0aXN0aWNzIGFuZCBhIHllYXJseS1iZXN0cyB0YWJsZVxuICogd2l0aCB0aGUgc2FtZSBgaWQ9XCJyZXN1bHRzXCJgLCBhbmQgdGhlIGNhcHRpb24gbmFtaW5nIHRoZSByaWdodCBvbmUgaXNcbiAqIGxvY2FsaXNlZCAoXCJBbGwgUmVzdWx0c1wiIC8gXCLigJMgQWxsYSByZXN1bHRhdFwiKSwgc28gd2UgdHJ5IHRoZSBFbmdsaXNoIGNhcHRpb25cbiAqIGZpcnN0IGFuZCB0aGVuIGZhbGwgYmFjayB0byBldmVyeSByZXN1bHRzIHRhYmxlLCBsYXN0IG9uZSBmaXJzdCAodGhlXG4gKiBhbGwtcmVzdWx0cyB0YWJsZSBpcyB0aGUgbGFzdCBvbiB0aGUgcGFnZSkuXG4gKi9cbmZ1bmN0aW9uIGZpbmRSZXN1bHRUYm9kaWVzKGh0bWw6IHN0cmluZyk6IHN0cmluZ1tdIHtcblx0Y29uc3QgY2FuZGlkYXRlczogc3RyaW5nW10gPSBbXVxuXG5cdGNvbnN0IGNhcHRpb25NYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0L0FsbFxccytSZXN1bHRzXFxzKjxcXC9jYXB0aW9uPltcXHNcXFNdKj88dGJvZHlbXj5dKj4oW1xcc1xcU10qPyk8XFwvdGJvZHk+L2ksXG5cdClcblx0aWYgKGNhcHRpb25NYXRjaCkgY2FuZGlkYXRlcy5wdXNoKGNhcHRpb25NYXRjaFsxXSlcblxuXHRjb25zdCB0YWJsZXMgPSBbXG5cdFx0Li4uaHRtbC5tYXRjaEFsbCgvPHRhYmxlW14+XSppZD1cInJlc3VsdHNcIltePl0qPihbXFxzXFxTXSo/KTxcXC90YWJsZT4vZ2kpLFxuXHRdXG5cdGZvciAoY29uc3QgdGFibGUgb2YgdGFibGVzLnJldmVyc2UoKSkge1xuXHRcdGNvbnN0IHRib2R5ID0gdGFibGVbMV0ubWF0Y2goLzx0Ym9keVtePl0qPihbXFxzXFxTXSo/KTxcXC90Ym9keT4vaSlcblx0XHRjYW5kaWRhdGVzLnB1c2godGJvZHkgPyB0Ym9keVsxXSA6IHRhYmxlWzFdKVxuXHR9XG5cblx0cmV0dXJuIGNhbmRpZGF0ZXNcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlUnVuUmVzdWx0cyhodG1sOiBzdHJpbmcpOiBSdW5SZXN1bHRbXSB7XG5cdGZvciAoY29uc3QgdGJvZHkgb2YgZmluZFJlc3VsdFRib2RpZXMoaHRtbCkpIHtcblx0XHRjb25zdCByZXN1bHRzID0gcGFyc2VSZXN1bHRSb3dzKHRib2R5KVxuXHRcdGlmIChyZXN1bHRzLmxlbmd0aCA+IDApIHJldHVybiByZXN1bHRzXG5cdH1cblx0cmV0dXJuIFtdXG59XG5cbmZ1bmN0aW9uIHBhcnNlUmVzdWx0Um93cyh0Ym9keTogc3RyaW5nKTogUnVuUmVzdWx0W10ge1xuXHRjb25zdCByZXN1bHRzOiBSdW5SZXN1bHRbXSA9IFtdXG5cblx0Ly8gTWF0Y2ggZWFjaCByb3c6IDx0ciBjbGFzcz1cIi4uLlwiPjx0ZD4uLi48L3RkPjx0ZD4uLi48L3RkPi4uLjwvdHI+XG5cdGNvbnN0IHJvd1JlZ2V4ID0gLzx0cltePl0qPihbXFxzXFxTXSo/KTxcXC90cj4vZ2lcblxuXHRmb3IgKGNvbnN0IHJvd01hdGNoIG9mIHRib2R5Lm1hdGNoQWxsKHJvd1JlZ2V4KSkge1xuXHRcdGNvbnN0IHJvdyA9IHJvd01hdGNoWzFdXG5cblx0XHQvLyBFeHRyYWN0IGNlbGxzXG5cdFx0Y29uc3QgY2VsbFJlZ2V4ID0gLzx0ZFtePl0qPihbXFxzXFxTXSo/KTxcXC90ZD4vZ2lcblx0XHRjb25zdCBjZWxsczogc3RyaW5nW10gPSBbXVxuXHRcdGZvciAoY29uc3QgY2VsbE1hdGNoIG9mIHJvdy5tYXRjaEFsbChjZWxsUmVnZXgpKSB7XG5cdFx0XHRjZWxscy5wdXNoKGNlbGxNYXRjaFsxXSlcblx0XHR9XG5cblx0XHQvLyBDb2x1bW5zOiBFdmVudCwgUnVuIERhdGUsIFJ1biBOdW1iZXIsIFBvcywgVGltZSwgQWdlIEdyYWRlLCBQQj9cblx0XHRpZiAoY2VsbHMubGVuZ3RoIDwgNikgY29udGludWVcblxuXHRcdC8vIEV2ZW50IG5hbWUgKyBVUkw6IDxhIGhyZWY9XCJodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvcmVzdWx0cy8zOTQvXCI+SGFnYTwvYT5cblx0XHRjb25zdCBldmVudExpbmtNYXRjaCA9IGNlbGxzWzBdLm1hdGNoKFxuXHRcdFx0LzxhXFxzK2hyZWY9XCIoW15cIl0rKVwiW14+XSo+KFtePF0rKTxcXC9hPi8sXG5cdFx0KVxuXHRcdGNvbnN0IGV2ZW50VXJsID0gZXZlbnRMaW5rTWF0Y2ggPyBldmVudExpbmtNYXRjaFsxXS50cmltKCkgOiAnJ1xuXHRcdGNvbnN0IGV2ZW50TmFtZSA9IGV2ZW50TGlua01hdGNoXG5cdFx0XHQ/IGRlY29kZUVudGl0aWVzKGV2ZW50TGlua01hdGNoWzJdKS50cmltKClcblx0XHRcdDogZGVjb2RlRW50aXRpZXMoc3RyaXBUYWdzKGNlbGxzWzBdKSlcblxuXHRcdC8vIE9ubHkgdGhlIGFsbC1yZXN1bHRzIHRhYmxlIGxpbmtzIGVhY2ggcm93IHRvIGFuIGV2ZW50J3MgcmVzdWx0cyBwYWdlIOKAlFxuXHRcdC8vIHRoaXMgaXMgd2hhdCBydWxlcyBvdXQgdGhlIHN0YXRpc3RpY3MgdGFibGVzIHNoYXJpbmcgaWQ9XCJyZXN1bHRzXCIuXG5cdFx0aWYgKCEvXFwvcmVzdWx0c1xcLy8udGVzdChldmVudFVybCkpIGNvbnRpbnVlXG5cblx0XHQvLyBEZXJpdmUgZXZlbnRJZCBmcm9tIFVSTCAoZS5nLiBcImhhZ2FcIiBmcm9tIFwiLi4uL2hhZ2EvcmVzdWx0cy8zOTQvXCIpXG5cdFx0Y29uc3QgZXZlbnRJZE1hdGNoID0gZXZlbnRVcmwubWF0Y2goL1xcLyhbXi9dKylcXC9yZXN1bHRzXFwvLylcblx0XHRjb25zdCBldmVudCA9IGV2ZW50SWRNYXRjaFxuXHRcdFx0PyBldmVudElkTWF0Y2hbMV1cblx0XHRcdDogZXZlbnROYW1lLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvW15hLXowLTldL2csICcnKVxuXG5cdFx0Ly8gUnVuIERhdGU6IDxhIGhyZWY9XCIuLi5cIj48c3BhbiBjbGFzcz1cImZvcm1hdC1kYXRlXCI+MDcvMDMvMjAyNjwvc3Bhbj48L2E+XG5cdFx0Ly8gU2F2ZWQgcGFnZXMgbWF5IGNhcnJ5IGFuIGFscmVhZHktSVNPIGRhdGUgaW5zdGVhZCwgZGVwZW5kaW5nIG9uIHdoaWNoXG5cdFx0Ly8gbG9jYWxlIHJlZm9ybWF0dGVkIHRoZSBjZWxsLlxuXHRcdGNvbnN0IGRhdGUgPSBwYXJzZVJlc3VsdERhdGUoY2VsbHNbMV0pXG5cblx0XHQvLyBSdW4gTnVtYmVyOiA8YSBocmVmPVwiLi4uXCI+Mzk0PC9hPlxuXHRcdGNvbnN0IGV2ZW50TnVtYmVyID0gTnVtYmVyLnBhcnNlSW50KHN0cmlwVGFncyhjZWxsc1syXSksIDEwKSB8fCAwXG5cblx0XHQvLyBQb3NpdGlvblxuXHRcdGNvbnN0IHBvc2l0aW9uID0gTnVtYmVyLnBhcnNlSW50KHN0cmlwVGFncyhjZWxsc1szXSksIDEwKSB8fCAwXG5cblx0XHQvLyBUaW1lIChlLmcuIFwiMTk6MzlcIiBvciBcIjAxOjA4OjMwXCIpXG5cdFx0Y29uc3QgdGltZSA9IHN0cmlwVGFncyhjZWxsc1s0XSlcblxuXHRcdC8vIEFnZSBHcmFkZSAoZS5nLiBcIjY3LjA5JVwiKVxuXHRcdGNvbnN0IGFnZUdyYWRlID0gc3RyaXBUYWdzKGNlbGxzWzVdKVxuXG5cdFx0aWYgKGV2ZW50TmFtZSAmJiB0aW1lKSB7XG5cdFx0XHRyZXN1bHRzLnB1c2goe1xuXHRcdFx0XHRldmVudCxcblx0XHRcdFx0ZXZlbnROYW1lLFxuXHRcdFx0XHRldmVudFVybCxcblx0XHRcdFx0ZXZlbnROdW1iZXIsXG5cdFx0XHRcdHBvc2l0aW9uLFxuXHRcdFx0XHR0aW1lLFxuXHRcdFx0XHRhZ2VHcmFkZSxcblx0XHRcdFx0ZGF0ZSxcblx0XHRcdH0pXG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHJlc3VsdHNcbn1cblxuLyoqIFJlYWQgYSBydW4gZGF0ZSBjZWxsIGFzIFlZWVktTU0tREQuIEFjY2VwdHMgREQvTU0vWVlZWSBhbmQgWVlZWS1NTS1ERC4gKi9cbmZ1bmN0aW9uIHBhcnNlUmVzdWx0RGF0ZShjZWxsOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRjb25zdCBkbXkgPSBjZWxsLm1hdGNoKC8+KFxcZHsyfSlcXC8oXFxkezJ9KVxcLyhcXGR7NH0pPC8pXG5cdGlmIChkbXkpIHJldHVybiBgJHtkbXlbM119LSR7ZG15WzJdfS0ke2RteVsxXX1gXG5cblx0Y29uc3QgaXNvID0gY2VsbC5tYXRjaCgvPihcXGR7NH0tXFxkezJ9LVxcZHsyfSk8Lylcblx0aWYgKGlzbykgcmV0dXJuIGlzb1sxXVxuXG5cdHJldHVybiBzdHJpcFRhZ3MoY2VsbClcbn1cblxuLy8gLS0tIFBhcnNlIHRoZSBcImxhcmdlc3QgY2x1YnNcIiBsZWFndWUgdGFibGUgLS0tXG4vLyBQYXJzZXMgaHR0cHM6Ly93d3cucGFya3J1bi5zZS9yZXN1bHRzL2xhcmdlc3RjbHVicy9cbi8vIENvbHVtbnM6IEtsdWJiIHwgKHNwYWNlcikgfCBBbnRhbCBkZWx0YWdhcmUgfCBBbnRhbCBzdGFydGVyIHwgS2x1YmJlbnMgaGVtc2lkYVxuXG5leHBvcnQgaW50ZXJmYWNlIExhcmdlc3RDbHViRW50cnkge1xuXHQvKiogcGFya3J1bidzIGludGVybmFsIGNsdWIgaWQsIGZyb20gdGhlIGAjZmVhdHVyZUNsdWI9NTAzMTBgIGFuY2hvci4gKi9cblx0Y2x1YklkPzogc3RyaW5nXG5cdG5hbWU6IHN0cmluZ1xuXHQvKiogXCJBbnRhbCBkZWx0YWdhcmVcIiDigJQgZGlzdGluY3QgY2x1YiBtZW1iZXJzIHdobyBoYXZlIHJ1bi4gKi9cblx0bWVtYmVyczogbnVtYmVyXG5cdC8qKiBcIkFudGFsIHN0YXJ0ZXJcIiDigJQgdG90YWwgcnVucyBzdGFydGVkIGJ5IGNsdWIgbWVtYmVycy4gKi9cblx0ZXZlbnRzOiBudW1iZXJcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlTGFyZ2VzdENsdWJzKGh0bWw6IHN0cmluZyk6IExhcmdlc3RDbHViRW50cnlbXSB7XG5cdGNvbnN0IGVudHJpZXM6IExhcmdlc3RDbHViRW50cnlbXSA9IFtdXG5cblx0Y29uc3QgdGFibGVNYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0Lzx0YWJsZVtePl0qaWQ9XCJyZXN1bHRzXCJbXj5dKj5bXFxzXFxTXSo/PHRib2R5W14+XSo+KFtcXHNcXFNdKj8pPFxcL3Rib2R5Pi9pLFxuXHQpXG5cdGlmICghdGFibGVNYXRjaCkgcmV0dXJuIGVudHJpZXNcblxuXHRjb25zdCB0Ym9keSA9IHRhYmxlTWF0Y2hbMV1cblxuXHRmb3IgKGNvbnN0IHJvd01hdGNoIG9mIHRib2R5Lm1hdGNoQWxsKC88dHJbXj5dKj4oW1xcc1xcU10qPyk8XFwvdHI+L2dpKSkge1xuXHRcdGNvbnN0IGNlbGxzOiBzdHJpbmdbXSA9IFtdXG5cdFx0Zm9yIChjb25zdCBjZWxsTWF0Y2ggb2Ygcm93TWF0Y2hbMV0ubWF0Y2hBbGwoXG5cdFx0XHQvPHRkW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RkPi9naSxcblx0XHQpKSB7XG5cdFx0XHRjZWxscy5wdXNoKGNlbGxNYXRjaFsxXSlcblx0XHR9XG5cblx0XHRpZiAoY2VsbHMubGVuZ3RoIDwgNCkgY29udGludWVcblxuXHRcdGNvbnN0IG5hbWUgPSBkZWNvZGVFbnRpdGllcyhzdHJpcFRhZ3MoY2VsbHNbMF0pKVxuXHRcdGlmICghbmFtZSkgY29udGludWVcblxuXHRcdGNvbnN0IGNsdWJJZE1hdGNoID0gY2VsbHNbMF0ubWF0Y2goLyNmZWF0dXJlQ2x1Yj0oXFxkKykvKVxuXHRcdGNvbnN0IG1lbWJlcnMgPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzJdKSwgMTApXG5cdFx0Y29uc3QgZXZlbnRzID0gTnVtYmVyLnBhcnNlSW50KHN0cmlwVGFncyhjZWxsc1szXSksIDEwKVxuXG5cdFx0aWYgKE51bWJlci5pc05hTihtZW1iZXJzKSB8fCBOdW1iZXIuaXNOYU4oZXZlbnRzKSkgY29udGludWVcblxuXHRcdGVudHJpZXMucHVzaCh7XG5cdFx0XHRjbHViSWQ6IGNsdWJJZE1hdGNoID8gY2x1YklkTWF0Y2hbMV0gOiB1bmRlZmluZWQsXG5cdFx0XHRuYW1lLFxuXHRcdFx0bWVtYmVycyxcblx0XHRcdGV2ZW50cyxcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIGVudHJpZXNcbn1cblxuLy8gLS0tIFR5cGVzIGZvciBldmVudCBwYWdlIHBhcnNpbmcgLS0tXG5cbmV4cG9ydCBpbnRlcmZhY2UgRXZlbnRIaXN0b3J5RW50cnkge1xuXHRldmVudE51bWJlcjogbnVtYmVyXG5cdGRhdGU6IHN0cmluZyAvLyBZWVlZLU1NLUREXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVm9sdW50ZWVyRW50cnkge1xuXHRwYXJrcnVuSWQ6IHN0cmluZ1xuXHRyb2xlczogc3RyaW5nW11cbn1cblxuLy8gLS0tIFBhcnNlIGV2ZW50IGhpc3RvcnkgcGFnZSAtLS1cbi8vIFBhcnNlcyBodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvcmVzdWx0cy9ldmVudGhpc3RvcnkvXG4vLyBFYWNoIHJvdzogPHRyIGNsYXNzPVwiUmVzdWx0cy10YWJsZS1yb3dcIiBkYXRhLXBhcmtydW49XCIzOTZcIiBkYXRhLWRhdGU9XCIyMDI2LTAzLTIxXCIgLi4uPlxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VFdmVudEhpc3RvcnkoaHRtbDogc3RyaW5nKTogRXZlbnRIaXN0b3J5RW50cnlbXSB7XG5cdGNvbnN0IGVudHJpZXM6IEV2ZW50SGlzdG9yeUVudHJ5W10gPSBbXVxuXG5cdGNvbnN0IHJvd1JlZ2V4ID1cblx0XHQvPHRyXFxzK2NsYXNzPVwiUmVzdWx0cy10YWJsZS1yb3dcIltePl0qZGF0YS1wYXJrcnVuPVwiKFxcZCspXCJbXj5dKmRhdGEtZGF0ZT1cIihcXGR7NH0tXFxkezJ9LVxcZHsyfSlcIltePl0qPi9naVxuXG5cdGZvciAoY29uc3QgbWF0Y2ggb2YgaHRtbC5tYXRjaEFsbChyb3dSZWdleCkpIHtcblx0XHRlbnRyaWVzLnB1c2goe1xuXHRcdFx0ZXZlbnROdW1iZXI6IE51bWJlci5wYXJzZUludChtYXRjaFsxXSwgMTApLFxuXHRcdFx0ZGF0ZTogbWF0Y2hbMl0sXG5cdFx0fSlcblx0fVxuXG5cdC8vIFNvcnQgZGVzY2VuZGluZyBieSBldmVudCBudW1iZXIgKG1vc3QgcmVjZW50IGZpcnN0KVxuXHRlbnRyaWVzLnNvcnQoKGEsIGIpID0+IGIuZXZlbnROdW1iZXIgLSBhLmV2ZW50TnVtYmVyKVxuXHRyZXR1cm4gZW50cmllc1xufVxuXG4vLyAtLS0gUGFyc2UgZXZlbnQgZGF0ZSBmcm9tIGEgc2luZ2xlIGV2ZW50IHJlc3VsdHMgcGFnZSAtLS1cbi8vIFdpdGggU3dlZGlzaCBsb2NhbGUgKHN2LVNFKSB0aGUgZm9ybWF0LWRhdGUgc3BhbiBjb250YWlucyBZWVlZLU1NLURELlxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VFdmVudERhdGUoaHRtbDogc3RyaW5nKTogc3RyaW5nIHtcblx0Y29uc3QgbWF0Y2ggPSBodG1sLm1hdGNoKFxuXHRcdC88c3BhblxccytjbGFzcz1cImZvcm1hdC1kYXRlXCI+KFxcZHs0fS1cXGR7Mn0tXFxkezJ9KTxcXC9zcGFuPi8sXG5cdClcblx0cmV0dXJuIG1hdGNoID8gbWF0Y2hbMV0gOiAnJ1xufVxuXG4vLyAtLS0gUGFyc2UgdGhlIGlkZW50aXR5IG9mIGEgc2luZ2xlIGV2ZW50IHJlc3VsdHMgcGFnZSAtLS1cbi8vIFRoZSBzY3JhcGluZyBzY3JpcHRzIGFscmVhZHkga25vdyB3aGljaCBldmVudCBwYWdlIHRoZXkgYXNrZWQgZm9yOyB0aGUgbWFudWFsXG4vLyB1cGxvYWQgcGFnZSBoYXMgdG8gcmVhZCBpdCBiYWNrIG9mZiB0aGUgZmlsZSBpdCB3YXMgaGFuZGVkLlxuLy9cbi8vICAgPGgxPkhhZ2EgcGFya3J1bjwvaDE+XG4vLyAgIDxoMz48c3BhbiBjbGFzcz1cImZvcm1hdC1kYXRlXCI+MjAyNi0wOC0wMTwvc3Bhbj4g4oCmIDxzcGFuPiM0MTU8L3NwYW4+PC9oMz5cblxuZXhwb3J0IGludGVyZmFjZSBFdmVudFBhZ2VNZXRhIHtcblx0LyoqIGV2ZW50SWQgZnJvbSB0aGUgaW4tcGFnZSBhdGhsZXRlIGxpbmtzLCBlLmcuIFwiaGFnYVwiLiBFbXB0eSBpZiBub3QgZm91bmQuICovXG5cdGV2ZW50SWQ6IHN0cmluZ1xuXHQvKiogRXZlbnQgdGl0bGUsIGUuZy4gXCJIYWdhIHBhcmtydW5cIi4gRW1wdHkgaWYgbm90IGZvdW5kLiAqL1xuXHR0aXRsZTogc3RyaW5nXG5cdC8qKiBFdmVudCBudW1iZXIsIGUuZy4gNDE1LiBaZXJvIGlmIG5vdCBmb3VuZC4gKi9cblx0ZXZlbnROdW1iZXI6IG51bWJlclxuXHQvKiogWVlZWS1NTS1ERCwgb3IgZW1wdHkgaWYgbm90IGZvdW5kLiAqL1xuXHRkYXRlOiBzdHJpbmdcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlRXZlbnRQYWdlTWV0YShodG1sOiBzdHJpbmcpOiBFdmVudFBhZ2VNZXRhIHtcblx0Y29uc3QgdGl0bGUgPSBkZWNvZGVFbnRpdGllcyhcblx0XHRzdHJpcFRhZ3MoaHRtbC5tYXRjaCgvPGgxW14+XSo+KFtcXHNcXFNdKj8pPFxcL2gxPi8pPy5bMV0gPz8gJycpLFxuXHQpXG5cblx0Ly8gQXRobGV0ZSBsaW5rcyBvbiB0aGUgcGFnZSBhcmUgZXZlbnQtcmVsYXRpdmU6IC9oYWdhL3BhcmtydW5uZXIvNjE0ODc5NFxuXHRjb25zdCBldmVudElkID0gaHRtbC5tYXRjaCgvaHJlZj1cIlxcLyhbXi9cIl0rKVxcL3BhcmtydW5uZXJcXC8vKT8uWzFdID8/ICcnXG5cblx0Y29uc3QgbnVtYmVyTWF0Y2ggPSBodG1sLm1hdGNoKC88c3Bhbj5cXHMqIyhcXGQrKVxccyo8XFwvc3Bhbj4vKVxuXG5cdHJldHVybiB7XG5cdFx0ZXZlbnRJZCxcblx0XHR0aXRsZSxcblx0XHRldmVudE51bWJlcjogbnVtYmVyTWF0Y2ggPyBOdW1iZXIucGFyc2VJbnQobnVtYmVyTWF0Y2hbMV0sIDEwKSA6IDAsXG5cdFx0ZGF0ZTogcGFyc2VFdmVudERhdGUoaHRtbCksXG5cdH1cbn1cblxuLy8gLS0tIFBhcnNlIHZvbHVudGVlcnMgZnJvbSBhIHNpbmdsZSBldmVudCByZXN1bHRzIHBhZ2UgLS0tXG4vLyBGaW5kcyB0cmFja2VkIGF0aGxldGVzIGluIHRoZSBWb2x1bnRlZXJzLXRhYmxlIGFuZCBleHRyYWN0cyB0aGVpciByb2xlcy5cbi8vIEVhY2ggdm9sdW50ZWVyIHJvdzogPHRyIGNsYXNzPVwiVm9sdW50ZWVycy10YWJsZS1yb3dcIiAuLi4gZGF0YS1yb2xlPVwiRnVua3Rpb27DpHIsUmVzdWx0YXRzYW5zdmFyaWcsXCIgLi4uPlxuLy8gICB3aXRoIDxhIGhyZWY9XCIvaGFnYS9wYXJrcnVubmVyL3twYXJrcnVuSWR9XCIgLi4uPlxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VFdmVudFZvbHVudGVlcnMoXG5cdGh0bWw6IHN0cmluZyxcblx0dHJhY2tlZElkczogU2V0PHN0cmluZz4sXG4pOiBWb2x1bnRlZXJFbnRyeVtdIHtcblx0Y29uc3Qgdm9sdW50ZWVyczogVm9sdW50ZWVyRW50cnlbXSA9IFtdXG5cblx0Ly8gRmluZCB0aGUgdm9sdW50ZWVycyB0YWJsZSBzZWN0aW9uXG5cdGNvbnN0IHRhYmxlTWF0Y2ggPSBodG1sLm1hdGNoKFxuXHRcdC9jbGFzcz1cIlZvbHVudGVlcnMtdGFibGVbXlwiXSpqcy1Wb2x1bnRlZXJzVGFibGVbXlwiXSpcIltcXHNcXFNdKj88dGJvZHlbXj5dKj4oW1xcc1xcU10qPyk8XFwvdGJvZHk+L2ksXG5cdClcblx0aWYgKCF0YWJsZU1hdGNoKSByZXR1cm4gdm9sdW50ZWVyc1xuXG5cdGNvbnN0IHRib2R5ID0gdGFibGVNYXRjaFsxXVxuXG5cdC8vIE1hdGNoIGVhY2ggdm9sdW50ZWVyIHJvd1xuXHRjb25zdCByb3dSZWdleCA9XG5cdFx0Lzx0clxccytjbGFzcz1cIlZvbHVudGVlcnMtdGFibGUtcm93XCJbXj5dKmRhdGEtcm9sZT1cIihbXlwiXSopXCJbXj5dKj4oW1xcc1xcU10qPyk8XFwvdHI+L2dpXG5cblx0Zm9yIChjb25zdCBtYXRjaCBvZiB0Ym9keS5tYXRjaEFsbChyb3dSZWdleCkpIHtcblx0XHRjb25zdCBkYXRhUm9sZSA9IG1hdGNoWzFdXG5cdFx0Y29uc3Qgcm93SHRtbCA9IG1hdGNoWzJdXG5cblx0XHQvLyBFeHRyYWN0IHBhcmtydW5JZCBmcm9tIHRoZSBsaW5rXG5cdFx0Y29uc3QgaWRNYXRjaCA9IHJvd0h0bWwubWF0Y2goL1xcL3BhcmtydW5uZXJcXC8oXFxkKykvKVxuXHRcdGlmICghaWRNYXRjaCkgY29udGludWVcblxuXHRcdGNvbnN0IHBhcmtydW5JZCA9IGlkTWF0Y2hbMV1cblx0XHRpZiAoIXRyYWNrZWRJZHMuaGFzKHBhcmtydW5JZCkpIGNvbnRpbnVlXG5cblx0XHQvLyBQYXJzZSByb2xlcyBmcm9tIGRhdGEtcm9sZSAoY29tbWEtc2VwYXJhdGVkLCB0cmFpbGluZyBjb21tYSlcblx0XHRjb25zdCByb2xlcyA9IGRhdGFSb2xlXG5cdFx0XHQuc3BsaXQoJywnKVxuXHRcdFx0Lm1hcCgocikgPT4gci50cmltKCkpXG5cdFx0XHQuZmlsdGVyKChyKSA9PiByLmxlbmd0aCA+IDApXG5cblx0XHR2b2x1bnRlZXJzLnB1c2goeyBwYXJrcnVuSWQsIHJvbGVzIH0pXG5cdH1cblxuXHRyZXR1cm4gdm9sdW50ZWVyc1xufVxuIiwiLyoqXG4gKiBUaGUgcGFya3J1biBwYWdlcyBvdXIgZGF0YSBjb21lcyBmcm9tLlxuICpcbiAqIFNoYXJlZCBieSB0aGUgYWRtaW4gdXBsb2FkIGZvcm0gKHdoaWNoIGxpbmtzIHRvIGVhY2ggcGFnZSB5b3UgbmVlZCB0byBkb3dubG9hZClcbiAqIGFuZCB0aGUgcmVzdWx0cy1zY3JhcGVyIGV4dGVuc2lvbiAod2hpY2ggbmF2aWdhdGVzIHRvIHRoZW0pLCBzbyB0aGUgdHdvIGFsd2F5c1xuICogYWdyZWUgb24gd2hhdCB0byBmZXRjaC4gVGhlIFBsYXl3cmlnaHQgc2NyaXB0cyBwcmVkYXRlIHRoaXMgbW9kdWxlIGFuZCBzdGlsbFxuICogYnVpbGQgYXRobGV0ZSBVUkxzIHRoZW1zZWx2ZXMuXG4gKi9cbmltcG9ydCB7IERPTUFJTl9UT19DT1VOVFJZIH0gZnJvbSAnLi9wYXJrcnVuLXBhcnNlcnMnXG5cbi8qKlxuICogV2hpY2ggcGFya3J1biBzaXRlIHRvIHJlYWQgYXRobGV0ZSBoaXN0b3J5IGZyb20uXG4gKlxuICogRXZlcnkgY291bnRyeSdzIHNpdGUgc2VydmVzIHRoZSBzYW1lIGF0aGxldGUgcGFnZXMsIHNvIHRoaXMgaXMgYSBmcmVlIGNob2ljZSxcbiAqIGFuZCBpdCdzIHRoZSBTd2VkaXNoIG9uZSBiZWNhdXNlIHRoYXQncyB3aGVyZSBldmVyeXRoaW5nIGVsc2Ugd2UgZmV0Y2ggbGl2ZXMg4oCUXG4gKiB0aGUgY2x1YidzIGV2ZW50cyBhbmQgdGhlIGxlYWd1ZSB0YWJsZSBhcmUgYm90aCBvbiBgcGFya3J1bi5zZWAuIEtlZXBpbmcgYXRobGV0ZVxuICogcGFnZXMgdGhlcmUgbWVhbnMgYSB3aG9sZSBzY3JhcGUgc3RheXMgb24gb25lIG9yaWdpbiwgd2hpY2ggbWF0dGVycyBmb3IgYW55XG4gKiBzY3JhcGVyIHdvcmtpbmcgZnJvbSBpbnNpZGUgYSBwYWdlIHJhdGhlciB0aGFuIHRocm91Z2ggaG9zdCBwZXJtaXNzaW9uczogdGhlXG4gKiBzYW1lLW9yaWdpbiBwb2xpY3kgbWFrZXMgb25lIG9yaWdpbiByZWFkYWJsZSBhbmQgdGhlIHJlc3Qgbm90LlxuICpcbiAqIFN3ZWRpc2ggcGFnZXMgYXJlIGEgc3VwcG9ydGVkIHBhcnNlciBwYXRoIHJhdGhlciB0aGFuIGEgbHVja3kgb25lOiB0aGUgdG90YWwtcnVuc1xuICogcmVnZXggbWF0Y2hlcyBcInRvdGFsdFwiIGFzIHdlbGwgYXMgXCJ0b3RhbFwiLCBhbmQgYGZpbmRSZXN1bHRUYm9kaWVzYCBoYW5kbGVzIHRoZVxuICogbG9jYWxpc2VkIFwiQWxsYSByZXN1bHRhdFwiIGNhcHRpb24gYnkgZmFsbGluZyBiYWNrIHRvIHRoZSBsYXN0IHJlc3VsdHMgdGFibGUuXG4gKiBWZXJpZmllZCBhZ2FpbnN0IGEgcmVhbCBgcGFya3J1bi5zZWAgYXRobGV0ZSBwYWdlIOKAlCAxNTUgcmVzdWx0cyBwYXJzZWQuXG4gKlxuICogTm90ZSB0aGlzIGNvbnN0YW50IGRvZXMgbm90IHJlYWNoIHRoZSBQbGF5d3JpZ2h0IHNjcmlwdHMsIHdoaWNoIGJ1aWxkIHRoZSBzYW1lXG4gKiBVUkwgYWdhaW5zdCBgcGFya3J1bi5vcmcudWtgIGJ5IGhhbmQgKGBhcHBzL2FwaS9zY3JpcHRzL2ZldGNoLXJlc3VsdHMudHNgKS5cbiAqL1xuZXhwb3J0IGNvbnN0IEFUSExFVEVfU0lURSA9ICdodHRwczovL3d3dy5wYXJrcnVuLnNlJ1xuXG4vKipcbiAqIEFuIGF0aGxldGUncyBmdWxsIHJ1biBoaXN0b3J5IOKAlCByZXF1ZXN0ZWQgYnkgdGhlIGV4dGVuc2lvbiBhbmQgbGlua2VkIHRvIGJ5IHRoZVxuICogbWFudWFsIHVwbG9hZCBmb3JtLlxuICovXG5leHBvcnQgZnVuY3Rpb24gYXRobGV0ZVBhZ2VVcmwocGFya3J1bklkOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gYCR7QVRITEVURV9TSVRFfS9wYXJrcnVubmVyLyR7cGFya3J1bklkfS9hbGwvYFxufVxuXG4vKipcbiAqIEFuIGV2ZW50J3MgbW9zdCByZWNlbnQgcmVzdWx0cy4gZmV0Y2gtcGFya3J1bi50cyB3YWxrcyB0aGUgZXZlbnQgaGlzdG9yeSB0b1xuICogZmluZCBldmVyeSB1bnNjcmFwZWQgbnVtYmVyOyBieSBoYW5kIHlvdSB3YW50IHRoZSBsYXRlc3Qgb25lLCB3aGljaCBwYXJrcnVuXG4gKiBzZXJ2ZXMgYXQgYSBzdGFibGUgVVJMLlxuICovXG5leHBvcnQgZnVuY3Rpb24gbGF0ZXN0UmVzdWx0c1VybChldmVudEJhc2VVcmw6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiBgJHt0cmltU2xhc2goZXZlbnRCYXNlVXJsKX0vcmVzdWx0cy9sYXRlc3RyZXN1bHRzL2Bcbn1cblxuLyoqIEEgbnVtYmVyZWQgZXZlbnQgcmVzdWx0cyBwYWdlLCBlLmcuIOKApi9oYWdhL3Jlc3VsdHMvNDE1LyAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV2ZW50UmVzdWx0c1VybChcblx0ZXZlbnRCYXNlVXJsOiBzdHJpbmcsXG5cdGV2ZW50TnVtYmVyOiBudW1iZXIsXG4pOiBzdHJpbmcge1xuXHRyZXR1cm4gYCR7dHJpbVNsYXNoKGV2ZW50QmFzZVVybCl9L3Jlc3VsdHMvJHtldmVudE51bWJlcn0vYFxufVxuXG4vKiogQW4gZXZlbnQncyBjb3Vyc2UgcGFnZSwgd2hpY2ggZW1iZWRzIHRoZSBHb29nbGUgbWFwIGhvbGRpbmcgdGhlIEtNWi4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3Vyc2VQYWdlVXJsKGV2ZW50QmFzZVVybDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGAke3RyaW1TbGFzaChldmVudEJhc2VVcmwpfS9jb3Vyc2UvYFxufVxuXG4vKiogVGhlIEdvb2dsZSBNeSBNYXBzIEtNWiBleHBvcnQgZm9yIGEgbWFwIGlkIGZvdW5kIG9uIGEgY291cnNlIHBhZ2UuICovXG5leHBvcnQgZnVuY3Rpb24gY291cnNlS216VXJsKG1pZDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGBodHRwczovL3d3dy5nb29nbGUuY29tL21hcHMvZC9rbWw/bWlkPSR7bWlkfWBcbn1cblxuLyoqIFRoZSBlbWJlZCBVUkwsIHVzZWQgdG8gcmVzb2x2ZSBsZWdhY3kgbWFwIGlkcyB2aWEgdGhlaXIgcmVkaXJlY3QuICovXG5leHBvcnQgZnVuY3Rpb24gY291cnNlTWFwRW1iZWRVcmwobWlkOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gYGh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vbWFwcy9kL2VtYmVkP21pZD0ke21pZH1gXG59XG5cbi8qKiBUaGUgbGVhZ3VlIHRhYmxlIGZldGNoLWxhcmdlc3QtY2x1YnMudHMgc2NyYXBlcy4gKi9cbmV4cG9ydCBjb25zdCBMQVJHRVNUX0NMVUJTX1VSTCA9ICdodHRwczovL3d3dy5wYXJrcnVuLnNlL3Jlc3VsdHMvbGFyZ2VzdGNsdWJzLydcblxuZnVuY3Rpb24gdHJpbVNsYXNoKHVybDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIHVybC5yZXBsYWNlKC9cXC8kLywgJycpXG59XG5cbi8vIC0tLSBIb3N0IHBhdHRlcm5zLCBmb3IgdGhlIGV4dGVuc2lvbidzIG1hbmlmZXN0IC0tLVxuXG4vKipcbiAqIE1hdGNoIHBhdHRlcm5zIGNvdmVyaW5nIGV2ZXJ5IHBhcmtydW4gc2l0ZSB3ZSBrbm93IGFib3V0LCBwbHVzIEdvb2dsZSBNYXBzLlxuICogTWF0Y2ggcGF0dGVybnMgY2FuJ3Qgd2lsZGNhcmQgYSBUTEQsIHNvIHRoZXNlIGhhdmUgdG8gYmUgZW51bWVyYXRlZCDigJQgaGVuY2VcbiAqIGRlcml2aW5nIHRoZW0gZnJvbSB0aGUgY291bnRyeSBtYXAgdGhlIHBhcnNlcnMgYWxyZWFkeSBtYWludGFpbi5cbiAqL1xuZXhwb3J0IGNvbnN0IFBBUktSVU5fSE9TVF9QQVRURVJOUyA9IE9iamVjdC5rZXlzKERPTUFJTl9UT19DT1VOVFJZKS5mbGF0TWFwKFxuXHQoZG9tYWluKSA9PiBbYCo6Ly8ke2RvbWFpbn0vKmAsIGAqOi8vKi4ke2RvbWFpbn0vKmBdLFxuKVxuXG5leHBvcnQgY29uc3QgR09PR0xFX01BUFNfSE9TVF9QQVRURVJOUyA9IFsnKjovLyouZ29vZ2xlLmNvbS9tYXBzLyonXVxuIiwiLyoqXG4gKiBLZWVwcyB0aGUgc2VydmljZSB3b3JrZXIgYWxpdmUgZm9yIHRoZSBkdXJhdGlvbiBvZiBhIHJ1bi5cbiAqXG4gKiBDYXB0dXJlIGRlcGVuZHMgb24gYGNocm9tZS5kZWJ1Z2dlcmAgTmV0d29yayBldmVudHMsIGFuZCB0aG9zZSBhcmUgb25seVxuICogZGVsaXZlcmVkIHRvIGEgKnJ1bm5pbmcqIHdvcmtlciDigJQgdW5saWtlIHRhYnMvYWxhcm1zL21lc3NhZ2VzLCBhIGRlYnVnZ2VyIGV2ZW50XG4gKiBkb2VzIG5vdCB3YWtlIGEgd29ya2VyIENocm9tZSBoYXMgcmV0aXJlZC4gTWlzcyB0aGUgYHJlc3BvbnNlUmVjZWl2ZWRgIGZvciBhXG4gKiBwYWdlIGFuZCB0aGVyZSBpcyBubyByZXF1ZXN0IElEIGxlZnQgdG8gZmV0Y2ggaXRzIGJvZHkgd2l0aCwgc28gdGhlIHBhZ2UgbG9hZHNcbiAqIGZpbmUgaW4gdGhlIHRhYiBhbmQgdGhlIGV4dGVuc2lvbiBoYXMgbm90aGluZy4gVGhhdCB3YXMgdGhlIFwibm8gcmVzcG9uc2UsIHRoZW5cbiAqIHJlbG9hZHMgYWZ0ZXIgMzBzXCIgc3ltcHRvbS5cbiAqXG4gKiBDYWxsaW5nIGludG8gYSBjaHJvbWUgQVBJIHJlc2V0cyB0aGUgaWRsZSB0aW1lciwgc28gYSBzbG93IHNlbGYtcGluZyBob2xkcyB0aGVcbiAqIHdvcmtlciBvcGVuLiBUaGlzIGNvc3RzIG5vdGhpbmcgYW5kIG5lZWRzIG5vIGV4dHJhIHBlcm1pc3Npb24g4oCUIGJ1dCBpdCBvbmx5XG4gKiB3b3JrcyB3aGlsZSB0aGUgd29ya2VyIGlzIGFsaXZlLCBzbyBgYmFja2dyb3VuZC50c2Agc3RpbGwgcmVjb3ZlcnMgZnJvbSBhIGNvbGRcbiAqIHN0YXJ0IG9uIGl0cyBvd24uXG4gKi9cblxuLyoqIENvbWZvcnRhYmx5IGluc2lkZSBDaHJvbWUncyAzMHMgaWRsZSB0aW1lb3V0LiAqL1xuY29uc3QgUElOR19JTlRFUlZBTF9NUyA9IDIwXzAwMFxuXG5sZXQgdGltZXI6IFJldHVyblR5cGU8dHlwZW9mIHNldEludGVydmFsPiB8IG51bGwgPSBudWxsXG5cbmV4cG9ydCBmdW5jdGlvbiBzdGFydEtlZXBhbGl2ZSgpOiB2b2lkIHtcblx0aWYgKHRpbWVyKSByZXR1cm5cblx0dGltZXIgPSBzZXRJbnRlcnZhbCgoKSA9PiB7XG5cdFx0Ly8gVGhlIGNhbGwgaXRzZWxmIGlzIHRoZSBwb2ludDsgdGhlIHJlc3VsdCBpcyBpcnJlbGV2YW50LlxuXHRcdHZvaWQgY2hyb21lLnJ1bnRpbWUuZ2V0UGxhdGZvcm1JbmZvKCkuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKVxuXHR9LCBQSU5HX0lOVEVSVkFMX01TKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gc3RvcEtlZXBhbGl2ZSgpOiB2b2lkIHtcblx0aWYgKCF0aW1lcikgcmV0dXJuXG5cdGNsZWFySW50ZXJ2YWwodGltZXIpXG5cdHRpbWVyID0gbnVsbFxufVxuIiwiLyoqXG4gKiBSdW4gc3RhdGUgYW5kIGNhcHR1cmVkIGZpbGVzLCBwZXJzaXN0ZWQgaW4gY2hyb21lLnN0b3JhZ2UubG9jYWwuXG4gKlxuICogRXZlcnl0aGluZyBsaXZlcyBpbiBzdG9yYWdlIHJhdGhlciB0aGFuIGluIG1vZHVsZSBzY29wZSBiZWNhdXNlIGFuIE1WMyBzZXJ2aWNlXG4gKiB3b3JrZXIgaXMgdGVybWluYXRlZCB3aGVuZXZlciBpdCBnb2VzIGlkbGUg4oCUIHdoaWNoIGl0IHdpbGwsIHJlcGVhdGVkbHksIGFjcm9zc1xuICogYSBydW4gdGhhdCB3YWl0cyBvbiBwYWdlIGxvYWRzIGFuZCBjYXB0Y2hhcy4gRWFjaCB3YWtlLXVwIHJlYWRzIHN0YXRlIGJhY2sgYW5kXG4gKiBjYXJyaWVzIG9uLlxuICpcbiAqIGB1bmxpbWl0ZWRTdG9yYWdlYCBpcyBkZWNsYXJlZCBpbiB0aGUgbWFuaWZlc3Q6IGZpZnRlZW4gYXRobGV0ZSBwYWdlcyBpcyB3ZWxsXG4gKiBwYXN0IGNocm9tZS5zdG9yYWdlLmxvY2FsJ3MgdXN1YWwgMTAgTUIgY2FwLCBhbmQgYSB2b2x1bnRlZXIgYmFja2ZpbGwgaXNcbiAqIGh1bmRyZWRzIG9mIGV2ZW50IHBhZ2VzLlxuICovXG5pbXBvcnQgdHlwZSB7XG5cdENhcHR1cmVkRmlsZSxcblx0SXRlbVN0YXRlLFxuXHRJdGVtU3RhdHVzLFxuXHRSdW5TdGF0ZSxcbn0gZnJvbSAnQHNoYXJlZC9zY3JhcGVyLXByb3RvY29sJ1xuaW1wb3J0IHsgZW1wdHlSdW5TdGF0ZSB9IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcblxuY29uc3QgUlVOX0tFWSA9ICdydW4nXG5jb25zdCBTRVNTSU9OX0tFWSA9ICdzZXNzaW9uJ1xuLyoqIFN0b3JhZ2Uga2V5cyBvZiB0aGUgY2FwdHVyZWQgZmlsZXMsIGluIGNhcHR1cmUgb3JkZXIuICovXG5jb25zdCBGSUxFX0lOREVYX0tFWSA9ICdmaWxlS2V5cydcbi8qKiBXaGVyZSB2ZXJzaW9uIDEga2VwdCBldmVyeSBmaWxlLCBpbiBvbmUgYXJyYXkuIE9ubHkgZXZlciByZW1vdmVkIG5vdy4gKi9cbmNvbnN0IExFR0FDWV9GSUxFU19LRVkgPSAnZmlsZXMnXG5cbi8qKiBCb29ra2VlcGluZyB0aGUgVUkgbmV2ZXIgc2Vlcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUnVuU2Vzc2lvbiB7XG5cdGFkbWluVGFiSWQ/OiBudW1iZXJcblx0c2NyYXBlVGFiSWQ/OiBudW1iZXJcblx0LyoqIEV2ZW50IElEcyB0aGF0IGFscmVhZHkgaGFkIGNvdXJzZSBkYXRhIGJlZm9yZSB0aGUgcnVuIHN0YXJ0ZWQuICovXG5cdGtub3duQ291cnNlRXZlbnRJZHM6IHN0cmluZ1tdXG5cdC8qKiBFdmVudHMgZm91bmQgb24gYXRobGV0ZSBwYWdlczogZXZlbnRJZCDihpIgYmFzZSBVUkwgYW5kIGRpc3BsYXkgbmFtZS4gKi9cblx0ZGlzY292ZXJlZEV2ZW50czogUmVjb3JkPHN0cmluZywgeyBuYW1lOiBzdHJpbmc7IHVybDogc3RyaW5nIH0+XG5cdC8qKiBTZXQgb25jZSB0aGUgcXVldWUgaGFzIGJlZW4gZXh0ZW5kZWQgd2l0aCBjb3Vyc2UgcGFnZXMuICovXG5cdGNvdXJzZXNRdWV1ZWQ6IGJvb2xlYW5cblx0c2tpcENvdXJzZXM6IGJvb2xlYW5cblx0LyoqIENvbnNlY3V0aXZlIGNhcHR1cmUgYXR0ZW1wdHMgZm9yIHRoZSBjdXJyZW50IGl0ZW0sIHRvIHN0b3AgbG9vcHMuICovXG5cdGF0dGVtcHRzOiBudW1iZXJcblx0LyoqIFJvdWdoIHdhaXQgYmV0d2VlbiBwYWdlcywgZnJvbSB0aGUgcnVuIHJlcXVlc3QuICovXG5cdHBhdXNlTXM/OiBudW1iZXJcbn1cblxuZnVuY3Rpb24gZW1wdHlTZXNzaW9uKCk6IFJ1blNlc3Npb24ge1xuXHRyZXR1cm4ge1xuXHRcdGtub3duQ291cnNlRXZlbnRJZHM6IFtdLFxuXHRcdGRpc2NvdmVyZWRFdmVudHM6IHt9LFxuXHRcdGNvdXJzZXNRdWV1ZWQ6IGZhbHNlLFxuXHRcdHNraXBDb3Vyc2VzOiBmYWxzZSxcblx0XHRhdHRlbXB0czogMCxcblx0fVxufVxuXG4vLyDilIDilIAgUnVuIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuU3RhdGUoKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQ8eyBydW4/OiBSdW5TdGF0ZSB9PihSVU5fS0VZKVxuXHRyZXR1cm4gc3RvcmVkLnJ1biA/PyBlbXB0eVJ1blN0YXRlKClcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1blN0YXRlKHN0YXRlOiBSdW5TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbUlVOX0tFWV06IHN0YXRlIH0pXG59XG5cbi8qKiBBcHBseSBhIGNoYW5nZSB0byB0aGUgc3RvcmVkIHN0YXRlIGFuZCByZXR1cm4gd2hhdCB3YXMgd3JpdHRlbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVSdW5TdGF0ZShcblx0Y2hhbmdlOiAoc3RhdGU6IFJ1blN0YXRlKSA9PiBSdW5TdGF0ZSxcbik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3QgbmV4dCA9IGNoYW5nZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRhd2FpdCBzZXRSdW5TdGF0ZShuZXh0KVxuXHRyZXR1cm4gbmV4dFxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0SXRlbVN0YXR1cyhcblx0a2V5OiBzdHJpbmcsXG5cdHN0YXR1czogSXRlbVN0YXR1cyxcblx0ZGV0YWlsPzogc3RyaW5nLFxuXHRhdHRlbXB0cz86IG51bWJlcixcbik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0cmV0dXJuIHVwZGF0ZVJ1blN0YXRlKChzdGF0ZSkgPT4gKHtcblx0XHQuLi5zdGF0ZSxcblx0XHRpdGVtczogc3RhdGUuaXRlbXMubWFwKChpdGVtKSA9PlxuXHRcdFx0aXRlbS5rZXkgPT09IGtleVxuXHRcdFx0XHQ/IHtcblx0XHRcdFx0XHRcdC4uLml0ZW0sXG5cdFx0XHRcdFx0XHRzdGF0dXMsXG5cdFx0XHRcdFx0XHRkZXRhaWwsXG5cdFx0XHRcdFx0XHRhdHRlbXB0czogYXR0ZW1wdHMgPz8gaXRlbS5hdHRlbXB0cyxcblx0XHRcdFx0XHRcdHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdDogaXRlbSxcblx0XHQpLFxuXHR9KSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEl0ZW1zKGl0ZW1zOiBJdGVtU3RhdGVbXSk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0cmV0dXJuIHVwZGF0ZVJ1blN0YXRlKChzdGF0ZSkgPT4gKHtcblx0XHQuLi5zdGF0ZSxcblx0XHRpdGVtczogWy4uLnN0YXRlLml0ZW1zLCAuLi5pdGVtc10sXG5cdH0pKVxufVxuXG4vLyDilIDilIAgU2Vzc2lvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlc3Npb24oKTogUHJvbWlzZTxSdW5TZXNzaW9uPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDx7IHNlc3Npb24/OiBSdW5TZXNzaW9uIH0+KFxuXHRcdFNFU1NJT05fS0VZLFxuXHQpXG5cdHJldHVybiBzdG9yZWQuc2Vzc2lvbiA/PyBlbXB0eVNlc3Npb24oKVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2Vzc2lvbihzZXNzaW9uOiBSdW5TZXNzaW9uKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTRVNTSU9OX0tFWV06IHNlc3Npb24gfSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNlc3Npb24oXG5cdGNoYW5nZTogKHNlc3Npb246IFJ1blNlc3Npb24pID0+IFJ1blNlc3Npb24sXG4pOiBQcm9taXNlPFJ1blNlc3Npb24+IHtcblx0Y29uc3QgbmV4dCA9IGNoYW5nZShhd2FpdCBnZXRTZXNzaW9uKCkpXG5cdGF3YWl0IHNldFNlc3Npb24obmV4dClcblx0cmV0dXJuIG5leHRcbn1cblxuLy8g4pSA4pSAIENhcHR1cmVkIGZpbGVzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuLy9cbi8vIE9uZSBzdG9yYWdlIGtleSBwZXIgZmlsZS4gVGhleSB1c2VkIHRvIHNoYXJlIGEgc2luZ2xlIGFycmF5LCB3aGljaCBtZWFudFxuLy8gcmV3cml0aW5nIGV2ZXJ5IHBhZ2UgY2FwdHVyZWQgc28gZmFyIG9uIGVhY2ggY2FwdHVyZSDigJQgZmluZSBmb3IgdHdlbnR5IHBhZ2VzLFxuLy8gcXVhZHJhdGljIGZvciBhIGZldyBodW5kcmVkLlxuXG5mdW5jdGlvbiBmaWxlU3RvcmFnZUtleShmaWxlOiBQaWNrPENhcHR1cmVkRmlsZSwgJ2tpbmQnIHwgJ2tleSc+KTogc3RyaW5nIHtcblx0cmV0dXJuIGBmaWxlOiR7ZmlsZS5raW5kfToke2ZpbGUua2V5fWBcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2V0RmlsZUluZGV4KCk6IFByb21pc2U8c3RyaW5nW10+IHtcblx0Y29uc3Qgc3RvcmVkID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0PHsgZmlsZUtleXM/OiBzdHJpbmdbXSB9Pihcblx0XHRGSUxFX0lOREVYX0tFWSxcblx0KVxuXHRyZXR1cm4gc3RvcmVkLmZpbGVLZXlzID8/IFtdXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRGaWxlcygpOiBQcm9taXNlPENhcHR1cmVkRmlsZVtdPiB7XG5cdGNvbnN0IGluZGV4ID0gYXdhaXQgZ2V0RmlsZUluZGV4KClcblx0aWYgKGluZGV4Lmxlbmd0aCA9PT0gMCkgcmV0dXJuIFtdXG5cdGNvbnN0IHN0b3JlZCA9XG5cdFx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0PFJlY29yZDxzdHJpbmcsIENhcHR1cmVkRmlsZSB8IHVuZGVmaW5lZD4+KFxuXHRcdFx0aW5kZXgsXG5cdFx0KVxuXHRyZXR1cm4gaW5kZXguZmxhdE1hcCgoa2V5KSA9PiBzdG9yZWRba2V5XSA/PyBbXSlcbn1cblxuLyoqIFN0b3JlIGEgY2FwdHVyZWQgZmlsZSwgcmVwbGFjaW5nIGFueSBlYXJsaWVyIGNhcHR1cmUgZm9yIHRoZSBzYW1lIHNsb3QuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHV0RmlsZShmaWxlOiBDYXB0dXJlZEZpbGUpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc3RvcmFnZUtleSA9IGZpbGVTdG9yYWdlS2V5KGZpbGUpXG5cdC8vIFRoZSBmaWxlIGJlZm9yZSB0aGUgaW5kZXgsIHNvIHRoZSBpbmRleCBuZXZlciBuYW1lcyBzb21ldGhpbmcgbWlzc2luZy5cblx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW3N0b3JhZ2VLZXldOiBmaWxlIH0pXG5cdGNvbnN0IGluZGV4ID0gYXdhaXQgZ2V0RmlsZUluZGV4KClcblx0aWYgKCFpbmRleC5pbmNsdWRlcyhzdG9yYWdlS2V5KSkge1xuXHRcdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtGSUxFX0lOREVYX0tFWV06IFsuLi5pbmRleCwgc3RvcmFnZUtleV0gfSlcblx0fVxufVxuXG4vLyDilIDilIAgTGlmZWN5Y2xlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVzZXRBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnJlbW92ZShbXG5cdFx0UlVOX0tFWSxcblx0XHRTRVNTSU9OX0tFWSxcblx0XHRGSUxFX0lOREVYX0tFWSxcblx0XHRMRUdBQ1lfRklMRVNfS0VZLFxuXHRcdC4uLihhd2FpdCBnZXRGaWxlSW5kZXgoKSksXG5cdF0pXG59XG4iLCIvKipcbiAqIFB1c2hpbmcgdXBkYXRlcyBvdXQgb2YgdGhlIHNlcnZpY2Ugd29ya2VyLlxuICpcbiAqIFByb2dyZXNzIGdvZXMgdG8gdHdvIHBsYWNlczogdGhlIGFkbWluIHRhYiAod2hpY2ggZHJhd3MgdGhlIHBhbmVsIHRoYXRcbiAqIHJlcGxhY2VkIHRoZSBmb3JtKSBhbmQgd2hhdGV2ZXIgcGFnZSBpcyBjdXJyZW50bHkgaW4gdGhlIHNjcmFwZSB0YWIgKHdoaWNoXG4gKiBzaG93cyB0aGUgZmxvYXRpbmcgb3ZlcmxheSkuIEJvdGggYXJlIGJlc3QtZWZmb3J0IOKAlCBhIHRhYiB3aXRoIG5vIGNvbnRlbnRcbiAqIHNjcmlwdCBsb2FkZWQgeWV0IGp1c3QgaXNuJ3QgbGlzdGVuaW5nLCBhbmQgdGhhdCdzIGZpbmUsIGJlY2F1c2UgYm90aCBhbHNvXG4gKiByZWFkIHRoZSBjdXJyZW50IHN0YXRlIGZyb20gc3RvcmFnZSB3aGVuIHRoZXkgc3RhcnQgdXAuXG4gKi9cbmltcG9ydCB0eXBlIHsgQ2FwdHVyZWRGaWxlLCBSdW5TdGF0ZSB9IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcbmltcG9ydCB7IGdldFNlc3Npb24gfSBmcm9tICcuL3N0YXRlJ1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbm90aWZ5U3RhdGUoc3RhdGU6IFJ1blN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0Y29uc3QgbWVzc2FnZSA9IHsgdHlwZTogJ3N0YXRlJyBhcyBjb25zdCwgc3RhdGUgfVxuXG5cdGZvciAoY29uc3QgdGFiSWQgb2YgW3Nlc3Npb24uYWRtaW5UYWJJZCwgc2Vzc2lvbi5zY3JhcGVUYWJJZF0pIHtcblx0XHRpZiAodGFiSWQgPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJJZCwgbWVzc2FnZSkuY2F0Y2goKCkgPT4ge30pXG5cdH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5vdGlmeUZpbGUoZmlsZTogQ2FwdHVyZWRGaWxlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHsgYWRtaW5UYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVyblxuXHRhd2FpdCBjaHJvbWUudGFic1xuXHRcdC5zZW5kTWVzc2FnZShhZG1pblRhYklkLCB7IHR5cGU6ICdmaWxlJyBhcyBjb25zdCwgZmlsZSB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcbn1cbiIsIi8qKlxuICogRGVjaWRlcyB3aGF0IHdlIGFjdHVhbGx5IGdvdCBiYWNrLlxuICpcbiAqIFJhdGhlciB0aGFuIHBhdHRlcm4tbWF0Y2hpbmcgYm90LWNoZWNrIHBhZ2VzICh3aGljaCBjaGFuZ2UpLCB0aGUgdGVzdCBpc1xuICogd2hldGhlciB0aGUgcmVwbydzIG93biBwYXJzZXJzIGNhbiByZWFkIHRoZSBwYWdlLiBJZiB0aGV5IGNhbiwgaXQncyB0aGUgcmVhbFxuICogdGhpbmc7IGlmIHRoZXkgY2FuJ3QgYW5kIHRoZSBzdGF0dXMgbG9va3MgbGlrZSBhIGJsb2NrLCB0aGUgdXNlciBuZWVkcyB0b1xuICogc29sdmUgc29tZXRoaW5nLiBUaGF0IHdheSBhIHJlZGVzaWduZWQgY2hhbGxlbmdlIHBhZ2Ugc3RpbGwgbGFuZHMgaW4gdGhlIHJpZ2h0XG4gKiBzdGF0ZSwgYW5kIGEgcmVkZXNpZ25lZCAqcGFya3J1biogcGFnZSBmYWlscyBsb3VkbHkgaW5zdGVhZCBvZiBzaWxlbnRseVxuICogaW5nZXN0aW5nIG5vdGhpbmcuXG4gKi9cbmltcG9ydCB7XG5cdHBhcnNlRXZlbnRQYWdlTWV0YSxcblx0cGFyc2VMYXJnZXN0Q2x1YnMsXG5cdHBhcnNlUnVuUmVzdWx0cyxcblx0cGFyc2VSdW5uZXJEYXRhLFxufSBmcm9tICdAc2hhcmVkL3BhcmtydW4tcGFyc2VycydcbmltcG9ydCB7IHR5cGUgQ2FwdHVyZUtpbmQsIHJlYWRQYXN0RXZlbnRLZXkgfSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5cbmV4cG9ydCB0eXBlIFZlcmRpY3QgPVxuXHQvKiogVGhlIHBhZ2UgcGFyc2VkIOKAlCBjYXB0dXJlIGl0LiAqL1xuXHR8IHsgb3V0Y29tZTogJ29rJzsgZGV0YWlsOiBzdHJpbmcgfVxuXHQvKipcblx0ICogQSBib3QgY2hlY2sgb3IgYSB3b2JibGUuIFJldHJ5YWJsZSwgYW5kIHJldHJpZWQgYXV0b21hdGljYWxseS5cblx0ICpcblx0ICogYGF3YWl0VXNlcmAgbWFya3MgdGhlIG9uZXMgd2l0aCBzb21ldGhpbmcgb24gc2NyZWVuIGZvciBhIGh1bWFuIHRvIHNvbHZlIOKAlFxuXHQgKiB0aG9zZSBtdXN0IG5ldmVyIGJlIHJlbG9hZGVkIGZyb20gdW5kZXIgdGhlbSwgYW5kIG11c3QgbmV2ZXIgdGltZSBvdXQuXG5cdCAqL1xuXHR8IHsgb3V0Y29tZTogJ2Jsb2NrZWQnOyBkZXRhaWw6IHN0cmluZzsgYXdhaXRVc2VyPzogYm9vbGVhbiB9XG5cdC8qKiBMb2FkZWQgZmluZSBidXQgaXNuJ3Qgd2hhdCB3ZSBhc2tlZCBmb3IsIG9yIHBhcmtydW4gY2hhbmdlZCBzaGFwZS4gKi9cblx0fCB7IG91dGNvbWU6ICd1bnVzYWJsZSc7IGRldGFpbDogc3RyaW5nIH1cblxuLyoqXG4gKiBGaW5nZXJwcmludHMgb2YgYW4gaW50ZXJhY3RpdmUgY2hhbGxlbmdlIOKAlCBzb21ldGhpbmcgYSBwZXJzb24gaGFzIHRvIGNsaWNrXG4gKiB0aHJvdWdoLCBhcyBvcHBvc2VkIHRvIGEgdHJhbnNpZW50IGVycm9yLlxuICpcbiAqIHBhcmtydW4ncyBpbWFnZSBjYXB0Y2hhIChcIkxldCdzIGNvbmZpcm0geW91IGFyZSBodW1hbiDigJQgY2hvb3NlIGFsbCB0aGVcbiAqIGNsb2Nrc1wiKSBhcnJpdmVzIGFzIEhUVFAgNDA1LCBzbyB0aGUgc3RhdHVzIGFsb25lIHRlbGxzIHlvdSBub3RoaW5nIHVzZWZ1bC5cbiAqL1xuY29uc3QgQ0hBTExFTkdFX01BUktFUlMgPSBbXG5cdCcvY2RuLWNnaS9jaGFsbGVuZ2UtcGxhdGZvcm0nLFxuXHQnY29uZmlybSB5b3UgYXJlIGh1bWFuJyxcblx0J3ZlcmlmeSB5b3UgYXJlIGh1bWFuJyxcblx0J2FyZSB5b3UgYSByb2JvdCcsXG5cdCdjYXB0Y2hhJyxcblx0J3R1cm5zdGlsZScsXG5cdCdjZl9jaGwnLFxuXHQnY2YtY2hhbGxlbmdlJyxcblx0J2NoZWNraW5nIHlvdXIgYnJvd3NlcicsXG5cdCdqdXN0IGEgbW9tZW50Jyxcbl1cblxuZnVuY3Rpb24gbG9va3NMaWtlQ2hhbGxlbmdlKGh0bWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuXHRjb25zdCBoYXlzdGFjayA9IGh0bWwuc2xpY2UoMCwgMjAwXzAwMCkudG9Mb3dlckNhc2UoKVxuXHRyZXR1cm4gQ0hBTExFTkdFX01BUktFUlMuc29tZSgobWFya2VyKSA9PiBoYXlzdGFjay5pbmNsdWRlcyhtYXJrZXIpKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGUoXG5cdGtpbmQ6IENhcHR1cmVLaW5kLFxuXHRrZXk6IHN0cmluZyxcblx0c3RhdHVzOiBudW1iZXIsXG5cdGh0bWw6IHN0cmluZyxcbik6IFZlcmRpY3Qge1xuXHQvLyBBbnkgZXJyb3Igc3RhdHVzIGlzIHRyZWF0ZWQgYXMgcmV0cnlhYmxlIHJhdGhlciB0aGFuIGZhdGFsLiBCb3QgY2hlY2tzIGNvbWVcblx0Ly8gYmFjayB3aXRoIGFsbCBzb3J0cyDigJQgNDAzLCA0MDUsIDQyOSwgNTAzIOKAlCBhbmQgZmFpbGluZyBhbiBpdGVtIG91dHJpZ2h0IG9uXG5cdC8vIG9uZSB0aHJvd3MgYXdheSBhIHBhZ2UgdGhlIHVzZXIgY291bGQgaGF2ZSB1bmxvY2tlZCBpbiB0d28gY2xpY2tzLiBUaGVcblx0Ly8gYXR0ZW1wdCBsaW1pdCBzdG9wcyB0aGlzIGxvb3BpbmcgZm9yZXZlciwgYW5kIFNraXAgaXMgYWx3YXlzIGF2YWlsYWJsZS5cblx0aWYgKHN0YXR1cyA+PSA0MDApIHtcblx0XHRjb25zdCBjaGFsbGVuZ2UgPSBsb29rc0xpa2VDaGFsbGVuZ2UoaHRtbClcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0YXdhaXRVc2VyOiBjaGFsbGVuZ2UsXG5cdFx0XHRkZXRhaWw6IGNoYWxsZW5nZVxuXHRcdFx0XHQ/IGBwYXJrcnVuIHJlcGxpZWQgJHtzdGF0dXN9IGFuZCBpcyBhc2tpbmcgeW91IHRvIHByb3ZlIHlvdSdyZSBodW1hbiDigJQgc29sdmUgaXQgaW4gdGhlIHNjcmFwZSB0YWIgYW5kIHRoZSBydW4gY2FycmllcyBvbi5gXG5cdFx0XHRcdDogYHBhcmtydW4gcmVwbGllZCAke3N0YXR1c30g4oCUIHJldHJ5aW5nLmAsXG5cdFx0fVxuXHR9XG5cblx0Ly8gQSAyMDAgY2FuIHN0aWxsIGJlIGEgY2hhbGxlbmdlIHBhZ2UuXG5cdGlmIChsb29rc0xpa2VDaGFsbGVuZ2UoaHRtbCkgJiYgIXBhcnNlc0FzUmVhbFBhZ2Uoa2luZCwga2V5LCBodG1sKSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRhd2FpdFVzZXI6IHRydWUsXG5cdFx0XHRkZXRhaWw6XG5cdFx0XHRcdFwicGFya3J1biBpcyBhc2tpbmcgeW91IHRvIHByb3ZlIHlvdSdyZSBodW1hbiDigJQgc29sdmUgaXQgaW4gdGhlIHNjcmFwZSB0YWIgYW5kIHRoZSBydW4gY2FycmllcyBvbi5cIixcblx0XHR9XG5cdH1cblxuXHRzd2l0Y2ggKGtpbmQpIHtcblx0XHRjYXNlICdhdGhsZXRlJzpcblx0XHRcdHJldHVybiB2YWxpZGF0ZUF0aGxldGUoa2V5LCBodG1sKVxuXHRcdGNhc2UgJ2V2ZW50Jzpcblx0XHRcdHJldHVybiB2YWxpZGF0ZUV2ZW50KGtleSwgaHRtbClcblx0XHRjYXNlICdwYXN0RXZlbnQnOlxuXHRcdFx0cmV0dXJuIHZhbGlkYXRlUGFzdEV2ZW50KGtleSwgaHRtbClcblx0XHRjYXNlICdjbHVicyc6XG5cdFx0XHRyZXR1cm4gdmFsaWRhdGVDbHVicyhodG1sKVxuXHRcdGNhc2UgJ2NvdXJzZSc6XG5cdFx0XHRyZXR1cm4gdmFsaWRhdGVDb3Vyc2UoaHRtbClcblx0fVxufVxuXG4vKipcbiAqIFdoZXRoZXIgdGhlIHBhZ2UgaXMgZ2VudWluZWx5IHRoZSBvbmUgd2UgYXNrZWQgZm9yLiBVc2VkIHRvIHN0b3AgYSBjaGFsbGVuZ2VcbiAqIG1hcmtlciBpbiwgc2F5LCBhbiBhbmFseXRpY3Mgc25pcHBldCBmcm9tIHJlamVjdGluZyBhIHBlcmZlY3RseSBnb29kIHBhZ2UuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlc0FzUmVhbFBhZ2UoXG5cdGtpbmQ6IENhcHR1cmVLaW5kLFxuXHRrZXk6IHN0cmluZyxcblx0aHRtbDogc3RyaW5nLFxuKTogYm9vbGVhbiB7XG5cdHN3aXRjaCAoa2luZCkge1xuXHRcdGNhc2UgJ2F0aGxldGUnOlxuXHRcdFx0cmV0dXJuIHBhcnNlUnVuUmVzdWx0cyhodG1sKS5sZW5ndGggPiAwXG5cdFx0Y2FzZSAnZXZlbnQnOlxuXHRcdGNhc2UgJ3Bhc3RFdmVudCc6XG5cdFx0XHRyZXR1cm4gcGFyc2VFdmVudFBhZ2VNZXRhKGh0bWwpLmV2ZW50TnVtYmVyID4gMFxuXHRcdGNhc2UgJ2NsdWJzJzpcblx0XHRcdHJldHVybiBwYXJzZUxhcmdlc3RDbHVicyhodG1sKS5sZW5ndGggPiAwXG5cdFx0Y2FzZSAnY291cnNlJzpcblx0XHRcdHJldHVybiBleHRyYWN0TWFwTWlkKGh0bWwpICE9PSBudWxsXG5cdH1cbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVBdGhsZXRlKHBhcmtydW5JZDogc3RyaW5nLCBodG1sOiBzdHJpbmcpOiBWZXJkaWN0IHtcblx0Y29uc3QgcnVubmVyID0gcGFyc2VSdW5uZXJEYXRhKGh0bWwpXG5cdGNvbnN0IHJlc3VsdHMgPSBwYXJzZVJ1blJlc3VsdHMoaHRtbClcblxuXHRpZiAocnVubmVyLm5hbWUgPT09ICdVbmtub3duJyAmJiByZXN1bHRzLmxlbmd0aCA9PT0gMCkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRkZXRhaWw6IFwiQ291bGRuJ3QgcmVhZCB0aGUgcGFnZSDigJQgaXQgbWF5IGJlIGEgYm90IGNoZWNrLiBSZXRyeWluZy5cIixcblx0XHR9XG5cdH1cblx0aWYgKHJ1bm5lci5wYXJrcnVuSWQgJiYgcnVubmVyLnBhcmtydW5JZCAhPT0gcGFya3J1bklkKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG91dGNvbWU6ICd1bnVzYWJsZScsXG5cdFx0XHRkZXRhaWw6IGBQYWdlIGlzIGZvciBhdGhsZXRlICR7cnVubmVyLnBhcmtydW5JZH0sIGV4cGVjdGVkICR7cGFya3J1bklkfS5gLFxuXHRcdH1cblx0fVxuXHRpZiAocmVzdWx0cy5sZW5ndGggPT09IDApIHtcblx0XHRyZXR1cm4geyBvdXRjb21lOiAndW51c2FibGUnLCBkZXRhaWw6ICdObyBydW4gcmVzdWx0cyBmb3VuZCBvbiB0aGUgcGFnZS4nIH1cblx0fVxuXG5cdHJldHVybiB7XG5cdFx0b3V0Y29tZTogJ29rJyxcblx0XHRkZXRhaWw6IGAke3J1bm5lci5uYW1lfSDCtyAke3Jlc3VsdHMubGVuZ3RofSByZXN1bHRzYCxcblx0fVxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUV2ZW50KGV2ZW50SWQ6IHN0cmluZywgaHRtbDogc3RyaW5nKTogVmVyZGljdCB7XG5cdGNvbnN0IG1ldGEgPSBwYXJzZUV2ZW50UGFnZU1ldGEoaHRtbClcblxuXHRpZiAoIW1ldGEuZXZlbnROdW1iZXIgfHwgIW1ldGEuZGF0ZSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRkZXRhaWw6IFwiQ291bGRuJ3QgcmVhZCB0aGUgZXZlbnQgbnVtYmVyIG9yIGRhdGUg4oCUIGl0IG1heSBiZSBhIGJvdCBjaGVjay5cIixcblx0XHR9XG5cdH1cblx0aWYgKG1ldGEuZXZlbnRJZCAmJiBtZXRhLmV2ZW50SWQgIT09IGV2ZW50SWQpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ3VudXNhYmxlJyxcblx0XHRcdGRldGFpbDogYFBhZ2UgaXMgZm9yIFwiJHttZXRhLmV2ZW50SWR9XCIsIGV4cGVjdGVkIFwiJHtldmVudElkfVwiLmAsXG5cdFx0fVxuXHR9XG5cblx0Ly8gVm9sdW50ZWVyIGNvdW50cyBhcmVuJ3QgY2hlY2tlZDogYW4gZXZlbnQgd2hlcmUgbm9ib2R5IHdlIHRyYWNrIHZvbHVudGVlcmVkXG5cdC8vIGlzIGEgcGVyZmVjdGx5IGdvb2QgY2FwdHVyZS4gVGhlIHBhZ2UgZGVjaWRlcyB3aGF0J3MgaW4gaXQuXG5cdHJldHVybiB7IG91dGNvbWU6ICdvaycsIGRldGFpbDogYCMke21ldGEuZXZlbnROdW1iZXJ9IMK3ICR7bWV0YS5kYXRlfWAgfVxufVxuXG4vKipcbiAqIEEgbnVtYmVyZWQgcGFnZSBoYXMgdG8gYmUgdGhhdCBudW1iZXIsIHRvbzogYSBwYWdlIHRoYXQgcGFyc2VzIGZpbmUgYnV0IGlzXG4gKiBzb21lIG90aGVyIGV2ZW50IHdvdWxkIGJlIGNyZWRpdGVkIHRvIHRoZSB3cm9uZyB3ZWVrLlxuICovXG5mdW5jdGlvbiB2YWxpZGF0ZVBhc3RFdmVudChrZXk6IHN0cmluZywgaHRtbDogc3RyaW5nKTogVmVyZGljdCB7XG5cdGNvbnN0IGV4cGVjdGVkID0gcmVhZFBhc3RFdmVudEtleShrZXkpXG5cdGlmICghZXhwZWN0ZWQpIHtcblx0XHRyZXR1cm4geyBvdXRjb21lOiAndW51c2FibGUnLCBkZXRhaWw6IGBCYWQgd29yayBpdGVtIGtleSBcIiR7a2V5fVwiLmAgfVxuXHR9XG5cblx0Y29uc3QgdmVyZGljdCA9IHZhbGlkYXRlRXZlbnQoZXhwZWN0ZWQuZXZlbnRJZCwgaHRtbClcblx0aWYgKHZlcmRpY3Qub3V0Y29tZSAhPT0gJ29rJykgcmV0dXJuIHZlcmRpY3RcblxuXHRjb25zdCB7IGV2ZW50TnVtYmVyIH0gPSBwYXJzZUV2ZW50UGFnZU1ldGEoaHRtbClcblx0aWYgKGV2ZW50TnVtYmVyICE9PSBleHBlY3RlZC5ldmVudE51bWJlcikge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAndW51c2FibGUnLFxuXHRcdFx0ZGV0YWlsOiBgUGFnZSBpcyBldmVudCAjJHtldmVudE51bWJlcn0sIGV4cGVjdGVkICMke2V4cGVjdGVkLmV2ZW50TnVtYmVyfS5gLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4gdmVyZGljdFxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUNsdWJzKGh0bWw6IHN0cmluZyk6IFZlcmRpY3Qge1xuXHRjb25zdCBjbHVicyA9IHBhcnNlTGFyZ2VzdENsdWJzKGh0bWwpXG5cdGlmIChjbHVicy5sZW5ndGggPT09IDApIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0ZGV0YWlsOiBcIkNvdWxkbid0IHJlYWQgdGhlIGxlYWd1ZSB0YWJsZSDigJQgaXQgbWF5IGJlIGEgYm90IGNoZWNrLlwiLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4geyBvdXRjb21lOiAnb2snLCBkZXRhaWw6IGAke2NsdWJzLmxlbmd0aH0gY2x1YnNgIH1cbn1cblxuLyoqXG4gKiBDb3Vyc2UgcGFnZXMgYXJlIHZhbGlkYXRlZCBieSBmaW5kaW5nIHRoZSBHb29nbGUgbWFwLCBzaW5jZSB0aGF0J3MgdGhlIG9ubHlcbiAqIHBhcnQgd2UgdXNlLiBTYW1lIHJlZ2V4IGFzIGFwcHMvYXBpL2xpYi9tYXAtc2NyYXBlci50cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RNYXBNaWQoaHRtbDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG5cdGNvbnN0IG1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvc3JjPVwiaHR0cHM6XFwvXFwvd3d3XFwuZ29vZ2xlXFwuY29tXFwvbWFwc1xcL2RcXC9bXlwiXSo/Wz8mXW1pZD0oW14mXCJdKykvLFxuXHQpXG5cdHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbFxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUNvdXJzZShodG1sOiBzdHJpbmcpOiBWZXJkaWN0IHtcblx0aWYgKGV4dHJhY3RNYXBNaWQoaHRtbCkpIHtcblx0XHRyZXR1cm4geyBvdXRjb21lOiAnb2snLCBkZXRhaWw6ICdGb3VuZCB0aGUgZW1iZWRkZWQgbWFwJyB9XG5cdH1cblx0Ly8gQSBib3QgY2hlY2sgaGFzIG5vIG1hcCBlaXRoZXIg4oCUIGJ1dCBuZWl0aGVyIGRvZXMgYSBjb3Vyc2UgcGFnZSB3aXRob3V0IG9uZSxcblx0Ly8gd2hpY2ggaXMgYSByZWFsIGFuZCBwZXJtYW5lbnQgY29uZGl0aW9uLiBEaXN0aW5ndWlzaCBvbiBwYWdlIHNoYXBlLlxuXHRjb25zdCBsb29rc0xpa2VQYXJrcnVuID0gL3BhcmtydW4vaS50ZXN0KGh0bWwpICYmIGh0bWwubGVuZ3RoID4gMjBfMDAwXG5cdHJldHVybiBsb29rc0xpa2VQYXJrcnVuXG5cdFx0PyB7XG5cdFx0XHRcdG91dGNvbWU6ICd1bnVzYWJsZScsXG5cdFx0XHRcdGRldGFpbDogJ05vIEdvb2dsZSBtYXAgZW1iZWRkZWQgb24gdGhpcyBjb3Vyc2UgcGFnZS4nLFxuXHRcdFx0fVxuXHRcdDoge1xuXHRcdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRcdGRldGFpbDogXCJDb3VsZG4ndCByZWFkIHRoZSBjb3Vyc2UgcGFnZSDigJQgaXQgbWF5IGJlIGEgYm90IGNoZWNrLlwiLFxuXHRcdFx0fVxufVxuIiwiLyoqXG4gKiBUaGUgcnVuOiB3YWxrIHRoZSB3b3JrIGxpc3QsIGNhcHR1cmUgZWFjaCBwYWdlLCBkaXNjb3ZlciBuZXcgY291cnNlcywgZmluaXNoLlxuICpcbiAqIERyaXZlbiBlbnRpcmVseSBieSBldmVudHMgcmF0aGVyIHRoYW4gYSBsb29wLCBiZWNhdXNlIHRoZSBzZXJ2aWNlIHdvcmtlciBpc1xuICogdGVybWluYXRlZCBiZXR3ZWVuIHBhZ2UgbG9hZHMuIEV2ZXJ5IG1haW4tZnJhbWUgZG9jdW1lbnQgbG9hZCBpbiB0aGUgc2NyYXBlXG4gKiB0YWIgY2FsbHMgYGhhbmRsZURvY3VtZW50TG9hZGVkYCwgd2hpY2ggZGVjaWRlcyB3aGV0aGVyIHRoYXQgd2FzIHRoZSBwYWdlIHdlXG4gKiB3ZXJlIHdhaXRpbmcgZm9yLiBUaGF0J3MgYWxzbyBob3cgY2FwdGNoYXMgcmVzb2x2ZSB0aGVtc2VsdmVzOiBzb2x2aW5nIG9uZVxuICogbmF2aWdhdGVzIGFnYWluLCB3aGljaCBsYW5kcyBoZXJlIGFnYWluLlxuICovXG5pbXBvcnQgeyBleHRyYWN0RXZlbnRzLCBwYXJzZVJ1blJlc3VsdHMgfSBmcm9tICdAc2hhcmVkL3BhcmtydW4tcGFyc2VycydcbmltcG9ydCB7IGNvdXJzZUttelVybCwgY291cnNlUGFnZVVybCB9IGZyb20gJ0BzaGFyZWQvcGFya3J1bi11cmxzJ1xuaW1wb3J0IHtcblx0dHlwZSBDYXB0dXJlZEZpbGUsXG5cdHR5cGUgSXRlbVN0YXRlLFxuXHR0eXBlIFJ1blJlcXVlc3QsXG5cdHR5cGUgUnVuU3RhdGUsXG5cdHJlYWRQYXN0RXZlbnRLZXksXG59IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcbmltcG9ydCB7XG5cdGNsZWFyTGFzdERvY3VtZW50LFxuXHRkZXNjcmliZUVycm9yLFxuXHRkZXRhY2gsXG5cdGVuc3VyZUF0dGFjaGVkLFxuXHRnZXRMYXN0RG9jdW1lbnQsXG5cdGlzQm9keU5vdFJlYWR5LFxuXHRtYXJrRG9jdW1lbnRDb25zdW1lZCxcblx0cmVhZEJvZHksXG59IGZyb20gJy4vY2FwdHVyZSdcbmltcG9ydCB7IHN0YXJ0S2VlcGFsaXZlLCBzdG9wS2VlcGFsaXZlIH0gZnJvbSAnLi9rZWVwYWxpdmUnXG5pbXBvcnQgeyBub3RpZnlGaWxlLCBub3RpZnlTdGF0ZSB9IGZyb20gJy4vbWVzc2FnaW5nJ1xuaW1wb3J0IHtcblx0YXBwZW5kSXRlbXMsXG5cdGdldEZpbGVzLFxuXHRnZXRSdW5TdGF0ZSxcblx0Z2V0U2Vzc2lvbixcblx0cHV0RmlsZSxcblx0cmVzZXRBbGwsXG5cdHNldEl0ZW1TdGF0dXMsXG5cdHNldFJ1blN0YXRlLFxuXHRzZXRTZXNzaW9uLFxuXHR1cGRhdGVSdW5TdGF0ZSxcblx0dXBkYXRlU2Vzc2lvbixcbn0gZnJvbSAnLi9zdGF0ZSdcbmltcG9ydCB7IGV4dHJhY3RNYXBNaWQsIHZhbGlkYXRlIH0gZnJvbSAnLi92YWxpZGF0ZSdcblxuLyoqIEdpdmUgdXAgb24gYW4gaXRlbSBhZnRlciB0aGlzIG1hbnkgZmFpbGVkIGF0dGVtcHRzIGF0IHRoZSBzYW1lIFVSTC4gKi9cbmNvbnN0IE1BWF9BVFRFTVBUUyA9IDhcblxuLyoqXG4gKiBBIHBhZ2UgdGhhdCBoYXMgYmVlbiBgYWN0aXZlYCB0aGlzIGxvbmcgd2l0aG91dCBwcm9kdWNpbmcgYSBjYXB0dXJlIGhhc1xuICogYWxtb3N0IGNlcnRhaW5seSBoYWQgaXRzIGxvYWQgZXZlbnRzIG1pc3NlZCDigJQgcmVsb2FkIGl0IHJhdGhlciB0aGFuIGhhbmcuXG4gKi9cbmNvbnN0IFNUQUxMX1RJTUVPVVRfTVMgPSAyMF8wMDBcblxuLyoqIEhvdyBvZnRlbiB0aGUgd2F0Y2hkb2cgbG9va3MgZm9yIGEgc3RhbGxlZCBwYWdlLiAqL1xuY29uc3QgV0FUQ0hET0dfQUxBUk0gPSAnd2F0Y2hkb2cnXG5jb25zdCBXQVRDSERPR19QRVJJT0RfTUlOVVRFUyA9IDAuNVxuXG5mdW5jdGlvbiBsb2coLi4uYXJnczogdW5rbm93bltdKTogdm9pZCB7XG5cdGNvbnNvbGUubG9nKCdbcmVzdWx0cy1zY3JhcGVyXScsIC4uLmFyZ3MpXG59XG5cbi8qKlxuICogSG93IGxvbmcgYSBibG9ja2VkIHBhZ2Ugc2l0cyBiZWZvcmUgd2UgcmVsb2FkIGl0IG91cnNlbHZlcy5cbiAqXG4gKiBBIENsb3VkZmxhcmUgaW50ZXJzdGl0aWFsIHJlbG9hZHMgaXRzZWxmIG9uY2UgaXRzIGNoZWNrIHBhc3Nlcywgc28gdGhvc2UgY2xlYXJcbiAqIHdpdGhvdXQgaGVscC4gQSBmbGF0IDQwMyBkb2Vzbid0LCBhbmQgd291bGQgb3RoZXJ3aXNlIHdhaXQgZm9yZXZlci4gTG9uZ1xuICogZW5vdWdoIG5vdCB0byB5YW5rIHRoZSBwYWdlIG91dCBmcm9tIHVuZGVyIHNvbWVvbmUgbWlkLWNhcHRjaGEuXG4gKi9cbmNvbnN0IFJFVFJZX0FMQVJNID0gJ3JldHJ5LWJsb2NrZWQnXG5jb25zdCBSRVRSWV9ERUxBWV9NSU5VVEVTID0gMVxuXG5hc3luYyBmdW5jdGlvbiBzY2hlZHVsZVJldHJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuYWxhcm1zXG5cdFx0LmNyZWF0ZShSRVRSWV9BTEFSTSwgeyBkZWxheUluTWludXRlczogUkVUUllfREVMQVlfTUlOVVRFUyB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsU2NoZWR1bGVkUmV0cnkoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5hbGFybXMuY2xlYXIoUkVUUllfQUxBUk0pLmNhdGNoKCgpID0+IHt9KVxufVxuXG4vKiogUmVsb2FkIHdoYXRldmVyIHBhZ2UgdGhlIHJ1biBpcyBzdHVjayBvbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXRyeUN1cnJlbnQoKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnIHx8ICFzdGF0ZS5jdXJyZW50S2V5KSByZXR1cm4gc3RhdGVcblxuXHRjb25zdCBpdGVtID0gc3RhdGUuaXRlbXMuZmluZCgoaSkgPT4gaS5rZXkgPT09IHN0YXRlLmN1cnJlbnRLZXkpXG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKCFpdGVtIHx8IHNlc3Npb24uc2NyYXBlVGFiSWQgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHN0YXRlXG5cblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRhd2FpdCBjbGVhckxhc3REb2N1bWVudChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXG5cdHRyeSB7XG5cdFx0YXdhaXQgZW5zdXJlQXR0YWNoZWQoc2Vzc2lvbi5zY3JhcGVUYWJJZClcblx0XHRhd2FpdCBjaHJvbWUudGFicy51cGRhdGUoc2Vzc2lvbi5zY3JhcGVUYWJJZCwgeyB1cmw6IGl0ZW0udXJsIH0pXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oZGVzY3JpYmVFcnJvcihlcnJvcikpXG5cdH1cblx0cmV0dXJuIHN0YXRlXG59XG5cbi8qKiBBYmFuZG9uIHRoZSBjdXJyZW50IHBhZ2UgYW5kIGNhcnJ5IG9uIHdpdGggdGhlIG5leHQgb25lLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNraXBDdXJyZW50KCk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuIHN0YXRlXG5cblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRhd2FpdCBzZXRJdGVtU3RhdHVzKHN0YXRlLmN1cnJlbnRLZXksICdza2lwcGVkJywgJ1NraXBwZWQuJylcblx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0cmV0dXJuIGFkdmFuY2UoKVxufVxuXG4vKipcbiAqIFRoZSBzY3JhcGUgdGFiIGZpbmlzaGVkIGxvYWRpbmcgYnV0IHdlIGhhdmUgbm8gY2FwdHVyZWQgYm9keSBmb3IgaXQuXG4gKlxuICogVGhhdCBtZWFucyB0aGUgZGVidWdnZXIncyBOZXR3b3JrIGV2ZW50cyBmb3IgdGhpcyBuYXZpZ2F0aW9uIG5ldmVyIHJlYWNoZWQgdXMg4oCUXG4gKiBhIHdvcmtlciB0aGF0IHdhcyBhc2xlZXAgYXQgdGhlIHdyb25nIG1vbWVudCwgbW9zdCBvZnRlbi4gVGhlcmUncyBubyB3YXkgdG8gYXNrXG4gKiBmb3IgYSBib2R5IGFmdGVyIHRoZSBmYWN0LCBzbyB0aGUgb25seSByZWNvdmVyeSBpcyB0byBsb2FkIHRoZSBwYWdlIGFnYWluIHdpdGhcbiAqIHRoZSB3b3JrZXIgbm93IGRlbW9uc3RyYWJseSBhd2FrZS4gRG9pbmcgaXQgaGVyZSByYXRoZXIgdGhhbiBsZWF2aW5nIGl0IHRvIHRoZVxuICogd2F0Y2hkb2cgdHVybnMgYSAyMC1zZWNvbmQgc3RhbGwgaW50byBhYm91dCBhIHNlY29uZC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlY292ZXJNaXNzZWRDYXB0dXJlKHRhYklkOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuXG5cblx0Y29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGkpID0+IGkua2V5ID09PSBzdGF0ZS5jdXJyZW50S2V5KVxuXHRpZiAoaXRlbT8uc3RhdHVzICE9PSAnYWN0aXZlJykgcmV0dXJuXG5cblx0Ly8gSWYgYSBib2R5IGlzIHdhaXRpbmcsIHRoZSBub3JtYWwgcGF0aCBoYXMgaXQg4oCUIG5vdGhpbmcgdG8gcmVjb3Zlci5cblx0Y29uc3QgZG9jdW1lbnQgPSBhd2FpdCBnZXRMYXN0RG9jdW1lbnQodGFiSWQpXG5cdGlmIChkb2N1bWVudCAmJiAhZG9jdW1lbnQuY29uc3VtZWQpIHJldHVyblxuXG5cdGNvbnN0IGF0dGVtcHRzID0gKGl0ZW0uYXR0ZW1wdHMgPz8gMCkgKyAxXG5cdGlmIChhdHRlbXB0cyA+IE1BWF9BVFRFTVBUUykge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdmYWlsZWQnLFxuXHRcdFx0YFBhZ2UgbG9hZGVkIGJ1dCBpdHMgcmVzcG9uc2Ugd2FzIG5ldmVyIGNhcHR1cmVkLCBhZnRlciAke2F0dGVtcHRzfSBhdHRlbXB0cy5gLFxuXHRcdFx0YXR0ZW1wdHMsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRsb2coXG5cdFx0YCR7aXRlbS5sYWJlbH06IGxvYWRlZCBidXQgbm8gcmVzcG9uc2UgY2FwdHVyZWQg4oCUIHJlbG9hZGluZyAoYXR0ZW1wdCAke2F0dGVtcHRzfSlgLFxuXHQpXG5cdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0aXRlbS5rZXksXG5cdFx0J2FjdGl2ZScsXG5cdFx0J1BhZ2UgbG9hZGVkIGJ1dCB0aGUgY2FwdHVyZSB3YXMgbWlzc2VkIOKAlCByZWxvYWRpbmcuJyxcblx0XHRhdHRlbXB0cyxcblx0KVxuXHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRhd2FpdCByZXRyeUN1cnJlbnQoKVxufVxuXG4vKiogRmlyZWQgYnkgdGhlIGFsYXJtOiBudWRnZSBhIHBhZ2UgdGhhdCdzIHN0aWxsIHN0dWNrLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJldHJ5SWZTdGlsbEJsb2NrZWQoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycgfHwgIXN0YXRlLmN1cnJlbnRLZXkpIHJldHVyblxuXG5cdGNvbnN0IGl0ZW0gPSBzdGF0ZS5pdGVtcy5maW5kKChpKSA9PiBpLmtleSA9PT0gc3RhdGUuY3VycmVudEtleSlcblx0aWYgKGl0ZW0/LnN0YXR1cyAhPT0gJ2Jsb2NrZWQnKSByZXR1cm5cblxuXHQvLyBOZXZlciByZWxvYWQgYSBwYWdlIHRoZSB1c2VyIGlzIHBhcnQtd2F5IHRocm91Z2ggc29sdmluZy5cblx0aWYgKGl0ZW0uYXdhaXRVc2VyKSB7XG5cdFx0bG9nKGAke2l0ZW0ubGFiZWx9OiBzdGlsbCB3YWl0aW5nIGZvciB0aGUgdXNlcjsgbm90IHJlbG9hZGluZ2ApXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLmF0dGVtcHRzID49IE1BWF9BVFRFTVBUUykge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdmYWlsZWQnLFxuXHRcdFx0YCR7aXRlbS5kZXRhaWwgPz8gJ0Jsb2NrZWQuJ30gR2F2ZSB1cCBhZnRlciAke3Nlc3Npb24uYXR0ZW1wdHN9IGF0dGVtcHRzLmAsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRhd2FpdCByZXRyeUN1cnJlbnQoKVxufVxuXG4vLyDilIDilIAgU3RhcnRpbmcgYW5kIHN0b3BwaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3RhcnRSdW4oXG5cdHJlcXVlc3Q6IFJ1blJlcXVlc3QsXG5cdGFkbWluVGFiSWQ6IG51bWJlcixcbik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0YXdhaXQgcmVzZXRBbGwoKVxuXG5cdGNvbnN0IGl0ZW1zOiBJdGVtU3RhdGVbXSA9IHJlcXVlc3QuaXRlbXMubWFwKChpdGVtKSA9PiAoe1xuXHRcdC4uLml0ZW0sXG5cdFx0c3RhdHVzOiAncGVuZGluZycsXG5cdH0pKVxuXG5cdGlmIChpdGVtcy5sZW5ndGggPT09IDApIHtcblx0XHRjb25zdCBzdGF0ZTogUnVuU3RhdGUgPSB7XG5cdFx0XHRzdGF0dXM6ICdlcnJvcicsXG5cdFx0XHRpdGVtczogW10sXG5cdFx0XHRtZXNzYWdlOiAnTm90aGluZyB0byBzY3JhcGUuJyxcblx0XHR9XG5cdFx0YXdhaXQgc2V0UnVuU3RhdGUoc3RhdGUpXG5cdFx0cmV0dXJuIHN0YXRlXG5cdH1cblxuXHQvLyBBIGRlZGljYXRlZCB0YWIga2VlcHMgdGhlIGFkbWluIHBhZ2UgYWxpdmUsIHNvIGl0IGNhbiBzaG93IHByb2dyZXNzIGFuZFxuXHQvLyB0YWtlIGZpbGVzIGFzIHRoZXkgYXJyaXZlLlxuXHRjb25zdCB0YWIgPSBhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6ICdhYm91dDpibGFuaycsIGFjdGl2ZTogdHJ1ZSB9KVxuXHRpZiAodGFiLmlkID09PSB1bmRlZmluZWQpIHRocm93IG5ldyBFcnJvcignQ291bGQgbm90IG9wZW4gYSBzY3JhcGUgdGFiJylcblxuXHRhd2FpdCBzZXRTZXNzaW9uKHtcblx0XHRhZG1pblRhYklkLFxuXHRcdHNjcmFwZVRhYklkOiB0YWIuaWQsXG5cdFx0a25vd25Db3Vyc2VFdmVudElkczogcmVxdWVzdC5rbm93bkNvdXJzZUV2ZW50SWRzLFxuXHRcdGRpc2NvdmVyZWRFdmVudHM6IHt9LFxuXHRcdGNvdXJzZXNRdWV1ZWQ6IGZhbHNlLFxuXHRcdHNraXBDb3Vyc2VzOiByZXF1ZXN0LnNraXBDb3Vyc2VzID8/IGZhbHNlLFxuXHRcdGF0dGVtcHRzOiAwLFxuXHRcdHBhdXNlTXM6IHJlcXVlc3QucGF1c2VNcyxcblx0fSlcblxuXHRjb25zdCBzdGF0ZTogUnVuU3RhdGUgPSB7XG5cdFx0c3RhdHVzOiAncnVubmluZycsXG5cdFx0aXRlbXMsXG5cdFx0c3RhcnRlZEF0OiBEYXRlLm5vdygpLFxuXHR9XG5cdGF3YWl0IHNldFJ1blN0YXRlKHN0YXRlKVxuXG5cdHRyeSB7XG5cdFx0YXdhaXQgZW5zdXJlQXR0YWNoZWQodGFiLmlkKVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBmYWlsUnVuKGRlc2NyaWJlRXJyb3IoZXJyb3IpKVxuXHR9XG5cblx0YXdhaXQgc2V0QmFkZ2UoJ+KApicpXG5cdHN0YXJ0S2VlcGFsaXZlKClcblx0YXdhaXQgY2hyb21lLmFsYXJtc1xuXHRcdC5jcmVhdGUoV0FUQ0hET0dfQUxBUk0sIHsgcGVyaW9kSW5NaW51dGVzOiBXQVRDSERPR19QRVJJT0RfTUlOVVRFUyB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcblx0bG9nKGBydW4gc3RhcnRlZDogJHtpdGVtcy5sZW5ndGh9IGl0ZW1zLCBzY3JhcGUgdGFiICR7dGFiLmlkfWApXG5cdHJldHVybiBhZHZhbmNlKClcbn1cblxuLyoqXG4gKiBVbnN0aWNrIGEgcGFnZSB3aG9zZSBsb2FkIGV2ZW50cyBuZXZlciBhcnJpdmVkLlxuICpcbiAqIFRoZSBkZWJ1Z2dlciBpcyB0aGUgb25seSBzb3VyY2Ugb2YgY2FwdHVyZSBldmVudHMsIGFuZCBpZiB0aGUgc2VydmljZSB3b3JrZXJcbiAqIHdhcyBhc2xlZXAgd2hlbiB0aGV5IGZpcmVkIOKAlCBvciB0aGV5IHdlcmUgZHJvcHBlZCDigJQgbm90aGluZyBlbHNlIHdpbGwgZXZlclxuICogdHJpZ2dlci4gUmVsb2FkaW5nIHByb2R1Y2VzIGEgZnJlc2ggc2V0LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2hlY2tGb3JTdGFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuXG5cblx0Y29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGkpID0+IGkua2V5ID09PSBzdGF0ZS5jdXJyZW50S2V5KVxuXHRpZiAoaXRlbT8uc3RhdHVzICE9PSAnYWN0aXZlJykgcmV0dXJuXG5cblx0Y29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIChpdGVtLnVwZGF0ZWRBdCA/PyAwKVxuXHRpZiAoYWdlIDwgU1RBTExfVElNRU9VVF9NUykgcmV0dXJuXG5cblx0Y29uc3QgYXR0ZW1wdHMgPSAoaXRlbS5hdHRlbXB0cyA/PyAwKSArIDFcblx0aWYgKGF0dGVtcHRzID4gTUFYX0FUVEVNUFRTKSB7XG5cdFx0bG9nKGBnaXZpbmcgdXAgb24gJHtpdGVtLmxhYmVsfSBhZnRlciAke2F0dGVtcHRzfSBhdHRlbXB0c2ApXG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRcdGl0ZW0ua2V5LFxuXHRcdFx0J2ZhaWxlZCcsXG5cdFx0XHRgTm8gcmVzcG9uc2UgYWZ0ZXIgJHthdHRlbXB0c30gYXR0ZW1wdHMg4oCUIHBhZ2UgbmV2ZXIgZmluaXNoZWQgbG9hZGluZy5gLFxuXHRcdFx0YXR0ZW1wdHMsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRsb2coXG5cdFx0YCR7aXRlbS5sYWJlbH0gc3RhbGxlZCBmb3IgJHtNYXRoLnJvdW5kKGFnZSAvIDEwMDApfXMg4oCUIHJlbG9hZGluZyAoYXR0ZW1wdCAke2F0dGVtcHRzfSlgLFxuXHQpXG5cdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0aXRlbS5rZXksXG5cdFx0J2FjdGl2ZScsXG5cdFx0YE5vIHJlc3BvbnNlIGFmdGVyICR7TWF0aC5yb3VuZChhZ2UgLyAxMDAwKX1zIOKAlCByZWxvYWRpbmcgKGF0dGVtcHQgJHthdHRlbXB0c30pLmAsXG5cdFx0YXR0ZW1wdHMsXG5cdClcblx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0YXdhaXQgcmV0cnlDdXJyZW50KClcbn1cblxuLyoqXG4gKiBXaXBlIHRoZSBydW4gYW5kIGl0cyBjYXB0dXJlZCBmaWxlcy5cbiAqXG4gKiBDYWxsZWQgb25jZSB0aGUgYWRtaW4gcGFnZSBoYXMgdXBsb2FkZWQsIHNvIHJlb3BlbmluZyB0aGUgcGFnZSBkb2Vzbid0IG9mZmVyXG4gKiB0byByZS1kZWxpdmVyIHBhZ2VzIHdob3NlIGRhdGEgaXMgYWxyZWFkeSBpbiB0aGUgZGF0YWJhc2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmb3JnZXRSdW4oKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0c3RvcEtlZXBhbGl2ZSgpXG5cdGF3YWl0IGNocm9tZS5hbGFybXMuY2xlYXIoV0FUQ0hET0dfQUxBUk0pLmNhdGNoKCgpID0+IHt9KVxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB1bmRlZmluZWQpIHtcblx0XHRhd2FpdCBkZXRhY2goc2Vzc2lvbi5zY3JhcGVUYWJJZClcblx0XHRhd2FpdCBjbGVhckxhc3REb2N1bWVudChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXHR9XG5cdGF3YWl0IHJlc2V0QWxsKClcblx0YXdhaXQgc2V0QmFkZ2UoJycpXG5cdGxvZygncnVuIGNsZWFyZWQnKVxufVxuXG4vKipcbiAqIFBpY2sgdXAgYSBydW4gdGhhdCBzdG9wcGVkIGVhcmx5IOKAlCBjYW5jZWxsZWQsIHRhYiBjbG9zZWQsIGRlYnVnZ2VyIGRldGFjaGVkLFxuICogYnJvd3NlciByZXN0YXJ0ZWQuXG4gKlxuICogRGVsaWJlcmF0ZWx5IG5vdCBhIGZyZXNoIGBzdGFydFJ1bmA6IHRoYXQgd291bGQgd2lwZSB0aGUgY2FwdHVyZWQgcGFnZXMgYW5kXG4gKiByZS1mZXRjaCBldmVyeXRoaW5nLiBJbnN0ZWFkIHRoZSBjYXB0dXJlZCBhbmQgc2tpcHBlZCBpdGVtcyBhcmUgbGVmdCBhbG9uZSBhbmRcbiAqIGV2ZXJ5dGhpbmcgZWxzZSBnb2VzIGJhY2sgdG8gcGVuZGluZywgc28gYSBzY3JhcGUgaW50ZXJydXB0ZWQgYXQgcGFnZSA3IG9mIDE4XG4gKiBjb3N0cyAxMSBtb3JlIHBhZ2UgbG9hZHMsIG5vdCAxOC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlc3VtZVJ1bihhZG1pblRhYklkOiBudW1iZXIpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGNvbnN0IHByZXZpb3VzID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAocHJldmlvdXMuaXRlbXMubGVuZ3RoID09PSAwKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oJ1RoZXJlIGlzIG5vIHJ1biB0byByZXN1bWUuJylcblx0fVxuXG5cdGNvbnN0IGl0ZW1zOiBJdGVtU3RhdGVbXSA9IHByZXZpb3VzLml0ZW1zLm1hcCgoaXRlbSkgPT5cblx0XHRpdGVtLnN0YXR1cyA9PT0gJ2NhcHR1cmVkJyB8fCBpdGVtLnN0YXR1cyA9PT0gJ3NraXBwZWQnXG5cdFx0XHQ/IGl0ZW1cblx0XHRcdDoge1xuXHRcdFx0XHRcdC4uLml0ZW0sXG5cdFx0XHRcdFx0c3RhdHVzOiAncGVuZGluZycgYXMgY29uc3QsXG5cdFx0XHRcdFx0ZGV0YWlsOiB1bmRlZmluZWQsXG5cdFx0XHRcdFx0YXR0ZW1wdHM6IDAsXG5cdFx0XHRcdFx0YXdhaXRVc2VyOiB1bmRlZmluZWQsXG5cdFx0XHRcdFx0dXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHR9LFxuXHQpXG5cblx0Y29uc3Qgb3V0c3RhbmRpbmcgPSBpdGVtcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzID09PSAncGVuZGluZycpLmxlbmd0aFxuXHRpZiAob3V0c3RhbmRpbmcgPT09IDApIHtcblx0XHRyZXR1cm4gZmFpbFJ1bignRXZlcnkgcGFnZSBpbiB0aGF0IHJ1biBpcyBhbHJlYWR5IGNhcHR1cmVkIG9yIHNraXBwZWQuJylcblx0fVxuXG5cdGNvbnN0IHRhYiA9IGF3YWl0IGNocm9tZS50YWJzLmNyZWF0ZSh7IHVybDogJ2Fib3V0OmJsYW5rJywgYWN0aXZlOiB0cnVlIH0pXG5cdGlmICh0YWIuaWQgPT09IHVuZGVmaW5lZCkgdGhyb3cgbmV3IEVycm9yKCdDb3VsZCBub3Qgb3BlbiBhIHNjcmFwZSB0YWInKVxuXG5cdC8vIFRoZSBzZXNzaW9uIGNhcnJpZXMgdGhlIGV2ZW50cyBkaXNjb3ZlcmVkIGJ5IGF0aGxldGUgcGFnZXMgd2UgYWxyZWFkeSBoYXZlLFxuXHQvLyBzbyB0aGUgY291cnNlIGh1bnQgc3RpbGwga25vd3MgYWJvdXQgdGhlbSB3aXRob3V0IHJlLXBhcnNpbmcgYW55dGhpbmcuXG5cdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHNlc3Npb24pID0+ICh7XG5cdFx0Li4uc2Vzc2lvbixcblx0XHRhZG1pblRhYklkLFxuXHRcdHNjcmFwZVRhYklkOiB0YWIuaWQsXG5cdFx0YXR0ZW1wdHM6IDAsXG5cdH0pKVxuXG5cdGF3YWl0IHNldFJ1blN0YXRlKHtcblx0XHQuLi5wcmV2aW91cyxcblx0XHRzdGF0dXM6ICdydW5uaW5nJyxcblx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0aXRlbXMsXG5cdFx0bWVzc2FnZTogdW5kZWZpbmVkLFxuXHRcdGZpbmlzaGVkQXQ6IHVuZGVmaW5lZCxcblx0fSlcblxuXHR0cnkge1xuXHRcdGF3YWl0IGVuc3VyZUF0dGFjaGVkKHRhYi5pZClcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRyZXR1cm4gZmFpbFJ1bihkZXNjcmliZUVycm9yKGVycm9yKSlcblx0fVxuXG5cdGF3YWl0IHNldEJhZGdlKCfigKYnKVxuXHRzdGFydEtlZXBhbGl2ZSgpXG5cdGF3YWl0IGNocm9tZS5hbGFybXNcblx0XHQuY3JlYXRlKFdBVENIRE9HX0FMQVJNLCB7IHBlcmlvZEluTWludXRlczogV0FUQ0hET0dfUEVSSU9EX01JTlVURVMgfSlcblx0XHQuY2F0Y2goKCkgPT4ge30pXG5cdGxvZyhgcmVzdW1pbmc6ICR7b3V0c3RhbmRpbmd9IG9mICR7aXRlbXMubGVuZ3RofSBwYWdlcyBzdGlsbCBuZWVkZWRgKVxuXHRyZXR1cm4gYWR2YW5jZSgpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjYW5jZWxSdW4oKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRhd2FpdCBjYW5jZWxTY2hlZHVsZWRSZXRyeSgpXG5cdHN0b3BLZWVwYWxpdmUoKVxuXHRhd2FpdCBjaHJvbWUuYWxhcm1zLmNsZWFyKFdBVENIRE9HX0FMQVJNKS5jYXRjaCgoKSA9PiB7fSlcblxuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0Y29uc3QgY2FuY2VsbGVkOiBSdW5TdGF0ZSA9IHtcblx0XHQuLi5zdGF0ZSxcblx0XHRzdGF0dXM6ICdjYW5jZWxsZWQnLFxuXHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRmaW5pc2hlZEF0OiBEYXRlLm5vdygpLFxuXHRcdG1lc3NhZ2U6ICdDYW5jZWxsZWQuJyxcblx0fVxuXHQvLyBTdGF0dXMgZmlyc3QsIHRoZW4gdGhlIHRhYiDigJQgc2VlIGZpbmlzaFJ1bi5cblx0YXdhaXQgc2V0UnVuU3RhdGUoY2FuY2VsbGVkKVxuXHRhd2FpdCBjbG9zZVNjcmFwZVRhYigpXG5cdGF3YWl0IHNldEJhZGdlKCcnKVxuXHRhd2FpdCBmb2N1c0FkbWluVGFiKClcblx0YXdhaXQgbm90aWZ5U3RhdGUoY2FuY2VsbGVkKVxuXHRyZXR1cm4gY2FuY2VsbGVkXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZhaWxSdW4obWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRzdG9wS2VlcGFsaXZlKClcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGNvbnN0IGZhaWxlZDogUnVuU3RhdGUgPSB7XG5cdFx0Li4uc3RhdGUsXG5cdFx0c3RhdHVzOiAnZXJyb3InLFxuXHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRmaW5pc2hlZEF0OiBEYXRlLm5vdygpLFxuXHRcdG1lc3NhZ2UsXG5cdH1cblx0YXdhaXQgc2V0UnVuU3RhdGUoZmFpbGVkKVxuXHRhd2FpdCBzZXRCYWRnZSgnIScpXG5cdGF3YWl0IG5vdGlmeVN0YXRlKGZhaWxlZClcblx0cmV0dXJuIGZhaWxlZFxufVxuXG4vLyDilIDilIAgTW92aW5nIHRocm91Z2ggdGhlIHF1ZXVlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKiogTmF2aWdhdGUgdG8gdGhlIG5leHQgcGVuZGluZyBpdGVtLCBvciBmaW5pc2ggaWYgdGhlcmUgYXJlIG5vbmUgbGVmdC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZHZhbmNlKCk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0YXdhaXQgcGF1c2VCZXR3ZWVuUGFnZXMoKVxuXG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycpIHJldHVybiBzdGF0ZVxuXG5cdGNvbnN0IG5leHQgPSBzdGF0ZS5pdGVtcy5maW5kKChpdGVtKSA9PiBpdGVtLnN0YXR1cyA9PT0gJ3BlbmRpbmcnKVxuXG5cdGlmICghbmV4dCkge1xuXHRcdC8vIEF0aGxldGUgcGFnZXMgYXJlIGRvbmUg4oCUIGlzIHRoZXJlIGNvdXJzZSB3b3JrIHRvIGFkZCBiZWZvcmUgZmluaXNoaW5nP1xuXHRcdGNvbnN0IHF1ZXVlZCA9IGF3YWl0IHF1ZXVlTmV3Q291cnNlcygpXG5cdFx0aWYgKHF1ZXVlZCkgcmV0dXJuIGFkdmFuY2UoKVxuXHRcdHJldHVybiBmaW5pc2hSdW4oKVxuXHR9XG5cblx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoc2Vzc2lvbi5zY3JhcGVUYWJJZCA9PT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oJ1RoZSBzY3JhcGUgdGFiIGlzIGdvbmUuJylcblx0fVxuXG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0YXdhaXQgdXBkYXRlU2Vzc2lvbigocykgPT4gKHsgLi4ucywgYXR0ZW1wdHM6IDAgfSkpXG5cdGF3YWl0IGNsZWFyTGFzdERvY3VtZW50KHNlc3Npb24uc2NyYXBlVGFiSWQpXG5cblx0Y29uc3QgcnVubmluZzogUnVuU3RhdGUgPSB7XG5cdFx0Li4uc3RhdGUsXG5cdFx0Y3VycmVudEtleTogbmV4dC5rZXksXG5cdFx0aXRlbXM6IHN0YXRlLml0ZW1zLm1hcCgoaXRlbSkgPT5cblx0XHRcdGl0ZW0ua2V5ID09PSBuZXh0LmtleVxuXHRcdFx0XHQ/IHtcblx0XHRcdFx0XHRcdC4uLml0ZW0sXG5cdFx0XHRcdFx0XHRzdGF0dXM6ICdhY3RpdmUnLFxuXHRcdFx0XHRcdFx0ZGV0YWlsOiAnTG9hZGluZ+KApicsXG5cdFx0XHRcdFx0XHRhdHRlbXB0czogMCxcblx0XHRcdFx0XHRcdHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdDogaXRlbSxcblx0XHQpLFxuXHRcdG1lc3NhZ2U6IHVuZGVmaW5lZCxcblx0fVxuXHRhd2FpdCBzZXRSdW5TdGF0ZShydW5uaW5nKVxuXHRhd2FpdCBub3RpZnlTdGF0ZShydW5uaW5nKVxuXG5cdGxvZyhg4oaSICR7bmV4dC5sYWJlbH06ICR7bmV4dC51cmx9YClcblxuXHR0cnkge1xuXHRcdGF3YWl0IGVuc3VyZUF0dGFjaGVkKHNlc3Npb24uc2NyYXBlVGFiSWQpXG5cdFx0YXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKHNlc3Npb24uc2NyYXBlVGFiSWQsIHsgdXJsOiBuZXh0LnVybCB9KVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBmYWlsUnVuKGRlc2NyaWJlRXJyb3IoZXJyb3IpKVxuXHR9XG5cblx0cmV0dXJuIHJ1bm5pbmdcbn1cblxuLyoqXG4gKiBXYWl0IGJlZm9yZSB0aGUgbmV4dCBwYWdlLCBpZiB0aGUgcnVuIGFza2VkIGZvciB0aGF0LlxuICpcbiAqIEppdHRlcmVkIHNvIHRoZSBsb2FkcyBkb24ndCBsYW5kIG9uIGEgbWV0cm9ub21lLiBTa2lwcGVkIGJlZm9yZSB0aGUgZmlyc3RcbiAqIHBhZ2UgYW5kIGFmdGVyIHRoZSBsYXN0LiBUaGUga2VlcGFsaXZlIGhvbGRzIHRoZSB3b3JrZXIgb3BlbiBtZWFud2hpbGUsIGFuZFxuICogYGFkdmFuY2VgIHJlLXJlYWRzIHRoZSBzdGF0ZSBhZnRlcndhcmRzLCBzbyBhIGNhbmNlbCBkdXJpbmcgdGhlIHdhaXQgc3RpY2tzLlxuICovXG5hc3luYyBmdW5jdGlvbiBwYXVzZUJldHdlZW5QYWdlcygpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgeyBwYXVzZU1zIH0gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKCFwYXVzZU1zKSByZXR1cm5cblxuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnKSByZXR1cm5cblx0Y29uc3Qgc3RhcnRlZCA9IHN0YXRlLml0ZW1zLnNvbWUoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzICE9PSAncGVuZGluZycpXG5cdGNvbnN0IHJlbWFpbmluZyA9IHN0YXRlLml0ZW1zLnNvbWUoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzID09PSAncGVuZGluZycpXG5cdGlmICghc3RhcnRlZCB8fCAhcmVtYWluaW5nKSByZXR1cm5cblxuXHRjb25zdCB3YWl0ID0gTWF0aC5yb3VuZChwYXVzZU1zICogKDAuNSArIE1hdGgucmFuZG9tKCkpKVxuXHRhd2FpdCBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCB3YWl0KSlcbn1cblxuLyoqXG4gKiBDYWxsZWQgZm9yIGV2ZXJ5IGZpbmlzaGVkIG1haW4tZnJhbWUgZG9jdW1lbnQgaW4gdGhlIHNjcmFwZSB0YWIuXG4gKlxuICogSWdub3JlcyBhbnl0aGluZyB0aGF0IGlzbid0IHRoZSBwYWdlIHRoZSBjdXJyZW50IGl0ZW0gYXNrZWQgZm9yIOKAlCBwYXJrcnVuXG4gKiByZWRpcmVjdHMsIGFuZCBhIGNoYWxsZW5nZSBwYWdlIGNhbiBuYXZpZ2F0ZSBhIGZldyB0aW1lcyBiZWZvcmUgc2V0dGxpbmcuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYW5kbGVEb2N1bWVudExvYWRlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycgfHwgIXN0YXRlLmN1cnJlbnRLZXkpIHJldHVyblxuXG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKHNlc3Npb24uc2NyYXBlVGFiSWQgIT09IHRhYklkKSByZXR1cm5cblxuXHRjb25zdCBpdGVtID0gc3RhdGUuaXRlbXMuZmluZCgoaSkgPT4gaS5rZXkgPT09IHN0YXRlLmN1cnJlbnRLZXkpXG5cdGlmICghaXRlbSkgcmV0dXJuXG5cblx0Ly8gRGVsaWJlcmF0ZWx5IG5vdCByZXF1aXJpbmcgYGZpbmlzaGVkYDogdGhpcyBydW5zIGZyb20gdGhlIGRlYnVnZ2VyJ3Ncblx0Ly8gbG9hZGluZ0ZpbmlzaGVkIGV2ZW50ICphbmQqIGZyb20gdGFicy5vblVwZGF0ZWQsIGJlY2F1c2UgdGhlIGRlYnVnZ2VyIGV2ZW50c1xuXHQvLyBhcmUgbm90IHJlbGlhYmx5IGRlbGl2ZXJlZCDigJQgYSBydW4gd291bGQgb3RoZXJ3aXNlIHNpdCBvbiBcIkxvYWRpbmfigKZcIiB1bnRpbFxuXHQvLyB0aGUgd2F0Y2hkb2cgbm90aWNlZC4gV2hpY2hldmVyIHRyaWdnZXIgYXJyaXZlcyBmaXJzdCB3aXRoIGEgcmVhZGFibGUgYm9keVxuXHQvLyB3aW5zLCBhbmQgYSBib2R5IHRoYXQgaXNuJ3QgcmVhZHkgeWV0IGlzIHNpbXBseSB3YWl0ZWQgb3V0LlxuXHRjb25zdCBkb2N1bWVudCA9IGF3YWl0IGdldExhc3REb2N1bWVudCh0YWJJZClcblx0aWYgKCFkb2N1bWVudCB8fCBkb2N1bWVudC5jb25zdW1lZCkgcmV0dXJuXG5cblx0bGV0IGNhcHR1cmVkOiBBd2FpdGVkPFJldHVyblR5cGU8dHlwZW9mIHJlYWRCb2R5Pj5cblx0dHJ5IHtcblx0XHRjYXB0dXJlZCA9IGF3YWl0IHJlYWRCb2R5KHRhYklkLCBkb2N1bWVudClcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRpZiAoaXNCb2R5Tm90UmVhZHkoZXJyb3IpKSByZXR1cm5cblxuXHRcdGNvbnN0IGF0dGVtcHRzID0gKFxuXHRcdFx0YXdhaXQgdXBkYXRlU2Vzc2lvbigocykgPT4gKHsgLi4ucywgYXR0ZW1wdHM6IHMuYXR0ZW1wdHMgKyAxIH0pKVxuXHRcdCkuYXR0ZW1wdHNcblx0XHRsb2coYCR7aXRlbS5sYWJlbH06IGNvdWxkIG5vdCByZWFkIGJvZHkg4oCUICR7ZGVzY3JpYmVFcnJvcihlcnJvcil9YClcblx0XHRpZiAoYXR0ZW1wdHMgPj0gTUFYX0FUVEVNUFRTKSB7XG5cdFx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKGl0ZW0ua2V5LCAnZmFpbGVkJywgZGVzY3JpYmVFcnJvcihlcnJvciksIGF0dGVtcHRzKVxuXHRcdFx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0XHRcdGF3YWl0IGFkdmFuY2UoKVxuXHRcdH1cblx0XHRyZXR1cm5cblx0fVxuXG5cdGNvbnN0IGF0dGVtcHRzID0gKFxuXHRcdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHMpID0+ICh7IC4uLnMsIGF0dGVtcHRzOiBzLmF0dGVtcHRzICsgMSB9KSlcblx0KS5hdHRlbXB0c1xuXG5cdGNvbnN0IHZlcmRpY3QgPSB2YWxpZGF0ZShpdGVtLmtpbmQsIGl0ZW0ua2V5LCBjYXB0dXJlZC5zdGF0dXMsIGNhcHR1cmVkLmJvZHkpXG5cdGxvZyhcblx0XHRgJHtpdGVtLmxhYmVsfTogSFRUUCAke2NhcHR1cmVkLnN0YXR1c30sICR7Y2FwdHVyZWQuYm9keS5sZW5ndGh9IGJ5dGVzIOKGkiAke3ZlcmRpY3Qub3V0Y29tZX0gKCR7dmVyZGljdC5kZXRhaWx9KWAsXG5cdClcblxuXHRpZiAodmVyZGljdC5vdXRjb21lID09PSAnYmxvY2tlZCcpIHtcblx0XHQvLyBBIGNoYWxsZW5nZSB3aXRoIHNvbWV0aGluZyBvbiBzY3JlZW4gdG8gc29sdmU6IHdhaXQgaW5kZWZpbml0ZWx5LCBhbmRcblx0XHQvLyBjcnVjaWFsbHkgZG8gTk9UIHJlbG9hZCDigJQgdGhhdCB3b3VsZCB3aXBlIG91dCBhIGhhbGYtZmluaXNoZWQgY2FwdGNoYS5cblx0XHQvLyBTb2x2aW5nIGl0IG5hdmlnYXRlcyB0aGUgcGFnZSwgd2hpY2ggYnJpbmdzIHVzIGJhY2sgaGVyZSBieSBpdHNlbGYuXG5cdFx0aWYgKHZlcmRpY3QuYXdhaXRVc2VyKSB7XG5cdFx0XHRsb2coYCR7aXRlbS5sYWJlbH06IHdhaXRpbmcgZm9yIHRoZSB1c2VyIHRvIGNsZWFyIGEgY2hhbGxlbmdlYClcblx0XHRcdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0XHRcdGF3YWl0IHVwZGF0ZVJ1blN0YXRlKChjdXJyZW50KSA9PiAoe1xuXHRcdFx0XHQuLi5jdXJyZW50LFxuXHRcdFx0XHRpdGVtczogY3VycmVudC5pdGVtcy5tYXAoKGkpID0+XG5cdFx0XHRcdFx0aS5rZXkgPT09IGl0ZW0ua2V5XG5cdFx0XHRcdFx0XHQ/IHtcblx0XHRcdFx0XHRcdFx0XHQuLi5pLFxuXHRcdFx0XHRcdFx0XHRcdHN0YXR1czogJ2Jsb2NrZWQnIGFzIGNvbnN0LFxuXHRcdFx0XHRcdFx0XHRcdGRldGFpbDogdmVyZGljdC5kZXRhaWwsXG5cdFx0XHRcdFx0XHRcdFx0YXR0ZW1wdHMsXG5cdFx0XHRcdFx0XHRcdFx0YXdhaXRVc2VyOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRcdHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHRcdFx0fVxuXHRcdFx0XHRcdFx0OiBpLFxuXHRcdFx0XHQpLFxuXHRcdFx0fSkpXG5cdFx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0aWYgKGF0dGVtcHRzID49IE1BWF9BVFRFTVBUUykge1xuXHRcdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRcdFx0aXRlbS5rZXksXG5cdFx0XHRcdCdmYWlsZWQnLFxuXHRcdFx0XHRgJHt2ZXJkaWN0LmRldGFpbH0gR2F2ZSB1cCBhZnRlciAke2F0dGVtcHRzfSBhdHRlbXB0cy5gLFxuXHRcdFx0KVxuXHRcdFx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0XHRcdGF3YWl0IGFkdmFuY2UoKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdibG9ja2VkJyxcblx0XHRcdGAke3ZlcmRpY3QuZGV0YWlsfSAoYXR0ZW1wdCAke2F0dGVtcHRzfSBvZiAke01BWF9BVFRFTVBUU307IHJldHJ5aW5nIGF1dG9tYXRpY2FsbHkpYCxcblx0XHRcdGF0dGVtcHRzLFxuXHRcdClcblx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdGF3YWl0IHNjaGVkdWxlUmV0cnkoKVxuXHRcdHJldHVyblxuXHR9XG5cblx0aWYgKHZlcmRpY3Qub3V0Y29tZSA9PT0gJ3VudXNhYmxlJykge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoaXRlbS5rZXksICdmYWlsZWQnLCB2ZXJkaWN0LmRldGFpbClcblx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdGF3YWl0IGFkdmFuY2UoKVxuXHRcdHJldHVyblxuXHR9XG5cblx0Ly8gLS0tIENhcHR1cmVkIHNvbWV0aGluZyB1c2FibGUgLS0tXG5cblx0Ly8gQ2xhaW0gaXQgYmVmb3JlIGRvaW5nIGFueXRoaW5nIGVsc2UsIHNvIHRoZSBvdGhlciB0cmlnZ2VyIGJvd3Mgb3V0LlxuXHRhd2FpdCBtYXJrRG9jdW1lbnRDb25zdW1lZCh0YWJJZCwgZG9jdW1lbnQpXG5cblx0aWYgKGl0ZW0ua2luZCA9PT0gJ2NvdXJzZScpIHtcblx0XHRhd2FpdCBoYW5kbGVDb3Vyc2VQYWdlKGl0ZW0sIGNhcHR1cmVkLmJvZHkpXG5cdH0gZWxzZSB7XG5cdFx0YXdhaXQgZGVsaXZlcih7XG5cdFx0XHRraW5kOiBpdGVtLmtpbmQsXG5cdFx0XHRrZXk6IGl0ZW0ua2V5LFxuXHRcdFx0bmFtZTogZmlsZU5hbWVGb3IoaXRlbS5raW5kLCBpdGVtLmtleSksXG5cdFx0XHR0ZXh0OiBjYXB0dXJlZC5ib2R5LFxuXHRcdH0pXG5cdFx0aWYgKGl0ZW0ua2luZCA9PT0gJ2F0aGxldGUnKSBhd2FpdCByZWNvcmRFdmVudHMoY2FwdHVyZWQuYm9keSlcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKGl0ZW0ua2V5LCAnY2FwdHVyZWQnLCB2ZXJkaWN0LmRldGFpbClcblx0fVxuXG5cdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdGF3YWl0IGFkdmFuY2UoKVxufVxuXG4vLyDilIDilIAgQ291cnNlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqXG4gKiBBIGNvdXJzZSBwYWdlIG9ubHkgdGVsbHMgdXMgdGhlIG1hcCBpZDsgdGhlIEtNWiBjb21lcyBmcm9tIEdvb2dsZSwgd2hpY2hcbiAqIHNlcnZlcyBpdCB0byBhIHBsYWluIGZldGNoIOKAlCBubyBuYXZpZ2F0aW9uLCBubyBjb29raWVzLlxuICovXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVDb3Vyc2VQYWdlKGl0ZW06IEl0ZW1TdGF0ZSwgaHRtbDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IG1pZCA9IGV4dHJhY3RNYXBNaWQoaHRtbClcblx0aWYgKCFtaWQpIHtcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKGl0ZW0ua2V5LCAnZmFpbGVkJywgJ05vIG1hcCBpZCBvbiB0aGUgY291cnNlIHBhZ2UuJylcblx0XHRyZXR1cm5cblx0fVxuXG5cdHRyeSB7XG5cdFx0Y29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChjb3Vyc2VLbXpVcmwobWlkKSlcblx0XHRpZiAoIXJlc3BvbnNlLm9rKSB0aHJvdyBuZXcgRXJyb3IoYEdvb2dsZSByZXBsaWVkICR7cmVzcG9uc2Uuc3RhdHVzfWApXG5cblx0XHRjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGF3YWl0IHJlc3BvbnNlLmFycmF5QnVmZmVyKCkpXG5cdFx0aWYgKGJ5dGVzWzBdICE9PSAweDUwIHx8IGJ5dGVzWzFdICE9PSAweDRiKSB7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ0Rvd25sb2FkZWQgZmlsZSBpcyBub3QgYSBLTVogYXJjaGl2ZScpXG5cdFx0fVxuXG5cdFx0YXdhaXQgZGVsaXZlcih7XG5cdFx0XHRraW5kOiAnY291cnNlJyxcblx0XHRcdGtleTogaXRlbS5rZXksXG5cdFx0XHRuYW1lOiBgJHtpdGVtLmtleX0ua216YCxcblx0XHRcdGJhc2U2NDogdG9CYXNlNjQoYnl0ZXMpLFxuXHRcdH0pXG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRcdGl0ZW0ua2V5LFxuXHRcdFx0J2NhcHR1cmVkJyxcblx0XHRcdGBLTVogZG93bmxvYWRlZCAoJHtNYXRoLnJvdW5kKGJ5dGVzLmxlbmd0aCAvIDEwMjQpfSBLQilgLFxuXHRcdClcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0aXRlbS5rZXksXG5cdFx0XHQnZmFpbGVkJyxcblx0XHRcdGBDb3VsZG4ndCBkb3dubG9hZCB0aGUgS01aOiAke2Rlc2NyaWJlRXJyb3IoZXJyb3IpfWAsXG5cdFx0KVxuXHR9XG59XG5cbi8qKiBSZW1lbWJlciBldmVyeSBldmVudCBhbiBhdGhsZXRlIHBhZ2UgbWVudGlvbnMsIGZvciB0aGUgY291cnNlIGh1bnQuICovXG5hc3luYyBmdW5jdGlvbiByZWNvcmRFdmVudHMoaHRtbDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IGV2ZW50cyA9IGV4dHJhY3RFdmVudHMocGFyc2VSdW5SZXN1bHRzKGh0bWwpKVxuXHRpZiAoZXZlbnRzLmxlbmd0aCA9PT0gMCkgcmV0dXJuXG5cblx0YXdhaXQgdXBkYXRlU2Vzc2lvbigoc2Vzc2lvbikgPT4ge1xuXHRcdGNvbnN0IGRpc2NvdmVyZWQgPSB7IC4uLnNlc3Npb24uZGlzY292ZXJlZEV2ZW50cyB9XG5cdFx0Zm9yIChjb25zdCBldmVudCBvZiBldmVudHMpIHtcblx0XHRcdGlmICghZGlzY292ZXJlZFtldmVudC5ldmVudElkXSkge1xuXHRcdFx0XHRkaXNjb3ZlcmVkW2V2ZW50LmV2ZW50SWRdID0geyBuYW1lOiBldmVudC5uYW1lLCB1cmw6IGV2ZW50LnVybCB9XG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiB7IC4uLnNlc3Npb24sIGRpc2NvdmVyZWRFdmVudHM6IGRpc2NvdmVyZWQgfVxuXHR9KVxufVxuXG4vKipcbiAqIEV4dGVuZCB0aGUgcXVldWUgd2l0aCBhIGNvdXJzZSBwYWdlIHBlciBldmVudCB0aGF0IGhhcyBubyBtYXAgeWV0LiBSdW5zIG9uY2UsXG4gKiBhZnRlciB0aGUgYXRobGV0ZSBwYWdlcywgc2luY2UgdGhhdCdzIHdoZW4gd2Uga25vdyB3aGljaCBldmVudHMgZXhpc3QuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIHF1ZXVlTmV3Q291cnNlcygpOiBQcm9taXNlPGJvb2xlYW4+IHtcblx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoc2Vzc2lvbi5jb3Vyc2VzUXVldWVkIHx8IHNlc3Npb24uc2tpcENvdXJzZXMpIHJldHVybiBmYWxzZVxuXG5cdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHMpID0+ICh7IC4uLnMsIGNvdXJzZXNRdWV1ZWQ6IHRydWUgfSkpXG5cblx0Y29uc3Qga25vd24gPSBuZXcgU2V0KHNlc3Npb24ua25vd25Db3Vyc2VFdmVudElkcylcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGNvbnN0IGFscmVhZHlRdWV1ZWQgPSBuZXcgU2V0KFxuXHRcdHN0YXRlLml0ZW1zLmZpbHRlcigoaSkgPT4gaS5raW5kID09PSAnY291cnNlJykubWFwKChpKSA9PiBpLmtleSksXG5cdClcblxuXHRjb25zdCBpdGVtczogSXRlbVN0YXRlW10gPSBPYmplY3QuZW50cmllcyhzZXNzaW9uLmRpc2NvdmVyZWRFdmVudHMpXG5cdFx0LmZpbHRlcigoW2V2ZW50SWRdKSA9PiAha25vd24uaGFzKGV2ZW50SWQpICYmICFhbHJlYWR5UXVldWVkLmhhcyhldmVudElkKSlcblx0XHQubWFwKChbZXZlbnRJZCwgZXZlbnRdKSA9PiAoe1xuXHRcdFx0a2luZDogJ2NvdXJzZScgYXMgY29uc3QsXG5cdFx0XHRrZXk6IGV2ZW50SWQsXG5cdFx0XHRsYWJlbDogYCR7ZXZlbnQubmFtZX0gY291cnNlIG1hcGAsXG5cdFx0XHR1cmw6IGNvdXJzZVBhZ2VVcmwoZXZlbnQudXJsKSxcblx0XHRcdHN0YXR1czogJ3BlbmRpbmcnIGFzIGNvbnN0LFxuXHRcdH0pKVxuXHRcdC5zb3J0KChhLCBiKSA9PiBhLmxhYmVsLmxvY2FsZUNvbXBhcmUoYi5sYWJlbCkpXG5cblx0aWYgKGl0ZW1zLmxlbmd0aCA9PT0gMCkgcmV0dXJuIGZhbHNlXG5cblx0Y29uc3QgbmV4dCA9IGF3YWl0IGFwcGVuZEl0ZW1zKGl0ZW1zKVxuXHRhd2FpdCBub3RpZnlTdGF0ZShuZXh0KVxuXHRyZXR1cm4gdHJ1ZVxufVxuXG4vLyDilIDilIAgRmluaXNoaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5hc3luYyBmdW5jdGlvbiBmaW5pc2hSdW4oKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRhd2FpdCBjYW5jZWxTY2hlZHVsZWRSZXRyeSgpXG5cdHN0b3BLZWVwYWxpdmUoKVxuXHRhd2FpdCBjaHJvbWUuYWxhcm1zLmNsZWFyKFdBVENIRE9HX0FMQVJNKS5jYXRjaCgoKSA9PiB7fSlcblxuXHQvLyBBbnl0aGluZyBub3QgaW4gYSB0ZXJtaW5hbCBzdGF0ZSBhdCB0aGlzIHBvaW50IG5ldmVyIGNvbXBsZXRlZDsgY2FsbCBpdCBhXG5cdC8vIGZhaWx1cmUgcmF0aGVyIHRoYW4gcXVpZXRseSByZXBvcnRpbmcgc3VjY2VzcyBmb3IgYSBwYWdlIHdlIG5ldmVyIGdvdC5cblx0Y29uc3Qgc2V0dGxlZCA9IGF3YWl0IHVwZGF0ZVJ1blN0YXRlKChjdXJyZW50KSA9PiAoe1xuXHRcdC4uLmN1cnJlbnQsXG5cdFx0aXRlbXM6IGN1cnJlbnQuaXRlbXMubWFwKChpdGVtKSA9PlxuXHRcdFx0aXRlbS5zdGF0dXMgPT09ICdjYXB0dXJlZCcgfHxcblx0XHRcdGl0ZW0uc3RhdHVzID09PSAnZmFpbGVkJyB8fFxuXHRcdFx0aXRlbS5zdGF0dXMgPT09ICdza2lwcGVkJ1xuXHRcdFx0XHQ/IGl0ZW1cblx0XHRcdFx0OiB7XG5cdFx0XHRcdFx0XHQuLi5pdGVtLFxuXHRcdFx0XHRcdFx0c3RhdHVzOiAnZmFpbGVkJyBhcyBjb25zdCxcblx0XHRcdFx0XHRcdGRldGFpbDogaXRlbS5kZXRhaWwgPz8gJ05ldmVyIGNvbXBsZXRlZC4nLFxuXHRcdFx0XHRcdH0sXG5cdFx0KSxcblx0fSkpXG5cblx0Y29uc3Qgc3RhdGUgPSBzZXR0bGVkXG5cdGNvbnN0IGNhcHR1cmVkID0gc3RhdGUuaXRlbXMuZmlsdGVyKChpKSA9PiBpLnN0YXR1cyA9PT0gJ2NhcHR1cmVkJykubGVuZ3RoXG5cdGNvbnN0IGZhaWxlZCA9IHN0YXRlLml0ZW1zLmZpbHRlcigoaSkgPT4gaS5zdGF0dXMgPT09ICdmYWlsZWQnKS5sZW5ndGhcblxuXHRjb25zdCBkb25lOiBSdW5TdGF0ZSA9IHtcblx0XHQuLi5zdGF0ZSxcblx0XHRzdGF0dXM6ICdkb25lJyxcblx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0ZmluaXNoZWRBdDogRGF0ZS5ub3coKSxcblx0XHRtZXNzYWdlOiBmYWlsZWRcblx0XHRcdD8gYENhcHR1cmVkICR7Y2FwdHVyZWR9IG9mICR7c3RhdGUuaXRlbXMubGVuZ3RofTsgJHtmYWlsZWR9IGZhaWxlZC5gXG5cdFx0XHQ6IGBDYXB0dXJlZCBhbGwgJHtjYXB0dXJlZH0gcGFnZXMuYCxcblx0fVxuXHQvLyBUaGUgdGVybWluYWwgc3RhdHVzIGlzIHdyaXR0ZW4gKmJlZm9yZSogdGhlIHRhYiBpcyBjbG9zZWQuIENsb3NpbmcgaXQgZmlyc3Rcblx0Ly8gZmlyZXMgdGFicy5vblJlbW92ZWQgd2hpbGUgdGhlIHJ1biBzdGlsbCByZWFkcyBhcyBcInJ1bm5pbmdcIiwgYW5kIHRoYXQgaGFuZGxlclxuXHQvLyB3b3VsZCBvdmVyd3JpdGUgdGhpcyB3aXRoIFwidGhlIHNjcmFwZSB0YWIgd2FzIGNsb3NlZFwiIOKAlCByZXBvcnRpbmcgYSBmaW5pc2hlZFxuXHQvLyBzY3JhcGUgYXMgY2FuY2VsbGVkLlxuXHRhd2FpdCBzZXRSdW5TdGF0ZShkb25lKVxuXHRhd2FpdCBjbG9zZVNjcmFwZVRhYigpXG5cdGF3YWl0IHNldEJhZGdlKGZhaWxlZCA/IFN0cmluZyhmYWlsZWQpIDogJycpXG5cdGF3YWl0IGZvY3VzQWRtaW5UYWIoKVxuXHRhd2FpdCBub3RpZnlTdGF0ZShkb25lKVxuXHRhd2FpdCBub3RpZnlGaW5pc2hlZChkb25lKVxuXHRyZXR1cm4gZG9uZVxufVxuXG4vKiogRGV0YWNoIGFuZCBjbG9zZSB0aGUgc2NyYXBlIHRhYi4gT25seSBjYWxsIG9uY2UgYSB0ZXJtaW5hbCBzdGF0dXMgaXMgc3RvcmVkLiAqL1xuYXN5bmMgZnVuY3Rpb24gY2xvc2VTY3JhcGVUYWIoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHsgc2NyYXBlVGFiSWQgfSA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoc2NyYXBlVGFiSWQgPT09IHVuZGVmaW5lZCkgcmV0dXJuXG5cdGF3YWl0IGRldGFjaChzY3JhcGVUYWJJZClcblx0YXdhaXQgY2xlYXJMYXN0RG9jdW1lbnQoc2NyYXBlVGFiSWQpXG5cdGF3YWl0IGNocm9tZS50YWJzLnJlbW92ZShzY3JhcGVUYWJJZCkuY2F0Y2goKCkgPT4ge30pXG5cdC8vIEZvcmdldCB0aGUgaWQgYWxvbmcgd2l0aCB0aGUgdGFiOiBpdCdzIHdoYXQgZGVjaWRlcyB3aGV0aGVyIGEgcGFnZSBnZXRzIHRoZVxuXHQvLyBvdmVybGF5LCBhbmQgbm90aGluZyBzaG91bGQgaW5oZXJpdCB0aGF0IGJ5IG9wZW5pbmcgYSB0YWIgbGF0ZXIuXG5cdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHNlc3Npb24pID0+ICh7IC4uLnNlc3Npb24sIHNjcmFwZVRhYklkOiB1bmRlZmluZWQgfSkpXG59XG5cbi8qKiBUaGUgcnVuIGlzIG92ZXIg4oCUIGhhbmQgdGhlIGFkbWluIHBhZ2UgZm9jdXMgYmFjay4gKi9cbmFzeW5jIGZ1bmN0aW9uIGZvY3VzQWRtaW5UYWIoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHsgYWRtaW5UYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVyblxuXHR0cnkge1xuXHRcdGNvbnN0IHRhYiA9IGF3YWl0IGNocm9tZS50YWJzLmdldChhZG1pblRhYklkKVxuXHRcdGF3YWl0IGNocm9tZS50YWJzLnVwZGF0ZShhZG1pblRhYklkLCB7IGFjdGl2ZTogdHJ1ZSB9KVxuXHRcdGlmICh0YWIud2luZG93SWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0YXdhaXQgY2hyb21lLndpbmRvd3MudXBkYXRlKHRhYi53aW5kb3dJZCwgeyBmb2N1c2VkOiB0cnVlIH0pXG5cdFx0fVxuXHR9IGNhdGNoIHtcblx0XHQvLyBUaGUgYWRtaW4gdGFiIHdhcyBjbG9zZWQ7IGZpbGVzIHN0YXkgaW4gc3RvcmFnZSBmb3IgdGhlIG5leHQgdmlzaXQuXG5cdH1cbn1cblxuYXN5bmMgZnVuY3Rpb24gbm90aWZ5RmluaXNoZWQoc3RhdGU6IFJ1blN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHsgYWRtaW5UYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVyblxuXHRhd2FpdCBjaHJvbWUudGFic1xuXHRcdC5zZW5kTWVzc2FnZShhZG1pblRhYklkLCB7IHR5cGU6ICdmaW5pc2hlZCcsIHN0YXRlIH0pXG5cdFx0LmNhdGNoKCgpID0+IHt9KVxufVxuXG4vLyDilIDilIAgRGVsaXZlcnkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKiBQZXJzaXN0IGEgY2FwdHVyZWQgZmlsZSBhbmQgcHVzaCBpdCB0byB0aGUgYWRtaW4gcGFnZSBzdHJhaWdodCBhd2F5LiAqL1xuYXN5bmMgZnVuY3Rpb24gZGVsaXZlcihmaWxlOiBDYXB0dXJlZEZpbGUpOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgcHV0RmlsZShmaWxlKVxuXHRhd2FpdCBub3RpZnlGaWxlKGZpbGUpXG59XG5cbi8qKiBSZS1zZW5kIGV2ZXJ5dGhpbmcgY2FwdHVyZWQgc28gZmFyLCBlLmcuIGFmdGVyIHRoZSBhZG1pbiBwYWdlIHJlbG9hZGVkLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlc2VuZEZpbGVzKCk6IFByb21pc2U8dm9pZD4ge1xuXHRmb3IgKGNvbnN0IGZpbGUgb2YgYXdhaXQgZ2V0RmlsZXMoKSkgYXdhaXQgbm90aWZ5RmlsZShmaWxlKVxufVxuXG5mdW5jdGlvbiBmaWxlTmFtZUZvcihraW5kOiBDYXB0dXJlZEZpbGVbJ2tpbmQnXSwga2V5OiBzdHJpbmcpOiBzdHJpbmcge1xuXHRzd2l0Y2ggKGtpbmQpIHtcblx0XHRjYXNlICdhdGhsZXRlJzpcblx0XHRcdHJldHVybiBgYXRobGV0ZS0ke2tleX0uaHRtbGBcblx0XHRjYXNlICdldmVudCc6XG5cdFx0XHRyZXR1cm4gYCR7a2V5fS1sYXRlc3QtcmVzdWx0cy5odG1sYFxuXHRcdGNhc2UgJ3Bhc3RFdmVudCc6IHtcblx0XHRcdGNvbnN0IHBhZ2UgPSByZWFkUGFzdEV2ZW50S2V5KGtleSlcblx0XHRcdHJldHVybiBwYWdlXG5cdFx0XHRcdD8gYCR7cGFnZS5ldmVudElkfS0ke3BhZ2UuZXZlbnROdW1iZXJ9LXJlc3VsdHMuaHRtbGBcblx0XHRcdFx0OiBgJHtrZXl9LXJlc3VsdHMuaHRtbGBcblx0XHR9XG5cdFx0Y2FzZSAnY2x1YnMnOlxuXHRcdFx0cmV0dXJuICdsYXJnZXN0LWNsdWJzLmh0bWwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgJHtrZXl9LmttemBcblx0fVxufVxuXG5mdW5jdGlvbiB0b0Jhc2U2NChieXRlczogVWludDhBcnJheSk6IHN0cmluZyB7XG5cdGxldCBiaW5hcnkgPSAnJ1xuXHQvLyBDaHVua2VkIHRvIHN0YXkgd2VsbCBjbGVhciBvZiB0aGUgYXJndW1lbnQgbGltaXQgb24gbGFyZ2UgYXJjaGl2ZXMuXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDB4ODAwMCkge1xuXHRcdGJpbmFyeSArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKC4uLmJ5dGVzLnN1YmFycmF5KGksIGkgKyAweDgwMDApKVxuXHR9XG5cdHJldHVybiBidG9hKGJpbmFyeSlcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0QmFkZ2UodGV4dDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dCB9KS5jYXRjaCgoKSA9PiB7fSlcbn1cbiIsIi8qKlxuICogQSBvbmUtYXQtYS10aW1lIHF1ZXVlLlxuICpcbiAqIENhcHR1cmVzIGFyZSB0cmlnZ2VyZWQgZnJvbSB0d28gcGxhY2VzIOKAlCB0aGUgZGVidWdnZXIncyBgbG9hZGluZ0ZpbmlzaGVkYCBhbmRcbiAqIGB0YWJzLm9uVXBkYXRlZGAg4oCUIGJlY2F1c2UgbmVpdGhlciBpcyByZWxpYWJsZSBlbm91Z2ggYWxvbmUuIFRoYXQgbWVhbnMgYm90aFxuICogY2FuIGZpcmUgZm9yIHRoZSBzYW1lIHBhZ2UgbG9hZCwgYW5kIGlmIHRoZXkgaW50ZXJsZWF2ZSB0aGV5IGVhY2ggY2FwdHVyZSBhbmRcbiAqIGVhY2ggY2FsbCBgYWR2YW5jZSgpYCwgd2hpY2ggd2Fsa3MgdGhlIHF1ZXVlIHR3aWNlIGFuZCBzaWxlbnRseSBza2lwcyBhbiBpdGVtLlxuICpcbiAqIEV2ZXJ5dGhpbmcgdGhhdCByZWFkcy10aGVuLXdyaXRlcyBydW4gc3RhdGUgZ29lcyB0aHJvdWdoIGhlcmUgc28gdGhhdCBjYW4ndFxuICogaGFwcGVuLiBUaGUgY2hhaW4gbGl2ZXMgaW4gbW9kdWxlIHNjb3BlLCB3aGljaCByZXNldHMgd2hlbiB0aGUgc2VydmljZSB3b3JrZXJcbiAqIHJlc3RhcnRzIOKAlCBmaW5lLCBiZWNhdXNlIG9yZGVyaW5nIG9ubHkgbWF0dGVycyB3aXRoaW4gYSBidXJzdCBvZiBldmVudHMuXG4gKi9cbmxldCBjaGFpbjogUHJvbWlzZTx1bmtub3duPiA9IFByb21pc2UucmVzb2x2ZSgpXG5cbmV4cG9ydCBmdW5jdGlvbiBzZXJpYWw8VD4od29yazogKCkgPT4gUHJvbWlzZTxUPik6IFByb21pc2U8VD4ge1xuXHRjb25zdCBuZXh0ID0gY2hhaW4udGhlbih3b3JrLCB3b3JrKVxuXHQvLyBTd2FsbG93IHJlamVjdGlvbnMgb24gdGhlIGNoYWluIGl0c2VsZiBzbyBvbmUgZmFpbHVyZSBjYW4ndCBwb2lzb24gdGhlIHF1ZXVlO1xuXHQvLyB0aGUgcmV0dXJuZWQgcHJvbWlzZSBzdGlsbCByZWplY3RzIGZvciB0aGUgY2FsbGVyLlxuXHRjaGFpbiA9IG5leHQuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKVxuXHRyZXR1cm4gbmV4dFxufVxuIiwiLyoqXG4gKiBTZXJ2aWNlIHdvcmtlcjogdGhlIGV4dGVuc2lvbidzIG9ubHkgbG9uZy1saXZlZCBsb2dpYywgZXhjZXB0IGl0IGlzbid0XG4gKiBsb25nLWxpdmVkIGF0IGFsbCDigJQgQ2hyb21lIHRlcm1pbmF0ZXMgaXQgd2hlbmV2ZXIgaXQgZ29lcyBpZGxlLlxuICpcbiAqIEV2ZXJ5IGxpc3RlbmVyIGJlbG93IGlzIHJlZ2lzdGVyZWQgc3luY2hyb25vdXNseSBhdCB0aGUgdG9wIGxldmVsLiBUaGF0J3Mgd2hhdFxuICogbWFrZXMgdGhlIHJ1biBzdXJ2aXZlOiBhIHJlZ2lzdGVyZWQgbGlzdGVuZXIgY2F1c2VzIENocm9tZSB0byAqc3RhcnQqIHRoZVxuICogd29ya2VyIHRvIGRlbGl2ZXIgaXRzIGV2ZW50LCBzbyB0aGUgZGVidWdnZXIgZXZlbnRzIGFuZCBtZXNzYWdlcyB0aGF0IGRyaXZlIGFcbiAqIHJ1biB3YWtlIGl0IGJhY2sgdXAuIEFsbCBzdGF0ZSBsaXZlcyBpbiBjaHJvbWUuc3RvcmFnZSAoc2VlIHN0YXRlLnRzKSwgbmV2ZXJcbiAqIGluIG1vZHVsZSBzY29wZS5cbiAqL1xuaW1wb3J0IHtcblx0dHlwZSBQYWdlTWVzc2FnZSxcblx0U0NSQVBFUl9QUk9UT0NPTF9WRVJTSU9OLFxuXHRlbXB0eVJ1blN0YXRlLFxufSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5pbXBvcnQgeyBkZXRhY2gsIG5vdGVEb2N1bWVudFJlc3BvbnNlLCBub3RlTG9hZGluZ0ZpbmlzaGVkIH0gZnJvbSAnLi9jYXB0dXJlJ1xuaW1wb3J0IHtcblx0aXNGcm9tQWRtaW5QYWdlLFxuXHRvcGVuQWRtaW5QYWdlLFxuXHRyZW1lbWJlckFkbWluT3JpZ2luLFxufSBmcm9tICcuL29wZW5BZG1pbidcbmltcG9ydCB7XG5cdGFkdmFuY2UsXG5cdGNhbmNlbFJ1bixcblx0Y2hlY2tGb3JTdGFsbCxcblx0Zm9yZ2V0UnVuLFxuXHRoYW5kbGVEb2N1bWVudExvYWRlZCxcblx0cmVjb3Zlck1pc3NlZENhcHR1cmUsXG5cdHJlc2VuZEZpbGVzLFxuXHRyZXN1bWVSdW4sXG5cdHJldHJ5Q3VycmVudCxcblx0cmV0cnlJZlN0aWxsQmxvY2tlZCxcblx0c2tpcEN1cnJlbnQsXG5cdHN0YXJ0UnVuLFxufSBmcm9tICcuL3J1bidcbmltcG9ydCB7IHNlcmlhbCB9IGZyb20gJy4vc2VyaWFsJ1xuaW1wb3J0IHsgZ2V0UnVuU3RhdGUsIGdldFNlc3Npb24sIHNldFJ1blN0YXRlIH0gZnJvbSAnLi9zdGF0ZSdcblxuLy8g4pSA4pSAIE1lc3NhZ2VzIGZyb20gY29udGVudCBzY3JpcHRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSA9PiB7XG5cdC8vIE5vdGUgd2hlcmUgdGhlIGFkbWluIHBhZ2UgbGl2ZXMsIHNvIHRoZSB0b29sYmFyIGljb24gY2FuIHJlb3BlbiBpdC4gQnJpZGdlXG5cdC8vIHRyYWZmaWMgb25seSDigJQgdGhlIG92ZXJsYXkncyBtZXNzYWdlcyBjb21lIGZyb20gcGFya3J1biBwYWdlcy5cblx0aWYgKGlzRnJvbUFkbWluUGFnZShtZXNzYWdlKSkge1xuXHRcdHZvaWQgcmVtZW1iZXJBZG1pbk9yaWdpbihzZW5kZXIudXJsID8/IHNlbmRlci5vcmlnaW4pXG5cdH1cblxuXHQvLyBSZXR1cm5pbmcgdHJ1ZSBrZWVwcyB0aGUgcmVzcG9uc2UgY2hhbm5lbCBvcGVuIGZvciB0aGUgYXN5bmMgd29yayBiZWxvdy5cblx0aGFuZGxlTWVzc2FnZShtZXNzYWdlIGFzIFBhZ2VNZXNzYWdlIHwgeyB0eXBlOiBzdHJpbmcgfSwgc2VuZGVyKVxuXHRcdC50aGVuKHNlbmRSZXNwb25zZSlcblx0XHQuY2F0Y2goKGVycm9yKSA9PiBzZW5kUmVzcG9uc2UoeyBlcnJvcjogU3RyaW5nKGVycm9yKSB9KSlcblx0cmV0dXJuIHRydWVcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UoXG5cdG1lc3NhZ2U6IFBhZ2VNZXNzYWdlIHwgeyB0eXBlOiBzdHJpbmcgfSxcblx0c2VuZGVyOiB7IHRhYj86IHsgaWQ/OiBudW1iZXIgfSB9LFxuKTogUHJvbWlzZTx1bmtub3duPiB7XG5cdHN3aXRjaCAobWVzc2FnZS50eXBlKSB7XG5cdFx0Y2FzZSAncGluZyc6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR0eXBlOiAnaGVsbG8nLFxuXHRcdFx0XHR2ZXJzaW9uOiBTQ1JBUEVSX1BST1RPQ09MX1ZFUlNJT04sXG5cdFx0XHRcdHN0YXRlOiBhd2FpdCBnZXRSdW5TdGF0ZSgpLFxuXHRcdFx0fVxuXG5cdFx0LyoqXG5cdFx0ICogQXNrZWQgYnkgdGhlIG92ZXJsYXksIHdoaWNoIGlzIGluamVjdGVkIGludG8gZXZlcnkgcGFya3J1biBwYWdlIOKAlCBidXRcblx0XHQgKiBvbmx5IHRoZSBzY3JhcGUgdGFiIGlzIHBhcnQgb2YgYSBydW4uIEEgcnVuJ3Mgc3RhdGUgb3V0bGl2ZXMgdGhlIHJ1blxuXHRcdCAqICh0aGUgYWRtaW4gcGFnZSBjYW4gc3RpbGwgYXNrIGZvciBpdHMgZmlsZXMpLCBzbyBhbnN3ZXJpbmcgZXZlcnkgdGFiXG5cdFx0ICogbWVhbnQgYSBwYWdlIG9wZW5lZCBieSBoYW5kIGRheXMgbGF0ZXIgc3RpbGwgZ290IFwiU2NyYXBlIGNvbXBsZXRlXCIuXG5cdFx0ICovXG5cdFx0Y2FzZSAnc3RhdGU/Jzoge1xuXHRcdFx0Y29uc3QgeyBzY3JhcGVUYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdFx0XHRjb25zdCBpblNjcmFwZVRhYiA9XG5cdFx0XHRcdHNlbmRlci50YWI/LmlkICE9PSB1bmRlZmluZWQgJiYgc2VuZGVyLnRhYi5pZCA9PT0gc2NyYXBlVGFiSWRcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdHR5cGU6ICdzdGF0ZScsXG5cdFx0XHRcdHN0YXRlOiBpblNjcmFwZVRhYiA/IGF3YWl0IGdldFJ1blN0YXRlKCkgOiBlbXB0eVJ1blN0YXRlKCksXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Y2FzZSAnc3RhcnQnOiB7XG5cdFx0XHRjb25zdCBhZG1pblRhYklkID0gc2VuZGVyLnRhYj8uaWRcblx0XHRcdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVybiB7IGVycm9yOiAnTm8gY2FsbGluZyB0YWInIH1cblx0XHRcdGNvbnN0IHJlcXVlc3QgPSAobWVzc2FnZSBhcyBFeHRyYWN0PFBhZ2VNZXNzYWdlLCB7IHR5cGU6ICdzdGFydCcgfT4pXG5cdFx0XHRcdC5yZXF1ZXN0XG5cdFx0XHRjb25zdCBzdGF0ZSA9IGF3YWl0IHN0YXJ0UnVuKHJlcXVlc3QsIGFkbWluVGFiSWQpXG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZSB9XG5cdFx0fVxuXG5cdFx0Y2FzZSAncmVzdW1lJzoge1xuXHRcdFx0Y29uc3QgYWRtaW5UYWJJZCA9IHNlbmRlci50YWI/LmlkXG5cdFx0XHRpZiAoYWRtaW5UYWJJZCA9PT0gdW5kZWZpbmVkKSByZXR1cm4geyBlcnJvcjogJ05vIGNhbGxpbmcgdGFiJyB9XG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZTogYXdhaXQgcmVzdW1lUnVuKGFkbWluVGFiSWQpIH1cblx0XHR9XG5cblx0XHRjYXNlICdjYW5jZWwnOlxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGNhbmNlbFJ1bigpIH1cblxuXHRcdGNhc2UgJ3JldHJ5Jzpcblx0XHRcdHJldHVybiB7IHR5cGU6ICdzdGF0ZScsIHN0YXRlOiBhd2FpdCByZXRyeUN1cnJlbnQoKSB9XG5cblx0XHRjYXNlICdza2lwJzpcblx0XHRcdHJldHVybiB7IHR5cGU6ICdzdGF0ZScsIHN0YXRlOiBhd2FpdCBza2lwQ3VycmVudCgpIH1cblxuXHRcdGNhc2UgJ3Jlc2VuZCc6XG5cdFx0XHRhd2FpdCByZXNlbmRGaWxlcygpXG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZTogYXdhaXQgZ2V0UnVuU3RhdGUoKSB9XG5cblx0XHRjYXNlICdjbGVhcic6XG5cdFx0XHRhd2FpdCBmb3JnZXRSdW4oKVxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGdldFJ1blN0YXRlKCkgfVxuXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiB7IGVycm9yOiBgVW5rbm93biBtZXNzYWdlOiAke21lc3NhZ2UudHlwZX1gIH1cblx0fVxufVxuXG4vLyDilIDilIAgRGVidWdnZXIgZXZlbnRzOiBob3cgcGFnZXMgZ2V0IGNhcHR1cmVkIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIERlYnVnZ2VyIGV2ZW50cyBhcmUgaGFuZGxlZCBzdHJpY3RseSBvbmUgYXQgYSB0aW1lLlxuICpcbiAqIGByZXNwb25zZVJlY2VpdmVkYCByZWNvcmRzIHRoZSBtYWluIGRvY3VtZW50J3MgcmVxdWVzdCBJRCBhbmRcbiAqIGBsb2FkaW5nRmluaXNoZWRgIGxvb2tzIGl0IHVwLCBib3RoIHZpYSBhc3luYyBzdG9yYWdlLiBIYW5kbGVkIGNvbmN1cnJlbnRseSxcbiAqIHRoZSBsb29rdXAgY2FuIHJ1biBiZWZvcmUgdGhlIHdyaXRlIGxhbmRzIOKAlCBhbmQgYmVjYXVzZSBvbmx5IHRoZSBtYWluXG4gKiBkb2N1bWVudCdzIGBsb2FkaW5nRmluaXNoZWRgIHRyaWdnZXJzIGEgY2FwdHVyZSwgbWlzc2luZyB0aGF0IG9uZSBldmVudCBzdGFsbHNcbiAqIHRoZSBydW4gcGVybWFuZW50bHkgd2l0aCBub3RoaW5nIHRvIHNob3cgd2h5LiBUaGUgdHdvIGV2ZW50cyBhcnJpdmUgd2l0aGluXG4gKiBtaWNyb3NlY29uZHMgb2YgZWFjaCBvdGhlciBvbiBhIGZhc3QgcGFnZSwgc28gdGhpcyB3YXMgbG9zaW5nIHJhY2VzLlxuICovXG5jaHJvbWUuZGVidWdnZXIub25FdmVudC5hZGRMaXN0ZW5lcigoc291cmNlLCBtZXRob2QsIHBhcmFtcykgPT4ge1xuXHRpZiAoc291cmNlLnRhYklkID09PSB1bmRlZmluZWQgfHwgIXBhcmFtcykgcmV0dXJuXG5cdGNvbnN0IHRhYklkID0gc291cmNlLnRhYklkXG5cdHZvaWQgc2VyaWFsKCgpID0+IGhhbmRsZURlYnVnZ2VyRXZlbnQodGFiSWQsIG1ldGhvZCwgcGFyYW1zKSkuY2F0Y2goXG5cdFx0KGVycm9yKSA9PiB7XG5cdFx0XHRjb25zb2xlLmVycm9yKCdbcmVzdWx0cy1zY3JhcGVyXSBldmVudCBoYW5kbGluZyBmYWlsZWQnLCBtZXRob2QsIGVycm9yKVxuXHRcdH0sXG5cdClcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlYnVnZ2VyRXZlbnQoXG5cdHRhYklkOiBudW1iZXIsXG5cdG1ldGhvZDogc3RyaW5nLFxuXHRwYXJhbXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmIChtZXRob2QgPT09ICdOZXR3b3JrLnJlc3BvbnNlUmVjZWl2ZWQnKSB7XG5cdFx0YXdhaXQgbm90ZURvY3VtZW50UmVzcG9uc2UodGFiSWQsIHBhcmFtcylcblx0XHRyZXR1cm5cblx0fVxuXG5cdGlmIChtZXRob2QgPT09ICdOZXR3b3JrLmxvYWRpbmdGaW5pc2hlZCcpIHtcblx0XHRjb25zdCBkb2N1bWVudCA9IGF3YWl0IG5vdGVMb2FkaW5nRmluaXNoZWQodGFiSWQsIHBhcmFtcylcblx0XHQvLyBPbmx5IHRoZSBtYWluLWZyYW1lIGRvY3VtZW50IHByb2R1Y2VzIGEgbWF0Y2ggaGVyZTsgZXZlcnl0aGluZyBlbHNlIG9uXG5cdFx0Ly8gdGhlIHBhZ2UgZmluaXNoZXMgbG9hZGluZyB0b28gYW5kIGlzIGlnbm9yZWQuXG5cdFx0aWYgKGRvY3VtZW50KSBhd2FpdCBoYW5kbGVEb2N1bWVudExvYWRlZCh0YWJJZClcblx0fVxufVxuXG4vKipcbiAqIENocm9tZSBkZXRhY2hlcyB1cyBpZiB0aGUgdXNlciBvcGVucyBEZXZUb29scyBvbiB0aGUgc2NyYXBlIHRhYiwgb3IgY2xpY2tzXG4gKiBcImNhbmNlbFwiIG9uIHRoZSBkZWJ1Z2dpbmcgbm90aWNlLiBXaXRob3V0IHRoZSBkZWJ1Z2dlciB0aGVyZSdzIG5vIHdheSB0byByZWFkXG4gKiByYXcgSFRNTCwgc28gdGhlIHJ1biBjYW4ndCBjb250aW51ZS5cbiAqL1xuY2hyb21lLmRlYnVnZ2VyLm9uRGV0YWNoLmFkZExpc3RlbmVyKChzb3VyY2UsIHJlYXNvbikgPT4ge1xuXHR2b2lkIGhhbmRsZURldGFjaChzb3VyY2UudGFiSWQsIHJlYXNvbilcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURldGFjaCh0YWJJZDogbnVtYmVyLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuXG5cblx0YXdhaXQgc2V0UnVuU3RhdGUoe1xuXHRcdC4uLnN0YXRlLFxuXHRcdHN0YXR1czogJ2Vycm9yJyxcblx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0ZmluaXNoZWRBdDogRGF0ZS5ub3coKSxcblx0XHRtZXNzYWdlOiBgTG9zdCB0aGUgZGVidWdnZXIgY29ubmVjdGlvbiAoJHtyZWFzb259KS5gLFxuXHR9KVxuXHRhd2FpdCBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6ICchJyB9KS5jYXRjaCgoKSA9PiB7fSlcbn1cblxuLy8g4pSA4pSAIFRhYiBjbG9zZWQgbWlkLXJ1biDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuY2hyb21lLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKCh0YWJJZCkgPT4ge1xuXHQvLyBTZXJpYWxpc2VkIHdpdGggdGhlIHJlc3Qgb2YgdGhlIHN0YXRlIG1hY2hpbmU6IHRoaXMgdXNlZCB0byByYWNlIGZpbmlzaFJ1blxuXHQvLyBhbmQgY2xvYmJlciBhIGNvbXBsZXRlZCBydW4ncyBzdGF0dXMuXG5cdHZvaWQgc2VyaWFsKCgpID0+IGhhbmRsZVRhYlJlbW92ZWQodGFiSWQpKVxufSlcblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlVGFiUmVtb3ZlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuXG5cblx0aWYgKHNlc3Npb24uc2NyYXBlVGFiSWQgPT09IHRhYklkKSB7XG5cdFx0YXdhaXQgZGV0YWNoKHRhYklkKVxuXHRcdGF3YWl0IHNldFJ1blN0YXRlKHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0c3RhdHVzOiAnY2FuY2VsbGVkJyxcblx0XHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRcdGZpbmlzaGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRtZXNzYWdlOiAnVGhlIHNjcmFwZSB0YWIgd2FzIGNsb3NlZC4nLFxuXHRcdH0pXG5cdFx0YXdhaXQgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiAnJyB9KS5jYXRjaCgoKSA9PiB7fSlcblx0fVxufVxuXG4vLyDilIDilIAgUmVjb3Zlcnkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogSWYgdGhlIGJyb3dzZXIgcmVzdGFydGVkIG1pZC1ydW4gdGhlcmUncyBubyB0YWIgYW5kIG5vIGRlYnVnZ2VyIGxlZnQsIHNvIHRoZVxuICogcnVuIGNhbid0IGJlIHJlc3VtZWQg4oCUIGJ1dCB3aGF0ZXZlciB3YXMgY2FwdHVyZWQgaXMgc3RpbGwgaW4gc3RvcmFnZSBhbmQgdGhlXG4gKiBhZG1pbiBwYWdlIGNhbiBzdGlsbCBhc2sgZm9yIGl0LlxuICovXG5jaHJvbWUucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuXHR2b2lkIChhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdFx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnKSByZXR1cm5cblx0XHRhd2FpdCBzZXRSdW5TdGF0ZSh7XG5cdFx0XHQuLi5zdGF0ZSxcblx0XHRcdHN0YXR1czogJ2NhbmNlbGxlZCcsXG5cdFx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0XHRtZXNzYWdlOiAnSW50ZXJydXB0ZWQgd2hlbiB0aGUgYnJvd3NlciBjbG9zZWQuJyxcblx0XHR9KVxuXHR9KSgpXG59KVxuXG4vKipcbiAqIFRoZSBzY3JhcGUgdGFiIGZpbmlzaGVkIGxvYWRpbmcuXG4gKlxuICogVGhpcyBpcyB0aGUgZGVwZW5kYWJsZSB0cmlnZ2VyIOKAlCB1bmxpa2UgY2hyb21lLmRlYnVnZ2VyIGV2ZW50cywgdGFicy5vblVwZGF0ZWRcbiAqIGlzIGFsd2F5cyBkZWxpdmVyZWQgYW5kIGFsd2F5cyB3YWtlcyB0aGUgd29ya2VyLiBJdCBydW5zIHRoZSBzYW1lIGNhcHR1cmUgcGF0aCxcbiAqIHNvIHdoaWNoZXZlciBzaWduYWwgYXJyaXZlcyBmaXJzdCB3aXRoIGEgcmVhZGFibGUgYm9keSB3aW5zLlxuICovXG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBpbmZvKSA9PiB7XG5cdGlmIChpbmZvLnN0YXR1cyAhPT0gJ2NvbXBsZXRlJykgcmV0dXJuXG5cdHZvaWQgKGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0XHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycpIHJldHVyblxuXG5cdFx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRcdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0XHQvLyBObyBjdXJyZW50IGl0ZW0gbWVhbnMgdGhlIHdvcmtlciBkaWVkIGJldHdlZW4gaXRlbXM7IHBpY2sgdGhlIHF1ZXVlIGJhY2sgdXAuXG5cdFx0aWYgKCFzdGF0ZS5jdXJyZW50S2V5KSB7XG5cdFx0XHRhd2FpdCBzZXJpYWwoKCkgPT4gYWR2YW5jZSgpKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0YXdhaXQgc2VyaWFsKCgpID0+IGhhbmRsZURvY3VtZW50TG9hZGVkKHRhYklkKSlcblxuXHRcdC8vIFRoZSBwYWdlIGlzIGxvYWRlZC4gSWYgdGhhdCBkaWRuJ3QgcHJvZHVjZSBhIGNhcHR1cmUsIGl0cyBOZXR3b3JrIGV2ZW50c1xuXHRcdC8vIHdlcmUgbG9zdCBhbmQgbm8gYW1vdW50IG9mIHdhaXRpbmcgd2lsbCBicmluZyB0aGVtIGJhY2sg4oCUIHJlbG9hZCBub3dcblx0XHQvLyByYXRoZXIgdGhhbiBsZXR0aW5nIHRoZSB3YXRjaGRvZyBub3RpY2UgaW4gMjAgc2Vjb25kcy5cblx0XHRhd2FpdCBzZXJpYWwoKCkgPT4gcmVjb3Zlck1pc3NlZENhcHR1cmUodGFiSWQpKVxuXHR9KSgpXG59KVxuXG4vKipcbiAqIEEgYmxvY2tlZCBwYWdlIHRoYXQgbm9ib2R5IGhhcyBjbGVhcmVkLiBSZWxvYWQgaXQg4oCUIGEgZmxhdCA0MDMgb2Z0ZW4gcGFzc2VzIG9uXG4gKiBhIHNlY29uZCB0cnksIGFuZCBhIGNoYWxsZW5nZSB0aGUgdXNlciBhbHJlYWR5IHNvbHZlZCB3aWxsIGhhdmUgbmF2aWdhdGVkIGF3YXlcbiAqIGJ5IG5vdywgaW4gd2hpY2ggY2FzZSB0aGlzIGRvZXMgbm90aGluZy5cbiAqL1xuY2hyb21lLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xuXHRpZiAoYWxhcm0ubmFtZSA9PT0gJ3JldHJ5LWJsb2NrZWQnKSB7XG5cdFx0dm9pZCBzZXJpYWwoKCkgPT4gcmV0cnlJZlN0aWxsQmxvY2tlZCgpKVxuXHRcdHJldHVyblxuXHR9XG5cdC8vIFRoZSB3YXRjaGRvZzogY2F0Y2hlcyBhIHBhZ2Ugd2hvc2UgbG9hZCBldmVudHMgbmV2ZXIgYXJyaXZlZCwgd2hpY2ggd291bGRcblx0Ly8gb3RoZXJ3aXNlIGxlYXZlIHRoZSBydW4gc2l0dGluZyBvbiBcIkxvYWRpbmfigKZcIiBmb3JldmVyLlxuXHRpZiAoYWxhcm0ubmFtZSA9PT0gJ3dhdGNoZG9nJykge1xuXHRcdHZvaWQgc2VyaWFsKCgpID0+IGNoZWNrRm9yU3RhbGwoKSlcblx0fVxufSlcblxuLy8gTm8gZGVmYXVsdF9wb3B1cCBpbiB0aGUgbWFuaWZlc3QsIHNvIHRoZSBpY29uIGNsaWNrIGNvbWVzIGhlcmUuXG5jaHJvbWUuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdHZvaWQgb3BlbkFkbWluUGFnZSgpXG59KVxuXG5jaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6ICcjM2Y2ZDNhJyB9KS5jYXRjaCgoKSA9PiB7fSlcbiJdLCJuYW1lcyI6WyJvcmlnaW4iLCJzdGF0ZSIsImF0dGVtcHRzIl0sIm1hcHBpbmdzIjoiQUFlTyxNQUFNLDJCQUEyQjtBQStCakMsU0FBUyxpQkFDZixLQUNrRDtBQUNsRCxRQUFNLFFBQVEsSUFBSSxNQUFNLGlCQUFpQjtBQUN6QyxNQUFJLENBQUMsTUFBTyxRQUFPO0FBQ25CLFNBQU8sRUFBRSxTQUFTLE1BQU0sQ0FBQyxHQUFHLGFBQWEsT0FBTyxTQUFTLE1BQU0sQ0FBQyxHQUFHLEVBQUUsRUFBQTtBQUN0RTtBQWlFTyxTQUFTLGdCQUEwQjtBQUN6QyxTQUFPLEVBQUUsUUFBUSxRQUFRLE9BQU8sQ0FBQSxFQUFDO0FBQ2xDO0FDbEdBLE1BQU0sbUJBQW1CO0FBRXpCLE1BQU0sVUFBVTtBQW9DaEIsZUFBc0IsT0FBTyxPQUE4QjtBQUMxRCxNQUFJO0FBQ0gsVUFBTSxPQUFPLFNBQVMsT0FBTyxFQUFFLE1BQUEsR0FBUyxnQkFBZ0I7QUFBQSxFQUN6RCxTQUFTLE9BQU87QUFFZixRQUFJLENBQUMsb0JBQW9CLEtBQUssY0FBYyxLQUFLLENBQUMsRUFBRyxPQUFNO0FBQUEsRUFDNUQ7QUFJQSxRQUFNLE9BQU8sU0FBUyxZQUFZLEVBQUUsTUFBQSxHQUFTLGdCQUFnQjtBQUM5RDtBQUVBLGVBQXNCLE9BQU8sT0FBOEI7QUFDMUQsTUFBSTtBQUNILFVBQU0sT0FBTyxTQUFTLE9BQU8sRUFBRSxPQUFPO0FBQUEsRUFDdkMsUUFBUTtBQUFBLEVBRVI7QUFDRDtBQUdBLGVBQXNCLGVBQWUsT0FBOEI7QUFDbEUsTUFBSTtBQUNILFVBQU0sT0FBTyxLQUFLO0FBQUEsRUFDbkIsU0FBUyxPQUFPO0FBQ2YsVUFBTSxJQUFJO0FBQUEsTUFDVCxtREFBbUQsY0FBYyxLQUFLLENBQUM7QUFBQSxJQUFBO0FBQUEsRUFFekU7QUFDRDtBQVFBLGVBQXNCLHFCQUNyQixPQUNBLFFBQ2dCO0FBQ2hCLE1BQUksT0FBTyxTQUFTLFdBQVk7QUFFaEMsUUFBTSxXQUFXLE9BQU87QUFDeEIsUUFBTSxZQUFZLE9BQU87QUFDekIsTUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLElBQUs7QUFRbEMsTUFBSSxPQUFPLFlBQVksT0FBTyxhQUFhLFVBQVc7QUFFdEQsUUFBTSxnQkFBZ0IsT0FBTztBQUFBLElBQzVCO0FBQUEsSUFDQSxLQUFLLFNBQVM7QUFBQSxJQUNkLFFBQVEsU0FBUyxVQUFVO0FBQUEsSUFDM0IsVUFBVTtBQUFBLEVBQUEsQ0FDVjtBQUNGO0FBRUEsZUFBc0Isb0JBQ3JCLE9BQ0EsUUFDbUM7QUFDbkMsUUFBTSxPQUFPLE1BQU0sZ0JBQWdCLEtBQUs7QUFDeEMsTUFBSSxDQUFDLFFBQVEsS0FBSyxjQUFjLE9BQU8sVUFBVyxRQUFPO0FBRXpELFFBQU0sV0FBVyxFQUFFLEdBQUcsTUFBTSxVQUFVLEtBQUE7QUFDdEMsUUFBTSxnQkFBZ0IsT0FBTyxRQUFRO0FBQ3JDLFNBQU87QUFDUjtBQVVPLFNBQVMsZUFBZSxPQUF5QjtBQUN2RCxTQUFPLG1EQUFtRDtBQUFBLElBQ3pELGNBQWMsS0FBSztBQUFBLEVBQUE7QUFFckI7QUFFQSxlQUFzQixnQkFDckIsT0FDbUM7QUFDbkMsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFFeEMsR0FBRyxPQUFPLElBQUksS0FBSyxFQUFFO0FBQ3ZCLFNBQU8sT0FBTyxHQUFHLE9BQU8sSUFBSSxLQUFLLEVBQUUsS0FBSztBQUN6QztBQUVBLGVBQWUsZ0JBQ2QsT0FDQSxPQUNnQjtBQUNoQixRQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRSxHQUFHLE9BQU87QUFDbEU7QUFHQSxlQUFzQixxQkFDckIsT0FDQSxVQUNnQjtBQUNoQixRQUFNLGdCQUFnQixPQUFPLEVBQUUsR0FBRyxVQUFVLFVBQVUsTUFBTTtBQUM3RDtBQUVBLGVBQXNCLGtCQUFrQixPQUE4QjtBQUNyRSxRQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU8sR0FBRyxPQUFPLElBQUksS0FBSyxFQUFFO0FBQ3hEO0FBSUEsZUFBc0IsU0FDckIsT0FDQSxVQUN3QjtBQUN4QixRQUFNLFNBQVMsTUFBTSxPQUFPLFNBQVMsWUFHbEMsRUFBRSxNQUFBLEdBQVMsMkJBQTJCLEVBQUUsV0FBVyxTQUFTLFdBQVc7QUFFMUUsU0FBTztBQUFBLElBQ04sS0FBSyxTQUFTO0FBQUEsSUFDZCxRQUFRLFNBQVM7QUFBQSxJQUNqQixNQUFNLE9BQU8sZ0JBQWdCLGFBQWEsT0FBTyxJQUFJLElBQUksT0FBTztBQUFBLElBQ2hFLGVBQWUsT0FBTztBQUFBLEVBQUE7QUFFeEI7QUFHQSxTQUFTLGFBQWEsUUFBd0I7QUFDN0MsUUFBTSxTQUFTLEtBQUssTUFBTTtBQUMxQixRQUFNLFFBQVEsSUFBSSxXQUFXLE9BQU8sTUFBTTtBQUMxQyxXQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFLLE9BQU0sQ0FBQyxJQUFJLE9BQU8sV0FBVyxDQUFDO0FBQ3RFLFNBQU8sSUFBSSxZQUFBLEVBQWMsT0FBTyxLQUFLO0FBQ3RDO0FBRU8sU0FBUyxjQUFjLE9BQXdCO0FBQ3JELE1BQUksaUJBQWlCLE1BQU8sUUFBTyxNQUFNO0FBQ3pDLE1BQUksT0FBTyxVQUFVLFNBQVUsUUFBTztBQUN0QyxTQUFPLEtBQUssVUFBVSxLQUFLO0FBQzVCO0FDdk1BLE1BQU0sYUFBYTtBQUNuQixNQUFNLFlBQVk7QUF5QlgsU0FBUyxnQkFBZ0IsU0FBMkI7QUFDMUQsU0FDQyxPQUFPLFlBQVksWUFDbkIsWUFBWSxRQUNYLFFBQXlCLGtCQUFrQjtBQUU5QztBQVNBLE1BQU0sbUJBQW1CLENBQUMsd0JBQXdCLHVCQUF1QjtBQVN6RSxlQUFzQixvQkFDckIsV0FDZ0I7QUFDaEIsTUFBSSxDQUFDLFVBQVc7QUFDaEIsTUFBSTtBQUNILFVBQU0sRUFBRSxPQUFBLElBQVcsSUFBSSxJQUFJLFNBQVM7QUFDcEMsVUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxVQUFVLEdBQUcsUUFBUTtBQUFBLEVBQ3hELFFBQVE7QUFBQSxFQUVSO0FBQ0Q7QUFFQSxlQUFlLG1CQUEyQztBQUN6RCxRQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLElBQ3pDO0FBQUEsRUFBQTtBQUVELFNBQU8sT0FBTyxtQkFBbUI7QUFDbEM7QUFRQSxlQUFzQixnQkFBK0I7QUFDcEQsUUFBTSxVQUFVLENBQUMsTUFBTSxvQkFBb0IsR0FBRyxnQkFBZ0IsRUFBRTtBQUFBLElBQy9ELENBQUNBLFlBQTZCLENBQUMsQ0FBQ0E7QUFBQUEsRUFBQTtBQUdqQyxhQUFXQSxXQUFVLFNBQVM7QUFDN0IsVUFBTSxXQUFXLE1BQU0sT0FBTyxLQUM1QixNQUFNLEVBQUUsS0FBSyxHQUFHQSxPQUFNLEdBQUcsU0FBUyxJQUFBLENBQUssRUFDdkMsTUFBTSxNQUFNLEVBQUU7QUFFaEIsVUFBTSxNQUFNLFNBQVMsS0FBSyxDQUFDLGNBQWMsVUFBVSxPQUFPLE1BQVM7QUFDbkUsUUFBSSxLQUFLLE9BQU8sUUFBVztBQUMxQixZQUFNLE9BQU8sS0FBSyxPQUFPLElBQUksSUFBSSxFQUFFLFFBQVEsTUFBTTtBQUNqRCxVQUFJLElBQUksYUFBYSxRQUFXO0FBQy9CLGNBQU0sT0FBTyxRQUFRLE9BQU8sSUFBSSxVQUFVLEVBQUUsU0FBUyxNQUFNO0FBQUEsTUFDNUQ7QUFDQTtBQUFBLElBQ0Q7QUFBQSxFQUNEO0FBRUEsUUFBTSxTQUFTLFFBQVEsQ0FBQztBQUN4QixRQUFNLE9BQU8sS0FBSyxPQUFPLEVBQUUsS0FBSyxHQUFHLE1BQU0sR0FBRyxTQUFTLElBQUksUUFBUSxLQUFBLENBQU07QUFDeEU7QUNoRUEsTUFBTSxpQkFBaUIsb0JBQUksSUFBSSxDQUFDLGFBQWEsWUFBWSxZQUFZLENBQUM7QUFFL0QsTUFBTSxvQkFBNEM7QUFBQSxFQUN4RCxrQkFBa0I7QUFBQSxFQUNsQixpQkFBaUI7QUFBQSxFQUNqQixjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxrQkFBa0I7QUFBQSxFQUNsQixjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxpQkFBaUI7QUFBQSxFQUNqQixpQkFBaUI7QUFBQSxFQUNqQixjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxjQUFjO0FBQUEsRUFDZCxpQkFBaUI7QUFBQSxFQUNqQixjQUFjO0FBQUEsRUFDZCxrQkFBa0I7QUFBQSxFQUNsQixjQUFjO0FBQ2Y7QUFFQSxTQUFTLGtCQUFrQixLQUFhLFNBQXlCO0FBQ2hFLE1BQUk7QUFDSCxVQUFNLFdBQVcsSUFBSSxJQUFJLEdBQUcsRUFBRSxTQUFTLFFBQVEsVUFBVSxFQUFFO0FBQzNELFFBQUksYUFBYSxtQkFBbUIsZUFBZSxJQUFJLE9BQU8sR0FBRztBQUNoRSxhQUFPO0FBQUEsSUFDUjtBQUNBLFdBQU8sa0JBQWtCLFFBQVEsS0FBSztBQUFBLEVBQ3ZDLFFBQVE7QUFDUCxXQUFPO0FBQUEsRUFDUjtBQUNEO0FBTU8sU0FBUyxjQUFjLFlBQXNDO0FBQ25FLFFBQU0sMkJBQVcsSUFBQTtBQUVqQixhQUFXLFVBQVUsWUFBWTtBQUNoQyxRQUFJLENBQUMsT0FBTyxZQUFZLENBQUMsT0FBTyxNQUFPO0FBQ3ZDLFFBQUksS0FBSyxJQUFJLE9BQU8sS0FBSyxFQUFHO0FBSTVCLFVBQU0sV0FBVyxPQUFPLFNBQVM7QUFBQSxNQUNoQztBQUFBLElBQUE7QUFFRCxRQUFJLENBQUMsU0FBVTtBQUVmLFVBQU0sVUFBVSxHQUFHLFNBQVMsQ0FBQyxDQUFDO0FBRTlCLFNBQUssSUFBSSxPQUFPLE9BQU87QUFBQSxNQUN0QixTQUFTLE9BQU87QUFBQSxNQUNoQixNQUFNLE9BQU87QUFBQSxNQUNiLEtBQUs7QUFBQSxNQUNMLFNBQVMsa0JBQWtCLE9BQU8sVUFBVSxPQUFPLEtBQUs7QUFBQSxJQUFBLENBQ3hEO0FBQUEsRUFDRjtBQUVBLFNBQU8sTUFBTSxLQUFLLEtBQUssT0FBQSxDQUFRO0FBQ2hDO0FBSUEsU0FBUyxVQUFVLE1BQXNCO0FBQ3hDLFNBQU8sS0FBSyxRQUFRLFlBQVksRUFBRSxFQUFFLEtBQUE7QUFDckM7QUFJQSxNQUFNLFdBQW1DO0FBQUEsRUFDeEMsU0FBUztBQUFBLEVBQ1QsUUFBUTtBQUFBLEVBQ1IsUUFBUTtBQUFBLEVBQ1IsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUFBLEVBQ1YsVUFBVTtBQUNYO0FBRUEsU0FBUyxlQUFlLE1BQXNCO0FBQzdDLFNBQU8sS0FDTCxRQUFRLHdDQUF3QyxDQUFDLE1BQU0sU0FBUyxDQUFDLEtBQUssQ0FBQyxFQUN2RTtBQUFBLElBQVE7QUFBQSxJQUFhLENBQUMsR0FBRyxTQUN6QixPQUFPLGNBQWMsT0FBTyxTQUFTLE1BQU0sRUFBRSxDQUFDO0FBQUEsRUFBQSxFQUU5QyxRQUFRLFdBQVcsR0FBRztBQUN6QjtBQUlPLFNBQVMsZ0JBQWdCLE1BQTBCO0FBS3pELFFBQU0sVUFBVSxLQUFLLE1BQU0sc0JBQXNCLElBQUksQ0FBQyxLQUFLO0FBQzNELFFBQU0sVUFBVSxRQUFRLE1BQU0sbUJBQW1CO0FBQ2pELFFBQU0sY0FBYyxlQUFlLFVBQVUsT0FBTyxDQUFDLEVBQ25ELFFBQVEsbUJBQW1CLEVBQUUsRUFDN0IsS0FBQTtBQUNGLFFBQU0sT0FBTyxXQUFXLGNBQWMsY0FBYztBQUlwRCxRQUFNLGFBQWEsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFBQTtBQUVELFFBQU0sWUFBWSxhQUFhLE9BQU8sU0FBUyxXQUFXLENBQUMsR0FBRyxFQUFFLElBQUk7QUFDcEUsUUFBTSxrQkFBa0IsYUFBYSxDQUFDLElBQ25DLE9BQU8sU0FBUyxXQUFXLENBQUMsR0FBRyxFQUFFLElBQ2pDO0FBRUgsU0FBTztBQUFBLElBQ047QUFBQSxJQUNBLFdBQVcsVUFBVSxRQUFRLENBQUMsSUFBSTtBQUFBLElBQ2xDO0FBQUEsSUFDQTtBQUFBLEVBQUE7QUFFRjtBQVlBLFNBQVMsa0JBQWtCLE1BQXdCO0FBQ2xELFFBQU0sYUFBdUIsQ0FBQTtBQUU3QixRQUFNLGVBQWUsS0FBSztBQUFBLElBQ3pCO0FBQUEsRUFBQTtBQUVELE1BQUksYUFBYyxZQUFXLEtBQUssYUFBYSxDQUFDLENBQUM7QUFFakQsUUFBTSxTQUFTO0FBQUEsSUFDZCxHQUFHLEtBQUssU0FBUyxvREFBb0Q7QUFBQSxFQUFBO0FBRXRFLGFBQVcsU0FBUyxPQUFPLFdBQVc7QUFDckMsVUFBTSxRQUFRLE1BQU0sQ0FBQyxFQUFFLE1BQU0sa0NBQWtDO0FBQy9ELGVBQVcsS0FBSyxRQUFRLE1BQU0sQ0FBQyxJQUFJLE1BQU0sQ0FBQyxDQUFDO0FBQUEsRUFDNUM7QUFFQSxTQUFPO0FBQ1I7QUFFTyxTQUFTLGdCQUFnQixNQUEyQjtBQUMxRCxhQUFXLFNBQVMsa0JBQWtCLElBQUksR0FBRztBQUM1QyxVQUFNLFVBQVUsZ0JBQWdCLEtBQUs7QUFDckMsUUFBSSxRQUFRLFNBQVMsRUFBRyxRQUFPO0FBQUEsRUFDaEM7QUFDQSxTQUFPLENBQUE7QUFDUjtBQUVBLFNBQVMsZ0JBQWdCLE9BQTRCO0FBQ3BELFFBQU0sVUFBdUIsQ0FBQTtBQUc3QixRQUFNLFdBQVc7QUFFakIsYUFBVyxZQUFZLE1BQU0sU0FBUyxRQUFRLEdBQUc7QUFDaEQsVUFBTSxNQUFNLFNBQVMsQ0FBQztBQUd0QixVQUFNLFlBQVk7QUFDbEIsVUFBTSxRQUFrQixDQUFBO0FBQ3hCLGVBQVcsYUFBYSxJQUFJLFNBQVMsU0FBUyxHQUFHO0FBQ2hELFlBQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUFBLElBQ3hCO0FBR0EsUUFBSSxNQUFNLFNBQVMsRUFBRztBQUd0QixVQUFNLGlCQUFpQixNQUFNLENBQUMsRUFBRTtBQUFBLE1BQy9CO0FBQUEsSUFBQTtBQUVELFVBQU0sV0FBVyxpQkFBaUIsZUFBZSxDQUFDLEVBQUUsU0FBUztBQUM3RCxVQUFNLFlBQVksaUJBQ2YsZUFBZSxlQUFlLENBQUMsQ0FBQyxFQUFFLEtBQUEsSUFDbEMsZUFBZSxVQUFVLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFJckMsUUFBSSxDQUFDLGNBQWMsS0FBSyxRQUFRLEVBQUc7QUFHbkMsVUFBTSxlQUFlLFNBQVMsTUFBTSxzQkFBc0I7QUFDMUQsVUFBTSxRQUFRLGVBQ1gsYUFBYSxDQUFDLElBQ2QsVUFBVSxjQUFjLFFBQVEsY0FBYyxFQUFFO0FBS25ELFVBQU0sT0FBTyxnQkFBZ0IsTUFBTSxDQUFDLENBQUM7QUFHckMsVUFBTSxjQUFjLE9BQU8sU0FBUyxVQUFVLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxLQUFLO0FBR2hFLFVBQU0sV0FBVyxPQUFPLFNBQVMsVUFBVSxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSztBQUc3RCxVQUFNLE9BQU8sVUFBVSxNQUFNLENBQUMsQ0FBQztBQUcvQixVQUFNLFdBQVcsVUFBVSxNQUFNLENBQUMsQ0FBQztBQUVuQyxRQUFJLGFBQWEsTUFBTTtBQUN0QixjQUFRLEtBQUs7QUFBQSxRQUNaO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQUEsQ0FDQTtBQUFBLElBQ0Y7QUFBQSxFQUNEO0FBRUEsU0FBTztBQUNSO0FBR0EsU0FBUyxnQkFBZ0IsTUFBc0I7QUFDOUMsUUFBTSxNQUFNLEtBQUssTUFBTSw2QkFBNkI7QUFDcEQsTUFBSSxJQUFLLFFBQU8sR0FBRyxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLENBQUM7QUFFN0MsUUFBTSxNQUFNLEtBQUssTUFBTSx1QkFBdUI7QUFDOUMsTUFBSSxJQUFLLFFBQU8sSUFBSSxDQUFDO0FBRXJCLFNBQU8sVUFBVSxJQUFJO0FBQ3RCO0FBZ0JPLFNBQVMsa0JBQWtCLE1BQWtDO0FBQ25FLFFBQU0sVUFBOEIsQ0FBQTtBQUVwQyxRQUFNLGFBQWEsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFBQTtBQUVELE1BQUksQ0FBQyxXQUFZLFFBQU87QUFFeEIsUUFBTSxRQUFRLFdBQVcsQ0FBQztBQUUxQixhQUFXLFlBQVksTUFBTSxTQUFTLDZCQUE2QixHQUFHO0FBQ3JFLFVBQU0sUUFBa0IsQ0FBQTtBQUN4QixlQUFXLGFBQWEsU0FBUyxDQUFDLEVBQUU7QUFBQSxNQUNuQztBQUFBLElBQUEsR0FDRTtBQUNGLFlBQU0sS0FBSyxVQUFVLENBQUMsQ0FBQztBQUFBLElBQ3hCO0FBRUEsUUFBSSxNQUFNLFNBQVMsRUFBRztBQUV0QixVQUFNLE9BQU8sZUFBZSxVQUFVLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDL0MsUUFBSSxDQUFDLEtBQU07QUFFWCxVQUFNLGNBQWMsTUFBTSxDQUFDLEVBQUUsTUFBTSxvQkFBb0I7QUFDdkQsVUFBTSxVQUFVLE9BQU8sU0FBUyxVQUFVLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRTtBQUN2RCxVQUFNLFNBQVMsT0FBTyxTQUFTLFVBQVUsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFO0FBRXRELFFBQUksT0FBTyxNQUFNLE9BQU8sS0FBSyxPQUFPLE1BQU0sTUFBTSxFQUFHO0FBRW5ELFlBQVEsS0FBSztBQUFBLE1BQ1osUUFBUSxjQUFjLFlBQVksQ0FBQyxJQUFJO0FBQUEsTUFDdkM7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQUEsQ0FDQTtBQUFBLEVBQ0Y7QUFFQSxTQUFPO0FBQ1I7QUF1Q08sU0FBUyxlQUFlLE1BQXNCO0FBQ3BELFFBQU0sUUFBUSxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUFBO0FBRUQsU0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQzNCO0FBb0JPLFNBQVMsbUJBQW1CLE1BQTZCO0FBQy9ELFFBQU0sUUFBUTtBQUFBLElBQ2IsVUFBVSxLQUFLLE1BQU0sMkJBQTJCLElBQUksQ0FBQyxLQUFLLEVBQUU7QUFBQSxFQUFBO0FBSTdELFFBQU0sVUFBVSxLQUFLLE1BQU0sZ0NBQWdDLElBQUksQ0FBQyxLQUFLO0FBRXJFLFFBQU0sY0FBYyxLQUFLLE1BQU0sNEJBQTRCO0FBRTNELFNBQU87QUFBQSxJQUNOO0FBQUEsSUFDQTtBQUFBLElBQ0EsYUFBYSxjQUFjLE9BQU8sU0FBUyxZQUFZLENBQUMsR0FBRyxFQUFFLElBQUk7QUFBQSxJQUNqRSxNQUFNLGVBQWUsSUFBSTtBQUFBLEVBQUE7QUFFM0I7QUM3V08sU0FBUyxjQUFjLGNBQThCO0FBQzNELFNBQU8sR0FBRyxVQUFVLFlBQVksQ0FBQztBQUNsQztBQUdPLFNBQVMsYUFBYSxLQUFxQjtBQUNqRCxTQUFPLHlDQUF5QyxHQUFHO0FBQ3BEO0FBVUEsU0FBUyxVQUFVLEtBQXFCO0FBQ3ZDLFNBQU8sSUFBSSxRQUFRLE9BQU8sRUFBRTtBQUM3QjtBQVNxQyxPQUFPLEtBQUssaUJBQWlCLEVBQUU7QUFBQSxFQUNuRSxDQUFDLFdBQVcsQ0FBQyxPQUFPLE1BQU0sTUFBTSxTQUFTLE1BQU0sSUFBSTtBQUNwRDtBQ3JFQSxNQUFNLG1CQUFtQjtBQUV6QixJQUFJLFFBQStDO0FBRTVDLFNBQVMsaUJBQXVCO0FBQ3RDLE1BQUksTUFBTztBQUNYLFVBQVEsWUFBWSxNQUFNO0FBRXpCLFNBQUssT0FBTyxRQUFRLGdCQUFBLEVBQWtCLE1BQU0sTUFBTSxNQUFTO0FBQUEsRUFDNUQsR0FBRyxnQkFBZ0I7QUFDcEI7QUFFTyxTQUFTLGdCQUFzQjtBQUNyQyxNQUFJLENBQUMsTUFBTztBQUNaLGdCQUFjLEtBQUs7QUFDbkIsVUFBUTtBQUNUO0FDYkEsTUFBTSxVQUFVO0FBQ2hCLE1BQU0sY0FBYztBQUVwQixNQUFNLGlCQUFpQjtBQUV2QixNQUFNLG1CQUFtQjtBQW1CekIsU0FBUyxlQUEyQjtBQUNuQyxTQUFPO0FBQUEsSUFDTixxQkFBcUIsQ0FBQTtBQUFBLElBQ3JCLGtCQUFrQixDQUFBO0FBQUEsSUFDbEIsZUFBZTtBQUFBLElBQ2YsYUFBYTtBQUFBLElBQ2IsVUFBVTtBQUFBLEVBQUE7QUFFWjtBQUlBLGVBQXNCLGNBQWlDO0FBQ3RELFFBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBQXdCLE9BQU87QUFDekUsU0FBTyxPQUFPLE9BQU8sY0FBQTtBQUN0QjtBQUVBLGVBQXNCLFlBQVksT0FBZ0M7QUFDakUsUUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxPQUFPLEdBQUcsT0FBTztBQUNwRDtBQUdBLGVBQXNCLGVBQ3JCLFFBQ29CO0FBQ3BCLFFBQU0sT0FBTyxPQUFPLE1BQU0sYUFBYTtBQUN2QyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1I7QUFFQSxlQUFzQixjQUNyQixLQUNBLFFBQ0EsUUFDQSxVQUNvQjtBQUNwQixTQUFPLGVBQWUsQ0FBQyxXQUFXO0FBQUEsSUFDakMsR0FBRztBQUFBLElBQ0gsT0FBTyxNQUFNLE1BQU07QUFBQSxNQUFJLENBQUMsU0FDdkIsS0FBSyxRQUFRLE1BQ1Y7QUFBQSxRQUNBLEdBQUc7QUFBQSxRQUNIO0FBQUEsUUFDQTtBQUFBLFFBQ0EsVUFBVSxZQUFZLEtBQUs7QUFBQSxRQUMzQixXQUFXLEtBQUssSUFBQTtBQUFBLE1BQUksSUFFcEI7QUFBQSxJQUFBO0FBQUEsRUFDSixFQUNDO0FBQ0g7QUFFQSxlQUFzQixZQUFZLE9BQXVDO0FBQ3hFLFNBQU8sZUFBZSxDQUFDLFdBQVc7QUFBQSxJQUNqQyxHQUFHO0FBQUEsSUFDSCxPQUFPLENBQUMsR0FBRyxNQUFNLE9BQU8sR0FBRyxLQUFLO0FBQUEsRUFBQSxFQUMvQjtBQUNIO0FBSUEsZUFBc0IsYUFBa0M7QUFDdkQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxJQUN6QztBQUFBLEVBQUE7QUFFRCxTQUFPLE9BQU8sV0FBVyxhQUFBO0FBQzFCO0FBRUEsZUFBc0IsV0FBVyxTQUFvQztBQUNwRSxRQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLFdBQVcsR0FBRyxTQUFTO0FBQzFEO0FBRUEsZUFBc0IsY0FDckIsUUFDc0I7QUFDdEIsUUFBTSxPQUFPLE9BQU8sTUFBTSxZQUFZO0FBQ3RDLFFBQU0sV0FBVyxJQUFJO0FBQ3JCLFNBQU87QUFDUjtBQVFBLFNBQVMsZUFBZSxNQUFrRDtBQUN6RSxTQUFPLFFBQVEsS0FBSyxJQUFJLElBQUksS0FBSyxHQUFHO0FBQ3JDO0FBRUEsZUFBZSxlQUFrQztBQUNoRCxRQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLElBQ3pDO0FBQUEsRUFBQTtBQUVELFNBQU8sT0FBTyxZQUFZLENBQUE7QUFDM0I7QUFFQSxlQUFzQixXQUFvQztBQUN6RCxRQUFNLFFBQVEsTUFBTSxhQUFBO0FBQ3BCLE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTyxDQUFBO0FBQy9CLFFBQU0sU0FDTCxNQUFNLE9BQU8sUUFBUSxNQUFNO0FBQUEsSUFDMUI7QUFBQSxFQUFBO0FBRUYsU0FBTyxNQUFNLFFBQVEsQ0FBQyxRQUFRLE9BQU8sR0FBRyxLQUFLLEVBQUU7QUFDaEQ7QUFHQSxlQUFzQixRQUFRLE1BQW1DO0FBQ2hFLFFBQU0sYUFBYSxlQUFlLElBQUk7QUFFdEMsUUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxVQUFVLEdBQUcsTUFBTTtBQUNyRCxRQUFNLFFBQVEsTUFBTSxhQUFBO0FBQ3BCLE1BQUksQ0FBQyxNQUFNLFNBQVMsVUFBVSxHQUFHO0FBQ2hDLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsY0FBYyxHQUFHLENBQUMsR0FBRyxPQUFPLFVBQVUsR0FBRztBQUFBLEVBQzVFO0FBQ0Q7QUFJQSxlQUFzQixXQUEwQjtBQUMvQyxRQUFNLE9BQU8sUUFBUSxNQUFNLE9BQU87QUFBQSxJQUNqQztBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0EsR0FBSSxNQUFNLGFBQUE7QUFBQSxFQUFhLENBQ3ZCO0FBQ0Y7QUNoS0EsZUFBc0IsWUFBWSxPQUFnQztBQUNqRSxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLFFBQU0sVUFBVSxFQUFFLE1BQU0sU0FBa0IsTUFBQTtBQUUxQyxhQUFXLFNBQVMsQ0FBQyxRQUFRLFlBQVksUUFBUSxXQUFXLEdBQUc7QUFDOUQsUUFBSSxVQUFVLE9BQVc7QUFDekIsVUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPLE9BQU8sRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUM3RDtBQUNEO0FBRUEsZUFBc0IsV0FBVyxNQUFtQztBQUNuRSxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsUUFBTSxPQUFPLEtBQ1gsWUFBWSxZQUFZLEVBQUUsTUFBTSxRQUFpQixLQUFBLENBQU0sRUFDdkQsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2pCO0FDVUEsTUFBTSxvQkFBb0I7QUFBQSxFQUN6QjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNEO0FBRUEsU0FBUyxtQkFBbUIsTUFBdUI7QUFDbEQsUUFBTSxXQUFXLEtBQUssTUFBTSxHQUFHLEdBQU8sRUFBRSxZQUFBO0FBQ3hDLFNBQU8sa0JBQWtCLEtBQUssQ0FBQyxXQUFXLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFDcEU7QUFFTyxTQUFTLFNBQ2YsTUFDQSxLQUNBLFFBQ0EsTUFDVTtBQUtWLE1BQUksVUFBVSxLQUFLO0FBQ2xCLFVBQU0sWUFBWSxtQkFBbUIsSUFBSTtBQUN6QyxXQUFPO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxXQUFXO0FBQUEsTUFDWCxRQUFRLFlBQ0wsbUJBQW1CLE1BQU0sa0dBQ3pCLG1CQUFtQixNQUFNO0FBQUEsSUFBQTtBQUFBLEVBRTlCO0FBR0EsTUFBSSxtQkFBbUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLEdBQUc7QUFDbkUsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLE1BQ1gsUUFDQztBQUFBLElBQUE7QUFBQSxFQUVIO0FBRUEsVUFBUSxNQUFBO0FBQUEsSUFDUCxLQUFLO0FBQ0osYUFBTyxnQkFBZ0IsS0FBSyxJQUFJO0FBQUEsSUFDakMsS0FBSztBQUNKLGFBQU8sY0FBYyxLQUFLLElBQUk7QUFBQSxJQUMvQixLQUFLO0FBQ0osYUFBTyxrQkFBa0IsS0FBSyxJQUFJO0FBQUEsSUFDbkMsS0FBSztBQUNKLGFBQU8sY0FBYyxJQUFJO0FBQUEsSUFDMUIsS0FBSztBQUNKLGFBQU8sZUFBZSxJQUFJO0FBQUEsRUFBQTtBQUU3QjtBQU1BLFNBQVMsaUJBQ1IsTUFDQSxLQUNBLE1BQ1U7QUFDVixVQUFRLE1BQUE7QUFBQSxJQUNQLEtBQUs7QUFDSixhQUFPLGdCQUFnQixJQUFJLEVBQUUsU0FBUztBQUFBLElBQ3ZDLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDSixhQUFPLG1CQUFtQixJQUFJLEVBQUUsY0FBYztBQUFBLElBQy9DLEtBQUs7QUFDSixhQUFPLGtCQUFrQixJQUFJLEVBQUUsU0FBUztBQUFBLElBQ3pDLEtBQUs7QUFDSixhQUFPLGNBQWMsSUFBSSxNQUFNO0FBQUEsRUFBQTtBQUVsQztBQUVBLFNBQVMsZ0JBQWdCLFdBQW1CLE1BQXVCO0FBQ2xFLFFBQU0sU0FBUyxnQkFBZ0IsSUFBSTtBQUNuQyxRQUFNLFVBQVUsZ0JBQWdCLElBQUk7QUFFcEMsTUFBSSxPQUFPLFNBQVMsYUFBYSxRQUFRLFdBQVcsR0FBRztBQUN0RCxXQUFPO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxRQUFRO0FBQUEsSUFBQTtBQUFBLEVBRVY7QUFDQSxNQUFJLE9BQU8sYUFBYSxPQUFPLGNBQWMsV0FBVztBQUN2RCxXQUFPO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxRQUFRLHVCQUF1QixPQUFPLFNBQVMsY0FBYyxTQUFTO0FBQUEsSUFBQTtBQUFBLEVBRXhFO0FBQ0EsTUFBSSxRQUFRLFdBQVcsR0FBRztBQUN6QixXQUFPLEVBQUUsU0FBUyxZQUFZLFFBQVEsb0NBQUE7QUFBQSxFQUN2QztBQUVBLFNBQU87QUFBQSxJQUNOLFNBQVM7QUFBQSxJQUNULFFBQVEsR0FBRyxPQUFPLElBQUksTUFBTSxRQUFRLE1BQU07QUFBQSxFQUFBO0FBRTVDO0FBRUEsU0FBUyxjQUFjLFNBQWlCLE1BQXVCO0FBQzlELFFBQU0sT0FBTyxtQkFBbUIsSUFBSTtBQUVwQyxNQUFJLENBQUMsS0FBSyxlQUFlLENBQUMsS0FBSyxNQUFNO0FBQ3BDLFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFVjtBQUNBLE1BQUksS0FBSyxXQUFXLEtBQUssWUFBWSxTQUFTO0FBQzdDLFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVEsZ0JBQWdCLEtBQUssT0FBTyxnQkFBZ0IsT0FBTztBQUFBLElBQUE7QUFBQSxFQUU3RDtBQUlBLFNBQU8sRUFBRSxTQUFTLE1BQU0sUUFBUSxJQUFJLEtBQUssV0FBVyxNQUFNLEtBQUssSUFBSSxHQUFBO0FBQ3BFO0FBTUEsU0FBUyxrQkFBa0IsS0FBYSxNQUF1QjtBQUM5RCxRQUFNLFdBQVcsaUJBQWlCLEdBQUc7QUFDckMsTUFBSSxDQUFDLFVBQVU7QUFDZCxXQUFPLEVBQUUsU0FBUyxZQUFZLFFBQVEsc0JBQXNCLEdBQUcsS0FBQTtBQUFBLEVBQ2hFO0FBRUEsUUFBTSxVQUFVLGNBQWMsU0FBUyxTQUFTLElBQUk7QUFDcEQsTUFBSSxRQUFRLFlBQVksS0FBTSxRQUFPO0FBRXJDLFFBQU0sRUFBRSxZQUFBLElBQWdCLG1CQUFtQixJQUFJO0FBQy9DLE1BQUksZ0JBQWdCLFNBQVMsYUFBYTtBQUN6QyxXQUFPO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxRQUFRLGtCQUFrQixXQUFXLGVBQWUsU0FBUyxXQUFXO0FBQUEsSUFBQTtBQUFBLEVBRTFFO0FBQ0EsU0FBTztBQUNSO0FBRUEsU0FBUyxjQUFjLE1BQXVCO0FBQzdDLFFBQU0sUUFBUSxrQkFBa0IsSUFBSTtBQUNwQyxNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3ZCLFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFVjtBQUNBLFNBQU8sRUFBRSxTQUFTLE1BQU0sUUFBUSxHQUFHLE1BQU0sTUFBTSxTQUFBO0FBQ2hEO0FBTU8sU0FBUyxjQUFjLE1BQTZCO0FBQzFELFFBQU0sUUFBUSxLQUFLO0FBQUEsSUFDbEI7QUFBQSxFQUFBO0FBRUQsU0FBTyxRQUFRLE1BQU0sQ0FBQyxJQUFJO0FBQzNCO0FBRUEsU0FBUyxlQUFlLE1BQXVCO0FBQzlDLE1BQUksY0FBYyxJQUFJLEdBQUc7QUFDeEIsV0FBTyxFQUFFLFNBQVMsTUFBTSxRQUFRLHlCQUFBO0FBQUEsRUFDakM7QUFHQSxRQUFNLG1CQUFtQixXQUFXLEtBQUssSUFBSSxLQUFLLEtBQUssU0FBUztBQUNoRSxTQUFPLG1CQUNKO0FBQUEsSUFDQSxTQUFTO0FBQUEsSUFDVCxRQUFRO0FBQUEsRUFBQSxJQUVSO0FBQUEsSUFDQSxTQUFTO0FBQUEsSUFDVCxRQUFRO0FBQUEsRUFBQTtBQUVaO0FDekxBLE1BQU0sZUFBZTtBQU1yQixNQUFNLG1CQUFtQjtBQUd6QixNQUFNLGlCQUFpQjtBQUN2QixNQUFNLDBCQUEwQjtBQUVoQyxTQUFTLE9BQU8sTUFBdUI7QUFDdEMsVUFBUSxJQUFJLHFCQUFxQixHQUFHLElBQUk7QUFDekM7QUFTQSxNQUFNLGNBQWM7QUFDcEIsTUFBTSxzQkFBc0I7QUFFNUIsZUFBZSxnQkFBK0I7QUFDN0MsUUFBTSxPQUFPLE9BQ1gsT0FBTyxhQUFhLEVBQUUsZ0JBQWdCLG9CQUFBLENBQXFCLEVBQzNELE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUNqQjtBQUVBLGVBQWUsdUJBQXNDO0FBQ3BELFFBQU0sT0FBTyxPQUFPLE1BQU0sV0FBVyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUN0RDtBQUdBLGVBQXNCLGVBQWtDO0FBQ3ZELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU0sV0FBWSxRQUFPO0FBRTVELFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUMvRCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLE1BQUksQ0FBQyxRQUFRLFFBQVEsZ0JBQWdCLE9BQVcsUUFBTztBQUV2RCxRQUFNLHFCQUFBO0FBQ04sUUFBTSxrQkFBa0IsUUFBUSxXQUFXO0FBRTNDLE1BQUk7QUFDSCxVQUFNLGVBQWUsUUFBUSxXQUFXO0FBQ3hDLFVBQU0sT0FBTyxLQUFLLE9BQU8sUUFBUSxhQUFhLEVBQUUsS0FBSyxLQUFLLEtBQUs7QUFBQSxFQUNoRSxTQUFTLE9BQU87QUFDZixXQUFPLFFBQVEsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUNwQztBQUNBLFNBQU87QUFDUjtBQUdBLGVBQXNCLGNBQWlDO0FBQ3RELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU0sV0FBWSxRQUFPO0FBRTVELFFBQU0scUJBQUE7QUFDTixRQUFNLGNBQWMsTUFBTSxZQUFZLFdBQVcsVUFBVTtBQUMzRCxRQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFNBQU8sUUFBQTtBQUNSO0FBV0EsZUFBc0IscUJBQXFCLE9BQThCO0FBQ3hFLFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU0sV0FBWTtBQUVyRCxRQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxNQUFNLFVBQVU7QUFDL0QsTUFBSSxNQUFNLFdBQVcsU0FBVTtBQUcvQixRQUFNLFdBQVcsTUFBTSxnQkFBZ0IsS0FBSztBQUM1QyxNQUFJLFlBQVksQ0FBQyxTQUFTLFNBQVU7QUFFcEMsUUFBTSxZQUFZLEtBQUssWUFBWSxLQUFLO0FBQ3hDLE1BQUksV0FBVyxjQUFjO0FBQzVCLFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSwwREFBMEQsUUFBUTtBQUFBLE1BQ2xFO0FBQUEsSUFBQTtBQUVELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxRQUFBO0FBQ047QUFBQSxFQUNEO0FBRUE7QUFBQSxJQUNDLEdBQUcsS0FBSyxLQUFLLDBEQUEwRCxRQUFRO0FBQUEsRUFBQTtBQUVoRixRQUFNO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTDtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsRUFBQTtBQUVELFFBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsUUFBTSxhQUFBO0FBQ1A7QUFHQSxlQUFzQixzQkFBcUM7QUFDMUQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZO0FBRXJELFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUMvRCxNQUFJLE1BQU0sV0FBVyxVQUFXO0FBR2hDLE1BQUksS0FBSyxXQUFXO0FBQ25CLFFBQUksR0FBRyxLQUFLLEtBQUssNkNBQTZDO0FBQzlEO0FBQUEsRUFDRDtBQUVBLFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxRQUFRLFlBQVksY0FBYztBQUNyQyxVQUFNO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0EsR0FBRyxLQUFLLFVBQVUsVUFBVSxrQkFBa0IsUUFBUSxRQUFRO0FBQUEsSUFBQTtBQUUvRCxVQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFVBQU0sUUFBQTtBQUNOO0FBQUEsRUFDRDtBQUVBLFFBQU0sYUFBQTtBQUNQO0FBSUEsZUFBc0IsU0FDckIsU0FDQSxZQUNvQjtBQUNwQixRQUFNLFNBQUE7QUFFTixRQUFNLFFBQXFCLFFBQVEsTUFBTSxJQUFJLENBQUMsVUFBVTtBQUFBLElBQ3ZELEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxFQUFBLEVBQ1A7QUFFRixNQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3ZCLFVBQU1DLFNBQWtCO0FBQUEsTUFDdkIsUUFBUTtBQUFBLE1BQ1IsT0FBTyxDQUFBO0FBQUEsTUFDUCxTQUFTO0FBQUEsSUFBQTtBQUVWLFVBQU0sWUFBWUEsTUFBSztBQUN2QixXQUFPQTtBQUFBQSxFQUNSO0FBSUEsUUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFLLGVBQWUsUUFBUSxNQUFNO0FBQ3pFLE1BQUksSUFBSSxPQUFPLE9BQVcsT0FBTSxJQUFJLE1BQU0sNkJBQTZCO0FBRXZFLFFBQU0sV0FBVztBQUFBLElBQ2hCO0FBQUEsSUFDQSxhQUFhLElBQUk7QUFBQSxJQUNqQixxQkFBcUIsUUFBUTtBQUFBLElBQzdCLGtCQUFrQixDQUFBO0FBQUEsSUFDbEIsZUFBZTtBQUFBLElBQ2YsYUFBYSxRQUFRLGVBQWU7QUFBQSxJQUNwQyxVQUFVO0FBQUEsSUFDVixTQUFTLFFBQVE7QUFBQSxFQUFBLENBQ2pCO0FBRUQsUUFBTSxRQUFrQjtBQUFBLElBQ3ZCLFFBQVE7QUFBQSxJQUNSO0FBQUEsSUFDQSxXQUFXLEtBQUssSUFBQTtBQUFBLEVBQUk7QUFFckIsUUFBTSxZQUFZLEtBQUs7QUFFdkIsTUFBSTtBQUNILFVBQU0sZUFBZSxJQUFJLEVBQUU7QUFBQSxFQUM1QixTQUFTLE9BQU87QUFDZixXQUFPLFFBQVEsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUNwQztBQUVBLFFBQU0sU0FBUyxHQUFHO0FBQ2xCLGlCQUFBO0FBQ0EsUUFBTSxPQUFPLE9BQ1gsT0FBTyxnQkFBZ0IsRUFBRSxpQkFBaUIsd0JBQUEsQ0FBeUIsRUFDbkUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2hCLE1BQUksZ0JBQWdCLE1BQU0sTUFBTSxzQkFBc0IsSUFBSSxFQUFFLEVBQUU7QUFDOUQsU0FBTyxRQUFBO0FBQ1I7QUFTQSxlQUFzQixnQkFBK0I7QUFDcEQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZO0FBRXJELFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUMvRCxNQUFJLE1BQU0sV0FBVyxTQUFVO0FBRS9CLFFBQU0sTUFBTSxLQUFLLElBQUEsS0FBUyxLQUFLLGFBQWE7QUFDNUMsTUFBSSxNQUFNLGlCQUFrQjtBQUU1QixRQUFNLFlBQVksS0FBSyxZQUFZLEtBQUs7QUFDeEMsTUFBSSxXQUFXLGNBQWM7QUFDNUIsUUFBSSxnQkFBZ0IsS0FBSyxLQUFLLFVBQVUsUUFBUSxXQUFXO0FBQzNELFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxxQkFBcUIsUUFBUTtBQUFBLE1BQzdCO0FBQUEsSUFBQTtBQUVELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxRQUFBO0FBQ047QUFBQSxFQUNEO0FBRUE7QUFBQSxJQUNDLEdBQUcsS0FBSyxLQUFLLGdCQUFnQixLQUFLLE1BQU0sTUFBTSxHQUFJLENBQUMsMEJBQTBCLFFBQVE7QUFBQSxFQUFBO0FBRXRGLFFBQU07QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMO0FBQUEsSUFDQSxxQkFBcUIsS0FBSyxNQUFNLE1BQU0sR0FBSSxDQUFDLDBCQUEwQixRQUFRO0FBQUEsSUFDN0U7QUFBQSxFQUFBO0FBRUQsUUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxRQUFNLGFBQUE7QUFDUDtBQVFBLGVBQXNCLFlBQTJCO0FBQ2hELFFBQU0scUJBQUE7QUFDTixnQkFBQTtBQUNBLFFBQU0sT0FBTyxPQUFPLE1BQU0sY0FBYyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUN4RCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLE1BQUksUUFBUSxnQkFBZ0IsUUFBVztBQUN0QyxVQUFNLE9BQU8sUUFBUSxXQUFXO0FBQ2hDLFVBQU0sa0JBQWtCLFFBQVEsV0FBVztBQUFBLEVBQzVDO0FBQ0EsUUFBTSxTQUFBO0FBQ04sUUFBTSxTQUFTLEVBQUU7QUFDakIsTUFBSSxhQUFhO0FBQ2xCO0FBV0EsZUFBc0IsVUFBVSxZQUF1QztBQUN0RSxRQUFNLFdBQVcsTUFBTSxZQUFBO0FBQ3ZCLE1BQUksU0FBUyxNQUFNLFdBQVcsR0FBRztBQUNoQyxXQUFPLFFBQVEsNEJBQTRCO0FBQUEsRUFDNUM7QUFFQSxRQUFNLFFBQXFCLFNBQVMsTUFBTTtBQUFBLElBQUksQ0FBQyxTQUM5QyxLQUFLLFdBQVcsY0FBYyxLQUFLLFdBQVcsWUFDM0MsT0FDQTtBQUFBLE1BQ0EsR0FBRztBQUFBLE1BQ0gsUUFBUTtBQUFBLE1BQ1IsUUFBUTtBQUFBLE1BQ1IsVUFBVTtBQUFBLE1BQ1YsV0FBVztBQUFBLE1BQ1gsV0FBVyxLQUFLLElBQUE7QUFBQSxJQUFJO0FBQUEsRUFDckI7QUFHSCxRQUFNLGNBQWMsTUFBTSxPQUFPLENBQUMsU0FBUyxLQUFLLFdBQVcsU0FBUyxFQUFFO0FBQ3RFLE1BQUksZ0JBQWdCLEdBQUc7QUFDdEIsV0FBTyxRQUFRLHdEQUF3RDtBQUFBLEVBQ3hFO0FBRUEsUUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLE9BQU8sRUFBRSxLQUFLLGVBQWUsUUFBUSxNQUFNO0FBQ3pFLE1BQUksSUFBSSxPQUFPLE9BQVcsT0FBTSxJQUFJLE1BQU0sNkJBQTZCO0FBSXZFLFFBQU0sY0FBYyxDQUFDLGFBQWE7QUFBQSxJQUNqQyxHQUFHO0FBQUEsSUFDSDtBQUFBLElBQ0EsYUFBYSxJQUFJO0FBQUEsSUFDakIsVUFBVTtBQUFBLEVBQUEsRUFDVDtBQUVGLFFBQU0sWUFBWTtBQUFBLElBQ2pCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaO0FBQUEsSUFDQSxTQUFTO0FBQUEsSUFDVCxZQUFZO0FBQUEsRUFBQSxDQUNaO0FBRUQsTUFBSTtBQUNILFVBQU0sZUFBZSxJQUFJLEVBQUU7QUFBQSxFQUM1QixTQUFTLE9BQU87QUFDZixXQUFPLFFBQVEsY0FBYyxLQUFLLENBQUM7QUFBQSxFQUNwQztBQUVBLFFBQU0sU0FBUyxHQUFHO0FBQ2xCLGlCQUFBO0FBQ0EsUUFBTSxPQUFPLE9BQ1gsT0FBTyxnQkFBZ0IsRUFBRSxpQkFBaUIsd0JBQUEsQ0FBeUIsRUFDbkUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2hCLE1BQUksYUFBYSxXQUFXLE9BQU8sTUFBTSxNQUFNLHFCQUFxQjtBQUNwRSxTQUFPLFFBQUE7QUFDUjtBQUVBLGVBQXNCLFlBQStCO0FBQ3BELFFBQU0scUJBQUE7QUFDTixnQkFBQTtBQUNBLFFBQU0sT0FBTyxPQUFPLE1BQU0sY0FBYyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUV4RCxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLFFBQU0sWUFBc0I7QUFBQSxJQUMzQixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZO0FBQUEsSUFDWixZQUFZLEtBQUssSUFBQTtBQUFBLElBQ2pCLFNBQVM7QUFBQSxFQUFBO0FBR1YsUUFBTSxZQUFZLFNBQVM7QUFDM0IsUUFBTSxlQUFBO0FBQ04sUUFBTSxTQUFTLEVBQUU7QUFDakIsUUFBTSxjQUFBO0FBQ04sUUFBTSxZQUFZLFNBQVM7QUFDM0IsU0FBTztBQUNSO0FBRUEsZUFBZSxRQUFRLFNBQW9DO0FBQzFELGdCQUFBO0FBQ0EsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixRQUFNLFNBQW1CO0FBQUEsSUFDeEIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osWUFBWSxLQUFLLElBQUE7QUFBQSxJQUNqQjtBQUFBLEVBQUE7QUFFRCxRQUFNLFlBQVksTUFBTTtBQUN4QixRQUFNLFNBQVMsR0FBRztBQUNsQixRQUFNLFlBQVksTUFBTTtBQUN4QixTQUFPO0FBQ1I7QUFLQSxlQUFzQixVQUE2QjtBQUNsRCxRQUFNLGtCQUFBO0FBRU4sUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxVQUFXLFFBQU87QUFFdkMsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLFdBQVcsU0FBUztBQUVqRSxNQUFJLENBQUMsTUFBTTtBQUVWLFVBQU0sU0FBUyxNQUFNLGdCQUFBO0FBQ3JCLFFBQUksZUFBZSxRQUFBO0FBQ25CLFdBQU8sVUFBQTtBQUFBLEVBQ1I7QUFFQSxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLE1BQUksUUFBUSxnQkFBZ0IsUUFBVztBQUN0QyxXQUFPLFFBQVEseUJBQXlCO0FBQUEsRUFDekM7QUFFQSxRQUFNLHFCQUFBO0FBQ04sUUFBTSxjQUFjLENBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxVQUFVLElBQUk7QUFDbEQsUUFBTSxrQkFBa0IsUUFBUSxXQUFXO0FBRTNDLFFBQU0sVUFBb0I7QUFBQSxJQUN6QixHQUFHO0FBQUEsSUFDSCxZQUFZLEtBQUs7QUFBQSxJQUNqQixPQUFPLE1BQU0sTUFBTTtBQUFBLE1BQUksQ0FBQyxTQUN2QixLQUFLLFFBQVEsS0FBSyxNQUNmO0FBQUEsUUFDQSxHQUFHO0FBQUEsUUFDSCxRQUFRO0FBQUEsUUFDUixRQUFRO0FBQUEsUUFDUixVQUFVO0FBQUEsUUFDVixXQUFXLEtBQUssSUFBQTtBQUFBLE1BQUksSUFFcEI7QUFBQSxJQUFBO0FBQUEsSUFFSixTQUFTO0FBQUEsRUFBQTtBQUVWLFFBQU0sWUFBWSxPQUFPO0FBQ3pCLFFBQU0sWUFBWSxPQUFPO0FBRXpCLE1BQUksS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUcsRUFBRTtBQUVsQyxNQUFJO0FBQ0gsVUFBTSxlQUFlLFFBQVEsV0FBVztBQUN4QyxVQUFNLE9BQU8sS0FBSyxPQUFPLFFBQVEsYUFBYSxFQUFFLEtBQUssS0FBSyxLQUFLO0FBQUEsRUFDaEUsU0FBUyxPQUFPO0FBQ2YsV0FBTyxRQUFRLGNBQWMsS0FBSyxDQUFDO0FBQUEsRUFDcEM7QUFFQSxTQUFPO0FBQ1I7QUFTQSxlQUFlLG9CQUFtQztBQUNqRCxRQUFNLEVBQUUsWUFBWSxNQUFNLFdBQUE7QUFDMUIsTUFBSSxDQUFDLFFBQVM7QUFFZCxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLE1BQUksTUFBTSxXQUFXLFVBQVc7QUFDaEMsUUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLLENBQUMsU0FBUyxLQUFLLFdBQVcsU0FBUztBQUNwRSxRQUFNLFlBQVksTUFBTSxNQUFNLEtBQUssQ0FBQyxTQUFTLEtBQUssV0FBVyxTQUFTO0FBQ3RFLE1BQUksQ0FBQyxXQUFXLENBQUMsVUFBVztBQUU1QixRQUFNLE9BQU8sS0FBSyxNQUFNLFdBQVcsTUFBTSxLQUFLLFNBQVM7QUFDdkQsUUFBTSxJQUFJLFFBQVEsQ0FBQyxZQUFZLFdBQVcsU0FBUyxJQUFJLENBQUM7QUFDekQ7QUFRQSxlQUFzQixxQkFBcUIsT0FBOEI7QUFDeEUsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZO0FBRXJELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxRQUFRLGdCQUFnQixNQUFPO0FBRW5DLFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUMvRCxNQUFJLENBQUMsS0FBTTtBQU9YLFFBQU0sV0FBVyxNQUFNLGdCQUFnQixLQUFLO0FBQzVDLE1BQUksQ0FBQyxZQUFZLFNBQVMsU0FBVTtBQUVwQyxNQUFJO0FBQ0osTUFBSTtBQUNILGVBQVcsTUFBTSxTQUFTLE9BQU8sUUFBUTtBQUFBLEVBQzFDLFNBQVMsT0FBTztBQUNmLFFBQUksZUFBZSxLQUFLLEVBQUc7QUFFM0IsVUFBTUMsYUFDTCxNQUFNLGNBQWMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLFVBQVUsRUFBRSxXQUFXLEVBQUEsRUFBSSxHQUM5RDtBQUNGLFFBQUksR0FBRyxLQUFLLEtBQUssMkJBQTJCLGNBQWMsS0FBSyxDQUFDLEVBQUU7QUFDbEUsUUFBSUEsYUFBWSxjQUFjO0FBQzdCLFlBQU0sY0FBYyxLQUFLLEtBQUssVUFBVSxjQUFjLEtBQUssR0FBR0EsU0FBUTtBQUN0RSxZQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFlBQU0sUUFBQTtBQUFBLElBQ1A7QUFDQTtBQUFBLEVBQ0Q7QUFFQSxRQUFNLFlBQ0wsTUFBTSxjQUFjLENBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxVQUFVLEVBQUUsV0FBVyxFQUFBLEVBQUksR0FDOUQ7QUFFRixRQUFNLFVBQVUsU0FBUyxLQUFLLE1BQU0sS0FBSyxLQUFLLFNBQVMsUUFBUSxTQUFTLElBQUk7QUFDNUU7QUFBQSxJQUNDLEdBQUcsS0FBSyxLQUFLLFVBQVUsU0FBUyxNQUFNLEtBQUssU0FBUyxLQUFLLE1BQU0sWUFBWSxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU07QUFBQSxFQUFBO0FBRzlHLE1BQUksUUFBUSxZQUFZLFdBQVc7QUFJbEMsUUFBSSxRQUFRLFdBQVc7QUFDdEIsVUFBSSxHQUFHLEtBQUssS0FBSyw2Q0FBNkM7QUFDOUQsWUFBTSxxQkFBQTtBQUNOLFlBQU0sZUFBZSxDQUFDLGFBQWE7QUFBQSxRQUNsQyxHQUFHO0FBQUEsUUFDSCxPQUFPLFFBQVEsTUFBTTtBQUFBLFVBQUksQ0FBQyxNQUN6QixFQUFFLFFBQVEsS0FBSyxNQUNaO0FBQUEsWUFDQSxHQUFHO0FBQUEsWUFDSCxRQUFRO0FBQUEsWUFDUixRQUFRLFFBQVE7QUFBQSxZQUNoQjtBQUFBLFlBQ0EsV0FBVztBQUFBLFlBQ1gsV0FBVyxLQUFLLElBQUE7QUFBQSxVQUFJLElBRXBCO0FBQUEsUUFBQTtBQUFBLE1BQ0osRUFDQztBQUNGLFlBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckM7QUFBQSxJQUNEO0FBRUEsUUFBSSxZQUFZLGNBQWM7QUFDN0IsWUFBTTtBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0w7QUFBQSxRQUNBLEdBQUcsUUFBUSxNQUFNLGtCQUFrQixRQUFRO0FBQUEsTUFBQTtBQUU1QyxZQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFlBQU0sUUFBQTtBQUNOO0FBQUEsSUFDRDtBQUNBLFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxHQUFHLFFBQVEsTUFBTSxhQUFhLFFBQVEsT0FBTyxZQUFZO0FBQUEsTUFDekQ7QUFBQSxJQUFBO0FBRUQsVUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFNLGNBQUE7QUFDTjtBQUFBLEVBQ0Q7QUFFQSxNQUFJLFFBQVEsWUFBWSxZQUFZO0FBQ25DLFVBQU0sY0FBYyxLQUFLLEtBQUssVUFBVSxRQUFRLE1BQU07QUFDdEQsVUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFNLFFBQUE7QUFDTjtBQUFBLEVBQ0Q7QUFLQSxRQUFNLHFCQUFxQixPQUFPLFFBQVE7QUFFMUMsTUFBSSxLQUFLLFNBQVMsVUFBVTtBQUMzQixVQUFNLGlCQUFpQixNQUFNLFNBQVMsSUFBSTtBQUFBLEVBQzNDLE9BQU87QUFDTixVQUFNLFFBQVE7QUFBQSxNQUNiLE1BQU0sS0FBSztBQUFBLE1BQ1gsS0FBSyxLQUFLO0FBQUEsTUFDVixNQUFNLFlBQVksS0FBSyxNQUFNLEtBQUssR0FBRztBQUFBLE1BQ3JDLE1BQU0sU0FBUztBQUFBLElBQUEsQ0FDZjtBQUNELFFBQUksS0FBSyxTQUFTLFVBQVcsT0FBTSxhQUFhLFNBQVMsSUFBSTtBQUM3RCxVQUFNLGNBQWMsS0FBSyxLQUFLLFlBQVksUUFBUSxNQUFNO0FBQUEsRUFDekQ7QUFFQSxRQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFFBQU0sUUFBQTtBQUNQO0FBUUEsZUFBZSxpQkFBaUIsTUFBaUIsTUFBNkI7QUFDN0UsUUFBTSxNQUFNLGNBQWMsSUFBSTtBQUM5QixNQUFJLENBQUMsS0FBSztBQUNULFVBQU0sY0FBYyxLQUFLLEtBQUssVUFBVSwrQkFBK0I7QUFDdkU7QUFBQSxFQUNEO0FBRUEsTUFBSTtBQUNILFVBQU0sV0FBVyxNQUFNLE1BQU0sYUFBYSxHQUFHLENBQUM7QUFDOUMsUUFBSSxDQUFDLFNBQVMsR0FBSSxPQUFNLElBQUksTUFBTSxrQkFBa0IsU0FBUyxNQUFNLEVBQUU7QUFFckUsVUFBTSxRQUFRLElBQUksV0FBVyxNQUFNLFNBQVMsYUFBYTtBQUN6RCxRQUFJLE1BQU0sQ0FBQyxNQUFNLE1BQVEsTUFBTSxDQUFDLE1BQU0sSUFBTTtBQUMzQyxZQUFNLElBQUksTUFBTSxzQ0FBc0M7QUFBQSxJQUN2RDtBQUVBLFVBQU0sUUFBUTtBQUFBLE1BQ2IsTUFBTTtBQUFBLE1BQ04sS0FBSyxLQUFLO0FBQUEsTUFDVixNQUFNLEdBQUcsS0FBSyxHQUFHO0FBQUEsTUFDakIsUUFBUSxTQUFTLEtBQUs7QUFBQSxJQUFBLENBQ3RCO0FBQ0QsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLG1CQUFtQixLQUFLLE1BQU0sTUFBTSxTQUFTLElBQUksQ0FBQztBQUFBLElBQUE7QUFBQSxFQUVwRCxTQUFTLE9BQU87QUFDZixVQUFNO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0EsOEJBQThCLGNBQWMsS0FBSyxDQUFDO0FBQUEsSUFBQTtBQUFBLEVBRXBEO0FBQ0Q7QUFHQSxlQUFlLGFBQWEsTUFBNkI7QUFDeEQsUUFBTSxTQUFTLGNBQWMsZ0JBQWdCLElBQUksQ0FBQztBQUNsRCxNQUFJLE9BQU8sV0FBVyxFQUFHO0FBRXpCLFFBQU0sY0FBYyxDQUFDLFlBQVk7QUFDaEMsVUFBTSxhQUFhLEVBQUUsR0FBRyxRQUFRLGlCQUFBO0FBQ2hDLGVBQVcsU0FBUyxRQUFRO0FBQzNCLFVBQUksQ0FBQyxXQUFXLE1BQU0sT0FBTyxHQUFHO0FBQy9CLG1CQUFXLE1BQU0sT0FBTyxJQUFJLEVBQUUsTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLElBQUE7QUFBQSxNQUM1RDtBQUFBLElBQ0Q7QUFDQSxXQUFPLEVBQUUsR0FBRyxTQUFTLGtCQUFrQixXQUFBO0FBQUEsRUFDeEMsQ0FBQztBQUNGO0FBTUEsZUFBZSxrQkFBb0M7QUFDbEQsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsaUJBQWlCLFFBQVEsWUFBYSxRQUFPO0FBRXpELFFBQU0sY0FBYyxDQUFDLE9BQU8sRUFBRSxHQUFHLEdBQUcsZUFBZSxPQUFPO0FBRTFELFFBQU0sUUFBUSxJQUFJLElBQUksUUFBUSxtQkFBbUI7QUFDakQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixRQUFNLGdCQUFnQixJQUFJO0FBQUEsSUFDekIsTUFBTSxNQUFNLE9BQU8sQ0FBQyxNQUFNLEVBQUUsU0FBUyxRQUFRLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHO0FBQUEsRUFBQTtBQUdoRSxRQUFNLFFBQXFCLE9BQU8sUUFBUSxRQUFRLGdCQUFnQixFQUNoRSxPQUFPLENBQUMsQ0FBQyxPQUFPLE1BQU0sQ0FBQyxNQUFNLElBQUksT0FBTyxLQUFLLENBQUMsY0FBYyxJQUFJLE9BQU8sQ0FBQyxFQUN4RSxJQUFJLENBQUMsQ0FBQyxTQUFTLEtBQUssT0FBTztBQUFBLElBQzNCLE1BQU07QUFBQSxJQUNOLEtBQUs7QUFBQSxJQUNMLE9BQU8sR0FBRyxNQUFNLElBQUk7QUFBQSxJQUNwQixLQUFLLGNBQWMsTUFBTSxHQUFHO0FBQUEsSUFDNUIsUUFBUTtBQUFBLEVBQUEsRUFDUCxFQUNELEtBQUssQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLGNBQWMsRUFBRSxLQUFLLENBQUM7QUFFL0MsTUFBSSxNQUFNLFdBQVcsRUFBRyxRQUFPO0FBRS9CLFFBQU0sT0FBTyxNQUFNLFlBQVksS0FBSztBQUNwQyxRQUFNLFlBQVksSUFBSTtBQUN0QixTQUFPO0FBQ1I7QUFJQSxlQUFlLFlBQStCO0FBQzdDLFFBQU0scUJBQUE7QUFDTixnQkFBQTtBQUNBLFFBQU0sT0FBTyxPQUFPLE1BQU0sY0FBYyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUl4RCxRQUFNLFVBQVUsTUFBTSxlQUFlLENBQUMsYUFBYTtBQUFBLElBQ2xELEdBQUc7QUFBQSxJQUNILE9BQU8sUUFBUSxNQUFNO0FBQUEsTUFBSSxDQUFDLFNBQ3pCLEtBQUssV0FBVyxjQUNoQixLQUFLLFdBQVcsWUFDaEIsS0FBSyxXQUFXLFlBQ2IsT0FDQTtBQUFBLFFBQ0EsR0FBRztBQUFBLFFBQ0gsUUFBUTtBQUFBLFFBQ1IsUUFBUSxLQUFLLFVBQVU7QUFBQSxNQUFBO0FBQUEsSUFDeEI7QUFBQSxFQUNILEVBQ0M7QUFFRixRQUFNLFFBQVE7QUFDZCxRQUFNLFdBQVcsTUFBTSxNQUFNLE9BQU8sQ0FBQyxNQUFNLEVBQUUsV0FBVyxVQUFVLEVBQUU7QUFDcEUsUUFBTSxTQUFTLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsUUFBUSxFQUFFO0FBRWhFLFFBQU0sT0FBaUI7QUFBQSxJQUN0QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZO0FBQUEsSUFDWixZQUFZLEtBQUssSUFBQTtBQUFBLElBQ2pCLFNBQVMsU0FDTixZQUFZLFFBQVEsT0FBTyxNQUFNLE1BQU0sTUFBTSxLQUFLLE1BQU0sYUFDeEQsZ0JBQWdCLFFBQVE7QUFBQSxFQUFBO0FBTTVCLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFFBQU0sZUFBQTtBQUNOLFFBQU0sU0FBUyxTQUFTLE9BQU8sTUFBTSxJQUFJLEVBQUU7QUFDM0MsUUFBTSxjQUFBO0FBQ04sUUFBTSxZQUFZLElBQUk7QUFDdEIsUUFBTSxlQUFlLElBQUk7QUFDekIsU0FBTztBQUNSO0FBR0EsZUFBZSxpQkFBZ0M7QUFDOUMsUUFBTSxFQUFFLGdCQUFnQixNQUFNLFdBQUE7QUFDOUIsTUFBSSxnQkFBZ0IsT0FBVztBQUMvQixRQUFNLE9BQU8sV0FBVztBQUN4QixRQUFNLGtCQUFrQixXQUFXO0FBQ25DLFFBQU0sT0FBTyxLQUFLLE9BQU8sV0FBVyxFQUFFLE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUdwRCxRQUFNLGNBQWMsQ0FBQyxhQUFhLEVBQUUsR0FBRyxTQUFTLGFBQWEsU0FBWTtBQUMxRTtBQUdBLGVBQWUsZ0JBQStCO0FBQzdDLFFBQU0sRUFBRSxlQUFlLE1BQU0sV0FBQTtBQUM3QixNQUFJLGVBQWUsT0FBVztBQUM5QixNQUFJO0FBQ0gsVUFBTSxNQUFNLE1BQU0sT0FBTyxLQUFLLElBQUksVUFBVTtBQUM1QyxVQUFNLE9BQU8sS0FBSyxPQUFPLFlBQVksRUFBRSxRQUFRLE1BQU07QUFDckQsUUFBSSxJQUFJLGFBQWEsUUFBVztBQUMvQixZQUFNLE9BQU8sUUFBUSxPQUFPLElBQUksVUFBVSxFQUFFLFNBQVMsTUFBTTtBQUFBLElBQzVEO0FBQUEsRUFDRCxRQUFRO0FBQUEsRUFFUjtBQUNEO0FBRUEsZUFBZSxlQUFlLE9BQWdDO0FBQzdELFFBQU0sRUFBRSxlQUFlLE1BQU0sV0FBQTtBQUM3QixNQUFJLGVBQWUsT0FBVztBQUM5QixRQUFNLE9BQU8sS0FDWCxZQUFZLFlBQVksRUFBRSxNQUFNLFlBQVksTUFBQSxDQUFPLEVBQ25ELE1BQU0sTUFBTTtBQUFBLEVBQUMsQ0FBQztBQUNqQjtBQUtBLGVBQWUsUUFBUSxNQUFtQztBQUN6RCxRQUFNLFFBQVEsSUFBSTtBQUNsQixRQUFNLFdBQVcsSUFBSTtBQUN0QjtBQUdBLGVBQXNCLGNBQTZCO0FBQ2xELGFBQVcsUUFBUSxNQUFNLFNBQUEsRUFBWSxPQUFNLFdBQVcsSUFBSTtBQUMzRDtBQUVBLFNBQVMsWUFBWSxNQUE0QixLQUFxQjtBQUNyRSxVQUFRLE1BQUE7QUFBQSxJQUNQLEtBQUs7QUFDSixhQUFPLFdBQVcsR0FBRztBQUFBLElBQ3RCLEtBQUs7QUFDSixhQUFPLEdBQUcsR0FBRztBQUFBLElBQ2QsS0FBSyxhQUFhO0FBQ2pCLFlBQU0sT0FBTyxpQkFBaUIsR0FBRztBQUNqQyxhQUFPLE9BQ0osR0FBRyxLQUFLLE9BQU8sSUFBSSxLQUFLLFdBQVcsa0JBQ25DLEdBQUcsR0FBRztBQUFBLElBQ1Y7QUFBQSxJQUNBLEtBQUs7QUFDSixhQUFPO0FBQUEsSUFDUjtBQUNDLGFBQU8sR0FBRyxHQUFHO0FBQUEsRUFBQTtBQUVoQjtBQUVBLFNBQVMsU0FBUyxPQUEyQjtBQUM1QyxNQUFJLFNBQVM7QUFFYixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLE9BQVE7QUFDOUMsY0FBVSxPQUFPLGFBQWEsR0FBRyxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQU0sQ0FBQztBQUFBLEVBQy9EO0FBQ0EsU0FBTyxLQUFLLE1BQU07QUFDbkI7QUFFQSxlQUFlLFNBQVMsTUFBNkI7QUFDcEQsUUFBTSxPQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDMUQ7QUNuMEJBLElBQUksUUFBMEIsUUFBUSxRQUFBO0FBRS9CLFNBQVMsT0FBVSxNQUFvQztBQUM3RCxRQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUdsQyxVQUFRLEtBQUssTUFBTSxNQUFNLE1BQVM7QUFDbEMsU0FBTztBQUNSO0FDb0JBLE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFFBQVEsaUJBQWlCO0FBR3ZFLE1BQUksZ0JBQWdCLE9BQU8sR0FBRztBQUM3QixTQUFLLG9CQUFvQixPQUFPLE9BQU8sT0FBTyxNQUFNO0FBQUEsRUFDckQ7QUFHQSxnQkFBYyxTQUEyQyxNQUFNLEVBQzdELEtBQUssWUFBWSxFQUNqQixNQUFNLENBQUMsVUFBVSxhQUFhLEVBQUUsT0FBTyxPQUFPLEtBQUssRUFBQSxDQUFHLENBQUM7QUFDekQsU0FBTztBQUNSLENBQUM7QUFFRCxlQUFlLGNBQ2QsU0FDQSxRQUNtQjtBQUNuQixVQUFRLFFBQVEsTUFBQTtBQUFBLElBQ2YsS0FBSztBQUNKLGFBQU87QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFNBQVM7QUFBQSxRQUNULE9BQU8sTUFBTSxZQUFBO0FBQUEsTUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUzNCLEtBQUssVUFBVTtBQUNkLFlBQU0sRUFBRSxnQkFBZ0IsTUFBTSxXQUFBO0FBQzlCLFlBQU0sY0FDTCxPQUFPLEtBQUssT0FBTyxVQUFhLE9BQU8sSUFBSSxPQUFPO0FBQ25ELGFBQU87QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLE9BQU8sY0FBYyxNQUFNLFlBQUEsSUFBZ0IsY0FBQTtBQUFBLE1BQWM7QUFBQSxJQUUzRDtBQUFBLElBRUEsS0FBSyxTQUFTO0FBQ2IsWUFBTSxhQUFhLE9BQU8sS0FBSztBQUMvQixVQUFJLGVBQWUsT0FBVyxRQUFPLEVBQUUsT0FBTyxpQkFBQTtBQUM5QyxZQUFNLFVBQVcsUUFDZjtBQUNGLFlBQU0sUUFBUSxNQUFNLFNBQVMsU0FBUyxVQUFVO0FBQ2hELGFBQU8sRUFBRSxNQUFNLFNBQVMsTUFBQTtBQUFBLElBQ3pCO0FBQUEsSUFFQSxLQUFLLFVBQVU7QUFDZCxZQUFNLGFBQWEsT0FBTyxLQUFLO0FBQy9CLFVBQUksZUFBZSxPQUFXLFFBQU8sRUFBRSxPQUFPLGlCQUFBO0FBQzlDLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLFVBQVUsVUFBVSxFQUFBO0FBQUEsSUFDMUQ7QUFBQSxJQUVBLEtBQUs7QUFDSixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxZQUFVO0FBQUEsSUFFaEQsS0FBSztBQUNKLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLGVBQWE7QUFBQSxJQUVuRCxLQUFLO0FBQ0osYUFBTyxFQUFFLE1BQU0sU0FBUyxPQUFPLE1BQU0sY0FBWTtBQUFBLElBRWxELEtBQUs7QUFDSixZQUFNLFlBQUE7QUFDTixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxjQUFZO0FBQUEsSUFFbEQsS0FBSztBQUNKLFlBQU0sVUFBQTtBQUNOLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLGNBQVk7QUFBQSxJQUVsRDtBQUNDLGFBQU8sRUFBRSxPQUFPLG9CQUFvQixRQUFRLElBQUksR0FBQTtBQUFBLEVBQUc7QUFFdEQ7QUFjQSxPQUFPLFNBQVMsUUFBUSxZQUFZLENBQUMsUUFBUSxRQUFRLFdBQVc7QUFDL0QsTUFBSSxPQUFPLFVBQVUsVUFBYSxDQUFDLE9BQVE7QUFDM0MsUUFBTSxRQUFRLE9BQU87QUFDckIsT0FBSyxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sUUFBUSxNQUFNLENBQUMsRUFBRTtBQUFBLElBQzdELENBQUMsVUFBVTtBQUNWLGNBQVEsTUFBTSwyQ0FBMkMsUUFBUSxLQUFLO0FBQUEsSUFDdkU7QUFBQSxFQUFBO0FBRUYsQ0FBQztBQUVELGVBQWUsb0JBQ2QsT0FDQSxRQUNBLFFBQ2dCO0FBQ2hCLE1BQUksV0FBVyw0QkFBNEI7QUFDMUMsVUFBTSxxQkFBcUIsT0FBTyxNQUFNO0FBQ3hDO0FBQUEsRUFDRDtBQUVBLE1BQUksV0FBVywyQkFBMkI7QUFDekMsVUFBTSxXQUFXLE1BQU0sb0JBQW9CLE9BQU8sTUFBTTtBQUd4RCxRQUFJLFNBQVUsT0FBTSxxQkFBcUIsS0FBSztBQUFBLEVBQy9DO0FBQ0Q7QUFPQSxPQUFPLFNBQVMsU0FBUyxZQUFZLENBQUMsUUFBUSxXQUFXO0FBQ3hELE9BQUssYUFBYSxPQUFPLE9BQU8sTUFBTTtBQUN2QyxDQUFDO0FBRUQsZUFBZSxhQUFhLE9BQWUsUUFBK0I7QUFDekUsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsZ0JBQWdCLE1BQU87QUFFbkMsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxVQUFXO0FBRWhDLFFBQU0sWUFBWTtBQUFBLElBQ2pCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFlBQVksS0FBSyxJQUFBO0FBQUEsSUFDakIsU0FBUyxpQ0FBaUMsTUFBTTtBQUFBLEVBQUEsQ0FDaEQ7QUFDRCxRQUFNLE9BQU8sT0FBTyxhQUFhLEVBQUUsTUFBTSxJQUFBLENBQUssRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0Q7QUFJQSxPQUFPLEtBQUssVUFBVSxZQUFZLENBQUMsVUFBVTtBQUc1QyxPQUFLLE9BQU8sTUFBTSxpQkFBaUIsS0FBSyxDQUFDO0FBQzFDLENBQUM7QUFFRCxlQUFlLGlCQUFpQixPQUE4QjtBQUM3RCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsVUFBVztBQUVoQyxNQUFJLFFBQVEsZ0JBQWdCLE9BQU87QUFDbEMsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxZQUFZO0FBQUEsTUFDakIsR0FBRztBQUFBLE1BQ0gsUUFBUTtBQUFBLE1BQ1IsWUFBWTtBQUFBLE1BQ1osWUFBWSxLQUFLLElBQUE7QUFBQSxNQUNqQixTQUFTO0FBQUEsSUFBQSxDQUNUO0FBQ0QsVUFBTSxPQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sR0FBQSxDQUFJLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQUEsRUFDOUQ7QUFDRDtBQVNBLE9BQU8sUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxRQUFNLFlBQVk7QUFDakIsVUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixRQUFJLE1BQU0sV0FBVyxVQUFXO0FBQ2hDLFVBQU0sWUFBWTtBQUFBLE1BQ2pCLEdBQUc7QUFBQSxNQUNILFFBQVE7QUFBQSxNQUNSLFlBQVk7QUFBQSxNQUNaLFNBQVM7QUFBQSxJQUFBLENBQ1Q7QUFBQSxFQUNGLEdBQUE7QUFDRCxDQUFDO0FBU0QsT0FBTyxLQUFLLFVBQVUsWUFBWSxDQUFDLE9BQU8sU0FBUztBQUNsRCxNQUFJLEtBQUssV0FBVyxXQUFZO0FBQ2hDLFFBQU0sWUFBWTtBQUNqQixVQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLFFBQUksTUFBTSxXQUFXLFVBQVc7QUFFaEMsVUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixRQUFJLFFBQVEsZ0JBQWdCLE1BQU87QUFHbkMsUUFBSSxDQUFDLE1BQU0sWUFBWTtBQUN0QixZQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCO0FBQUEsSUFDRDtBQUVBLFVBQU0sT0FBTyxNQUFNLHFCQUFxQixLQUFLLENBQUM7QUFLOUMsVUFBTSxPQUFPLE1BQU0scUJBQXFCLEtBQUssQ0FBQztBQUFBLEVBQy9DLEdBQUE7QUFDRCxDQUFDO0FBT0QsT0FBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsaUJBQWlCO0FBQ25DLFNBQUssT0FBTyxNQUFNLHFCQUFxQjtBQUN2QztBQUFBLEVBQ0Q7QUFHQSxNQUFJLE1BQU0sU0FBUyxZQUFZO0FBQzlCLFNBQUssT0FBTyxNQUFNLGVBQWU7QUFBQSxFQUNsQztBQUNELENBQUM7QUFHRCxPQUFPLE9BQU8sVUFBVSxZQUFZLE1BQU07QUFDekMsT0FBSyxjQUFBO0FBQ04sQ0FBQztBQUVELE9BQU8sT0FBTyx3QkFBd0IsRUFBRSxPQUFPLFdBQVcsRUFBRSxNQUFNLE1BQU07QUFBQyxDQUFDOyJ9
