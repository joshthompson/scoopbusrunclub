const SCRAPER_PROTOCOL_VERSION = 1;
function emptyRunState() {
  return { status: "idle", items: [] };
}
const DEBUGGER_VERSION = "1.3";
const DOC_KEY = "lastDocument";
async function attach(tabId) {
  try {
    await chrome.debugger.attach({ tabId }, DEBUGGER_VERSION);
  } catch (error) {
    if (!/already attached/i.test(describeError(error))) throw error;
  }
  await chrome.debugger.sendCommand({ tabId }, "Network.enable");
}
async function detach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}
async function ensureAttached(tabId) {
  try {
    await attach(tabId);
  } catch (error) {
    throw new Error(
      `Couldn't attach the debugger to the scrape tab: ${describeError(error)}. If DevTools is open on it, close them and press Scrape again.`
    );
  }
}
async function noteDocumentResponse(tabId, params) {
  if (params.type !== "Document") return;
  const response = params.response;
  const requestId = params.requestId;
  if (!requestId || !response?.url) return;
  if (params.loaderId && params.loaderId !== requestId) return;
  await setLastDocument(tabId, {
    requestId,
    url: response.url,
    status: response.status ?? 0,
    finished: false
  });
}
async function noteLoadingFinished(tabId, params) {
  const last = await getLastDocument(tabId);
  if (!last || last.requestId !== params.requestId) return null;
  const finished = { ...last, finished: true };
  await setLastDocument(tabId, finished);
  return finished;
}
function isBodyNotReady(error) {
  return /no resource with given identifier|no data found/i.test(
    describeError(error)
  );
}
async function getLastDocument(tabId) {
  const stored = await chrome.storage.local.get(`${DOC_KEY}:${tabId}`);
  return stored[`${DOC_KEY}:${tabId}`] ?? null;
}
async function setLastDocument(tabId, value) {
  await chrome.storage.local.set({ [`${DOC_KEY}:${tabId}`]: value });
}
async function markDocumentConsumed(tabId, document) {
  await setLastDocument(tabId, { ...document, consumed: true });
}
async function clearLastDocument(tabId) {
  await chrome.storage.local.remove(`${DOC_KEY}:${tabId}`);
}
async function readBody(tabId, document) {
  const result = await chrome.debugger.sendCommand({ tabId }, "Network.getResponseBody", { requestId: document.requestId });
  return {
    url: document.url,
    status: document.status,
    body: result.base64Encoded ? decodeBase64(result.body) : result.body,
    base64Encoded: result.base64Encoded
  };
}
function decodeBase64(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}
function describeError(error) {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return JSON.stringify(error);
}
const ORIGIN_KEY = "lastAdminOrigin";
const PAGE_PATH = "/admin/process-results";
function isFromAdminPage(message) {
  return typeof message === "object" && message !== null && message.fromAdminPage === true;
}
const FALLBACK_ORIGINS = ["https://scoopbus.run", "http://localhost:3005"];
async function rememberAdminOrigin(senderUrl) {
  if (!senderUrl) return;
  try {
    const { origin } = new URL(senderUrl);
    await chrome.storage.local.set({ [ORIGIN_KEY]: origin });
  } catch {
  }
}
async function knownAdminOrigin() {
  const stored = await chrome.storage.local.get(
    ORIGIN_KEY
  );
  return stored.lastAdminOrigin ?? null;
}
async function openAdminPage() {
  const origins = [await knownAdminOrigin(), ...FALLBACK_ORIGINS].filter(
    (origin2) => !!origin2
  );
  for (const origin2 of origins) {
    const existing = await chrome.tabs.query({ url: `${origin2}${PAGE_PATH}*` }).catch(() => []);
    const tab = existing.find((candidate) => candidate.id !== void 0);
    if (tab?.id !== void 0) {
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId !== void 0) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }
      return;
    }
  }
  const origin = origins[0];
  await chrome.tabs.create({ url: `${origin}${PAGE_PATH}`, active: true });
}
const NAMIBIA_EVENTS = /* @__PURE__ */ new Set(["walvisbay", "windhoek", "swakopmund"]);
const DOMAIN_TO_COUNTRY = {
  "parkrun.com.au": "AU",
  "parkrun.co.at": "AT",
  "parkrun.ca": "CA",
  "parkrun.dk": "DK",
  "parkrun.fi": "FI",
  "parkrun.com.de": "DE",
  "parkrun.ie": "IE",
  "parkrun.it": "IT",
  "parkrun.jp": "JP",
  "parkrun.lt": "LT",
  "parkrun.my": "MY",
  "parkrun.co.nl": "NL",
  "parkrun.co.nz": "NZ",
  "parkrun.no": "NO",
  "parkrun.pl": "PL",
  "parkrun.sg": "SG",
  "parkrun.co.za": "ZA",
  "parkrun.se": "SE",
  "parkrun.org.uk": "UK",
  "parkrun.us": "US"
};
function getCountryFromUrl(url, eventId) {
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, "");
    if (hostname === "parkrun.co.za" && NAMIBIA_EVENTS.has(eventId)) {
      return "NA";
    }
    return DOMAIN_TO_COUNTRY[hostname] ?? "??";
  } catch {
    return "??";
  }
}
function extractEvents(runResults) {
  const seen = /* @__PURE__ */ new Map();
  for (const result of runResults) {
    if (!result.eventUrl || !result.event) continue;
    if (seen.has(result.event)) continue;
    const urlMatch = result.eventUrl.match(
      /^(https?:\/\/[^/]+\/[^/]+)\/results\/?\d*\/?$/
    );
    if (!urlMatch) continue;
    const baseUrl = `${urlMatch[1]}/`;
    seen.set(result.event, {
      eventId: result.event,
      name: result.eventName,
      url: baseUrl,
      country: getCountryFromUrl(result.eventUrl, result.event)
    });
  }
  return Array.from(seen.values());
}
function stripTags(html) {
  return html.replace(/<[^>]*>/g, "").trim();
}
const ENTITIES = {
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&quot;": '"',
  "&#039;": "'",
  "&apos;": "'",
  "&nbsp;": " "
};
function decodeEntities(text) {
  return text.replace(/&(?:amp|lt|gt|quot|#039|apos|nbsp);/g, (m) => ENTITIES[m] ?? m).replace(
    /&#(\d+);/g,
    (_, code) => String.fromCodePoint(Number.parseInt(code, 10))
  ).replace(/\u00a0/g, " ");
}
function parseRunnerData(html) {
  const heading = html.match(/<h2>([\s\S]*?)<\/h2>/)?.[1] ?? "";
  const idMatch = heading.match(/\(\s*A?(\d+)\s*\)/);
  const headingName = decodeEntities(stripTags(heading)).replace(/\(\s*A?\d+\s*\)/, "").trim();
  const name = idMatch && headingName ? headingName : "Unknown";
  const totalMatch = html.match(
    /<h3>\s*(\d+)\s*parkruns?\s*(?:&amp;|&)?\s*(?:(\d+)\s*junior\s*parkruns?\s*)?total/i
  );
  const totalRuns = totalMatch ? Number.parseInt(totalMatch[1], 10) : 0;
  const totalJuniorRuns = totalMatch?.[2] ? Number.parseInt(totalMatch[2], 10) : 0;
  return {
    name,
    parkrunId: idMatch ? idMatch[1] : "",
    totalRuns,
    totalJuniorRuns
  };
}
function findResultTbodies(html) {
  const candidates = [];
  const captionMatch = html.match(
    /All\s+Results\s*<\/caption>[\s\S]*?<tbody[^>]*>([\s\S]*?)<\/tbody>/i
  );
  if (captionMatch) candidates.push(captionMatch[1]);
  const tables = [
    ...html.matchAll(/<table[^>]*id="results"[^>]*>([\s\S]*?)<\/table>/gi)
  ];
  for (const table of tables.reverse()) {
    const tbody = table[1].match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i);
    candidates.push(tbody ? tbody[1] : table[1]);
  }
  return candidates;
}
function parseRunResults(html) {
  for (const tbody of findResultTbodies(html)) {
    const results = parseResultRows(tbody);
    if (results.length > 0) return results;
  }
  return [];
}
function parseResultRows(tbody) {
  const results = [];
  const rowRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  for (const rowMatch of tbody.matchAll(rowRegex)) {
    const row = rowMatch[1];
    const cellRegex = /<td[^>]*>([\s\S]*?)<\/td>/gi;
    const cells = [];
    for (const cellMatch of row.matchAll(cellRegex)) {
      cells.push(cellMatch[1]);
    }
    if (cells.length < 6) continue;
    const eventLinkMatch = cells[0].match(
      /<a\s+href="([^"]+)"[^>]*>([^<]+)<\/a>/
    );
    const eventUrl = eventLinkMatch ? eventLinkMatch[1].trim() : "";
    const eventName = eventLinkMatch ? decodeEntities(eventLinkMatch[2]).trim() : decodeEntities(stripTags(cells[0]));
    if (!/\/results\//.test(eventUrl)) continue;
    const eventIdMatch = eventUrl.match(/\/([^/]+)\/results\//);
    const event = eventIdMatch ? eventIdMatch[1] : eventName.toLowerCase().replace(/[^a-z0-9]/g, "");
    const date = parseResultDate(cells[1]);
    const eventNumber = Number.parseInt(stripTags(cells[2]), 10) || 0;
    const position = Number.parseInt(stripTags(cells[3]), 10) || 0;
    const time = stripTags(cells[4]);
    const ageGrade = stripTags(cells[5]);
    if (eventName && time) {
      results.push({
        event,
        eventName,
        eventUrl,
        eventNumber,
        position,
        time,
        ageGrade,
        date
      });
    }
  }
  return results;
}
function parseResultDate(cell) {
  const dmy = cell.match(/>(\d{2})\/(\d{2})\/(\d{4})</);
  if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`;
  const iso = cell.match(/>(\d{4}-\d{2}-\d{2})</);
  if (iso) return iso[1];
  return stripTags(cell);
}
function parseLargestClubs(html) {
  const entries = [];
  const tableMatch = html.match(
    /<table[^>]*id="results"[^>]*>[\s\S]*?<tbody[^>]*>([\s\S]*?)<\/tbody>/i
  );
  if (!tableMatch) return entries;
  const tbody = tableMatch[1];
  for (const rowMatch of tbody.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = [];
    for (const cellMatch of rowMatch[1].matchAll(
      /<td[^>]*>([\s\S]*?)<\/td>/gi
    )) {
      cells.push(cellMatch[1]);
    }
    if (cells.length < 4) continue;
    const name = decodeEntities(stripTags(cells[0]));
    if (!name) continue;
    const clubIdMatch = cells[0].match(/#featureClub=(\d+)/);
    const members = Number.parseInt(stripTags(cells[2]), 10);
    const events = Number.parseInt(stripTags(cells[3]), 10);
    if (Number.isNaN(members) || Number.isNaN(events)) continue;
    entries.push({
      clubId: clubIdMatch ? clubIdMatch[1] : void 0,
      name,
      members,
      events
    });
  }
  return entries;
}
function parseEventDate(html) {
  const match = html.match(
    /<span\s+class="format-date">(\d{4}-\d{2}-\d{2})<\/span>/
  );
  return match ? match[1] : "";
}
function parseEventPageMeta(html) {
  const title = decodeEntities(
    stripTags(html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/)?.[1] ?? "")
  );
  const eventId = html.match(/href="\/([^/"]+)\/parkrunner\//)?.[1] ?? "";
  const numberMatch = html.match(/<span>\s*#(\d+)\s*<\/span>/);
  return {
    eventId,
    title,
    eventNumber: numberMatch ? Number.parseInt(numberMatch[1], 10) : 0,
    date: parseEventDate(html)
  };
}
function coursePageUrl(eventBaseUrl) {
  return `${trimSlash(eventBaseUrl)}/course/`;
}
function courseKmzUrl(mid) {
  return `https://www.google.com/maps/d/kml?mid=${mid}`;
}
function trimSlash(url) {
  return url.replace(/\/$/, "");
}
Object.keys(DOMAIN_TO_COUNTRY).flatMap(
  (domain) => [`*://${domain}/*`, `*://*.${domain}/*`]
);
const PING_INTERVAL_MS = 2e4;
let timer = null;
function startKeepalive() {
  if (timer) return;
  timer = setInterval(() => {
    void chrome.runtime.getPlatformInfo().catch(() => void 0);
  }, PING_INTERVAL_MS);
}
function stopKeepalive() {
  if (!timer) return;
  clearInterval(timer);
  timer = null;
}
const RUN_KEY = "run";
const FILES_KEY = "files";
const SESSION_KEY = "session";
function emptySession() {
  return {
    knownCourseEventIds: [],
    discoveredEvents: {},
    coursesQueued: false,
    skipCourses: false,
    attempts: 0
  };
}
async function getRunState() {
  const stored = await chrome.storage.local.get(RUN_KEY);
  return stored.run ?? emptyRunState();
}
async function setRunState(state) {
  await chrome.storage.local.set({ [RUN_KEY]: state });
}
async function updateRunState(change) {
  const next = change(await getRunState());
  await setRunState(next);
  return next;
}
async function setItemStatus(key, status, detail, attempts) {
  return updateRunState((state) => ({
    ...state,
    items: state.items.map(
      (item) => item.key === key ? {
        ...item,
        status,
        detail,
        attempts: attempts ?? item.attempts,
        updatedAt: Date.now()
      } : item
    )
  }));
}
async function appendItems(items) {
  return updateRunState((state) => ({
    ...state,
    items: [...state.items, ...items]
  }));
}
async function getSession() {
  const stored = await chrome.storage.local.get(
    SESSION_KEY
  );
  return stored.session ?? emptySession();
}
async function setSession(session) {
  await chrome.storage.local.set({ [SESSION_KEY]: session });
}
async function updateSession(change) {
  const next = change(await getSession());
  await setSession(next);
  return next;
}
async function getFiles() {
  const stored = await chrome.storage.local.get(
    FILES_KEY
  );
  return stored.files ?? [];
}
async function putFile(file) {
  const files = await getFiles();
  const existing = files.findIndex(
    (f) => f.kind === file.kind && f.key === file.key
  );
  if (existing === -1) files.push(file);
  else files[existing] = file;
  await chrome.storage.local.set({ [FILES_KEY]: files });
}
async function resetAll() {
  await chrome.storage.local.remove([RUN_KEY, FILES_KEY, SESSION_KEY]);
}
async function notifyState(state) {
  const session = await getSession();
  const message = { type: "state", state };
  for (const tabId of [session.adminTabId, session.scrapeTabId]) {
    if (tabId === void 0) continue;
    await chrome.tabs.sendMessage(tabId, message).catch(() => {
    });
  }
}
async function notifyFile(file) {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  await chrome.tabs.sendMessage(adminTabId, { type: "file", file }).catch(() => {
  });
}
const CHALLENGE_MARKERS = [
  "/cdn-cgi/challenge-platform",
  "confirm you are human",
  "verify you are human",
  "are you a robot",
  "captcha",
  "turnstile",
  "cf_chl",
  "cf-challenge",
  "checking your browser",
  "just a moment"
];
function looksLikeChallenge(html) {
  const haystack = html.slice(0, 2e5).toLowerCase();
  return CHALLENGE_MARKERS.some((marker) => haystack.includes(marker));
}
function validate(kind, key, status, html) {
  if (status >= 400) {
    const challenge = looksLikeChallenge(html);
    return {
      outcome: "blocked",
      awaitUser: challenge,
      detail: challenge ? `parkrun replied ${status} and is asking you to prove you're human — solve it in the scrape tab and the run carries on.` : `parkrun replied ${status} — retrying.`
    };
  }
  if (looksLikeChallenge(html) && !parsesAsRealPage(kind, key, html)) {
    return {
      outcome: "blocked",
      awaitUser: true,
      detail: "parkrun is asking you to prove you're human — solve it in the scrape tab and the run carries on."
    };
  }
  switch (kind) {
    case "athlete":
      return validateAthlete(key, html);
    case "event":
      return validateEvent(key, html);
    case "clubs":
      return validateClubs(html);
    case "course":
      return validateCourse(html);
  }
}
function parsesAsRealPage(kind, key, html) {
  switch (kind) {
    case "athlete":
      return parseRunResults(html).length > 0;
    case "event":
      return parseEventPageMeta(html).eventNumber > 0;
    case "clubs":
      return parseLargestClubs(html).length > 0;
    case "course":
      return extractMapMid(html) !== null;
  }
}
function validateAthlete(parkrunId, html) {
  const runner = parseRunnerData(html);
  const results = parseRunResults(html);
  if (runner.name === "Unknown" && results.length === 0) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the page — it may be a bot check. Retrying."
    };
  }
  if (runner.parkrunId && runner.parkrunId !== parkrunId) {
    return {
      outcome: "unusable",
      detail: `Page is for athlete ${runner.parkrunId}, expected ${parkrunId}.`
    };
  }
  if (results.length === 0) {
    return { outcome: "unusable", detail: "No run results found on the page." };
  }
  return {
    outcome: "ok",
    detail: `${runner.name} · ${results.length} results`
  };
}
function validateEvent(eventId, html) {
  const meta = parseEventPageMeta(html);
  if (!meta.eventNumber || !meta.date) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the event number or date — it may be a bot check."
    };
  }
  if (meta.eventId && meta.eventId !== eventId) {
    return {
      outcome: "unusable",
      detail: `Page is for "${meta.eventId}", expected "${eventId}".`
    };
  }
  return { outcome: "ok", detail: `#${meta.eventNumber} · ${meta.date}` };
}
function validateClubs(html) {
  const clubs = parseLargestClubs(html);
  if (clubs.length === 0) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the league table — it may be a bot check."
    };
  }
  return { outcome: "ok", detail: `${clubs.length} clubs` };
}
function extractMapMid(html) {
  const match = html.match(
    /src="https:\/\/www\.google\.com\/maps\/d\/[^"]*?[?&]mid=([^&"]+)/
  );
  return match ? match[1] : null;
}
function validateCourse(html) {
  if (extractMapMid(html)) {
    return { outcome: "ok", detail: "Found the embedded map" };
  }
  const looksLikeParkrun = /parkrun/i.test(html) && html.length > 2e4;
  return looksLikeParkrun ? {
    outcome: "unusable",
    detail: "No Google map embedded on this course page."
  } : {
    outcome: "blocked",
    detail: "Couldn't read the course page — it may be a bot check."
  };
}
const MAX_ATTEMPTS = 8;
const STALL_TIMEOUT_MS = 2e4;
const WATCHDOG_ALARM = "watchdog";
const WATCHDOG_PERIOD_MINUTES = 0.5;
function log(...args) {
  console.log("[results-scraper]", ...args);
}
const RETRY_ALARM = "retry-blocked";
const RETRY_DELAY_MINUTES = 1;
async function scheduleRetry() {
  await chrome.alarms.create(RETRY_ALARM, { delayInMinutes: RETRY_DELAY_MINUTES }).catch(() => {
  });
}
async function cancelScheduledRetry() {
  await chrome.alarms.clear(RETRY_ALARM).catch(() => {
  });
}
async function retryCurrent() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return state;
  const item = state.items.find((i) => i.key === state.currentKey);
  const session = await getSession();
  if (!item || session.scrapeTabId === void 0) return state;
  await cancelScheduledRetry();
  await clearLastDocument(session.scrapeTabId);
  try {
    await ensureAttached(session.scrapeTabId);
    await chrome.tabs.update(session.scrapeTabId, { url: item.url });
  } catch (error) {
    return failRun(describeError(error));
  }
  return state;
}
async function skipCurrent() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return state;
  await cancelScheduledRetry();
  await setItemStatus(state.currentKey, "skipped", "Skipped.");
  await notifyState(await getRunState());
  return advance();
}
async function recoverMissedCapture(tabId) {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "active") return;
  const document = await getLastDocument(tabId);
  if (document && !document.consumed) return;
  const attempts = (item.attempts ?? 0) + 1;
  if (attempts > MAX_ATTEMPTS) {
    await setItemStatus(
      item.key,
      "failed",
      `Page loaded but its response was never captured, after ${attempts} attempts.`,
      attempts
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  log(
    `${item.label}: loaded but no response captured — reloading (attempt ${attempts})`
  );
  await setItemStatus(
    item.key,
    "active",
    "Page loaded but the capture was missed — reloading.",
    attempts
  );
  await notifyState(await getRunState());
  await retryCurrent();
}
async function retryIfStillBlocked() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "blocked") return;
  if (item.awaitUser) {
    log(`${item.label}: still waiting for the user; not reloading`);
    return;
  }
  const session = await getSession();
  if (session.attempts >= MAX_ATTEMPTS) {
    await setItemStatus(
      item.key,
      "failed",
      `${item.detail ?? "Blocked."} Gave up after ${session.attempts} attempts.`
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  await retryCurrent();
}
async function startRun(request, adminTabId) {
  await resetAll();
  const items = request.items.map((item) => ({
    ...item,
    status: "pending"
  }));
  if (items.length === 0) {
    const state2 = {
      status: "error",
      items: [],
      message: "Nothing to scrape."
    };
    await setRunState(state2);
    return state2;
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open a scrape tab");
  await setSession({
    adminTabId,
    scrapeTabId: tab.id,
    knownCourseEventIds: request.knownCourseEventIds,
    discoveredEvents: {},
    coursesQueued: false,
    skipCourses: request.skipCourses ?? false,
    attempts: 0
  });
  const state = {
    status: "running",
    items,
    startedAt: Date.now()
  };
  await setRunState(state);
  try {
    await ensureAttached(tab.id);
  } catch (error) {
    return failRun(describeError(error));
  }
  await setBadge("…");
  startKeepalive();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MINUTES }).catch(() => {
  });
  log(`run started: ${items.length} items, scrape tab ${tab.id}`);
  return advance();
}
async function checkForStall() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "active") return;
  const age = Date.now() - (item.updatedAt ?? 0);
  if (age < STALL_TIMEOUT_MS) return;
  const attempts = (item.attempts ?? 0) + 1;
  if (attempts > MAX_ATTEMPTS) {
    log(`giving up on ${item.label} after ${attempts} attempts`);
    await setItemStatus(
      item.key,
      "failed",
      `No response after ${attempts} attempts — page never finished loading.`,
      attempts
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  log(
    `${item.label} stalled for ${Math.round(age / 1e3)}s — reloading (attempt ${attempts})`
  );
  await setItemStatus(
    item.key,
    "active",
    `No response after ${Math.round(age / 1e3)}s — reloading (attempt ${attempts}).`,
    attempts
  );
  await notifyState(await getRunState());
  await retryCurrent();
}
async function forgetRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const session = await getSession();
  if (session.scrapeTabId !== void 0) {
    await detach(session.scrapeTabId);
    await clearLastDocument(session.scrapeTabId);
  }
  await resetAll();
  await setBadge("");
  log("run cleared");
}
async function resumeRun(adminTabId) {
  const previous = await getRunState();
  if (previous.items.length === 0) {
    return failRun("There is no run to resume.");
  }
  const items = previous.items.map(
    (item) => item.status === "captured" || item.status === "skipped" ? item : {
      ...item,
      status: "pending",
      detail: void 0,
      attempts: 0,
      awaitUser: void 0,
      updatedAt: Date.now()
    }
  );
  const outstanding = items.filter((item) => item.status === "pending").length;
  if (outstanding === 0) {
    return failRun("Every page in that run is already captured or skipped.");
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open a scrape tab");
  await updateSession((session) => ({
    ...session,
    adminTabId,
    scrapeTabId: tab.id,
    attempts: 0
  }));
  await setRunState({
    ...previous,
    status: "running",
    currentKey: void 0,
    items,
    message: void 0,
    finishedAt: void 0
  });
  try {
    await ensureAttached(tab.id);
  } catch (error) {
    return failRun(describeError(error));
  }
  await setBadge("…");
  startKeepalive();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MINUTES }).catch(() => {
  });
  log(`resuming: ${outstanding} of ${items.length} pages still needed`);
  return advance();
}
async function cancelRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const state = await getRunState();
  const cancelled = {
    ...state,
    status: "cancelled",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: "Cancelled."
  };
  await setRunState(cancelled);
  await closeScrapeTab();
  await setBadge("");
  await focusAdminTab();
  await notifyState(cancelled);
  return cancelled;
}
async function failRun(message) {
  stopKeepalive();
  const state = await getRunState();
  const failed = {
    ...state,
    status: "error",
    currentKey: void 0,
    finishedAt: Date.now(),
    message
  };
  await setRunState(failed);
  await setBadge("!");
  await notifyState(failed);
  return failed;
}
async function advance() {
  const state = await getRunState();
  if (state.status !== "running") return state;
  const next = state.items.find((item) => item.status === "pending");
  if (!next) {
    const queued = await queueNewCourses();
    if (queued) return advance();
    return finishRun();
  }
  const session = await getSession();
  if (session.scrapeTabId === void 0) {
    return failRun("The scrape tab is gone.");
  }
  await cancelScheduledRetry();
  await updateSession((s) => ({ ...s, attempts: 0 }));
  await clearLastDocument(session.scrapeTabId);
  const running = {
    ...state,
    currentKey: next.key,
    items: state.items.map(
      (item) => item.key === next.key ? {
        ...item,
        status: "active",
        detail: "Loading…",
        attempts: 0,
        updatedAt: Date.now()
      } : item
    ),
    message: void 0
  };
  await setRunState(running);
  await notifyState(running);
  log(`→ ${next.label}: ${next.url}`);
  try {
    await ensureAttached(session.scrapeTabId);
    await chrome.tabs.update(session.scrapeTabId, { url: next.url });
  } catch (error) {
    return failRun(describeError(error));
  }
  return running;
}
async function handleDocumentLoaded(tabId) {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const session = await getSession();
  if (session.scrapeTabId !== tabId) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (!item) return;
  const document = await getLastDocument(tabId);
  if (!document || document.consumed) return;
  let captured;
  try {
    captured = await readBody(tabId, document);
  } catch (error) {
    if (isBodyNotReady(error)) return;
    const attempts2 = (await updateSession((s) => ({ ...s, attempts: s.attempts + 1 }))).attempts;
    log(`${item.label}: could not read body — ${describeError(error)}`);
    if (attempts2 >= MAX_ATTEMPTS) {
      await setItemStatus(item.key, "failed", describeError(error), attempts2);
      await notifyState(await getRunState());
      await advance();
    }
    return;
  }
  const attempts = (await updateSession((s) => ({ ...s, attempts: s.attempts + 1 }))).attempts;
  const verdict = validate(item.kind, item.key, captured.status, captured.body);
  log(
    `${item.label}: HTTP ${captured.status}, ${captured.body.length} bytes → ${verdict.outcome} (${verdict.detail})`
  );
  if (verdict.outcome === "blocked") {
    if (verdict.awaitUser) {
      log(`${item.label}: waiting for the user to clear a challenge`);
      await cancelScheduledRetry();
      await updateRunState((current) => ({
        ...current,
        items: current.items.map(
          (i) => i.key === item.key ? {
            ...i,
            status: "blocked",
            detail: verdict.detail,
            attempts,
            awaitUser: true,
            updatedAt: Date.now()
          } : i
        )
      }));
      await notifyState(await getRunState());
      return;
    }
    if (attempts >= MAX_ATTEMPTS) {
      await setItemStatus(
        item.key,
        "failed",
        `${verdict.detail} Gave up after ${attempts} attempts.`
      );
      await notifyState(await getRunState());
      await advance();
      return;
    }
    await setItemStatus(
      item.key,
      "blocked",
      `${verdict.detail} (attempt ${attempts} of ${MAX_ATTEMPTS}; retrying automatically)`,
      attempts
    );
    await notifyState(await getRunState());
    await scheduleRetry();
    return;
  }
  if (verdict.outcome === "unusable") {
    await setItemStatus(item.key, "failed", verdict.detail);
    await notifyState(await getRunState());
    await advance();
    return;
  }
  await markDocumentConsumed(tabId, document);
  if (item.kind === "course") {
    await handleCoursePage(item, captured.body);
  } else {
    await deliver({
      kind: item.kind,
      key: item.key,
      name: fileNameFor(item.kind, item.key),
      text: captured.body
    });
    if (item.kind === "athlete") await recordEvents(captured.body);
    await setItemStatus(item.key, "captured", verdict.detail);
  }
  await notifyState(await getRunState());
  await advance();
}
async function handleCoursePage(item, html) {
  const mid = extractMapMid(html);
  if (!mid) {
    await setItemStatus(item.key, "failed", "No map id on the course page.");
    return;
  }
  try {
    const response = await fetch(courseKmzUrl(mid));
    if (!response.ok) throw new Error(`Google replied ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes[0] !== 80 || bytes[1] !== 75) {
      throw new Error("Downloaded file is not a KMZ archive");
    }
    await deliver({
      kind: "course",
      key: item.key,
      name: `${item.key}.kmz`,
      base64: toBase64(bytes)
    });
    await setItemStatus(
      item.key,
      "captured",
      `KMZ downloaded (${Math.round(bytes.length / 1024)} KB)`
    );
  } catch (error) {
    await setItemStatus(
      item.key,
      "failed",
      `Couldn't download the KMZ: ${describeError(error)}`
    );
  }
}
async function recordEvents(html) {
  const events = extractEvents(parseRunResults(html));
  if (events.length === 0) return;
  await updateSession((session) => {
    const discovered = { ...session.discoveredEvents };
    for (const event of events) {
      if (!discovered[event.eventId]) {
        discovered[event.eventId] = { name: event.name, url: event.url };
      }
    }
    return { ...session, discoveredEvents: discovered };
  });
}
async function queueNewCourses() {
  const session = await getSession();
  if (session.coursesQueued || session.skipCourses) return false;
  await updateSession((s) => ({ ...s, coursesQueued: true }));
  const known = new Set(session.knownCourseEventIds);
  const state = await getRunState();
  const alreadyQueued = new Set(
    state.items.filter((i) => i.kind === "course").map((i) => i.key)
  );
  const items = Object.entries(session.discoveredEvents).filter(([eventId]) => !known.has(eventId) && !alreadyQueued.has(eventId)).map(([eventId, event]) => ({
    kind: "course",
    key: eventId,
    label: `${event.name} course map`,
    url: coursePageUrl(event.url),
    status: "pending"
  })).sort((a, b) => a.label.localeCompare(b.label));
  if (items.length === 0) return false;
  const next = await appendItems(items);
  await notifyState(next);
  return true;
}
async function finishRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const settled = await updateRunState((current) => ({
    ...current,
    items: current.items.map(
      (item) => item.status === "captured" || item.status === "failed" || item.status === "skipped" ? item : {
        ...item,
        status: "failed",
        detail: item.detail ?? "Never completed."
      }
    )
  }));
  const state = settled;
  const captured = state.items.filter((i) => i.status === "captured").length;
  const failed = state.items.filter((i) => i.status === "failed").length;
  const done = {
    ...state,
    status: "done",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: failed ? `Captured ${captured} of ${state.items.length}; ${failed} failed.` : `Captured all ${captured} pages.`
  };
  await setRunState(done);
  await closeScrapeTab();
  await setBadge(failed ? String(failed) : "");
  await focusAdminTab();
  await notifyState(done);
  await notifyFinished(done);
  return done;
}
async function closeScrapeTab() {
  const { scrapeTabId } = await getSession();
  if (scrapeTabId === void 0) return;
  await detach(scrapeTabId);
  await clearLastDocument(scrapeTabId);
  await chrome.tabs.remove(scrapeTabId).catch(() => {
  });
}
async function focusAdminTab() {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  try {
    const tab = await chrome.tabs.get(adminTabId);
    await chrome.tabs.update(adminTabId, { active: true });
    if (tab.windowId !== void 0) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
  } catch {
  }
}
async function notifyFinished(state) {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  await chrome.tabs.sendMessage(adminTabId, { type: "finished", state }).catch(() => {
  });
}
async function deliver(file) {
  await putFile(file);
  await notifyFile(file);
}
async function resendFiles() {
  for (const file of await getFiles()) await notifyFile(file);
}
function fileNameFor(kind, key) {
  switch (kind) {
    case "athlete":
      return `athlete-${key}.html`;
    case "event":
      return `${key}-latest-results.html`;
    case "clubs":
      return "largest-clubs.html";
    default:
      return `${key}.kmz`;
  }
}
function toBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(binary);
}
async function setBadge(text) {
  await chrome.action.setBadgeText({ text }).catch(() => {
  });
}
let chain = Promise.resolve();
function serial(work) {
  const next = chain.then(work, work);
  chain = next.catch(() => void 0);
  return next;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (isFromAdminPage(message)) {
    void rememberAdminOrigin(sender.url ?? sender.origin);
  }
  handleMessage(message, sender).then(sendResponse).catch((error) => sendResponse({ error: String(error) }));
  return true;
});
async function handleMessage(message, sender) {
  switch (message.type) {
    case "ping":
      return {
        type: "hello",
        version: SCRAPER_PROTOCOL_VERSION,
        state: await getRunState()
      };
    case "state?":
      return { type: "state", state: await getRunState() };
    case "start": {
      const adminTabId = sender.tab?.id;
      if (adminTabId === void 0) return { error: "No calling tab" };
      const request = message.request;
      const state = await startRun(request, adminTabId);
      return { type: "state", state };
    }
    case "resume": {
      const adminTabId = sender.tab?.id;
      if (adminTabId === void 0) return { error: "No calling tab" };
      return { type: "state", state: await resumeRun(adminTabId) };
    }
    case "cancel":
      return { type: "state", state: await cancelRun() };
    case "retry":
      return { type: "state", state: await retryCurrent() };
    case "skip":
      return { type: "state", state: await skipCurrent() };
    case "resend":
      await resendFiles();
      return { type: "state", state: await getRunState() };
    case "clear":
      await forgetRun();
      return { type: "state", state: await getRunState() };
    default:
      return { error: `Unknown message: ${message.type}` };
  }
}
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (source.tabId === void 0 || !params) return;
  const tabId = source.tabId;
  void serial(() => handleDebuggerEvent(tabId, method, params)).catch(
    (error) => {
      console.error("[results-scraper] event handling failed", method, error);
    }
  );
});
async function handleDebuggerEvent(tabId, method, params) {
  if (method === "Network.responseReceived") {
    await noteDocumentResponse(tabId, params);
    return;
  }
  if (method === "Network.loadingFinished") {
    const document = await noteLoadingFinished(tabId, params);
    if (document) await handleDocumentLoaded(tabId);
  }
}
chrome.debugger.onDetach.addListener((source, reason) => {
  void handleDetach(source.tabId, reason);
});
async function handleDetach(tabId, reason) {
  const session = await getSession();
  if (session.scrapeTabId !== tabId) return;
  const state = await getRunState();
  if (state.status !== "running") return;
  await setRunState({
    ...state,
    status: "error",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: `Lost the debugger connection (${reason}).`
  });
  await chrome.action.setBadgeText({ text: "!" }).catch(() => {
  });
}
chrome.tabs.onRemoved.addListener((tabId) => {
  void serial(() => handleTabRemoved(tabId));
});
async function handleTabRemoved(tabId) {
  const session = await getSession();
  const state = await getRunState();
  if (state.status !== "running") return;
  if (session.scrapeTabId === tabId) {
    await detach(tabId);
    await setRunState({
      ...state,
      status: "cancelled",
      currentKey: void 0,
      finishedAt: Date.now(),
      message: "The scrape tab was closed."
    });
    await chrome.action.setBadgeText({ text: "" }).catch(() => {
    });
  }
}
chrome.runtime.onStartup.addListener(() => {
  void (async () => {
    const state = await getRunState();
    if (state.status !== "running") return;
    await setRunState({
      ...state,
      status: "cancelled",
      currentKey: void 0,
      message: "Interrupted when the browser closed."
    });
  })();
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== "complete") return;
  void (async () => {
    const state = await getRunState();
    if (state.status !== "running") return;
    const session = await getSession();
    if (session.scrapeTabId !== tabId) return;
    if (!state.currentKey) {
      await serial(() => advance());
      return;
    }
    await serial(() => handleDocumentLoaded(tabId));
    await serial(() => recoverMissedCapture(tabId));
  })();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "retry-blocked") {
    void serial(() => retryIfStillBlocked());
    return;
  }
  if (alarm.name === "watchdog") {
    void serial(() => checkForStall());
  }
});
chrome.action.onClicked.addListener(() => {
  void openAdminPage();
});
chrome.action.setBadgeBackgroundColor({ color: "#3f6d3a" }).catch(() => {
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vbGlicy9zaGFyZWQvc2NyYXBlci1wcm90b2NvbC50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9jYXB0dXJlLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL29wZW5BZG1pbi50cyIsIi4uLy4uL2xpYnMvc2hhcmVkL3BhcmtydW4tcGFyc2Vycy50cyIsIi4uLy4uL2xpYnMvc2hhcmVkL3BhcmtydW4tdXJscy50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9rZWVwYWxpdmUudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvc3RhdGUudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvbWVzc2FnaW5nLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL3ZhbGlkYXRlLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL3J1bi50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9zZXJpYWwudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvYmFja2dyb3VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFRoZSBjb250cmFjdCBiZXR3ZWVuIHRoZSBQcm9jZXNzIFJlc3VsdHMgYWRtaW4gcGFnZSBhbmQgdGhlIHJlc3VsdHMtc2NyYXBlclxuICogQ2hyb21lIGV4dGVuc2lvbi5cbiAqXG4gKiBUaGUgcGFnZSBpcyB0aGUgYnJhaW46IGl0IGtub3dzIHdobyB3ZSB0cmFjaywgd2hpY2ggcGFnZXMgYXJlIG5lZWRlZCBhbmQgd2hpY2hcbiAqIGNvdXJzZXMgd2UgYWxyZWFkeSBoYXZlLCBhbmQgaXQgYnVpbGRzIHRoZSB3b3JrIGxpc3QuIFRoZSBleHRlbnNpb24gaXMgdGhlXG4gKiBleGVjdXRvcjogaXQgbmF2aWdhdGVzLCBjYXB0dXJlcyByYXcgSFRNTCwgYW5kIHN0cmVhbXMgZmlsZXMgYmFjay4gTmVpdGhlclxuICogc2lkZSBoYXJkY29kZXMgdGhlIG90aGVyJ3Mga25vd2xlZGdlLCBzbyBhZGRpbmcgYSBydW5uZXIgb3IgYW4gZXZlbnQgbmVlZHMgbm9cbiAqIGV4dGVuc2lvbiBjaGFuZ2UuXG4gKlxuICogTWVzc2FnZXMgdHJhdmVsIHBhZ2Ug4oaUIGNvbnRlbnQgc2NyaXB0IGJ5IHdpbmRvdy5wb3N0TWVzc2FnZSAod3JhcHBlZCBpbiBhblxuICogZW52ZWxvcGUgc28gd2UgaWdub3JlIGV2ZXJ5dGhpbmcgZWxzZSBvbiB0aGUgY2hhbm5lbCkgYW5kIGNvbnRlbnQgc2NyaXB0IOKGlFxuICogc2VydmljZSB3b3JrZXIgYnkgY2hyb21lLnJ1bnRpbWUgbWVzc2FnaW5nLlxuICovXG5cbmV4cG9ydCBjb25zdCBTQ1JBUEVSX1BST1RPQ09MX1ZFUlNJT04gPSAxXG5cbi8qKiBFbnZlbG9wZSBtYXJrZXIsIHNvIHBvc3RNZXNzYWdlIHRyYWZmaWMgZnJvbSBhbnl0aGluZyBlbHNlIGlzIGlnbm9yZWQuICovXG5leHBvcnQgY29uc3QgU0NSQVBFUl9FTlZFTE9QRSA9ICdzY29vcGJ1cy1yZXN1bHRzLXNjcmFwZXInXG5cbi8vIOKUgOKUgCBXb3JrIGxpc3Qg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKiBXaGljaCB1cGxvYWQgZmllbGQgYSBjYXB0dXJlZCBmaWxlIGJlbG9uZ3MgdG8uICovXG5leHBvcnQgdHlwZSBDYXB0dXJlS2luZCA9ICdhdGhsZXRlJyB8ICdldmVudCcgfCAnY2x1YnMnIHwgJ2NvdXJzZSdcblxuLyoqIFRoZSBzaW5nbGUgZm9ybSBzbG90IHRoYXQgaG9sZHMgdGhlIGxhcmdlc3QtY2x1YnMgcGFnZS4gKi9cbmV4cG9ydCBjb25zdCBDTFVCU19LRVkgPSAnY2x1YnMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgV29ya0l0ZW0ge1xuXHRraW5kOiBDYXB0dXJlS2luZFxuXHQvKiogTWF0Y2hlcyB0aGUgZm9ybSBzbG90OiBwYXJrcnVuSWQsIGV2ZW50SWQsIG9yIENMVUJTX0tFWS4gKi9cblx0a2V5OiBzdHJpbmdcblx0LyoqIEh1bWFuIGxhYmVsIGZvciB0aGUgcHJvZ3Jlc3MgVUksIGUuZy4gXCJKb3NoXCIgb3IgXCJIYWdhIEZ1bGwgUmVzdWx0c1wiLiAqL1xuXHRsYWJlbDogc3RyaW5nXG5cdHVybDogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuUmVxdWVzdCB7XG5cdGl0ZW1zOiBXb3JrSXRlbVtdXG5cdC8qKlxuXHQgKiBFdmVudCBJRHMgdGhhdCBhbHJlYWR5IGhhdmUgY291cnNlIGRhdGEuIEFueXRoaW5nIGFuIGF0aGxldGUgcGFnZSB0dXJucyB1cFxuXHQgKiB0aGF0IGlzbid0IGluIGhlcmUgZ2V0cyBpdHMgY291cnNlIHBhZ2UgcXVldWVkIG1pZC1ydW4uXG5cdCAqL1xuXHRrbm93bkNvdXJzZUV2ZW50SWRzOiBzdHJpbmdbXVxuXHQvKiogU2tpcCB0aGUgbWlkLXJ1biBodW50IGZvciBuZXcgY291cnNlIG1hcHMuICovXG5cdHNraXBDb3Vyc2VzPzogYm9vbGVhblxufVxuXG4vLyDilIDilIAgUnVuIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgdHlwZSBJdGVtU3RhdHVzID1cblx0fCAncGVuZGluZydcblx0fCAnYWN0aXZlJ1xuXHQvKiogTG9hZGVkLCBidXQgYmxvY2tlZCDigJQgdXN1YWxseSBhIGNhcHRjaGEgb3IgYm90IGNoZWNrIGF3YWl0aW5nIHRoZSB1c2VyLiAqL1xuXHR8ICdibG9ja2VkJ1xuXHR8ICdjYXB0dXJlZCdcblx0fCAnZmFpbGVkJ1xuXHR8ICdza2lwcGVkJ1xuXG5leHBvcnQgaW50ZXJmYWNlIEl0ZW1TdGF0ZSBleHRlbmRzIFdvcmtJdGVtIHtcblx0c3RhdHVzOiBJdGVtU3RhdHVzXG5cdC8qKiBPbmUtbGluZSBkZXRhaWwgZm9yIHRoZSBVSTogd2hhdCB3YXMgcGFyc2VkLCBvciB3aHkgaXQgZmFpbGVkLiAqL1xuXHRkZXRhaWw/OiBzdHJpbmdcblx0LyoqIEhvdyBtYW55IHRpbWVzIHRoaXMgcGFnZSBoYXMgYmVlbiBsb2FkZWQsIGZvciBzdGFsbHMgYW5kIHJldHJpZXMuICovXG5cdGF0dGVtcHRzPzogbnVtYmVyXG5cdC8qKiBFcG9jaCBtcyB3aGVuIHRoaXMgaXRlbSBsYXN0IGNoYW5nZWQsIHNvIGEgd2F0Y2hkb2cgY2FuIHNwb3QgYSBzdGFsbC4gKi9cblx0dXBkYXRlZEF0PzogbnVtYmVyXG5cdC8qKlxuXHQgKiBUaGVyZSdzIGFuIGludGVyYWN0aXZlIGNoYWxsZW5nZSBvbiBzY3JlZW4uIE5vdGhpbmcgbWF5IHJlbG9hZCB0aGUgcGFnZSBvclxuXHQgKiB0aW1lIHRoZSBpdGVtIG91dCB3aGlsZSB0aGlzIGlzIHNldCDigJQgdGhlIHBlcnNvbiBpcyBtaWQtY2FwdGNoYS5cblx0ICovXG5cdGF3YWl0VXNlcj86IGJvb2xlYW5cbn1cblxuZXhwb3J0IHR5cGUgUnVuU3RhdHVzID0gJ2lkbGUnIHwgJ3J1bm5pbmcnIHwgJ2RvbmUnIHwgJ2NhbmNlbGxlZCcgfCAnZXJyb3InXG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuU3RhdGUge1xuXHRzdGF0dXM6IFJ1blN0YXR1c1xuXHRpdGVtczogSXRlbVN0YXRlW11cblx0LyoqIEtleSBvZiB0aGUgaXRlbSBiZWluZyB3b3JrZWQgb24sIGlmIGFueS4gKi9cblx0Y3VycmVudEtleT86IHN0cmluZ1xuXHRtZXNzYWdlPzogc3RyaW5nXG5cdHN0YXJ0ZWRBdD86IG51bWJlclxuXHRmaW5pc2hlZEF0PzogbnVtYmVyXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBlbXB0eVJ1blN0YXRlKCk6IFJ1blN0YXRlIHtcblx0cmV0dXJuIHsgc3RhdHVzOiAnaWRsZScsIGl0ZW1zOiBbXSB9XG59XG5cbi8vIOKUgOKUgCBDYXB0dXJlZCBmaWxlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGludGVyZmFjZSBDYXB0dXJlZEZpbGUge1xuXHRraW5kOiBDYXB0dXJlS2luZFxuXHRrZXk6IHN0cmluZ1xuXHQvKiogRmlsZW5hbWUgaGFuZGVkIHRvIHRoZSBmb3JtLCBzbyBpdCByZWFkcyBsaWtlIGEgbm9ybWFsIHVwbG9hZC4gKi9cblx0bmFtZTogc3RyaW5nXG5cdC8qKiBVVEYtOCB0ZXh0IGZvciBIVE1MIHBhZ2VzLiAqL1xuXHR0ZXh0Pzogc3RyaW5nXG5cdC8qKiBCYXNlNjQgZm9yIGJpbmFyeSBwYXlsb2FkcyAoS01aKS4gKi9cblx0YmFzZTY0Pzogc3RyaW5nXG59XG5cbi8vIOKUgOKUgCBNZXNzYWdlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IHR5cGUgUGFnZU1lc3NhZ2UgPVxuXHQvKiogSXMgdGhlIGV4dGVuc2lvbiBpbnN0YWxsZWQ/ICovXG5cdHwgeyB0eXBlOiAncGluZycgfVxuXHR8IHsgdHlwZTogJ3N0YXJ0JzsgcmVxdWVzdDogUnVuUmVxdWVzdCB9XG5cdHwgeyB0eXBlOiAnY2FuY2VsJyB9XG5cdC8qKlxuXHQgKiBQaWNrIGFuIGludGVycnVwdGVkIHJ1biBiYWNrIHVwLiBFdmVyeXRoaW5nIGFscmVhZHkgY2FwdHVyZWQgaXMga2VwdDsgb25seVxuXHQgKiB0aGUgcGFnZXMgdGhhdCBuZXZlciBsYW5kZWQgYXJlIHF1ZXVlZCBhZ2Fpbi5cblx0ICovXG5cdHwgeyB0eXBlOiAncmVzdW1lJyB9XG5cdC8qKiBSZWxvYWQgdGhlIHBhZ2Ugd2UncmUgc3R1Y2sgb24uICovXG5cdHwgeyB0eXBlOiAncmV0cnknIH1cblx0LyoqIEdpdmUgdXAgb24gdGhlIGN1cnJlbnQgcGFnZSBhbmQgbW92ZSB0byB0aGUgbmV4dC4gKi9cblx0fCB7IHR5cGU6ICdza2lwJyB9XG5cdC8qKiBSZS1kZWxpdmVyIGV2ZXJ5dGhpbmcgY2FwdHVyZWQgc28gZmFyIChhZnRlciBhIHBhZ2UgcmVsb2FkKS4gKi9cblx0fCB7IHR5cGU6ICdyZXNlbmQnIH1cblx0LyoqXG5cdCAqIFRocm93IHRoZSBydW4gYXdheS4gU2VudCBvbmNlIGFuIHVwbG9hZCBoYXMgbGFuZGVkLCBzbyBhIHJlbG9hZCBkb2Vzbid0XG5cdCAqIHJlc3VycmVjdCBhIHNjcmFwZSB3aG9zZSBkYXRhIGlzIGFscmVhZHkgaW4gdGhlIGRhdGFiYXNlLlxuXHQgKi9cblx0fCB7IHR5cGU6ICdjbGVhcicgfVxuXG5leHBvcnQgdHlwZSBFeHRlbnNpb25NZXNzYWdlID1cblx0fCB7IHR5cGU6ICdoZWxsbyc7IHZlcnNpb246IG51bWJlcjsgc3RhdGU6IFJ1blN0YXRlIH1cblx0fCB7IHR5cGU6ICdzdGF0ZSc7IHN0YXRlOiBSdW5TdGF0ZSB9XG5cdHwgeyB0eXBlOiAnZmlsZSc7IGZpbGU6IENhcHR1cmVkRmlsZSB9XG5cdHwgeyB0eXBlOiAnZmluaXNoZWQnOyBzdGF0ZTogUnVuU3RhdGUgfVxuXG4vKipcbiAqIEV2ZXJ5IG1lc3NhZ2UgdGhlIHBhZ2UgbWF5IHNlbmQsIGFzIGEgcnVudGltZSBsaXN0LlxuICpcbiAqIFRoZSBicmlkZ2UgY29udGVudCBzY3JpcHQgZm9yd2FyZHMgb25seSB0aGVzZSwgc28gaXQgbmVlZHMgdGhlIHNldCBhdCBydW50aW1lXG4gKiDigJQgYW5kIGl0IHVzZWQgdG8ga2VlcCBpdHMgb3duIGNvcHksIHdoaWNoIHNpbGVudGx5IGZlbGwgYmVoaW5kIGFzIG1lc3NhZ2VzXG4gKiB3ZXJlIGFkZGVkOiBgcmV0cnlgLCBgc2tpcGAsIGByZXN1bWVgIGFuZCBgY2xlYXJgIHdlcmUgYWxsIGJlaW5nIGRyb3BwZWRcbiAqIHdpdGhvdXQgYSB0cmFjZS4gVGhlIGV4aGF1c3RpdmVuZXNzIGNoZWNrIGJlbG93IG1ha2VzIGxlYXZpbmcgb25lIG91dCBhXG4gKiBjb21waWxlIGVycm9yIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBjb25zdCBQQUdFX01FU1NBR0VfVFlQRVMgPSBbXG5cdCdwaW5nJyxcblx0J3N0YXJ0Jyxcblx0J3Jlc3VtZScsXG5cdCdyZXRyeScsXG5cdCdza2lwJyxcblx0J2NhbmNlbCcsXG5cdCdyZXNlbmQnLFxuXHQnY2xlYXInLFxuXSBhcyBjb25zdFxuXG5leHBvcnQgdHlwZSBQYWdlTWVzc2FnZVR5cGUgPSAodHlwZW9mIFBBR0VfTUVTU0FHRV9UWVBFUylbbnVtYmVyXVxuXG4vKiogRmFpbHMgdG8gY29tcGlsZSBpZiBQQUdFX01FU1NBR0VfVFlQRVMgYW5kIFBhZ2VNZXNzYWdlIGRyaWZ0IGFwYXJ0LiAqL1xudHlwZSBBc3NlcnRTYW1lTWVzc2FnZVR5cGVzID0gUGFnZU1lc3NhZ2VbJ3R5cGUnXSBleHRlbmRzIFBhZ2VNZXNzYWdlVHlwZVxuXHQ/IFBhZ2VNZXNzYWdlVHlwZSBleHRlbmRzIFBhZ2VNZXNzYWdlWyd0eXBlJ11cblx0XHQ/IHRydWVcblx0XHQ6IG5ldmVyXG5cdDogbmV2ZXJcbmNvbnN0IF9tZXNzYWdlVHlwZXNNYXRjaDogQXNzZXJ0U2FtZU1lc3NhZ2VUeXBlcyA9IHRydWVcbnZvaWQgX21lc3NhZ2VUeXBlc01hdGNoXG5cbmV4cG9ydCBmdW5jdGlvbiBpc1BhZ2VNZXNzYWdlVHlwZSh2YWx1ZTogc3RyaW5nKTogdmFsdWUgaXMgUGFnZU1lc3NhZ2VUeXBlIHtcblx0cmV0dXJuIChQQUdFX01FU1NBR0VfVFlQRVMgYXMgcmVhZG9ubHkgc3RyaW5nW10pLmluY2x1ZGVzKHZhbHVlKVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNjcmFwZXJFbnZlbG9wZTxUPiB7XG5cdGNoYW5uZWw6IHR5cGVvZiBTQ1JBUEVSX0VOVkVMT1BFXG5cdGRpcmVjdGlvbjogJ3RvLWV4dGVuc2lvbicgfCAndG8tcGFnZSdcblx0cGF5bG9hZDogVFxufVxuXG5leHBvcnQgZnVuY3Rpb24gd3JhcEZvckV4dGVuc2lvbihcblx0cGF5bG9hZDogUGFnZU1lc3NhZ2UsXG4pOiBTY3JhcGVyRW52ZWxvcGU8UGFnZU1lc3NhZ2U+IHtcblx0cmV0dXJuIHsgY2hhbm5lbDogU0NSQVBFUl9FTlZFTE9QRSwgZGlyZWN0aW9uOiAndG8tZXh0ZW5zaW9uJywgcGF5bG9hZCB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3cmFwRm9yUGFnZShcblx0cGF5bG9hZDogRXh0ZW5zaW9uTWVzc2FnZSxcbik6IFNjcmFwZXJFbnZlbG9wZTxFeHRlbnNpb25NZXNzYWdlPiB7XG5cdHJldHVybiB7IGNoYW5uZWw6IFNDUkFQRVJfRU5WRUxPUEUsIGRpcmVjdGlvbjogJ3RvLXBhZ2UnLCBwYXlsb2FkIH1cbn1cblxuZnVuY3Rpb24gaXNFbnZlbG9wZShkYXRhOiB1bmtub3duKTogZGF0YSBpcyBTY3JhcGVyRW52ZWxvcGU8dW5rbm93bj4ge1xuXHRyZXR1cm4gKFxuXHRcdHR5cGVvZiBkYXRhID09PSAnb2JqZWN0JyAmJlxuXHRcdGRhdGEgIT09IG51bGwgJiZcblx0XHQoZGF0YSBhcyB7IGNoYW5uZWw/OiB1bmtub3duIH0pLmNoYW5uZWwgPT09IFNDUkFQRVJfRU5WRUxPUEVcblx0KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVhZFBhZ2VNZXNzYWdlKGRhdGE6IHVua25vd24pOiBQYWdlTWVzc2FnZSB8IG51bGwge1xuXHRpZiAoIWlzRW52ZWxvcGUoZGF0YSkgfHwgZGF0YS5kaXJlY3Rpb24gIT09ICd0by1leHRlbnNpb24nKSByZXR1cm4gbnVsbFxuXHRyZXR1cm4gZGF0YS5wYXlsb2FkIGFzIFBhZ2VNZXNzYWdlXG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZWFkRXh0ZW5zaW9uTWVzc2FnZShkYXRhOiB1bmtub3duKTogRXh0ZW5zaW9uTWVzc2FnZSB8IG51bGwge1xuXHRpZiAoIWlzRW52ZWxvcGUoZGF0YSkgfHwgZGF0YS5kaXJlY3Rpb24gIT09ICd0by1wYWdlJykgcmV0dXJuIG51bGxcblx0cmV0dXJuIGRhdGEucGF5bG9hZCBhcyBFeHRlbnNpb25NZXNzYWdlXG59XG4iLCIvKipcbiAqIFJhdyByZXNwb25zZS1ib2R5IGNhcHR1cmUgdmlhIGNocm9tZS5kZWJ1Z2dlci5cbiAqXG4gKiBUaGlzIGlzIHRoZSBvbmx5IHdheSBhbiBNVjMgZXh0ZW5zaW9uIGNhbiByZWFkIGEgbmF2aWdhdGlvbidzICpyYXcqIEhUTUwuXG4gKiBJdCBtYXR0ZXJzIGJlY2F1c2UgcGFya3J1bidzIGNvb2tpZS1jb25zZW50IHNjcmlwdCByZXdyaXRlcyB0aGUgRE9NOiBjb3Vyc2VcbiAqIHBhZ2VzIGxvc2UgdGhlIEdvb2dsZSBNYXBzIGlmcmFtZSBlbnRpcmVseSwgc28gYSBET00gc2NyYXBlIGhhcyBubyBtYXAgaWQgdG9cbiAqIGZpbmQgKHNlZSBhcHBzL2FwaS9saWIvbWFwLXNjcmFwZXIudHMpLiBBdGhsZXRlIGFuZCBldmVudCBwYWdlcyBwYXJzZSBlaXRoZXJcbiAqIHdheSwgYnV0IHRoZXJlJ3Mgbm8gcmVhc29uIHRvIGhhdmUgdHdvIGNvZGUgcGF0aHMuXG4gKlxuICogVGhpbmdzIHRoYXQgd2VyZSB0cmllZCBhbmQgZG9uJ3Qgd29yazpcbiAqICAtIGBQYWdlLmdldFJlc291cmNlQ29udGVudGAg4oaSIFwiQ29udGVudCB1bmF2YWlsYWJsZS4gUmVzb3VyY2Ugd2FzIG5vdCBjYWNoZWRcIixcbiAqICAgIGV2ZW4gd2l0aCB0aGUgTmV0d29yayBkb21haW4gZW5hYmxlZC5cbiAqICAtIE5hdmlnYXRpbmcgdG8gYSBgdmlldy1zb3VyY2U6YCBVUkwg4oaSIHRoZSB0YWIgZG9lcyBsb2FkLCBidXQgc2NyaXB0XG4gKiAgICBpbmplY3Rpb24gaW50byBpdCBoYW5ncyBmb3JldmVyLCBzbyB0aGUgdGV4dCBjYW4gbmV2ZXIgYmUgcmVhZCBiYWNrLlxuICpcbiAqIFdoYXQgZG9lcyB3b3JrIGlzIHdhdGNoaW5nIE5ldHdvcmsgZXZlbnRzIGZvciB0aGUgbWFpbi1mcmFtZSBkb2N1bWVudCBhbmRcbiAqIGFza2luZyBmb3IgaXRzIGJvZHkgb25jZSBpdCBmaW5pc2hlcyBsb2FkaW5nLiBEb2N1bWVudCByZXF1ZXN0IElEcyBhcmUgd3JpdHRlblxuICogdG8gc3RvcmFnZSBhcyB0aGV5J3JlIHNlZW4sIHNvIGEgYm9keSBjYW4gc3RpbGwgYmUgZmV0Y2hlZCBhZnRlciB0aGUgc2VydmljZVxuICogd29ya2VyIGhhcyBiZWVuIHJlc3RhcnRlZC5cbiAqL1xuXG5jb25zdCBERUJVR0dFUl9WRVJTSU9OID0gJzEuMydcblxuY29uc3QgRE9DX0tFWSA9ICdsYXN0RG9jdW1lbnQnXG5cbmV4cG9ydCBpbnRlcmZhY2UgRG9jdW1lbnRSZXNwb25zZSB7XG5cdHJlcXVlc3RJZDogc3RyaW5nXG5cdHVybDogc3RyaW5nXG5cdHN0YXR1czogbnVtYmVyXG5cdC8qKiBUcnVlIG9uY2UgbG9hZGluZ0ZpbmlzaGVkIGhhcyBiZWVuIHNlZW4sIGkuZS4gdGhlIGJvZHkgaXMgYXZhaWxhYmxlLiAqL1xuXHRmaW5pc2hlZDogYm9vbGVhblxuXHQvKipcblx0ICogU2V0IG9uY2UgdGhpcyByZXNwb25zZSBoYXMgYmVlbiBjYXB0dXJlZC4gQm90aCBjYXB0dXJlIHRyaWdnZXJzIGNhbiBmaXJlIGZvclxuXHQgKiB0aGUgc2FtZSBsb2FkOyB3aXRob3V0IHRoaXMgdGhlIHBhZ2UgaXMgY2FwdHVyZWQgdHdpY2UgYW5kIHRoZSBxdWV1ZSBpc1xuXHQgKiBhZHZhbmNlZCB0d2ljZSwgd2hpY2ggc2tpcHMgdGhlIG5leHQgaXRlbS5cblx0ICovXG5cdGNvbnN1bWVkPzogYm9vbGVhblxufVxuXG5leHBvcnQgaW50ZXJmYWNlIENhcHR1cmVkQm9keSB7XG5cdHVybDogc3RyaW5nXG5cdHN0YXR1czogbnVtYmVyXG5cdGJvZHk6IHN0cmluZ1xuXHRiYXNlNjRFbmNvZGVkOiBib29sZWFuXG59XG5cbi8vIOKUgOKUgCBBdHRhY2ggLyBkZXRhY2gg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogQXR0YWNoIGFuZCBlbmFibGUgdGhlIE5ldHdvcmsgZG9tYWluLCBpZGVtcG90ZW50bHkuXG4gKlxuICogRGVsaWJlcmF0ZWx5IGRvZXMgKm5vdCogY29uc3VsdCBgY2hyb21lLmRlYnVnZ2VyLmdldFRhcmdldHMoKWAgdG8gZGVjaWRlXG4gKiB3aGV0aGVyIHRvIGF0dGFjaDogaXRzIGBhdHRhY2hlZGAgZmxhZyBpcyB0cnVlIHdoZW4gKmFueSogQ0RQIGNsaWVudCBpc1xuICogY29ubmVjdGVkLCBpbmNsdWRpbmcgdGhlIHVzZXIncyBEZXZUb29scyBhbmQgYW55IGF1dG9tYXRpb24gZHJpdmluZyB0aGVcbiAqIGJyb3dzZXIuIFRydXN0aW5nIGl0IG1lYW5zIHNpbGVudGx5IHNraXBwaW5nIG91ciBvd24gYXR0YWNoIGFuZCB0aGVuIGNhcHR1cmluZ1xuICogbm90aGluZy4gSW5zdGVhZCB3ZSBhbHdheXMgdHJ5LCBhbmQgbGV0IHRoZSBmb2xsb3ctdXAgY29tbWFuZCB0ZWxsIHVzIHdoZXRoZXJcbiAqIHdlIHJlYWxseSBob2xkIHRoZSBzZXNzaW9uIOKAlCBpZiBzb21lb25lIGVsc2UgZG9lcywgYE5ldHdvcmsuZW5hYmxlYCBmYWlscyBhbmRcbiAqIHRoZSBlcnJvciBzdXJmYWNlcy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGF0dGFjaCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdHRyeSB7XG5cdFx0YXdhaXQgY2hyb21lLmRlYnVnZ2VyLmF0dGFjaCh7IHRhYklkIH0sIERFQlVHR0VSX1ZFUlNJT04pXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0Ly8gXCJBbHJlYWR5IGF0dGFjaGVkXCIgaXMgZXhwZWN0ZWQgd2hlbiBpdCdzIG91ciBvd24gc2Vzc2lvbiBiZWluZyByZXVzZWQuXG5cdFx0aWYgKCEvYWxyZWFkeSBhdHRhY2hlZC9pLnRlc3QoZGVzY3JpYmVFcnJvcihlcnJvcikpKSB0aHJvdyBlcnJvclxuXHR9XG5cblx0Ly8gTmV0d29yayBtdXN0IGJlIGVuYWJsZWQgZm9yIHJlc3BvbnNlIGJvZGllcyB0byBiZSByZXRhaW5lZCBhdCBhbGwuIFRoaXMgaXNcblx0Ly8gYWxzbyB0aGUgcmVhbCB0ZXN0IG9mIHdoZXRoZXIgdGhlIHNlc3Npb24gaXMgb3Vycy5cblx0YXdhaXQgY2hyb21lLmRlYnVnZ2VyLnNlbmRDb21tYW5kKHsgdGFiSWQgfSwgJ05ldHdvcmsuZW5hYmxlJylcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRldGFjaCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdHRyeSB7XG5cdFx0YXdhaXQgY2hyb21lLmRlYnVnZ2VyLmRldGFjaCh7IHRhYklkIH0pXG5cdH0gY2F0Y2gge1xuXHRcdC8vIEFscmVhZHkgZ29uZSDigJQgdGhlIHRhYiB3YXMgY2xvc2VkLCBvciBDaHJvbWUgZGV0YWNoZWQgdXMuXG5cdH1cbn1cblxuLyoqIFJlLWF0dGFjaCBpZiBhIHNlcnZpY2Ugd29ya2VyIHJlc3RhcnQgb3IgYSBkZXRhY2ggbG9zdCB0aGUgc2Vzc2lvbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnN1cmVBdHRhY2hlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdHRyeSB7XG5cdFx0YXdhaXQgYXR0YWNoKHRhYklkKVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHRocm93IG5ldyBFcnJvcihcblx0XHRcdGBDb3VsZG4ndCBhdHRhY2ggdGhlIGRlYnVnZ2VyIHRvIHRoZSBzY3JhcGUgdGFiOiAke2Rlc2NyaWJlRXJyb3IoZXJyb3IpfS4gSWYgRGV2VG9vbHMgaXMgb3BlbiBvbiBpdCwgY2xvc2UgdGhlbSBhbmQgcHJlc3MgU2NyYXBlIGFnYWluLmAsXG5cdFx0KVxuXHR9XG59XG5cbi8vIOKUgOKUgCBUcmFja2luZyB0aGUgbWFpbi1mcmFtZSBkb2N1bWVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqXG4gKiBOb3RlIGEgbWFpbi1mcmFtZSBkb2N1bWVudCByZXNwb25zZS4gUmVkaXJlY3QgY2hhaW5zIHByb2R1Y2Ugc2V2ZXJhbCwgc28gdGhlXG4gKiBtb3N0IHJlY2VudCBvbmUgd2lucy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5vdGVEb2N1bWVudFJlc3BvbnNlKFxuXHR0YWJJZDogbnVtYmVyLFxuXHRwYXJhbXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmIChwYXJhbXMudHlwZSAhPT0gJ0RvY3VtZW50JykgcmV0dXJuXG5cblx0Y29uc3QgcmVzcG9uc2UgPSBwYXJhbXMucmVzcG9uc2UgYXMgeyB1cmw/OiBzdHJpbmc7IHN0YXR1cz86IG51bWJlciB9XG5cdGNvbnN0IHJlcXVlc3RJZCA9IHBhcmFtcy5yZXF1ZXN0SWQgYXMgc3RyaW5nXG5cdGlmICghcmVxdWVzdElkIHx8ICFyZXNwb25zZT8udXJsKSByZXR1cm5cblxuXHQvLyBTdWJmcmFtZSBkb2N1bWVudHMgKGFkcywgZW1iZWRzKSBhbHNvIGFycml2ZSBoZXJlOyBvbmx5IHRoZSBtYWluIGZyYW1lJ3Ncblx0Ly8gZG9jdW1lbnQgaGFzIGEgZnJhbWVJZCBtYXRjaGluZyB0aGUgdGFiJ3Mgb3duIHRvcCBmcmFtZS4gYGZyYW1lSWRgIGlzXG5cdC8vIHByZXNlbnQgb24gcmVzcG9uc2VSZWNlaXZlZCwgYW5kIHRoZSBtYWluIGZyYW1lJ3MgaWQgZXF1YWxzIHRoZSB0YWIgdGFyZ2V0LFxuXHQvLyB3aGljaCB3ZSBjYW4ndCBjb21wYXJlIGRpcmVjdGx5IOKAlCBzbyBmaWx0ZXIgb24gdGhlIGxvYWRlcklkIGluc3RlYWQ6IHRoZVxuXHQvLyBtYWluLWZyYW1lIG5hdmlnYXRpb24gaXMgdGhlIG9uZSB3aG9zZSBsb2FkZXJJZCBtYXRjaGVzIGl0cyBvd24gcmVxdWVzdElkLlxuXHQvLyBDaHJvbWUgc2V0cyB0aGVzZSBlcXVhbCBmb3IgbWFpbi1mcmFtZSBkb2N1bWVudCByZXF1ZXN0cy5cblx0aWYgKHBhcmFtcy5sb2FkZXJJZCAmJiBwYXJhbXMubG9hZGVySWQgIT09IHJlcXVlc3RJZCkgcmV0dXJuXG5cblx0YXdhaXQgc2V0TGFzdERvY3VtZW50KHRhYklkLCB7XG5cdFx0cmVxdWVzdElkLFxuXHRcdHVybDogcmVzcG9uc2UudXJsLFxuXHRcdHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzID8/IDAsXG5cdFx0ZmluaXNoZWQ6IGZhbHNlLFxuXHR9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbm90ZUxvYWRpbmdGaW5pc2hlZChcblx0dGFiSWQ6IG51bWJlcixcblx0cGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbik6IFByb21pc2U8RG9jdW1lbnRSZXNwb25zZSB8IG51bGw+IHtcblx0Y29uc3QgbGFzdCA9IGF3YWl0IGdldExhc3REb2N1bWVudCh0YWJJZClcblx0aWYgKCFsYXN0IHx8IGxhc3QucmVxdWVzdElkICE9PSBwYXJhbXMucmVxdWVzdElkKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IGZpbmlzaGVkID0geyAuLi5sYXN0LCBmaW5pc2hlZDogdHJ1ZSB9XG5cdGF3YWl0IHNldExhc3REb2N1bWVudCh0YWJJZCwgZmluaXNoZWQpXG5cdHJldHVybiBmaW5pc2hlZFxufVxuXG4vKipcbiAqIFRydWUgd2hlbiBgTmV0d29yay5nZXRSZXNwb25zZUJvZHlgIGZhaWxlZCBvbmx5IGJlY2F1c2UgdGhlIGJvZHkgaXNuJ3QgdGhlcmVcbiAqIHlldCwgYXMgb3Bwb3NlZCB0byBiZWluZyBnb25lIGZvciBnb29kLlxuICpcbiAqIFdvcnRoIGRpc3Rpbmd1aXNoaW5nIGJlY2F1c2Ugd2UgYWxzbyB0cnkgdG8gcmVhZCBib2RpZXMgb2ZmIGB0YWJzLm9uVXBkYXRlZGAsXG4gKiB3aGljaCBjYW4gbGFuZCBtYXJnaW5hbGx5IGJlZm9yZSB0aGUgYm9keSBpcyBhdmFpbGFibGUuIEEgXCJub3QgcmVhZHlcIiBpc1xuICogc29tZXRoaW5nIHRvIHdhaXQgb3V0OyBhbnl0aGluZyBlbHNlIG1lYW5zIHRoaXMgYXR0ZW1wdCBpcyBzcGVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQm9keU5vdFJlYWR5KGVycm9yOiB1bmtub3duKTogYm9vbGVhbiB7XG5cdHJldHVybiAvbm8gcmVzb3VyY2Ugd2l0aCBnaXZlbiBpZGVudGlmaWVyfG5vIGRhdGEgZm91bmQvaS50ZXN0KFxuXHRcdGRlc2NyaWJlRXJyb3IoZXJyb3IpLFxuXHQpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRMYXN0RG9jdW1lbnQoXG5cdHRhYklkOiBudW1iZXIsXG4pOiBQcm9taXNlPERvY3VtZW50UmVzcG9uc2UgfCBudWxsPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDxcblx0XHRSZWNvcmQ8c3RyaW5nLCBEb2N1bWVudFJlc3BvbnNlPlxuXHQ+KGAke0RPQ19LRVl9OiR7dGFiSWR9YClcblx0cmV0dXJuIHN0b3JlZFtgJHtET0NfS0VZfToke3RhYklkfWBdID8/IG51bGxcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0TGFzdERvY3VtZW50KFxuXHR0YWJJZDogbnVtYmVyLFxuXHR2YWx1ZTogRG9jdW1lbnRSZXNwb25zZSxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbYCR7RE9DX0tFWX06JHt0YWJJZH1gXTogdmFsdWUgfSlcbn1cblxuLyoqIE1hcmsgdGhlIGN1cnJlbnQgZG9jdW1lbnQgYXMgY2FwdHVyZWQsIHNvIGEgc2Vjb25kIHRyaWdnZXIgaXMgYSBuby1vcC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYXJrRG9jdW1lbnRDb25zdW1lZChcblx0dGFiSWQ6IG51bWJlcixcblx0ZG9jdW1lbnQ6IERvY3VtZW50UmVzcG9uc2UsXG4pOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgc2V0TGFzdERvY3VtZW50KHRhYklkLCB7IC4uLmRvY3VtZW50LCBjb25zdW1lZDogdHJ1ZSB9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJMYXN0RG9jdW1lbnQodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoYCR7RE9DX0tFWX06JHt0YWJJZH1gKVxufVxuXG4vLyDilIDilIAgUmVhZGluZyB0aGUgYm9keSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRCb2R5KFxuXHR0YWJJZDogbnVtYmVyLFxuXHRkb2N1bWVudDogRG9jdW1lbnRSZXNwb25zZSxcbik6IFByb21pc2U8Q2FwdHVyZWRCb2R5PiB7XG5cdGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5kZWJ1Z2dlci5zZW5kQ29tbWFuZDx7XG5cdFx0Ym9keTogc3RyaW5nXG5cdFx0YmFzZTY0RW5jb2RlZDogYm9vbGVhblxuXHR9Pih7IHRhYklkIH0sICdOZXR3b3JrLmdldFJlc3BvbnNlQm9keScsIHsgcmVxdWVzdElkOiBkb2N1bWVudC5yZXF1ZXN0SWQgfSlcblxuXHRyZXR1cm4ge1xuXHRcdHVybDogZG9jdW1lbnQudXJsLFxuXHRcdHN0YXR1czogZG9jdW1lbnQuc3RhdHVzLFxuXHRcdGJvZHk6IHJlc3VsdC5iYXNlNjRFbmNvZGVkID8gZGVjb2RlQmFzZTY0KHJlc3VsdC5ib2R5KSA6IHJlc3VsdC5ib2R5LFxuXHRcdGJhc2U2NEVuY29kZWQ6IHJlc3VsdC5iYXNlNjRFbmNvZGVkLFxuXHR9XG59XG5cbi8qKiBDaHJvbWUgaGFuZHMgYmFjayBiYXNlNjQgZm9yIGFueXRoaW5nIGl0IGRvZXNuJ3QgY29uc2lkZXIgdGV4dC4gKi9cbmZ1bmN0aW9uIGRlY29kZUJhc2U2NChiYXNlNjQ6IHN0cmluZyk6IHN0cmluZyB7XG5cdGNvbnN0IGJpbmFyeSA9IGF0b2IoYmFzZTY0KVxuXHRjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGJpbmFyeS5sZW5ndGgpXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYmluYXJ5Lmxlbmd0aDsgaSsrKSBieXRlc1tpXSA9IGJpbmFyeS5jaGFyQ29kZUF0KGkpXG5cdHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoYnl0ZXMpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycm9yOiB1bmtub3duKTogc3RyaW5nIHtcblx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBlcnJvci5tZXNzYWdlXG5cdGlmICh0eXBlb2YgZXJyb3IgPT09ICdzdHJpbmcnKSByZXR1cm4gZXJyb3Jcblx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KGVycm9yKVxufVxuIiwiLyoqXG4gKiBDbGlja2luZyB0aGUgdG9vbGJhciBpY29uIG9wZW5zIHRoZSBQcm9jZXNzIFJlc3VsdHMgcGFnZS5cbiAqXG4gKiBXaGljaCBvcmlnaW4gdGhhdCBpcyBkZXBlbmRzIG9uIHdoZXJlIHRoZSBzaXRlIGlzIGJlaW5nIHNlcnZlZCDigJQgbG9jYWxob3N0IGluXG4gKiBkZXZlbG9wbWVudCwgc2Nvb3BidXMucnVuIGluIHByb2R1Y3Rpb24g4oCUIHNvIHRoZSBicmlkZ2UgcmVjb3JkcyB0aGUgb3JpZ2luIGl0XG4gKiBsYXN0IHRhbGtlZCB0byBhbmQgdGhhdCdzIHdoYXQgZ2V0cyBvcGVuZWQuIEZhbGxpbmcgYmFjayB0byBhIGd1ZXNzIG9ubHkgd2hlblxuICogd2UndmUgbmV2ZXIgc2VlbiBvbmUuXG4gKi9cblxuY29uc3QgT1JJR0lOX0tFWSA9ICdsYXN0QWRtaW5PcmlnaW4nXG5jb25zdCBQQUdFX1BBVEggPSAnL2FkbWluL3Byb2Nlc3MtcmVzdWx0cydcblxuLyoqIEZpZWxkIHRoZSBicmlkZ2UgYWRkcyB0byBzYXkgYSBtZXNzYWdlIGNhbWUgZnJvbSBhbiBhZG1pbiBwYWdlLiAqL1xuaW50ZXJmYWNlIEFkbWluUGFnZVRhZyB7XG5cdGZyb21BZG1pblBhZ2U/OiB0cnVlXG59XG5cbi8qKlxuICogVGFnIGEgbWVzc2FnZSBhcyBjb21pbmcgZnJvbSB0aGUgYWRtaW4gcGFnZS4gQ2FsbGVkIGJ5IHRoZSBicmlkZ2Ugb25seS5cbiAqXG4gKiBUaGUgb3ZlcmxheSBjb250ZW50IHNjcmlwdCBzZW5kcyBgY2FuY2VsYCwgYHJldHJ5YCBhbmQgYHNraXBgIHRvbyDigJQgdGhlIHNhbWVcbiAqIHR5cGVzIHRoZSBhZG1pbiBwYWdlIHNlbmRzIOKAlCBzbyBhIG1lc3NhZ2UncyB0eXBlIHNheXMgbm90aGluZyBhYm91dCB3aGVyZSBpdFxuICogY2FtZSBmcm9tLCBhbmQgcmVtZW1iZXJpbmcgdGhlIHNlbmRlciBvZiAqYW55KiBtZXNzYWdlIG1lYW50IHRoZSBpY29uXG4gKiBcImxlYXJuZWRcIiBwYXJrcnVuLm9yZy51ayB0aGUgbW9tZW50IGEgc2NyYXBlIHN0YXJ0ZWQuIFRoZSBicmlkZ2UgcnVucyBvbiBhZG1pblxuICogb3JpZ2lucyBhbmQgbm93aGVyZSBlbHNlLCBzbyBpdHMgb3duIHRhZyBpcyB0aGUgZGVwZW5kYWJsZSBzaWduYWwuXG4gKlxuICogU3ByZWFkIGZpcnN0IHNvIGEgcGFnZSB0aGF0IHB1dHMgYGZyb21BZG1pblBhZ2VgIGluIGl0cyBvd24gbWVzc2FnZSBjYW4ndFxuICogdW5zZXQgaXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0YWdGcm9tQWRtaW5QYWdlPFQgZXh0ZW5kcyBvYmplY3Q+KFxuXHRtZXNzYWdlOiBULFxuKTogVCAmIEFkbWluUGFnZVRhZyB7XG5cdHJldHVybiB7IC4uLm1lc3NhZ2UsIGZyb21BZG1pblBhZ2U6IHRydWUgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNGcm9tQWRtaW5QYWdlKG1lc3NhZ2U6IHVua25vd24pOiBib29sZWFuIHtcblx0cmV0dXJuIChcblx0XHR0eXBlb2YgbWVzc2FnZSA9PT0gJ29iamVjdCcgJiZcblx0XHRtZXNzYWdlICE9PSBudWxsICYmXG5cdFx0KG1lc3NhZ2UgYXMgQWRtaW5QYWdlVGFnKS5mcm9tQWRtaW5QYWdlID09PSB0cnVlXG5cdClcbn1cblxuLyoqXG4gKiBVc2VkIG9ubHkgYmVmb3JlIHRoZSBicmlkZ2UgaGFzIGV2ZXIgYW5ub3VuY2VkIGl0c2VsZiBmcm9tIGEgcmVhbCBwYWdlLlxuICpcbiAqIFByb2R1Y3Rpb24gZmlyc3Q6IG9uIGEgZnJlc2ggaW5zdGFsbCB0aGUgbGl2ZSBzaXRlIGlzIHRoZSBzYWZlIGd1ZXNzLCBhbmQgYVxuICogZGV2IHdpbGwgaGF2ZSBsb2FkZWQgbG9jYWxob3N0IHdpdGhpbiBzZWNvbmRzLCBhZnRlciB3aGljaCB0aGUgcmVtZW1iZXJlZFxuICogb3JpZ2luIHRha2VzIG92ZXIuIE9uZSBidWlsZCBzZXJ2ZXMgYm90aCDigJQgdGhlIG1hbmlmZXN0IGdyYW50cyBib3RoIG9yaWdpbnMuXG4gKi9cbmNvbnN0IEZBTExCQUNLX09SSUdJTlMgPSBbJ2h0dHBzOi8vc2Nvb3BidXMucnVuJywgJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwNSddXG5cbi8qKlxuICogUmVtZW1iZXIgd2hlcmUgdGhlIGFkbWluIHBhZ2UgbGl2ZXMsIGZyb20gYW55IG1lc3NhZ2UgdGhlIGJyaWRnZSBzZW5kcy5cbiAqXG4gKiBFdmVyeSBhZG1pbiBwYWdlIGFubm91bmNlcyBpdHNlbGYgd2l0aCBhIGBwaW5nYCBvbiBsb2FkLCBzbyBzaW1wbHkgb3BlbmluZ1xuICogbG9jYWxob3N0OjMwMDUgaXMgZW5vdWdoIHRvIHBvaW50IHRoZSBpY29uIHRoZXJlLCBhbmQgb3BlbmluZyB0aGUgbGl2ZSBzaXRlXG4gKiBwb2ludHMgaXQgYmFjay5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbWVtYmVyQWRtaW5PcmlnaW4oXG5cdHNlbmRlclVybDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmICghc2VuZGVyVXJsKSByZXR1cm5cblx0dHJ5IHtcblx0XHRjb25zdCB7IG9yaWdpbiB9ID0gbmV3IFVSTChzZW5kZXJVcmwpXG5cdFx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW09SSUdJTl9LRVldOiBvcmlnaW4gfSlcblx0fSBjYXRjaCB7XG5cdFx0Ly8gTm90IGEgVVJMIHdlIGNhbiB1c2U7IGtlZXAgd2hhdGV2ZXIgd2UgaGFkLlxuXHR9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGtub3duQWRtaW5PcmlnaW4oKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDx7IGxhc3RBZG1pbk9yaWdpbj86IHN0cmluZyB9Pihcblx0XHRPUklHSU5fS0VZLFxuXHQpXG5cdHJldHVybiBzdG9yZWQubGFzdEFkbWluT3JpZ2luID8/IG51bGxcbn1cblxuLyoqXG4gKiBGb2N1cyBhbiBleGlzdGluZyBQcm9jZXNzIFJlc3VsdHMgdGFiIGlmIHRoZXJlIGlzIG9uZSwgb3RoZXJ3aXNlIG9wZW4gaXQuXG4gKlxuICogUmV1c2luZyB0aGUgdGFiIG1hdHRlcnM6IGEgc2NyYXBlJ3MgY2FwdHVyZWQgZmlsZXMgYXJlIGhlbGQgYnkgdGhlIHBhZ2UsIHNvXG4gKiBvcGVuaW5nIGEgc2Vjb25kIGNvcHkgd291bGQgc2hvdyBhbiBlbXB0eSBvbmUgbmV4dCB0byB0aGUgb25lIGRvaW5nIHRoZSB3b3JrLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlbkFkbWluUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgb3JpZ2lucyA9IFthd2FpdCBrbm93bkFkbWluT3JpZ2luKCksIC4uLkZBTExCQUNLX09SSUdJTlNdLmZpbHRlcihcblx0XHQob3JpZ2luKTogb3JpZ2luIGlzIHN0cmluZyA9PiAhIW9yaWdpbixcblx0KVxuXG5cdGZvciAoY29uc3Qgb3JpZ2luIG9mIG9yaWdpbnMpIHtcblx0XHRjb25zdCBleGlzdGluZyA9IGF3YWl0IGNocm9tZS50YWJzXG5cdFx0XHQucXVlcnkoeyB1cmw6IGAke29yaWdpbn0ke1BBR0VfUEFUSH0qYCB9KVxuXHRcdFx0LmNhdGNoKCgpID0+IFtdKVxuXG5cdFx0Y29uc3QgdGFiID0gZXhpc3RpbmcuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgIT09IHVuZGVmaW5lZClcblx0XHRpZiAodGFiPy5pZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRhd2FpdCBjaHJvbWUudGFicy51cGRhdGUodGFiLmlkLCB7IGFjdGl2ZTogdHJ1ZSB9KVxuXHRcdFx0aWYgKHRhYi53aW5kb3dJZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdGF3YWl0IGNocm9tZS53aW5kb3dzLnVwZGF0ZSh0YWIud2luZG93SWQsIHsgZm9jdXNlZDogdHJ1ZSB9KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXHR9XG5cblx0Y29uc3Qgb3JpZ2luID0gb3JpZ2luc1swXVxuXHRhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGAke29yaWdpbn0ke1BBR0VfUEFUSH1gLCBhY3RpdmU6IHRydWUgfSlcbn1cbiIsIi8vIFNoYXJlZCBQYXJrcnVuIEhUTUwgcGFyc2luZyBsb2dpYy5cbi8vIFVzZWQgYnkgdGhlIHNjcmFwaW5nIHNjcmlwdHMgKGFwcHMvYXBpL3NjcmlwdHMpIGFuZCBieSB0aGUgUHJvY2VzcyBSZXN1bHRzXG4vLyBhZG1pbiBwYWdlLCB3aGljaCBydW5zIHRoZXNlIHNhbWUgcGFyc2VycyBvdmVyIGhhbmQtZG93bmxvYWRlZCBwYWdlcy5cbi8vXG4vLyBQYXJzZXM6IC9wYXJrcnVubmVyL3tpZH0vYWxsLyDihpIgcnVubmVyIGluZm8gKyBhbGwgcnVuIHJlc3VsdHNcbi8vXG4vLyBUd28gZmxhdm91cnMgb2YgSFRNTCByZWFjaCB0aGVzZSBwYXJzZXJzOiB0aGUgRE9NIHNlcmlhbGlzZWQgYnkgUGxheXdyaWdodFxuLy8gKGVudGl0aWVzIGxpa2UgJm5ic3A7LCBFbmdsaXNoIFVJIHdoZW4gZmV0Y2hlZCBmcm9tIHBhcmtydW4ub3JnLnVrKSBhbmQgcGFnZVxuLy8gc291cmNlIHNhdmVkIHN0cmFpZ2h0IGZyb20gYSBicm93c2VyIChsaXRlcmFsIG5vbi1icmVha2luZyBzcGFjZXMsIGFuZCBhbnlcbi8vIHBhcmtydW4gbG9jYWxlJ3MgVUkgdGV4dCkuIEV2ZXJ5dGhpbmcgaGVyZSBrZXlzIG9mZiBzdHJ1Y3R1cmUgcmF0aGVyIHRoYW5cbi8vIHdvcmRpbmcgc28gYm90aCB3b3JrLlxuXG4vLyAtLS0gVHlwZXMgLS0tXG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVubmVySW5mbyB7XG5cdG5hbWU6IHN0cmluZ1xuXHQvKiogQXRobGV0ZSBJRCByZWFkIGJhY2sgb2ZmIHRoZSBwYWdlLCBlLmcuIFwiODA3MDgyMVwiLiBFbXB0eSBpZiBub3QgZm91bmQuICovXG5cdHBhcmtydW5JZDogc3RyaW5nXG5cdHRvdGFsUnVuczogbnVtYmVyXG5cdHRvdGFsSnVuaW9yUnVuczogbnVtYmVyXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuUmVzdWx0IHtcblx0ZXZlbnQ6IHN0cmluZyAvLyBldmVudElkLCBlLmcuIFwiaGFnYVwiXG5cdGV2ZW50TmFtZTogc3RyaW5nIC8vIGRpc3BsYXkgbmFtZSwgZS5nLiBcIkhhZ2FcIiAodXNlZCBieSBleHRyYWN0RXZlbnRzLCBub3Qgc3RvcmVkIGluIHJ1blJlc3VsdHMpXG5cdGV2ZW50VXJsOiBzdHJpbmcgLy8gZS5nLiBcImh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzLzM5NC9cIlxuXHRldmVudE51bWJlcjogbnVtYmVyXG5cdHBvc2l0aW9uOiBudW1iZXJcblx0dGltZTogc3RyaW5nXG5cdGFnZUdyYWRlOiBzdHJpbmdcblx0ZGF0ZTogc3RyaW5nIC8vIFlZWVktTU0tRERcbn1cblxuZXhwb3J0IGludGVyZmFjZSBFdmVudEluZm8ge1xuXHRldmVudElkOiBzdHJpbmcgLy8gZS5nLiBcImhhZ2FcIlxuXHRuYW1lOiBzdHJpbmcgLy8gZS5nLiBcIkhhZ2FcIlxuXHR1cmw6IHN0cmluZyAvLyBlLmcuIFwiaHR0cHM6Ly93d3cucGFya3J1bi5zZS9oYWdhL3Jlc3VsdHMvXCJcblx0Y291bnRyeTogc3RyaW5nIC8vIGUuZy4gXCJTRVwiXG59XG5cbi8vIC0tLSBDb3VudHJ5IGNvZGUgbWFwcGluZyBmcm9tIHBhcmtydW4gZG9tYWluIC0tLVxuXG5jb25zdCBOQU1JQklBX0VWRU5UUyA9IG5ldyBTZXQoWyd3YWx2aXNiYXknLCAnd2luZGhvZWsnLCAnc3dha29wbXVuZCddKVxuXG5leHBvcnQgY29uc3QgRE9NQUlOX1RPX0NPVU5UUlk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG5cdCdwYXJrcnVuLmNvbS5hdSc6ICdBVScsXG5cdCdwYXJrcnVuLmNvLmF0JzogJ0FUJyxcblx0J3BhcmtydW4uY2EnOiAnQ0EnLFxuXHQncGFya3J1bi5kayc6ICdESycsXG5cdCdwYXJrcnVuLmZpJzogJ0ZJJyxcblx0J3BhcmtydW4uY29tLmRlJzogJ0RFJyxcblx0J3BhcmtydW4uaWUnOiAnSUUnLFxuXHQncGFya3J1bi5pdCc6ICdJVCcsXG5cdCdwYXJrcnVuLmpwJzogJ0pQJyxcblx0J3BhcmtydW4ubHQnOiAnTFQnLFxuXHQncGFya3J1bi5teSc6ICdNWScsXG5cdCdwYXJrcnVuLmNvLm5sJzogJ05MJyxcblx0J3BhcmtydW4uY28ubnonOiAnTlonLFxuXHQncGFya3J1bi5ubyc6ICdOTycsXG5cdCdwYXJrcnVuLnBsJzogJ1BMJyxcblx0J3BhcmtydW4uc2cnOiAnU0cnLFxuXHQncGFya3J1bi5jby56YSc6ICdaQScsXG5cdCdwYXJrcnVuLnNlJzogJ1NFJyxcblx0J3BhcmtydW4ub3JnLnVrJzogJ1VLJyxcblx0J3BhcmtydW4udXMnOiAnVVMnLFxufVxuXG5mdW5jdGlvbiBnZXRDb3VudHJ5RnJvbVVybCh1cmw6IHN0cmluZywgZXZlbnRJZDogc3RyaW5nKTogc3RyaW5nIHtcblx0dHJ5IHtcblx0XHRjb25zdCBob3N0bmFtZSA9IG5ldyBVUkwodXJsKS5ob3N0bmFtZS5yZXBsYWNlKC9ed3d3XFwuLywgJycpXG5cdFx0aWYgKGhvc3RuYW1lID09PSAncGFya3J1bi5jby56YScgJiYgTkFNSUJJQV9FVkVOVFMuaGFzKGV2ZW50SWQpKSB7XG5cdFx0XHRyZXR1cm4gJ05BJ1xuXHRcdH1cblx0XHRyZXR1cm4gRE9NQUlOX1RPX0NPVU5UUllbaG9zdG5hbWVdID8/ICc/Pydcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuICc/Pydcblx0fVxufVxuXG4vKipcbiAqIEV4dHJhY3QgdW5pcXVlIGV2ZW50IGluZm8gZnJvbSBwYXJzZWQgcnVuIHJlc3VsdHMuXG4gKiBEZXJpdmVzIGV2ZW50SWQsIG5hbWUsIGJhc2UgVVJMLCBhbmQgY291bnRyeSBmcm9tIHRoZSByZXN1bHQgVVJMcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RFdmVudHMocnVuUmVzdWx0czogUnVuUmVzdWx0W10pOiBFdmVudEluZm9bXSB7XG5cdGNvbnN0IHNlZW4gPSBuZXcgTWFwPHN0cmluZywgRXZlbnRJbmZvPigpXG5cblx0Zm9yIChjb25zdCByZXN1bHQgb2YgcnVuUmVzdWx0cykge1xuXHRcdGlmICghcmVzdWx0LmV2ZW50VXJsIHx8ICFyZXN1bHQuZXZlbnQpIGNvbnRpbnVlXG5cdFx0aWYgKHNlZW4uaGFzKHJlc3VsdC5ldmVudCkpIGNvbnRpbnVlXG5cblx0XHQvLyBVUkwgbG9va3MgbGlrZSBodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvcmVzdWx0cy8zOTQvXG5cdFx0Ly8gV2Ugd2FudCBiYXNlOiBodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvXG5cdFx0Y29uc3QgdXJsTWF0Y2ggPSByZXN1bHQuZXZlbnRVcmwubWF0Y2goXG5cdFx0XHQvXihodHRwcz86XFwvXFwvW14vXStcXC9bXi9dKylcXC9yZXN1bHRzXFwvP1xcZCpcXC8/JC8sXG5cdFx0KVxuXHRcdGlmICghdXJsTWF0Y2gpIGNvbnRpbnVlXG5cblx0XHRjb25zdCBiYXNlVXJsID0gYCR7dXJsTWF0Y2hbMV19L2BcblxuXHRcdHNlZW4uc2V0KHJlc3VsdC5ldmVudCwge1xuXHRcdFx0ZXZlbnRJZDogcmVzdWx0LmV2ZW50LFxuXHRcdFx0bmFtZTogcmVzdWx0LmV2ZW50TmFtZSxcblx0XHRcdHVybDogYmFzZVVybCxcblx0XHRcdGNvdW50cnk6IGdldENvdW50cnlGcm9tVXJsKHJlc3VsdC5ldmVudFVybCwgcmVzdWx0LmV2ZW50KSxcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIEFycmF5LmZyb20oc2Vlbi52YWx1ZXMoKSlcbn1cblxuLy8gLS0tIEhlbHBlcjogc3RyaXAgSFRNTCB0YWdzIC0tLVxuXG5mdW5jdGlvbiBzdHJpcFRhZ3MoaHRtbDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGh0bWwucmVwbGFjZSgvPFtePl0qPi9nLCAnJykudHJpbSgpXG59XG5cbi8vIC0tLSBIZWxwZXI6IGRlY29kZSB0aGUgaGFuZGZ1bCBvZiBlbnRpdGllcyBwYXJrcnVuIGVtaXRzIGluIGNsdWIgbmFtZXMgLS0tXG5cbmNvbnN0IEVOVElUSUVTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuXHQnJmFtcDsnOiAnJicsXG5cdCcmbHQ7JzogJzwnLFxuXHQnJmd0Oyc6ICc+Jyxcblx0JyZxdW90Oyc6ICdcIicsXG5cdCcmIzAzOTsnOiBcIidcIixcblx0JyZhcG9zOyc6IFwiJ1wiLFxuXHQnJm5ic3A7JzogJyAnLFxufVxuXG5mdW5jdGlvbiBkZWNvZGVFbnRpdGllcyh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gdGV4dFxuXHRcdC5yZXBsYWNlKC8mKD86YW1wfGx0fGd0fHF1b3R8IzAzOXxhcG9zfG5ic3ApOy9nLCAobSkgPT4gRU5USVRJRVNbbV0gPz8gbSlcblx0XHQucmVwbGFjZSgvJiMoXFxkKyk7L2csIChfLCBjb2RlKSA9PlxuXHRcdFx0U3RyaW5nLmZyb21Db2RlUG9pbnQoTnVtYmVyLnBhcnNlSW50KGNvZGUsIDEwKSksXG5cdFx0KVxuXHRcdC5yZXBsYWNlKC9cXHUwMGEwL2csICcgJylcbn1cblxuLy8gLS0tIFBhcnNlIHJ1bm5lciBpbmZvIGZyb20gdGhlIC9hbGwvIHBhZ2UgLS0tXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVJ1bm5lckRhdGEoaHRtbDogc3RyaW5nKTogUnVubmVySW5mbyB7XG5cdC8vIE5hbWU6IDxoMj5Kb3NoIFRIT01QU09OJm5ic3A7PHNwYW4gdGl0bGU9XCJwYXJrcnVuIElEXCI+KEE4MDcwODIxKTwvc3Bhbj48L2gyPlxuXHQvLyBUaGUgSUQgc3BhbiBoYXMgdG8gYmUgdGhlcmUgZm9yIHVzIHRvIHRydXN0IHRoZSBoZWFkaW5nIOKAlCBhIGJsb2NrZWQgb3Jcblx0Ly8gZXJyb3IgcGFnZSBjYW4gY2FycnkgYW4gdW5yZWxhdGVkIDxoMj4sIGFuZCBjYWxsZXJzIHVzZSB0aGUgXCJVbmtub3duXCJcblx0Ly8gbmFtZSBhcyB0aGVpciBzaWduYWwgdG8gcmV0cnkuXG5cdGNvbnN0IGhlYWRpbmcgPSBodG1sLm1hdGNoKC88aDI+KFtcXHNcXFNdKj8pPFxcL2gyPi8pPy5bMV0gPz8gJydcblx0Y29uc3QgaWRNYXRjaCA9IGhlYWRpbmcubWF0Y2goL1xcKFxccypBPyhcXGQrKVxccypcXCkvKVxuXHRjb25zdCBoZWFkaW5nTmFtZSA9IGRlY29kZUVudGl0aWVzKHN0cmlwVGFncyhoZWFkaW5nKSlcblx0XHQucmVwbGFjZSgvXFwoXFxzKkE/XFxkK1xccypcXCkvLCAnJylcblx0XHQudHJpbSgpXG5cdGNvbnN0IG5hbWUgPSBpZE1hdGNoICYmIGhlYWRpbmdOYW1lID8gaGVhZGluZ05hbWUgOiAnVW5rbm93bidcblxuXHQvLyBUb3RhbCBydW5zOiA8aDM+MTM2IHBhcmtydW5zIHRvdGFsPC9oMz4gIG9yICA8aDM+XFxuICAxMzYgcGFya3J1bnMgdG90YWx0XFxuPC9oMz5cblx0Ly8gV2l0aCBqdW5pb3IgcGFya3J1bnM6IDxoMz4xMCBwYXJrcnVucyAmYW1wOyA0IGp1bmlvciBwYXJrcnVucyB0b3RhbHQ8L2gzPlxuXHRjb25zdCB0b3RhbE1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvPGgzPlxccyooXFxkKylcXHMqcGFya3J1bnM/XFxzKig/OiZhbXA7fCYpP1xccyooPzooXFxkKylcXHMqanVuaW9yXFxzKnBhcmtydW5zP1xccyopP3RvdGFsL2ksXG5cdClcblx0Y29uc3QgdG90YWxSdW5zID0gdG90YWxNYXRjaCA/IE51bWJlci5wYXJzZUludCh0b3RhbE1hdGNoWzFdLCAxMCkgOiAwXG5cdGNvbnN0IHRvdGFsSnVuaW9yUnVucyA9IHRvdGFsTWF0Y2g/LlsyXVxuXHRcdD8gTnVtYmVyLnBhcnNlSW50KHRvdGFsTWF0Y2hbMl0sIDEwKVxuXHRcdDogMFxuXG5cdHJldHVybiB7XG5cdFx0bmFtZSxcblx0XHRwYXJrcnVuSWQ6IGlkTWF0Y2ggPyBpZE1hdGNoWzFdIDogJycsXG5cdFx0dG90YWxSdW5zLFxuXHRcdHRvdGFsSnVuaW9yUnVucyxcblx0fVxufVxuXG4vLyAtLS0gUGFyc2UgYWxsIHJ1biByZXN1bHRzIGZyb20gdGhlIC9hbGwvIHBhZ2UgLS0tXG5cbi8qKlxuICogVGhlIGA8dGJvZHk+YCBibG9ja3MgdGhhdCBjb3VsZCBob2xkIHRoZSBhbGwtcmVzdWx0cyB0YWJsZSwgYmVzdCBjYW5kaWRhdGVcbiAqIGZpcnN0LiBUaGUgcGFnZSBhbHNvIGNhcnJpZXMgYSBzdW1tYXJ5LXN0YXRpc3RpY3MgYW5kIGEgeWVhcmx5LWJlc3RzIHRhYmxlXG4gKiB3aXRoIHRoZSBzYW1lIGBpZD1cInJlc3VsdHNcImAsIGFuZCB0aGUgY2FwdGlvbiBuYW1pbmcgdGhlIHJpZ2h0IG9uZSBpc1xuICogbG9jYWxpc2VkIChcIkFsbCBSZXN1bHRzXCIgLyBcIuKAkyBBbGxhIHJlc3VsdGF0XCIpLCBzbyB3ZSB0cnkgdGhlIEVuZ2xpc2ggY2FwdGlvblxuICogZmlyc3QgYW5kIHRoZW4gZmFsbCBiYWNrIHRvIGV2ZXJ5IHJlc3VsdHMgdGFibGUsIGxhc3Qgb25lIGZpcnN0ICh0aGVcbiAqIGFsbC1yZXN1bHRzIHRhYmxlIGlzIHRoZSBsYXN0IG9uIHRoZSBwYWdlKS5cbiAqL1xuZnVuY3Rpb24gZmluZFJlc3VsdFRib2RpZXMoaHRtbDogc3RyaW5nKTogc3RyaW5nW10ge1xuXHRjb25zdCBjYW5kaWRhdGVzOiBzdHJpbmdbXSA9IFtdXG5cblx0Y29uc3QgY2FwdGlvbk1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvQWxsXFxzK1Jlc3VsdHNcXHMqPFxcL2NhcHRpb24+W1xcc1xcU10qPzx0Ym9keVtePl0qPihbXFxzXFxTXSo/KTxcXC90Ym9keT4vaSxcblx0KVxuXHRpZiAoY2FwdGlvbk1hdGNoKSBjYW5kaWRhdGVzLnB1c2goY2FwdGlvbk1hdGNoWzFdKVxuXG5cdGNvbnN0IHRhYmxlcyA9IFtcblx0XHQuLi5odG1sLm1hdGNoQWxsKC88dGFibGVbXj5dKmlkPVwicmVzdWx0c1wiW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RhYmxlPi9naSksXG5cdF1cblx0Zm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZXMucmV2ZXJzZSgpKSB7XG5cdFx0Y29uc3QgdGJvZHkgPSB0YWJsZVsxXS5tYXRjaCgvPHRib2R5W14+XSo+KFtcXHNcXFNdKj8pPFxcL3Rib2R5Pi9pKVxuXHRcdGNhbmRpZGF0ZXMucHVzaCh0Ym9keSA/IHRib2R5WzFdIDogdGFibGVbMV0pXG5cdH1cblxuXHRyZXR1cm4gY2FuZGlkYXRlc1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VSdW5SZXN1bHRzKGh0bWw6IHN0cmluZyk6IFJ1blJlc3VsdFtdIHtcblx0Zm9yIChjb25zdCB0Ym9keSBvZiBmaW5kUmVzdWx0VGJvZGllcyhodG1sKSkge1xuXHRcdGNvbnN0IHJlc3VsdHMgPSBwYXJzZVJlc3VsdFJvd3ModGJvZHkpXG5cdFx0aWYgKHJlc3VsdHMubGVuZ3RoID4gMCkgcmV0dXJuIHJlc3VsdHNcblx0fVxuXHRyZXR1cm4gW11cbn1cblxuZnVuY3Rpb24gcGFyc2VSZXN1bHRSb3dzKHRib2R5OiBzdHJpbmcpOiBSdW5SZXN1bHRbXSB7XG5cdGNvbnN0IHJlc3VsdHM6IFJ1blJlc3VsdFtdID0gW11cblxuXHQvLyBNYXRjaCBlYWNoIHJvdzogPHRyIGNsYXNzPVwiLi4uXCI+PHRkPi4uLjwvdGQ+PHRkPi4uLjwvdGQ+Li4uPC90cj5cblx0Y29uc3Qgcm93UmVnZXggPSAvPHRyW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RyPi9naVxuXG5cdGZvciAoY29uc3Qgcm93TWF0Y2ggb2YgdGJvZHkubWF0Y2hBbGwocm93UmVnZXgpKSB7XG5cdFx0Y29uc3Qgcm93ID0gcm93TWF0Y2hbMV1cblxuXHRcdC8vIEV4dHJhY3QgY2VsbHNcblx0XHRjb25zdCBjZWxsUmVnZXggPSAvPHRkW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RkPi9naVxuXHRcdGNvbnN0IGNlbGxzOiBzdHJpbmdbXSA9IFtdXG5cdFx0Zm9yIChjb25zdCBjZWxsTWF0Y2ggb2Ygcm93Lm1hdGNoQWxsKGNlbGxSZWdleCkpIHtcblx0XHRcdGNlbGxzLnB1c2goY2VsbE1hdGNoWzFdKVxuXHRcdH1cblxuXHRcdC8vIENvbHVtbnM6IEV2ZW50LCBSdW4gRGF0ZSwgUnVuIE51bWJlciwgUG9zLCBUaW1lLCBBZ2UgR3JhZGUsIFBCP1xuXHRcdGlmIChjZWxscy5sZW5ndGggPCA2KSBjb250aW51ZVxuXG5cdFx0Ly8gRXZlbnQgbmFtZSArIFVSTDogPGEgaHJlZj1cImh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzLzM5NC9cIj5IYWdhPC9hPlxuXHRcdGNvbnN0IGV2ZW50TGlua01hdGNoID0gY2VsbHNbMF0ubWF0Y2goXG5cdFx0XHQvPGFcXHMraHJlZj1cIihbXlwiXSspXCJbXj5dKj4oW148XSspPFxcL2E+Lyxcblx0XHQpXG5cdFx0Y29uc3QgZXZlbnRVcmwgPSBldmVudExpbmtNYXRjaCA/IGV2ZW50TGlua01hdGNoWzFdLnRyaW0oKSA6ICcnXG5cdFx0Y29uc3QgZXZlbnROYW1lID0gZXZlbnRMaW5rTWF0Y2hcblx0XHRcdD8gZGVjb2RlRW50aXRpZXMoZXZlbnRMaW5rTWF0Y2hbMl0pLnRyaW0oKVxuXHRcdFx0OiBkZWNvZGVFbnRpdGllcyhzdHJpcFRhZ3MoY2VsbHNbMF0pKVxuXG5cdFx0Ly8gT25seSB0aGUgYWxsLXJlc3VsdHMgdGFibGUgbGlua3MgZWFjaCByb3cgdG8gYW4gZXZlbnQncyByZXN1bHRzIHBhZ2Ug4oCUXG5cdFx0Ly8gdGhpcyBpcyB3aGF0IHJ1bGVzIG91dCB0aGUgc3RhdGlzdGljcyB0YWJsZXMgc2hhcmluZyBpZD1cInJlc3VsdHNcIi5cblx0XHRpZiAoIS9cXC9yZXN1bHRzXFwvLy50ZXN0KGV2ZW50VXJsKSkgY29udGludWVcblxuXHRcdC8vIERlcml2ZSBldmVudElkIGZyb20gVVJMIChlLmcuIFwiaGFnYVwiIGZyb20gXCIuLi4vaGFnYS9yZXN1bHRzLzM5NC9cIilcblx0XHRjb25zdCBldmVudElkTWF0Y2ggPSBldmVudFVybC5tYXRjaCgvXFwvKFteL10rKVxcL3Jlc3VsdHNcXC8vKVxuXHRcdGNvbnN0IGV2ZW50ID0gZXZlbnRJZE1hdGNoXG5cdFx0XHQ/IGV2ZW50SWRNYXRjaFsxXVxuXHRcdFx0OiBldmVudE5hbWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOV0vZywgJycpXG5cblx0XHQvLyBSdW4gRGF0ZTogPGEgaHJlZj1cIi4uLlwiPjxzcGFuIGNsYXNzPVwiZm9ybWF0LWRhdGVcIj4wNy8wMy8yMDI2PC9zcGFuPjwvYT5cblx0XHQvLyBTYXZlZCBwYWdlcyBtYXkgY2FycnkgYW4gYWxyZWFkeS1JU08gZGF0ZSBpbnN0ZWFkLCBkZXBlbmRpbmcgb24gd2hpY2hcblx0XHQvLyBsb2NhbGUgcmVmb3JtYXR0ZWQgdGhlIGNlbGwuXG5cdFx0Y29uc3QgZGF0ZSA9IHBhcnNlUmVzdWx0RGF0ZShjZWxsc1sxXSlcblxuXHRcdC8vIFJ1biBOdW1iZXI6IDxhIGhyZWY9XCIuLi5cIj4zOTQ8L2E+XG5cdFx0Y29uc3QgZXZlbnROdW1iZXIgPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzJdKSwgMTApIHx8IDBcblxuXHRcdC8vIFBvc2l0aW9uXG5cdFx0Y29uc3QgcG9zaXRpb24gPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzNdKSwgMTApIHx8IDBcblxuXHRcdC8vIFRpbWUgKGUuZy4gXCIxOTozOVwiIG9yIFwiMDE6MDg6MzBcIilcblx0XHRjb25zdCB0aW1lID0gc3RyaXBUYWdzKGNlbGxzWzRdKVxuXG5cdFx0Ly8gQWdlIEdyYWRlIChlLmcuIFwiNjcuMDklXCIpXG5cdFx0Y29uc3QgYWdlR3JhZGUgPSBzdHJpcFRhZ3MoY2VsbHNbNV0pXG5cblx0XHRpZiAoZXZlbnROYW1lICYmIHRpbWUpIHtcblx0XHRcdHJlc3VsdHMucHVzaCh7XG5cdFx0XHRcdGV2ZW50LFxuXHRcdFx0XHRldmVudE5hbWUsXG5cdFx0XHRcdGV2ZW50VXJsLFxuXHRcdFx0XHRldmVudE51bWJlcixcblx0XHRcdFx0cG9zaXRpb24sXG5cdFx0XHRcdHRpbWUsXG5cdFx0XHRcdGFnZUdyYWRlLFxuXHRcdFx0XHRkYXRlLFxuXHRcdFx0fSlcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gcmVzdWx0c1xufVxuXG4vKiogUmVhZCBhIHJ1biBkYXRlIGNlbGwgYXMgWVlZWS1NTS1ERC4gQWNjZXB0cyBERC9NTS9ZWVlZIGFuZCBZWVlZLU1NLURELiAqL1xuZnVuY3Rpb24gcGFyc2VSZXN1bHREYXRlKGNlbGw6IHN0cmluZyk6IHN0cmluZyB7XG5cdGNvbnN0IGRteSA9IGNlbGwubWF0Y2goLz4oXFxkezJ9KVxcLyhcXGR7Mn0pXFwvKFxcZHs0fSk8Lylcblx0aWYgKGRteSkgcmV0dXJuIGAke2RteVszXX0tJHtkbXlbMl19LSR7ZG15WzFdfWBcblxuXHRjb25zdCBpc28gPSBjZWxsLm1hdGNoKC8+KFxcZHs0fS1cXGR7Mn0tXFxkezJ9KTwvKVxuXHRpZiAoaXNvKSByZXR1cm4gaXNvWzFdXG5cblx0cmV0dXJuIHN0cmlwVGFncyhjZWxsKVxufVxuXG4vLyAtLS0gUGFyc2UgdGhlIFwibGFyZ2VzdCBjbHVic1wiIGxlYWd1ZSB0YWJsZSAtLS1cbi8vIFBhcnNlcyBodHRwczovL3d3dy5wYXJrcnVuLnNlL3Jlc3VsdHMvbGFyZ2VzdGNsdWJzL1xuLy8gQ29sdW1uczogS2x1YmIgfCAoc3BhY2VyKSB8IEFudGFsIGRlbHRhZ2FyZSB8IEFudGFsIHN0YXJ0ZXIgfCBLbHViYmVucyBoZW1zaWRhXG5cbmV4cG9ydCBpbnRlcmZhY2UgTGFyZ2VzdENsdWJFbnRyeSB7XG5cdC8qKiBwYXJrcnVuJ3MgaW50ZXJuYWwgY2x1YiBpZCwgZnJvbSB0aGUgYCNmZWF0dXJlQ2x1Yj01MDMxMGAgYW5jaG9yLiAqL1xuXHRjbHViSWQ/OiBzdHJpbmdcblx0bmFtZTogc3RyaW5nXG5cdC8qKiBcIkFudGFsIGRlbHRhZ2FyZVwiIOKAlCBkaXN0aW5jdCBjbHViIG1lbWJlcnMgd2hvIGhhdmUgcnVuLiAqL1xuXHRtZW1iZXJzOiBudW1iZXJcblx0LyoqIFwiQW50YWwgc3RhcnRlclwiIOKAlCB0b3RhbCBydW5zIHN0YXJ0ZWQgYnkgY2x1YiBtZW1iZXJzLiAqL1xuXHRldmVudHM6IG51bWJlclxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VMYXJnZXN0Q2x1YnMoaHRtbDogc3RyaW5nKTogTGFyZ2VzdENsdWJFbnRyeVtdIHtcblx0Y29uc3QgZW50cmllczogTGFyZ2VzdENsdWJFbnRyeVtdID0gW11cblxuXHRjb25zdCB0YWJsZU1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvPHRhYmxlW14+XSppZD1cInJlc3VsdHNcIltePl0qPltcXHNcXFNdKj88dGJvZHlbXj5dKj4oW1xcc1xcU10qPyk8XFwvdGJvZHk+L2ksXG5cdClcblx0aWYgKCF0YWJsZU1hdGNoKSByZXR1cm4gZW50cmllc1xuXG5cdGNvbnN0IHRib2R5ID0gdGFibGVNYXRjaFsxXVxuXG5cdGZvciAoY29uc3Qgcm93TWF0Y2ggb2YgdGJvZHkubWF0Y2hBbGwoLzx0cltePl0qPihbXFxzXFxTXSo/KTxcXC90cj4vZ2kpKSB7XG5cdFx0Y29uc3QgY2VsbHM6IHN0cmluZ1tdID0gW11cblx0XHRmb3IgKGNvbnN0IGNlbGxNYXRjaCBvZiByb3dNYXRjaFsxXS5tYXRjaEFsbChcblx0XHRcdC88dGRbXj5dKj4oW1xcc1xcU10qPyk8XFwvdGQ+L2dpLFxuXHRcdCkpIHtcblx0XHRcdGNlbGxzLnB1c2goY2VsbE1hdGNoWzFdKVxuXHRcdH1cblxuXHRcdGlmIChjZWxscy5sZW5ndGggPCA0KSBjb250aW51ZVxuXG5cdFx0Y29uc3QgbmFtZSA9IGRlY29kZUVudGl0aWVzKHN0cmlwVGFncyhjZWxsc1swXSkpXG5cdFx0aWYgKCFuYW1lKSBjb250aW51ZVxuXG5cdFx0Y29uc3QgY2x1YklkTWF0Y2ggPSBjZWxsc1swXS5tYXRjaCgvI2ZlYXR1cmVDbHViPShcXGQrKS8pXG5cdFx0Y29uc3QgbWVtYmVycyA9IE51bWJlci5wYXJzZUludChzdHJpcFRhZ3MoY2VsbHNbMl0pLCAxMClcblx0XHRjb25zdCBldmVudHMgPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzNdKSwgMTApXG5cblx0XHRpZiAoTnVtYmVyLmlzTmFOKG1lbWJlcnMpIHx8IE51bWJlci5pc05hTihldmVudHMpKSBjb250aW51ZVxuXG5cdFx0ZW50cmllcy5wdXNoKHtcblx0XHRcdGNsdWJJZDogY2x1YklkTWF0Y2ggPyBjbHViSWRNYXRjaFsxXSA6IHVuZGVmaW5lZCxcblx0XHRcdG5hbWUsXG5cdFx0XHRtZW1iZXJzLFxuXHRcdFx0ZXZlbnRzLFxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gZW50cmllc1xufVxuXG4vLyAtLS0gVHlwZXMgZm9yIGV2ZW50IHBhZ2UgcGFyc2luZyAtLS1cblxuZXhwb3J0IGludGVyZmFjZSBFdmVudEhpc3RvcnlFbnRyeSB7XG5cdGV2ZW50TnVtYmVyOiBudW1iZXJcblx0ZGF0ZTogc3RyaW5nIC8vIFlZWVktTU0tRERcbn1cblxuZXhwb3J0IGludGVyZmFjZSBWb2x1bnRlZXJFbnRyeSB7XG5cdHBhcmtydW5JZDogc3RyaW5nXG5cdHJvbGVzOiBzdHJpbmdbXVxufVxuXG4vLyAtLS0gUGFyc2UgZXZlbnQgaGlzdG9yeSBwYWdlIC0tLVxuLy8gUGFyc2VzIGh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzL2V2ZW50aGlzdG9yeS9cbi8vIEVhY2ggcm93OiA8dHIgY2xhc3M9XCJSZXN1bHRzLXRhYmxlLXJvd1wiIGRhdGEtcGFya3J1bj1cIjM5NlwiIGRhdGEtZGF0ZT1cIjIwMjYtMDMtMjFcIiAuLi4+XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUV2ZW50SGlzdG9yeShodG1sOiBzdHJpbmcpOiBFdmVudEhpc3RvcnlFbnRyeVtdIHtcblx0Y29uc3QgZW50cmllczogRXZlbnRIaXN0b3J5RW50cnlbXSA9IFtdXG5cblx0Y29uc3Qgcm93UmVnZXggPVxuXHRcdC88dHJcXHMrY2xhc3M9XCJSZXN1bHRzLXRhYmxlLXJvd1wiW14+XSpkYXRhLXBhcmtydW49XCIoXFxkKylcIltePl0qZGF0YS1kYXRlPVwiKFxcZHs0fS1cXGR7Mn0tXFxkezJ9KVwiW14+XSo+L2dpXG5cblx0Zm9yIChjb25zdCBtYXRjaCBvZiBodG1sLm1hdGNoQWxsKHJvd1JlZ2V4KSkge1xuXHRcdGVudHJpZXMucHVzaCh7XG5cdFx0XHRldmVudE51bWJlcjogTnVtYmVyLnBhcnNlSW50KG1hdGNoWzFdLCAxMCksXG5cdFx0XHRkYXRlOiBtYXRjaFsyXSxcblx0XHR9KVxuXHR9XG5cblx0Ly8gU29ydCBkZXNjZW5kaW5nIGJ5IGV2ZW50IG51bWJlciAobW9zdCByZWNlbnQgZmlyc3QpXG5cdGVudHJpZXMuc29ydCgoYSwgYikgPT4gYi5ldmVudE51bWJlciAtIGEuZXZlbnROdW1iZXIpXG5cdHJldHVybiBlbnRyaWVzXG59XG5cbi8vIC0tLSBQYXJzZSBldmVudCBkYXRlIGZyb20gYSBzaW5nbGUgZXZlbnQgcmVzdWx0cyBwYWdlIC0tLVxuLy8gV2l0aCBTd2VkaXNoIGxvY2FsZSAoc3YtU0UpIHRoZSBmb3JtYXQtZGF0ZSBzcGFuIGNvbnRhaW5zIFlZWVktTU0tREQuXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUV2ZW50RGF0ZShodG1sOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRjb25zdCBtYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0LzxzcGFuXFxzK2NsYXNzPVwiZm9ybWF0LWRhdGVcIj4oXFxkezR9LVxcZHsyfS1cXGR7Mn0pPFxcL3NwYW4+Lyxcblx0KVxuXHRyZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6ICcnXG59XG5cbi8vIC0tLSBQYXJzZSB0aGUgaWRlbnRpdHkgb2YgYSBzaW5nbGUgZXZlbnQgcmVzdWx0cyBwYWdlIC0tLVxuLy8gVGhlIHNjcmFwaW5nIHNjcmlwdHMgYWxyZWFkeSBrbm93IHdoaWNoIGV2ZW50IHBhZ2UgdGhleSBhc2tlZCBmb3I7IHRoZSBtYW51YWxcbi8vIHVwbG9hZCBwYWdlIGhhcyB0byByZWFkIGl0IGJhY2sgb2ZmIHRoZSBmaWxlIGl0IHdhcyBoYW5kZWQuXG4vL1xuLy8gICA8aDE+SGFnYSBwYXJrcnVuPC9oMT5cbi8vICAgPGgzPjxzcGFuIGNsYXNzPVwiZm9ybWF0LWRhdGVcIj4yMDI2LTA4LTAxPC9zcGFuPiDigKYgPHNwYW4+IzQxNTwvc3Bhbj48L2gzPlxuXG5leHBvcnQgaW50ZXJmYWNlIEV2ZW50UGFnZU1ldGEge1xuXHQvKiogZXZlbnRJZCBmcm9tIHRoZSBpbi1wYWdlIGF0aGxldGUgbGlua3MsIGUuZy4gXCJoYWdhXCIuIEVtcHR5IGlmIG5vdCBmb3VuZC4gKi9cblx0ZXZlbnRJZDogc3RyaW5nXG5cdC8qKiBFdmVudCB0aXRsZSwgZS5nLiBcIkhhZ2EgcGFya3J1blwiLiBFbXB0eSBpZiBub3QgZm91bmQuICovXG5cdHRpdGxlOiBzdHJpbmdcblx0LyoqIEV2ZW50IG51bWJlciwgZS5nLiA0MTUuIFplcm8gaWYgbm90IGZvdW5kLiAqL1xuXHRldmVudE51bWJlcjogbnVtYmVyXG5cdC8qKiBZWVlZLU1NLURELCBvciBlbXB0eSBpZiBub3QgZm91bmQuICovXG5cdGRhdGU6IHN0cmluZ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VFdmVudFBhZ2VNZXRhKGh0bWw6IHN0cmluZyk6IEV2ZW50UGFnZU1ldGEge1xuXHRjb25zdCB0aXRsZSA9IGRlY29kZUVudGl0aWVzKFxuXHRcdHN0cmlwVGFncyhodG1sLm1hdGNoKC88aDFbXj5dKj4oW1xcc1xcU10qPyk8XFwvaDE+Lyk/LlsxXSA/PyAnJyksXG5cdClcblxuXHQvLyBBdGhsZXRlIGxpbmtzIG9uIHRoZSBwYWdlIGFyZSBldmVudC1yZWxhdGl2ZTogL2hhZ2EvcGFya3J1bm5lci82MTQ4Nzk0XG5cdGNvbnN0IGV2ZW50SWQgPSBodG1sLm1hdGNoKC9ocmVmPVwiXFwvKFteL1wiXSspXFwvcGFya3J1bm5lclxcLy8pPy5bMV0gPz8gJydcblxuXHRjb25zdCBudW1iZXJNYXRjaCA9IGh0bWwubWF0Y2goLzxzcGFuPlxccyojKFxcZCspXFxzKjxcXC9zcGFuPi8pXG5cblx0cmV0dXJuIHtcblx0XHRldmVudElkLFxuXHRcdHRpdGxlLFxuXHRcdGV2ZW50TnVtYmVyOiBudW1iZXJNYXRjaCA/IE51bWJlci5wYXJzZUludChudW1iZXJNYXRjaFsxXSwgMTApIDogMCxcblx0XHRkYXRlOiBwYXJzZUV2ZW50RGF0ZShodG1sKSxcblx0fVxufVxuXG4vLyAtLS0gUGFyc2Ugdm9sdW50ZWVycyBmcm9tIGEgc2luZ2xlIGV2ZW50IHJlc3VsdHMgcGFnZSAtLS1cbi8vIEZpbmRzIHRyYWNrZWQgYXRobGV0ZXMgaW4gdGhlIFZvbHVudGVlcnMtdGFibGUgYW5kIGV4dHJhY3RzIHRoZWlyIHJvbGVzLlxuLy8gRWFjaCB2b2x1bnRlZXIgcm93OiA8dHIgY2xhc3M9XCJWb2x1bnRlZXJzLXRhYmxlLXJvd1wiIC4uLiBkYXRhLXJvbGU9XCJGdW5rdGlvbsOkcixSZXN1bHRhdHNhbnN2YXJpZyxcIiAuLi4+XG4vLyAgIHdpdGggPGEgaHJlZj1cIi9oYWdhL3BhcmtydW5uZXIve3BhcmtydW5JZH1cIiAuLi4+XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUV2ZW50Vm9sdW50ZWVycyhcblx0aHRtbDogc3RyaW5nLFxuXHR0cmFja2VkSWRzOiBTZXQ8c3RyaW5nPixcbik6IFZvbHVudGVlckVudHJ5W10ge1xuXHRjb25zdCB2b2x1bnRlZXJzOiBWb2x1bnRlZXJFbnRyeVtdID0gW11cblxuXHQvLyBGaW5kIHRoZSB2b2x1bnRlZXJzIHRhYmxlIHNlY3Rpb25cblx0Y29uc3QgdGFibGVNYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0L2NsYXNzPVwiVm9sdW50ZWVycy10YWJsZVteXCJdKmpzLVZvbHVudGVlcnNUYWJsZVteXCJdKlwiW1xcc1xcU10qPzx0Ym9keVtePl0qPihbXFxzXFxTXSo/KTxcXC90Ym9keT4vaSxcblx0KVxuXHRpZiAoIXRhYmxlTWF0Y2gpIHJldHVybiB2b2x1bnRlZXJzXG5cblx0Y29uc3QgdGJvZHkgPSB0YWJsZU1hdGNoWzFdXG5cblx0Ly8gTWF0Y2ggZWFjaCB2b2x1bnRlZXIgcm93XG5cdGNvbnN0IHJvd1JlZ2V4ID1cblx0XHQvPHRyXFxzK2NsYXNzPVwiVm9sdW50ZWVycy10YWJsZS1yb3dcIltePl0qZGF0YS1yb2xlPVwiKFteXCJdKilcIltePl0qPihbXFxzXFxTXSo/KTxcXC90cj4vZ2lcblxuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIHRib2R5Lm1hdGNoQWxsKHJvd1JlZ2V4KSkge1xuXHRcdGNvbnN0IGRhdGFSb2xlID0gbWF0Y2hbMV1cblx0XHRjb25zdCByb3dIdG1sID0gbWF0Y2hbMl1cblxuXHRcdC8vIEV4dHJhY3QgcGFya3J1bklkIGZyb20gdGhlIGxpbmtcblx0XHRjb25zdCBpZE1hdGNoID0gcm93SHRtbC5tYXRjaCgvXFwvcGFya3J1bm5lclxcLyhcXGQrKS8pXG5cdFx0aWYgKCFpZE1hdGNoKSBjb250aW51ZVxuXG5cdFx0Y29uc3QgcGFya3J1bklkID0gaWRNYXRjaFsxXVxuXHRcdGlmICghdHJhY2tlZElkcy5oYXMocGFya3J1bklkKSkgY29udGludWVcblxuXHRcdC8vIFBhcnNlIHJvbGVzIGZyb20gZGF0YS1yb2xlIChjb21tYS1zZXBhcmF0ZWQsIHRyYWlsaW5nIGNvbW1hKVxuXHRcdGNvbnN0IHJvbGVzID0gZGF0YVJvbGVcblx0XHRcdC5zcGxpdCgnLCcpXG5cdFx0XHQubWFwKChyKSA9PiByLnRyaW0oKSlcblx0XHRcdC5maWx0ZXIoKHIpID0+IHIubGVuZ3RoID4gMClcblxuXHRcdHZvbHVudGVlcnMucHVzaCh7IHBhcmtydW5JZCwgcm9sZXMgfSlcblx0fVxuXG5cdHJldHVybiB2b2x1bnRlZXJzXG59XG4iLCIvKipcbiAqIFRoZSBwYXJrcnVuIHBhZ2VzIG91ciBkYXRhIGNvbWVzIGZyb20uXG4gKlxuICogU2hhcmVkIGJ5IHRoZSBzY3JhcGluZyBzY3JpcHRzLCB0aGUgYWRtaW4gdXBsb2FkIGZvcm0gKHdoaWNoIGxpbmtzIHRvXG4gKiBlYWNoIHBhZ2UgeW91IG5lZWQgdG8gZG93bmxvYWQpIGFuZCB0aGUgcmVzdWx0cy1zY3JhcGVyIGV4dGVuc2lvbiAod2hpY2hcbiAqIG5hdmlnYXRlcyB0byB0aGVtKS4gT25lIGRlZmluaXRpb24gc28gYWxsIHRocmVlIGFncmVlLlxuICovXG5pbXBvcnQgeyBET01BSU5fVE9fQ09VTlRSWSB9IGZyb20gJy4vcGFya3J1bi1wYXJzZXJzJ1xuXG4vKipcbiAqIFdoaWNoIHBhcmtydW4gc2l0ZSB0byByZWFkIGF0aGxldGUgaGlzdG9yeSBmcm9tLiBFdmVyeSBjb3VudHJ5J3Mgc2l0ZSBzZXJ2ZXNcbiAqIHRoZSBzYW1lIGF0aGxldGUgcGFnZXM7IHRoZSBzY3JpcHRzIGhhdmUgYWx3YXlzIHVzZWQgdGhlIFVLIG9uZSwgYW5kIGl0c1xuICogcGFnZXMgYXJlIGluIEVuZ2xpc2gsIHdoaWNoIGlzIHRoZSBwYXJzZXJzJyBwcmltYXJ5IHBhdGguXG4gKi9cbmV4cG9ydCBjb25zdCBBVEhMRVRFX1NJVEUgPSAnaHR0cHM6Ly93d3cucGFya3J1bi5vcmcudWsnXG5cbi8qKiBBbiBhdGhsZXRlJ3MgZnVsbCBydW4gaGlzdG9yeSDigJQgd2hhdCBmZXRjaC1yZXN1bHRzLnRzIHJlcXVlc3RzLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGF0aGxldGVQYWdlVXJsKHBhcmtydW5JZDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGAke0FUSExFVEVfU0lURX0vcGFya3J1bm5lci8ke3BhcmtydW5JZH0vYWxsL2Bcbn1cblxuLyoqXG4gKiBBbiBldmVudCdzIG1vc3QgcmVjZW50IHJlc3VsdHMuIGZldGNoLXBhcmtydW4udHMgd2Fsa3MgdGhlIGV2ZW50IGhpc3RvcnkgdG9cbiAqIGZpbmQgZXZlcnkgdW5zY3JhcGVkIG51bWJlcjsgYnkgaGFuZCB5b3Ugd2FudCB0aGUgbGF0ZXN0IG9uZSwgd2hpY2ggcGFya3J1blxuICogc2VydmVzIGF0IGEgc3RhYmxlIFVSTC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxhdGVzdFJlc3VsdHNVcmwoZXZlbnRCYXNlVXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gYCR7dHJpbVNsYXNoKGV2ZW50QmFzZVVybCl9L3Jlc3VsdHMvbGF0ZXN0cmVzdWx0cy9gXG59XG5cbi8qKiBBIG51bWJlcmVkIGV2ZW50IHJlc3VsdHMgcGFnZSwgZS5nLiDigKYvaGFnYS9yZXN1bHRzLzQxNS8gKi9cbmV4cG9ydCBmdW5jdGlvbiBldmVudFJlc3VsdHNVcmwoXG5cdGV2ZW50QmFzZVVybDogc3RyaW5nLFxuXHRldmVudE51bWJlcjogbnVtYmVyLFxuKTogc3RyaW5nIHtcblx0cmV0dXJuIGAke3RyaW1TbGFzaChldmVudEJhc2VVcmwpfS9yZXN1bHRzLyR7ZXZlbnROdW1iZXJ9L2Bcbn1cblxuLyoqIEFuIGV2ZW50J3MgY291cnNlIHBhZ2UsIHdoaWNoIGVtYmVkcyB0aGUgR29vZ2xlIG1hcCBob2xkaW5nIHRoZSBLTVouICovXG5leHBvcnQgZnVuY3Rpb24gY291cnNlUGFnZVVybChldmVudEJhc2VVcmw6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiBgJHt0cmltU2xhc2goZXZlbnRCYXNlVXJsKX0vY291cnNlL2Bcbn1cblxuLyoqIFRoZSBHb29nbGUgTXkgTWFwcyBLTVogZXhwb3J0IGZvciBhIG1hcCBpZCBmb3VuZCBvbiBhIGNvdXJzZSBwYWdlLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvdXJzZUttelVybChtaWQ6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiBgaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9tYXBzL2Qva21sP21pZD0ke21pZH1gXG59XG5cbi8qKiBUaGUgZW1iZWQgVVJMLCB1c2VkIHRvIHJlc29sdmUgbGVnYWN5IG1hcCBpZHMgdmlhIHRoZWlyIHJlZGlyZWN0LiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvdXJzZU1hcEVtYmVkVXJsKG1pZDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGBodHRwczovL3d3dy5nb29nbGUuY29tL21hcHMvZC9lbWJlZD9taWQ9JHttaWR9YFxufVxuXG4vKiogVGhlIGxlYWd1ZSB0YWJsZSBmZXRjaC1sYXJnZXN0LWNsdWJzLnRzIHNjcmFwZXMuICovXG5leHBvcnQgY29uc3QgTEFSR0VTVF9DTFVCU19VUkwgPSAnaHR0cHM6Ly93d3cucGFya3J1bi5zZS9yZXN1bHRzL2xhcmdlc3RjbHVicy8nXG5cbmZ1bmN0aW9uIHRyaW1TbGFzaCh1cmw6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiB1cmwucmVwbGFjZSgvXFwvJC8sICcnKVxufVxuXG4vLyAtLS0gSG9zdCBwYXR0ZXJucywgZm9yIHRoZSBleHRlbnNpb24ncyBtYW5pZmVzdCAtLS1cblxuLyoqXG4gKiBNYXRjaCBwYXR0ZXJucyBjb3ZlcmluZyBldmVyeSBwYXJrcnVuIHNpdGUgd2Uga25vdyBhYm91dCwgcGx1cyBHb29nbGUgTWFwcy5cbiAqIE1hdGNoIHBhdHRlcm5zIGNhbid0IHdpbGRjYXJkIGEgVExELCBzbyB0aGVzZSBoYXZlIHRvIGJlIGVudW1lcmF0ZWQg4oCUIGhlbmNlXG4gKiBkZXJpdmluZyB0aGVtIGZyb20gdGhlIGNvdW50cnkgbWFwIHRoZSBwYXJzZXJzIGFscmVhZHkgbWFpbnRhaW4uXG4gKi9cbmV4cG9ydCBjb25zdCBQQVJLUlVOX0hPU1RfUEFUVEVSTlMgPSBPYmplY3Qua2V5cyhET01BSU5fVE9fQ09VTlRSWSkuZmxhdE1hcChcblx0KGRvbWFpbikgPT4gW2AqOi8vJHtkb21haW59LypgLCBgKjovLyouJHtkb21haW59LypgXSxcbilcblxuZXhwb3J0IGNvbnN0IEdPT0dMRV9NQVBTX0hPU1RfUEFUVEVSTlMgPSBbJyo6Ly8qLmdvb2dsZS5jb20vbWFwcy8qJ11cbiIsIi8qKlxuICogS2VlcHMgdGhlIHNlcnZpY2Ugd29ya2VyIGFsaXZlIGZvciB0aGUgZHVyYXRpb24gb2YgYSBydW4uXG4gKlxuICogQ2FwdHVyZSBkZXBlbmRzIG9uIGBjaHJvbWUuZGVidWdnZXJgIE5ldHdvcmsgZXZlbnRzLCBhbmQgdGhvc2UgYXJlIG9ubHlcbiAqIGRlbGl2ZXJlZCB0byBhICpydW5uaW5nKiB3b3JrZXIg4oCUIHVubGlrZSB0YWJzL2FsYXJtcy9tZXNzYWdlcywgYSBkZWJ1Z2dlciBldmVudFxuICogZG9lcyBub3Qgd2FrZSBhIHdvcmtlciBDaHJvbWUgaGFzIHJldGlyZWQuIE1pc3MgdGhlIGByZXNwb25zZVJlY2VpdmVkYCBmb3IgYVxuICogcGFnZSBhbmQgdGhlcmUgaXMgbm8gcmVxdWVzdCBJRCBsZWZ0IHRvIGZldGNoIGl0cyBib2R5IHdpdGgsIHNvIHRoZSBwYWdlIGxvYWRzXG4gKiBmaW5lIGluIHRoZSB0YWIgYW5kIHRoZSBleHRlbnNpb24gaGFzIG5vdGhpbmcuIFRoYXQgd2FzIHRoZSBcIm5vIHJlc3BvbnNlLCB0aGVuXG4gKiByZWxvYWRzIGFmdGVyIDMwc1wiIHN5bXB0b20uXG4gKlxuICogQ2FsbGluZyBpbnRvIGEgY2hyb21lIEFQSSByZXNldHMgdGhlIGlkbGUgdGltZXIsIHNvIGEgc2xvdyBzZWxmLXBpbmcgaG9sZHMgdGhlXG4gKiB3b3JrZXIgb3Blbi4gVGhpcyBjb3N0cyBub3RoaW5nIGFuZCBuZWVkcyBubyBleHRyYSBwZXJtaXNzaW9uIOKAlCBidXQgaXQgb25seVxuICogd29ya3Mgd2hpbGUgdGhlIHdvcmtlciBpcyBhbGl2ZSwgc28gYGJhY2tncm91bmQudHNgIHN0aWxsIHJlY292ZXJzIGZyb20gYSBjb2xkXG4gKiBzdGFydCBvbiBpdHMgb3duLlxuICovXG5cbi8qKiBDb21mb3J0YWJseSBpbnNpZGUgQ2hyb21lJ3MgMzBzIGlkbGUgdGltZW91dC4gKi9cbmNvbnN0IFBJTkdfSU5URVJWQUxfTVMgPSAyMF8wMDBcblxubGV0IHRpbWVyOiBSZXR1cm5UeXBlPHR5cGVvZiBzZXRJbnRlcnZhbD4gfCBudWxsID0gbnVsbFxuXG5leHBvcnQgZnVuY3Rpb24gc3RhcnRLZWVwYWxpdmUoKTogdm9pZCB7XG5cdGlmICh0aW1lcikgcmV0dXJuXG5cdHRpbWVyID0gc2V0SW50ZXJ2YWwoKCkgPT4ge1xuXHRcdC8vIFRoZSBjYWxsIGl0c2VsZiBpcyB0aGUgcG9pbnQ7IHRoZSByZXN1bHQgaXMgaXJyZWxldmFudC5cblx0XHR2b2lkIGNocm9tZS5ydW50aW1lLmdldFBsYXRmb3JtSW5mbygpLmNhdGNoKCgpID0+IHVuZGVmaW5lZClcblx0fSwgUElOR19JTlRFUlZBTF9NUylcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIHN0b3BLZWVwYWxpdmUoKTogdm9pZCB7XG5cdGlmICghdGltZXIpIHJldHVyblxuXHRjbGVhckludGVydmFsKHRpbWVyKVxuXHR0aW1lciA9IG51bGxcbn1cbiIsIi8qKlxuICogUnVuIHN0YXRlIGFuZCBjYXB0dXJlZCBmaWxlcywgcGVyc2lzdGVkIGluIGNocm9tZS5zdG9yYWdlLmxvY2FsLlxuICpcbiAqIEV2ZXJ5dGhpbmcgbGl2ZXMgaW4gc3RvcmFnZSByYXRoZXIgdGhhbiBpbiBtb2R1bGUgc2NvcGUgYmVjYXVzZSBhbiBNVjMgc2VydmljZVxuICogd29ya2VyIGlzIHRlcm1pbmF0ZWQgd2hlbmV2ZXIgaXQgZ29lcyBpZGxlIOKAlCB3aGljaCBpdCB3aWxsLCByZXBlYXRlZGx5LCBhY3Jvc3NcbiAqIGEgcnVuIHRoYXQgd2FpdHMgb24gcGFnZSBsb2FkcyBhbmQgY2FwdGNoYXMuIEVhY2ggd2FrZS11cCByZWFkcyBzdGF0ZSBiYWNrIGFuZFxuICogY2FycmllcyBvbi5cbiAqXG4gKiBgdW5saW1pdGVkU3RvcmFnZWAgaXMgZGVjbGFyZWQgaW4gdGhlIG1hbmlmZXN0OiBmaWZ0ZWVuIGF0aGxldGUgcGFnZXMgaXMgd2VsbFxuICogcGFzdCBjaHJvbWUuc3RvcmFnZS5sb2NhbCdzIHVzdWFsIDEwIE1CIGNhcC5cbiAqL1xuaW1wb3J0IHR5cGUge1xuXHRDYXB0dXJlZEZpbGUsXG5cdEl0ZW1TdGF0ZSxcblx0SXRlbVN0YXR1cyxcblx0UnVuU3RhdGUsXG59IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcbmltcG9ydCB7IGVtcHR5UnVuU3RhdGUgfSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5cbmNvbnN0IFJVTl9LRVkgPSAncnVuJ1xuY29uc3QgRklMRVNfS0VZID0gJ2ZpbGVzJ1xuY29uc3QgU0VTU0lPTl9LRVkgPSAnc2Vzc2lvbidcblxuLyoqIEJvb2trZWVwaW5nIHRoZSBVSSBuZXZlciBzZWVzLiAqL1xuZXhwb3J0IGludGVyZmFjZSBSdW5TZXNzaW9uIHtcblx0YWRtaW5UYWJJZD86IG51bWJlclxuXHRzY3JhcGVUYWJJZD86IG51bWJlclxuXHQvKiogRXZlbnQgSURzIHRoYXQgYWxyZWFkeSBoYWQgY291cnNlIGRhdGEgYmVmb3JlIHRoZSBydW4gc3RhcnRlZC4gKi9cblx0a25vd25Db3Vyc2VFdmVudElkczogc3RyaW5nW11cblx0LyoqIEV2ZW50cyBmb3VuZCBvbiBhdGhsZXRlIHBhZ2VzOiBldmVudElkIOKGkiBiYXNlIFVSTCBhbmQgZGlzcGxheSBuYW1lLiAqL1xuXHRkaXNjb3ZlcmVkRXZlbnRzOiBSZWNvcmQ8c3RyaW5nLCB7IG5hbWU6IHN0cmluZzsgdXJsOiBzdHJpbmcgfT5cblx0LyoqIFNldCBvbmNlIHRoZSBxdWV1ZSBoYXMgYmVlbiBleHRlbmRlZCB3aXRoIGNvdXJzZSBwYWdlcy4gKi9cblx0Y291cnNlc1F1ZXVlZDogYm9vbGVhblxuXHRza2lwQ291cnNlczogYm9vbGVhblxuXHQvKiogQ29uc2VjdXRpdmUgY2FwdHVyZSBhdHRlbXB0cyBmb3IgdGhlIGN1cnJlbnQgaXRlbSwgdG8gc3RvcCBsb29wcy4gKi9cblx0YXR0ZW1wdHM6IG51bWJlclxufVxuXG5mdW5jdGlvbiBlbXB0eVNlc3Npb24oKTogUnVuU2Vzc2lvbiB7XG5cdHJldHVybiB7XG5cdFx0a25vd25Db3Vyc2VFdmVudElkczogW10sXG5cdFx0ZGlzY292ZXJlZEV2ZW50czoge30sXG5cdFx0Y291cnNlc1F1ZXVlZDogZmFsc2UsXG5cdFx0c2tpcENvdXJzZXM6IGZhbHNlLFxuXHRcdGF0dGVtcHRzOiAwLFxuXHR9XG59XG5cbi8vIOKUgOKUgCBSdW4gc3RhdGUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRSdW5TdGF0ZSgpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDx7IHJ1bj86IFJ1blN0YXRlIH0+KFJVTl9LRVkpXG5cdHJldHVybiBzdG9yZWQucnVuID8/IGVtcHR5UnVuU3RhdGUoKVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0UnVuU3RhdGUoc3RhdGU6IFJ1blN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtSVU5fS0VZXTogc3RhdGUgfSlcbn1cblxuLyoqIEFwcGx5IGEgY2hhbmdlIHRvIHRoZSBzdG9yZWQgc3RhdGUgYW5kIHJldHVybiB3aGF0IHdhcyB3cml0dGVuLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVJ1blN0YXRlKFxuXHRjaGFuZ2U6IChzdGF0ZTogUnVuU3RhdGUpID0+IFJ1blN0YXRlLFxuKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRjb25zdCBuZXh0ID0gY2hhbmdlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdGF3YWl0IHNldFJ1blN0YXRlKG5leHQpXG5cdHJldHVybiBuZXh0XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRJdGVtU3RhdHVzKFxuXHRrZXk6IHN0cmluZyxcblx0c3RhdHVzOiBJdGVtU3RhdHVzLFxuXHRkZXRhaWw/OiBzdHJpbmcsXG5cdGF0dGVtcHRzPzogbnVtYmVyLFxuKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRyZXR1cm4gdXBkYXRlUnVuU3RhdGUoKHN0YXRlKSA9PiAoe1xuXHRcdC4uLnN0YXRlLFxuXHRcdGl0ZW1zOiBzdGF0ZS5pdGVtcy5tYXAoKGl0ZW0pID0+XG5cdFx0XHRpdGVtLmtleSA9PT0ga2V5XG5cdFx0XHRcdD8ge1xuXHRcdFx0XHRcdFx0Li4uaXRlbSxcblx0XHRcdFx0XHRcdHN0YXR1cyxcblx0XHRcdFx0XHRcdGRldGFpbCxcblx0XHRcdFx0XHRcdGF0dGVtcHRzOiBhdHRlbXB0cyA/PyBpdGVtLmF0dGVtcHRzLFxuXHRcdFx0XHRcdFx0dXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0OiBpdGVtLFxuXHRcdCksXG5cdH0pKVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gYXBwZW5kSXRlbXMoaXRlbXM6IEl0ZW1TdGF0ZVtdKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRyZXR1cm4gdXBkYXRlUnVuU3RhdGUoKHN0YXRlKSA9PiAoe1xuXHRcdC4uLnN0YXRlLFxuXHRcdGl0ZW1zOiBbLi4uc3RhdGUuaXRlbXMsIC4uLml0ZW1zXSxcblx0fSkpXG59XG5cbi8vIOKUgOKUgCBTZXNzaW9uIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0U2Vzc2lvbigpOiBQcm9taXNlPFJ1blNlc3Npb24+IHtcblx0Y29uc3Qgc3RvcmVkID0gYXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuZ2V0PHsgc2Vzc2lvbj86IFJ1blNlc3Npb24gfT4oXG5cdFx0U0VTU0lPTl9LRVksXG5cdClcblx0cmV0dXJuIHN0b3JlZC5zZXNzaW9uID8/IGVtcHR5U2Vzc2lvbigpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBzZXRTZXNzaW9uKHNlc3Npb246IFJ1blNlc3Npb24pOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW1NFU1NJT05fS0VZXTogc2Vzc2lvbiB9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdXBkYXRlU2Vzc2lvbihcblx0Y2hhbmdlOiAoc2Vzc2lvbjogUnVuU2Vzc2lvbikgPT4gUnVuU2Vzc2lvbixcbik6IFByb21pc2U8UnVuU2Vzc2lvbj4ge1xuXHRjb25zdCBuZXh0ID0gY2hhbmdlKGF3YWl0IGdldFNlc3Npb24oKSlcblx0YXdhaXQgc2V0U2Vzc2lvbihuZXh0KVxuXHRyZXR1cm4gbmV4dFxufVxuXG4vLyDilIDilIAgQ2FwdHVyZWQgZmlsZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRGaWxlcygpOiBQcm9taXNlPENhcHR1cmVkRmlsZVtdPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDx7IGZpbGVzPzogQ2FwdHVyZWRGaWxlW10gfT4oXG5cdFx0RklMRVNfS0VZLFxuXHQpXG5cdHJldHVybiBzdG9yZWQuZmlsZXMgPz8gW11cbn1cblxuLyoqIFN0b3JlIGEgY2FwdHVyZWQgZmlsZSwgcmVwbGFjaW5nIGFueSBlYXJsaWVyIGNhcHR1cmUgZm9yIHRoZSBzYW1lIHNsb3QuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcHV0RmlsZShmaWxlOiBDYXB0dXJlZEZpbGUpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgZmlsZXMgPSBhd2FpdCBnZXRGaWxlcygpXG5cdGNvbnN0IGV4aXN0aW5nID0gZmlsZXMuZmluZEluZGV4KFxuXHRcdChmKSA9PiBmLmtpbmQgPT09IGZpbGUua2luZCAmJiBmLmtleSA9PT0gZmlsZS5rZXksXG5cdClcblx0aWYgKGV4aXN0aW5nID09PSAtMSkgZmlsZXMucHVzaChmaWxlKVxuXHRlbHNlIGZpbGVzW2V4aXN0aW5nXSA9IGZpbGVcblx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW0ZJTEVTX0tFWV06IGZpbGVzIH0pXG59XG5cbi8vIOKUgOKUgCBMaWZlY3ljbGUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXNldEFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwucmVtb3ZlKFtSVU5fS0VZLCBGSUxFU19LRVksIFNFU1NJT05fS0VZXSlcbn1cbiIsIi8qKlxuICogUHVzaGluZyB1cGRhdGVzIG91dCBvZiB0aGUgc2VydmljZSB3b3JrZXIuXG4gKlxuICogUHJvZ3Jlc3MgZ29lcyB0byB0d28gcGxhY2VzOiB0aGUgYWRtaW4gdGFiICh3aGljaCBkcmF3cyB0aGUgcGFuZWwgdGhhdFxuICogcmVwbGFjZWQgdGhlIGZvcm0pIGFuZCB3aGF0ZXZlciBwYWdlIGlzIGN1cnJlbnRseSBpbiB0aGUgc2NyYXBlIHRhYiAod2hpY2hcbiAqIHNob3dzIHRoZSBmbG9hdGluZyBvdmVybGF5KS4gQm90aCBhcmUgYmVzdC1lZmZvcnQg4oCUIGEgdGFiIHdpdGggbm8gY29udGVudFxuICogc2NyaXB0IGxvYWRlZCB5ZXQganVzdCBpc24ndCBsaXN0ZW5pbmcsIGFuZCB0aGF0J3MgZmluZSwgYmVjYXVzZSBib3RoIGFsc29cbiAqIHJlYWQgdGhlIGN1cnJlbnQgc3RhdGUgZnJvbSBzdG9yYWdlIHdoZW4gdGhleSBzdGFydCB1cC5cbiAqL1xuaW1wb3J0IHR5cGUgeyBDYXB0dXJlZEZpbGUsIFJ1blN0YXRlIH0gZnJvbSAnQHNoYXJlZC9zY3JhcGVyLXByb3RvY29sJ1xuaW1wb3J0IHsgZ2V0U2Vzc2lvbiB9IGZyb20gJy4vc3RhdGUnXG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBub3RpZnlTdGF0ZShzdGF0ZTogUnVuU3RhdGUpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRjb25zdCBtZXNzYWdlID0geyB0eXBlOiAnc3RhdGUnIGFzIGNvbnN0LCBzdGF0ZSB9XG5cblx0Zm9yIChjb25zdCB0YWJJZCBvZiBbc2Vzc2lvbi5hZG1pblRhYklkLCBzZXNzaW9uLnNjcmFwZVRhYklkXSkge1xuXHRcdGlmICh0YWJJZCA9PT0gdW5kZWZpbmVkKSBjb250aW51ZVxuXHRcdGF3YWl0IGNocm9tZS50YWJzLnNlbmRNZXNzYWdlKHRhYklkLCBtZXNzYWdlKS5jYXRjaCgoKSA9PiB7fSlcblx0fVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbm90aWZ5RmlsZShmaWxlOiBDYXB0dXJlZEZpbGUpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgeyBhZG1pblRhYklkIH0gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKGFkbWluVGFiSWQgPT09IHVuZGVmaW5lZCkgcmV0dXJuXG5cdGF3YWl0IGNocm9tZS50YWJzXG5cdFx0LnNlbmRNZXNzYWdlKGFkbWluVGFiSWQsIHsgdHlwZTogJ2ZpbGUnIGFzIGNvbnN0LCBmaWxlIH0pXG5cdFx0LmNhdGNoKCgpID0+IHt9KVxufVxuIiwiLyoqXG4gKiBEZWNpZGVzIHdoYXQgd2UgYWN0dWFsbHkgZ290IGJhY2suXG4gKlxuICogUmF0aGVyIHRoYW4gcGF0dGVybi1tYXRjaGluZyBib3QtY2hlY2sgcGFnZXMgKHdoaWNoIGNoYW5nZSksIHRoZSB0ZXN0IGlzXG4gKiB3aGV0aGVyIHRoZSByZXBvJ3Mgb3duIHBhcnNlcnMgY2FuIHJlYWQgdGhlIHBhZ2UuIElmIHRoZXkgY2FuLCBpdCdzIHRoZSByZWFsXG4gKiB0aGluZzsgaWYgdGhleSBjYW4ndCBhbmQgdGhlIHN0YXR1cyBsb29rcyBsaWtlIGEgYmxvY2ssIHRoZSB1c2VyIG5lZWRzIHRvXG4gKiBzb2x2ZSBzb21ldGhpbmcuIFRoYXQgd2F5IGEgcmVkZXNpZ25lZCBjaGFsbGVuZ2UgcGFnZSBzdGlsbCBsYW5kcyBpbiB0aGUgcmlnaHRcbiAqIHN0YXRlLCBhbmQgYSByZWRlc2lnbmVkICpwYXJrcnVuKiBwYWdlIGZhaWxzIGxvdWRseSBpbnN0ZWFkIG9mIHNpbGVudGx5XG4gKiBpbmdlc3Rpbmcgbm90aGluZy5cbiAqL1xuaW1wb3J0IHtcblx0cGFyc2VFdmVudFBhZ2VNZXRhLFxuXHRwYXJzZUxhcmdlc3RDbHVicyxcblx0cGFyc2VSdW5SZXN1bHRzLFxuXHRwYXJzZVJ1bm5lckRhdGEsXG59IGZyb20gJ0BzaGFyZWQvcGFya3J1bi1wYXJzZXJzJ1xuaW1wb3J0IHR5cGUgeyBDYXB0dXJlS2luZCB9IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcblxuZXhwb3J0IHR5cGUgVmVyZGljdCA9XG5cdC8qKiBUaGUgcGFnZSBwYXJzZWQg4oCUIGNhcHR1cmUgaXQuICovXG5cdHwgeyBvdXRjb21lOiAnb2snOyBkZXRhaWw6IHN0cmluZyB9XG5cdC8qKlxuXHQgKiBBIGJvdCBjaGVjayBvciBhIHdvYmJsZS4gUmV0cnlhYmxlLCBhbmQgcmV0cmllZCBhdXRvbWF0aWNhbGx5LlxuXHQgKlxuXHQgKiBgYXdhaXRVc2VyYCBtYXJrcyB0aGUgb25lcyB3aXRoIHNvbWV0aGluZyBvbiBzY3JlZW4gZm9yIGEgaHVtYW4gdG8gc29sdmUg4oCUXG5cdCAqIHRob3NlIG11c3QgbmV2ZXIgYmUgcmVsb2FkZWQgZnJvbSB1bmRlciB0aGVtLCBhbmQgbXVzdCBuZXZlciB0aW1lIG91dC5cblx0ICovXG5cdHwgeyBvdXRjb21lOiAnYmxvY2tlZCc7IGRldGFpbDogc3RyaW5nOyBhd2FpdFVzZXI/OiBib29sZWFuIH1cblx0LyoqIExvYWRlZCBmaW5lIGJ1dCBpc24ndCB3aGF0IHdlIGFza2VkIGZvciwgb3IgcGFya3J1biBjaGFuZ2VkIHNoYXBlLiAqL1xuXHR8IHsgb3V0Y29tZTogJ3VudXNhYmxlJzsgZGV0YWlsOiBzdHJpbmcgfVxuXG4vKipcbiAqIEZpbmdlcnByaW50cyBvZiBhbiBpbnRlcmFjdGl2ZSBjaGFsbGVuZ2Ug4oCUIHNvbWV0aGluZyBhIHBlcnNvbiBoYXMgdG8gY2xpY2tcbiAqIHRocm91Z2gsIGFzIG9wcG9zZWQgdG8gYSB0cmFuc2llbnQgZXJyb3IuXG4gKlxuICogcGFya3J1bidzIGltYWdlIGNhcHRjaGEgKFwiTGV0J3MgY29uZmlybSB5b3UgYXJlIGh1bWFuIOKAlCBjaG9vc2UgYWxsIHRoZVxuICogY2xvY2tzXCIpIGFycml2ZXMgYXMgSFRUUCA0MDUsIHNvIHRoZSBzdGF0dXMgYWxvbmUgdGVsbHMgeW91IG5vdGhpbmcgdXNlZnVsLlxuICovXG5jb25zdCBDSEFMTEVOR0VfTUFSS0VSUyA9IFtcblx0Jy9jZG4tY2dpL2NoYWxsZW5nZS1wbGF0Zm9ybScsXG5cdCdjb25maXJtIHlvdSBhcmUgaHVtYW4nLFxuXHQndmVyaWZ5IHlvdSBhcmUgaHVtYW4nLFxuXHQnYXJlIHlvdSBhIHJvYm90Jyxcblx0J2NhcHRjaGEnLFxuXHQndHVybnN0aWxlJyxcblx0J2NmX2NobCcsXG5cdCdjZi1jaGFsbGVuZ2UnLFxuXHQnY2hlY2tpbmcgeW91ciBicm93c2VyJyxcblx0J2p1c3QgYSBtb21lbnQnLFxuXVxuXG5mdW5jdGlvbiBsb29rc0xpa2VDaGFsbGVuZ2UoaHRtbDogc3RyaW5nKTogYm9vbGVhbiB7XG5cdGNvbnN0IGhheXN0YWNrID0gaHRtbC5zbGljZSgwLCAyMDBfMDAwKS50b0xvd2VyQ2FzZSgpXG5cdHJldHVybiBDSEFMTEVOR0VfTUFSS0VSUy5zb21lKChtYXJrZXIpID0+IGhheXN0YWNrLmluY2x1ZGVzKG1hcmtlcikpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiB2YWxpZGF0ZShcblx0a2luZDogQ2FwdHVyZUtpbmQsXG5cdGtleTogc3RyaW5nLFxuXHRzdGF0dXM6IG51bWJlcixcblx0aHRtbDogc3RyaW5nLFxuKTogVmVyZGljdCB7XG5cdC8vIEFueSBlcnJvciBzdGF0dXMgaXMgdHJlYXRlZCBhcyByZXRyeWFibGUgcmF0aGVyIHRoYW4gZmF0YWwuIEJvdCBjaGVja3MgY29tZVxuXHQvLyBiYWNrIHdpdGggYWxsIHNvcnRzIOKAlCA0MDMsIDQwNSwgNDI5LCA1MDMg4oCUIGFuZCBmYWlsaW5nIGFuIGl0ZW0gb3V0cmlnaHQgb25cblx0Ly8gb25lIHRocm93cyBhd2F5IGEgcGFnZSB0aGUgdXNlciBjb3VsZCBoYXZlIHVubG9ja2VkIGluIHR3byBjbGlja3MuIFRoZVxuXHQvLyBhdHRlbXB0IGxpbWl0IHN0b3BzIHRoaXMgbG9vcGluZyBmb3JldmVyLCBhbmQgU2tpcCBpcyBhbHdheXMgYXZhaWxhYmxlLlxuXHRpZiAoc3RhdHVzID49IDQwMCkge1xuXHRcdGNvbnN0IGNoYWxsZW5nZSA9IGxvb2tzTGlrZUNoYWxsZW5nZShodG1sKVxuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRhd2FpdFVzZXI6IGNoYWxsZW5nZSxcblx0XHRcdGRldGFpbDogY2hhbGxlbmdlXG5cdFx0XHRcdD8gYHBhcmtydW4gcmVwbGllZCAke3N0YXR1c30gYW5kIGlzIGFza2luZyB5b3UgdG8gcHJvdmUgeW91J3JlIGh1bWFuIOKAlCBzb2x2ZSBpdCBpbiB0aGUgc2NyYXBlIHRhYiBhbmQgdGhlIHJ1biBjYXJyaWVzIG9uLmBcblx0XHRcdFx0OiBgcGFya3J1biByZXBsaWVkICR7c3RhdHVzfSDigJQgcmV0cnlpbmcuYCxcblx0XHR9XG5cdH1cblxuXHQvLyBBIDIwMCBjYW4gc3RpbGwgYmUgYSBjaGFsbGVuZ2UgcGFnZS5cblx0aWYgKGxvb2tzTGlrZUNoYWxsZW5nZShodG1sKSAmJiAhcGFyc2VzQXNSZWFsUGFnZShraW5kLCBrZXksIGh0bWwpKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG91dGNvbWU6ICdibG9ja2VkJyxcblx0XHRcdGF3YWl0VXNlcjogdHJ1ZSxcblx0XHRcdGRldGFpbDpcblx0XHRcdFx0XCJwYXJrcnVuIGlzIGFza2luZyB5b3UgdG8gcHJvdmUgeW91J3JlIGh1bWFuIOKAlCBzb2x2ZSBpdCBpbiB0aGUgc2NyYXBlIHRhYiBhbmQgdGhlIHJ1biBjYXJyaWVzIG9uLlwiLFxuXHRcdH1cblx0fVxuXG5cdHN3aXRjaCAoa2luZCkge1xuXHRcdGNhc2UgJ2F0aGxldGUnOlxuXHRcdFx0cmV0dXJuIHZhbGlkYXRlQXRobGV0ZShrZXksIGh0bWwpXG5cdFx0Y2FzZSAnZXZlbnQnOlxuXHRcdFx0cmV0dXJuIHZhbGlkYXRlRXZlbnQoa2V5LCBodG1sKVxuXHRcdGNhc2UgJ2NsdWJzJzpcblx0XHRcdHJldHVybiB2YWxpZGF0ZUNsdWJzKGh0bWwpXG5cdFx0Y2FzZSAnY291cnNlJzpcblx0XHRcdHJldHVybiB2YWxpZGF0ZUNvdXJzZShodG1sKVxuXHR9XG59XG5cbi8qKlxuICogV2hldGhlciB0aGUgcGFnZSBpcyBnZW51aW5lbHkgdGhlIG9uZSB3ZSBhc2tlZCBmb3IuIFVzZWQgdG8gc3RvcCBhIGNoYWxsZW5nZVxuICogbWFya2VyIGluLCBzYXksIGFuIGFuYWx5dGljcyBzbmlwcGV0IGZyb20gcmVqZWN0aW5nIGEgcGVyZmVjdGx5IGdvb2QgcGFnZS5cbiAqL1xuZnVuY3Rpb24gcGFyc2VzQXNSZWFsUGFnZShcblx0a2luZDogQ2FwdHVyZUtpbmQsXG5cdGtleTogc3RyaW5nLFxuXHRodG1sOiBzdHJpbmcsXG4pOiBib29sZWFuIHtcblx0c3dpdGNoIChraW5kKSB7XG5cdFx0Y2FzZSAnYXRobGV0ZSc6XG5cdFx0XHRyZXR1cm4gcGFyc2VSdW5SZXN1bHRzKGh0bWwpLmxlbmd0aCA+IDBcblx0XHRjYXNlICdldmVudCc6XG5cdFx0XHRyZXR1cm4gcGFyc2VFdmVudFBhZ2VNZXRhKGh0bWwpLmV2ZW50TnVtYmVyID4gMFxuXHRcdGNhc2UgJ2NsdWJzJzpcblx0XHRcdHJldHVybiBwYXJzZUxhcmdlc3RDbHVicyhodG1sKS5sZW5ndGggPiAwXG5cdFx0Y2FzZSAnY291cnNlJzpcblx0XHRcdHJldHVybiBleHRyYWN0TWFwTWlkKGh0bWwpICE9PSBudWxsXG5cdH1cbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVBdGhsZXRlKHBhcmtydW5JZDogc3RyaW5nLCBodG1sOiBzdHJpbmcpOiBWZXJkaWN0IHtcblx0Y29uc3QgcnVubmVyID0gcGFyc2VSdW5uZXJEYXRhKGh0bWwpXG5cdGNvbnN0IHJlc3VsdHMgPSBwYXJzZVJ1blJlc3VsdHMoaHRtbClcblxuXHRpZiAocnVubmVyLm5hbWUgPT09ICdVbmtub3duJyAmJiByZXN1bHRzLmxlbmd0aCA9PT0gMCkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRkZXRhaWw6IFwiQ291bGRuJ3QgcmVhZCB0aGUgcGFnZSDigJQgaXQgbWF5IGJlIGEgYm90IGNoZWNrLiBSZXRyeWluZy5cIixcblx0XHR9XG5cdH1cblx0aWYgKHJ1bm5lci5wYXJrcnVuSWQgJiYgcnVubmVyLnBhcmtydW5JZCAhPT0gcGFya3J1bklkKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG91dGNvbWU6ICd1bnVzYWJsZScsXG5cdFx0XHRkZXRhaWw6IGBQYWdlIGlzIGZvciBhdGhsZXRlICR7cnVubmVyLnBhcmtydW5JZH0sIGV4cGVjdGVkICR7cGFya3J1bklkfS5gLFxuXHRcdH1cblx0fVxuXHRpZiAocmVzdWx0cy5sZW5ndGggPT09IDApIHtcblx0XHRyZXR1cm4geyBvdXRjb21lOiAndW51c2FibGUnLCBkZXRhaWw6ICdObyBydW4gcmVzdWx0cyBmb3VuZCBvbiB0aGUgcGFnZS4nIH1cblx0fVxuXG5cdHJldHVybiB7XG5cdFx0b3V0Y29tZTogJ29rJyxcblx0XHRkZXRhaWw6IGAke3J1bm5lci5uYW1lfSDCtyAke3Jlc3VsdHMubGVuZ3RofSByZXN1bHRzYCxcblx0fVxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUV2ZW50KGV2ZW50SWQ6IHN0cmluZywgaHRtbDogc3RyaW5nKTogVmVyZGljdCB7XG5cdGNvbnN0IG1ldGEgPSBwYXJzZUV2ZW50UGFnZU1ldGEoaHRtbClcblxuXHRpZiAoIW1ldGEuZXZlbnROdW1iZXIgfHwgIW1ldGEuZGF0ZSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRkZXRhaWw6IFwiQ291bGRuJ3QgcmVhZCB0aGUgZXZlbnQgbnVtYmVyIG9yIGRhdGUg4oCUIGl0IG1heSBiZSBhIGJvdCBjaGVjay5cIixcblx0XHR9XG5cdH1cblx0aWYgKG1ldGEuZXZlbnRJZCAmJiBtZXRhLmV2ZW50SWQgIT09IGV2ZW50SWQpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ3VudXNhYmxlJyxcblx0XHRcdGRldGFpbDogYFBhZ2UgaXMgZm9yIFwiJHttZXRhLmV2ZW50SWR9XCIsIGV4cGVjdGVkIFwiJHtldmVudElkfVwiLmAsXG5cdFx0fVxuXHR9XG5cblx0Ly8gVm9sdW50ZWVyIGNvdW50cyBhcmVuJ3QgY2hlY2tlZDogYW4gZXZlbnQgd2hlcmUgbm9ib2R5IHdlIHRyYWNrIHZvbHVudGVlcmVkXG5cdC8vIGlzIGEgcGVyZmVjdGx5IGdvb2QgY2FwdHVyZS4gVGhlIHBhZ2UgZGVjaWRlcyB3aGF0J3MgaW4gaXQuXG5cdHJldHVybiB7IG91dGNvbWU6ICdvaycsIGRldGFpbDogYCMke21ldGEuZXZlbnROdW1iZXJ9IMK3ICR7bWV0YS5kYXRlfWAgfVxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUNsdWJzKGh0bWw6IHN0cmluZyk6IFZlcmRpY3Qge1xuXHRjb25zdCBjbHVicyA9IHBhcnNlTGFyZ2VzdENsdWJzKGh0bWwpXG5cdGlmIChjbHVicy5sZW5ndGggPT09IDApIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0ZGV0YWlsOiBcIkNvdWxkbid0IHJlYWQgdGhlIGxlYWd1ZSB0YWJsZSDigJQgaXQgbWF5IGJlIGEgYm90IGNoZWNrLlwiLFxuXHRcdH1cblx0fVxuXHRyZXR1cm4geyBvdXRjb21lOiAnb2snLCBkZXRhaWw6IGAke2NsdWJzLmxlbmd0aH0gY2x1YnNgIH1cbn1cblxuLyoqXG4gKiBDb3Vyc2UgcGFnZXMgYXJlIHZhbGlkYXRlZCBieSBmaW5kaW5nIHRoZSBHb29nbGUgbWFwLCBzaW5jZSB0aGF0J3MgdGhlIG9ubHlcbiAqIHBhcnQgd2UgdXNlLiBTYW1lIHJlZ2V4IGFzIGFwcHMvYXBpL2xpYi9tYXAtc2NyYXBlci50cy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RNYXBNaWQoaHRtbDogc3RyaW5nKTogc3RyaW5nIHwgbnVsbCB7XG5cdGNvbnN0IG1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvc3JjPVwiaHR0cHM6XFwvXFwvd3d3XFwuZ29vZ2xlXFwuY29tXFwvbWFwc1xcL2RcXC9bXlwiXSo/Wz8mXW1pZD0oW14mXCJdKykvLFxuXHQpXG5cdHJldHVybiBtYXRjaCA/IG1hdGNoWzFdIDogbnVsbFxufVxuXG5mdW5jdGlvbiB2YWxpZGF0ZUNvdXJzZShodG1sOiBzdHJpbmcpOiBWZXJkaWN0IHtcblx0aWYgKGV4dHJhY3RNYXBNaWQoaHRtbCkpIHtcblx0XHRyZXR1cm4geyBvdXRjb21lOiAnb2snLCBkZXRhaWw6ICdGb3VuZCB0aGUgZW1iZWRkZWQgbWFwJyB9XG5cdH1cblx0Ly8gQSBib3QgY2hlY2sgaGFzIG5vIG1hcCBlaXRoZXIg4oCUIGJ1dCBuZWl0aGVyIGRvZXMgYSBjb3Vyc2UgcGFnZSB3aXRob3V0IG9uZSxcblx0Ly8gd2hpY2ggaXMgYSByZWFsIGFuZCBwZXJtYW5lbnQgY29uZGl0aW9uLiBEaXN0aW5ndWlzaCBvbiBwYWdlIHNoYXBlLlxuXHRjb25zdCBsb29rc0xpa2VQYXJrcnVuID0gL3BhcmtydW4vaS50ZXN0KGh0bWwpICYmIGh0bWwubGVuZ3RoID4gMjBfMDAwXG5cdHJldHVybiBsb29rc0xpa2VQYXJrcnVuXG5cdFx0PyB7XG5cdFx0XHRcdG91dGNvbWU6ICd1bnVzYWJsZScsXG5cdFx0XHRcdGRldGFpbDogJ05vIEdvb2dsZSBtYXAgZW1iZWRkZWQgb24gdGhpcyBjb3Vyc2UgcGFnZS4nLFxuXHRcdFx0fVxuXHRcdDoge1xuXHRcdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRcdGRldGFpbDogXCJDb3VsZG4ndCByZWFkIHRoZSBjb3Vyc2UgcGFnZSDigJQgaXQgbWF5IGJlIGEgYm90IGNoZWNrLlwiLFxuXHRcdFx0fVxufVxuIiwiLyoqXG4gKiBUaGUgcnVuOiB3YWxrIHRoZSB3b3JrIGxpc3QsIGNhcHR1cmUgZWFjaCBwYWdlLCBkaXNjb3ZlciBuZXcgY291cnNlcywgZmluaXNoLlxuICpcbiAqIERyaXZlbiBlbnRpcmVseSBieSBldmVudHMgcmF0aGVyIHRoYW4gYSBsb29wLCBiZWNhdXNlIHRoZSBzZXJ2aWNlIHdvcmtlciBpc1xuICogdGVybWluYXRlZCBiZXR3ZWVuIHBhZ2UgbG9hZHMuIEV2ZXJ5IG1haW4tZnJhbWUgZG9jdW1lbnQgbG9hZCBpbiB0aGUgc2NyYXBlXG4gKiB0YWIgY2FsbHMgYGhhbmRsZURvY3VtZW50TG9hZGVkYCwgd2hpY2ggZGVjaWRlcyB3aGV0aGVyIHRoYXQgd2FzIHRoZSBwYWdlIHdlXG4gKiB3ZXJlIHdhaXRpbmcgZm9yLiBUaGF0J3MgYWxzbyBob3cgY2FwdGNoYXMgcmVzb2x2ZSB0aGVtc2VsdmVzOiBzb2x2aW5nIG9uZVxuICogbmF2aWdhdGVzIGFnYWluLCB3aGljaCBsYW5kcyBoZXJlIGFnYWluLlxuICovXG5pbXBvcnQgeyBleHRyYWN0RXZlbnRzLCBwYXJzZVJ1blJlc3VsdHMgfSBmcm9tICdAc2hhcmVkL3BhcmtydW4tcGFyc2VycydcbmltcG9ydCB7IGNvdXJzZUttelVybCwgY291cnNlUGFnZVVybCB9IGZyb20gJ0BzaGFyZWQvcGFya3J1bi11cmxzJ1xuaW1wb3J0IHR5cGUge1xuXHRDYXB0dXJlZEZpbGUsXG5cdEl0ZW1TdGF0ZSxcblx0UnVuUmVxdWVzdCxcblx0UnVuU3RhdGUsXG59IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcbmltcG9ydCB7XG5cdGNsZWFyTGFzdERvY3VtZW50LFxuXHRkZXNjcmliZUVycm9yLFxuXHRkZXRhY2gsXG5cdGVuc3VyZUF0dGFjaGVkLFxuXHRnZXRMYXN0RG9jdW1lbnQsXG5cdGlzQm9keU5vdFJlYWR5LFxuXHRtYXJrRG9jdW1lbnRDb25zdW1lZCxcblx0cmVhZEJvZHksXG59IGZyb20gJy4vY2FwdHVyZSdcbmltcG9ydCB7IHN0YXJ0S2VlcGFsaXZlLCBzdG9wS2VlcGFsaXZlIH0gZnJvbSAnLi9rZWVwYWxpdmUnXG5pbXBvcnQgeyBub3RpZnlGaWxlLCBub3RpZnlTdGF0ZSB9IGZyb20gJy4vbWVzc2FnaW5nJ1xuaW1wb3J0IHtcblx0YXBwZW5kSXRlbXMsXG5cdGdldEZpbGVzLFxuXHRnZXRSdW5TdGF0ZSxcblx0Z2V0U2Vzc2lvbixcblx0cHV0RmlsZSxcblx0cmVzZXRBbGwsXG5cdHNldEl0ZW1TdGF0dXMsXG5cdHNldFJ1blN0YXRlLFxuXHRzZXRTZXNzaW9uLFxuXHR1cGRhdGVSdW5TdGF0ZSxcblx0dXBkYXRlU2Vzc2lvbixcbn0gZnJvbSAnLi9zdGF0ZSdcbmltcG9ydCB7IGV4dHJhY3RNYXBNaWQsIHZhbGlkYXRlIH0gZnJvbSAnLi92YWxpZGF0ZSdcblxuLyoqIEdpdmUgdXAgb24gYW4gaXRlbSBhZnRlciB0aGlzIG1hbnkgZmFpbGVkIGF0dGVtcHRzIGF0IHRoZSBzYW1lIFVSTC4gKi9cbmNvbnN0IE1BWF9BVFRFTVBUUyA9IDhcblxuLyoqXG4gKiBBIHBhZ2UgdGhhdCBoYXMgYmVlbiBgYWN0aXZlYCB0aGlzIGxvbmcgd2l0aG91dCBwcm9kdWNpbmcgYSBjYXB0dXJlIGhhc1xuICogYWxtb3N0IGNlcnRhaW5seSBoYWQgaXRzIGxvYWQgZXZlbnRzIG1pc3NlZCDigJQgcmVsb2FkIGl0IHJhdGhlciB0aGFuIGhhbmcuXG4gKi9cbmNvbnN0IFNUQUxMX1RJTUVPVVRfTVMgPSAyMF8wMDBcblxuLyoqIEhvdyBvZnRlbiB0aGUgd2F0Y2hkb2cgbG9va3MgZm9yIGEgc3RhbGxlZCBwYWdlLiAqL1xuY29uc3QgV0FUQ0hET0dfQUxBUk0gPSAnd2F0Y2hkb2cnXG5jb25zdCBXQVRDSERPR19QRVJJT0RfTUlOVVRFUyA9IDAuNVxuXG5mdW5jdGlvbiBsb2coLi4uYXJnczogdW5rbm93bltdKTogdm9pZCB7XG5cdGNvbnNvbGUubG9nKCdbcmVzdWx0cy1zY3JhcGVyXScsIC4uLmFyZ3MpXG59XG5cbi8qKlxuICogSG93IGxvbmcgYSBibG9ja2VkIHBhZ2Ugc2l0cyBiZWZvcmUgd2UgcmVsb2FkIGl0IG91cnNlbHZlcy5cbiAqXG4gKiBBIENsb3VkZmxhcmUgaW50ZXJzdGl0aWFsIHJlbG9hZHMgaXRzZWxmIG9uY2UgaXRzIGNoZWNrIHBhc3Nlcywgc28gdGhvc2UgY2xlYXJcbiAqIHdpdGhvdXQgaGVscC4gQSBmbGF0IDQwMyBkb2Vzbid0LCBhbmQgd291bGQgb3RoZXJ3aXNlIHdhaXQgZm9yZXZlci4gTG9uZ1xuICogZW5vdWdoIG5vdCB0byB5YW5rIHRoZSBwYWdlIG91dCBmcm9tIHVuZGVyIHNvbWVvbmUgbWlkLWNhcHRjaGEuXG4gKi9cbmNvbnN0IFJFVFJZX0FMQVJNID0gJ3JldHJ5LWJsb2NrZWQnXG5jb25zdCBSRVRSWV9ERUxBWV9NSU5VVEVTID0gMVxuXG5hc3luYyBmdW5jdGlvbiBzY2hlZHVsZVJldHJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuYWxhcm1zXG5cdFx0LmNyZWF0ZShSRVRSWV9BTEFSTSwgeyBkZWxheUluTWludXRlczogUkVUUllfREVMQVlfTUlOVVRFUyB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcbn1cblxuYXN5bmMgZnVuY3Rpb24gY2FuY2VsU2NoZWR1bGVkUmV0cnkoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5hbGFybXMuY2xlYXIoUkVUUllfQUxBUk0pLmNhdGNoKCgpID0+IHt9KVxufVxuXG4vKiogUmVsb2FkIHdoYXRldmVyIHBhZ2UgdGhlIHJ1biBpcyBzdHVjayBvbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXRyeUN1cnJlbnQoKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnIHx8ICFzdGF0ZS5jdXJyZW50S2V5KSByZXR1cm4gc3RhdGVcblxuXHRjb25zdCBpdGVtID0gc3RhdGUuaXRlbXMuZmluZCgoaSkgPT4gaS5rZXkgPT09IHN0YXRlLmN1cnJlbnRLZXkpXG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKCFpdGVtIHx8IHNlc3Npb24uc2NyYXBlVGFiSWQgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHN0YXRlXG5cblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRhd2FpdCBjbGVhckxhc3REb2N1bWVudChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXG5cdHRyeSB7XG5cdFx0YXdhaXQgZW5zdXJlQXR0YWNoZWQoc2Vzc2lvbi5zY3JhcGVUYWJJZClcblx0XHRhd2FpdCBjaHJvbWUudGFicy51cGRhdGUoc2Vzc2lvbi5zY3JhcGVUYWJJZCwgeyB1cmw6IGl0ZW0udXJsIH0pXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oZGVzY3JpYmVFcnJvcihlcnJvcikpXG5cdH1cblx0cmV0dXJuIHN0YXRlXG59XG5cbi8qKiBBYmFuZG9uIHRoZSBjdXJyZW50IHBhZ2UgYW5kIGNhcnJ5IG9uIHdpdGggdGhlIG5leHQgb25lLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNraXBDdXJyZW50KCk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuIHN0YXRlXG5cblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRhd2FpdCBzZXRJdGVtU3RhdHVzKHN0YXRlLmN1cnJlbnRLZXksICdza2lwcGVkJywgJ1NraXBwZWQuJylcblx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0cmV0dXJuIGFkdmFuY2UoKVxufVxuXG4vKipcbiAqIFRoZSBzY3JhcGUgdGFiIGZpbmlzaGVkIGxvYWRpbmcgYnV0IHdlIGhhdmUgbm8gY2FwdHVyZWQgYm9keSBmb3IgaXQuXG4gKlxuICogVGhhdCBtZWFucyB0aGUgZGVidWdnZXIncyBOZXR3b3JrIGV2ZW50cyBmb3IgdGhpcyBuYXZpZ2F0aW9uIG5ldmVyIHJlYWNoZWQgdXMg4oCUXG4gKiBhIHdvcmtlciB0aGF0IHdhcyBhc2xlZXAgYXQgdGhlIHdyb25nIG1vbWVudCwgbW9zdCBvZnRlbi4gVGhlcmUncyBubyB3YXkgdG8gYXNrXG4gKiBmb3IgYSBib2R5IGFmdGVyIHRoZSBmYWN0LCBzbyB0aGUgb25seSByZWNvdmVyeSBpcyB0byBsb2FkIHRoZSBwYWdlIGFnYWluIHdpdGhcbiAqIHRoZSB3b3JrZXIgbm93IGRlbW9uc3RyYWJseSBhd2FrZS4gRG9pbmcgaXQgaGVyZSByYXRoZXIgdGhhbiBsZWF2aW5nIGl0IHRvIHRoZVxuICogd2F0Y2hkb2cgdHVybnMgYSAyMC1zZWNvbmQgc3RhbGwgaW50byBhYm91dCBhIHNlY29uZC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlY292ZXJNaXNzZWRDYXB0dXJlKHRhYklkOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuXG5cblx0Y29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGkpID0+IGkua2V5ID09PSBzdGF0ZS5jdXJyZW50S2V5KVxuXHRpZiAoaXRlbT8uc3RhdHVzICE9PSAnYWN0aXZlJykgcmV0dXJuXG5cblx0Ly8gSWYgYSBib2R5IGlzIHdhaXRpbmcsIHRoZSBub3JtYWwgcGF0aCBoYXMgaXQg4oCUIG5vdGhpbmcgdG8gcmVjb3Zlci5cblx0Y29uc3QgZG9jdW1lbnQgPSBhd2FpdCBnZXRMYXN0RG9jdW1lbnQodGFiSWQpXG5cdGlmIChkb2N1bWVudCAmJiAhZG9jdW1lbnQuY29uc3VtZWQpIHJldHVyblxuXG5cdGNvbnN0IGF0dGVtcHRzID0gKGl0ZW0uYXR0ZW1wdHMgPz8gMCkgKyAxXG5cdGlmIChhdHRlbXB0cyA+IE1BWF9BVFRFTVBUUykge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdmYWlsZWQnLFxuXHRcdFx0YFBhZ2UgbG9hZGVkIGJ1dCBpdHMgcmVzcG9uc2Ugd2FzIG5ldmVyIGNhcHR1cmVkLCBhZnRlciAke2F0dGVtcHRzfSBhdHRlbXB0cy5gLFxuXHRcdFx0YXR0ZW1wdHMsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRsb2coXG5cdFx0YCR7aXRlbS5sYWJlbH06IGxvYWRlZCBidXQgbm8gcmVzcG9uc2UgY2FwdHVyZWQg4oCUIHJlbG9hZGluZyAoYXR0ZW1wdCAke2F0dGVtcHRzfSlgLFxuXHQpXG5cdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0aXRlbS5rZXksXG5cdFx0J2FjdGl2ZScsXG5cdFx0J1BhZ2UgbG9hZGVkIGJ1dCB0aGUgY2FwdHVyZSB3YXMgbWlzc2VkIOKAlCByZWxvYWRpbmcuJyxcblx0XHRhdHRlbXB0cyxcblx0KVxuXHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRhd2FpdCByZXRyeUN1cnJlbnQoKVxufVxuXG4vKiogRmlyZWQgYnkgdGhlIGFsYXJtOiBudWRnZSBhIHBhZ2UgdGhhdCdzIHN0aWxsIHN0dWNrLiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJldHJ5SWZTdGlsbEJsb2NrZWQoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycgfHwgIXN0YXRlLmN1cnJlbnRLZXkpIHJldHVyblxuXG5cdGNvbnN0IGl0ZW0gPSBzdGF0ZS5pdGVtcy5maW5kKChpKSA9PiBpLmtleSA9PT0gc3RhdGUuY3VycmVudEtleSlcblx0aWYgKGl0ZW0/LnN0YXR1cyAhPT0gJ2Jsb2NrZWQnKSByZXR1cm5cblxuXHQvLyBOZXZlciByZWxvYWQgYSBwYWdlIHRoZSB1c2VyIGlzIHBhcnQtd2F5IHRocm91Z2ggc29sdmluZy5cblx0aWYgKGl0ZW0uYXdhaXRVc2VyKSB7XG5cdFx0bG9nKGAke2l0ZW0ubGFiZWx9OiBzdGlsbCB3YWl0aW5nIGZvciB0aGUgdXNlcjsgbm90IHJlbG9hZGluZ2ApXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLmF0dGVtcHRzID49IE1BWF9BVFRFTVBUUykge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdmYWlsZWQnLFxuXHRcdFx0YCR7aXRlbS5kZXRhaWwgPz8gJ0Jsb2NrZWQuJ30gR2F2ZSB1cCBhZnRlciAke3Nlc3Npb24uYXR0ZW1wdHN9IGF0dGVtcHRzLmAsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRhd2FpdCByZXRyeUN1cnJlbnQoKVxufVxuXG4vLyDilIDilIAgU3RhcnRpbmcgYW5kIHN0b3BwaW5nIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc3RhcnRSdW4oXG5cdHJlcXVlc3Q6IFJ1blJlcXVlc3QsXG5cdGFkbWluVGFiSWQ6IG51bWJlcixcbik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0YXdhaXQgcmVzZXRBbGwoKVxuXG5cdGNvbnN0IGl0ZW1zOiBJdGVtU3RhdGVbXSA9IHJlcXVlc3QuaXRlbXMubWFwKChpdGVtKSA9PiAoe1xuXHRcdC4uLml0ZW0sXG5cdFx0c3RhdHVzOiAncGVuZGluZycsXG5cdH0pKVxuXG5cdGlmIChpdGVtcy5sZW5ndGggPT09IDApIHtcblx0XHRjb25zdCBzdGF0ZTogUnVuU3RhdGUgPSB7XG5cdFx0XHRzdGF0dXM6ICdlcnJvcicsXG5cdFx0XHRpdGVtczogW10sXG5cdFx0XHRtZXNzYWdlOiAnTm90aGluZyB0byBzY3JhcGUuJyxcblx0XHR9XG5cdFx0YXdhaXQgc2V0UnVuU3RhdGUoc3RhdGUpXG5cdFx0cmV0dXJuIHN0YXRlXG5cdH1cblxuXHQvLyBBIGRlZGljYXRlZCB0YWIga2VlcHMgdGhlIGFkbWluIHBhZ2UgYWxpdmUsIHNvIGl0IGNhbiBzaG93IHByb2dyZXNzIGFuZFxuXHQvLyB0YWtlIGZpbGVzIGFzIHRoZXkgYXJyaXZlLlxuXHRjb25zdCB0YWIgPSBhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6ICdhYm91dDpibGFuaycsIGFjdGl2ZTogdHJ1ZSB9KVxuXHRpZiAodGFiLmlkID09PSB1bmRlZmluZWQpIHRocm93IG5ldyBFcnJvcignQ291bGQgbm90IG9wZW4gYSBzY3JhcGUgdGFiJylcblxuXHRhd2FpdCBzZXRTZXNzaW9uKHtcblx0XHRhZG1pblRhYklkLFxuXHRcdHNjcmFwZVRhYklkOiB0YWIuaWQsXG5cdFx0a25vd25Db3Vyc2VFdmVudElkczogcmVxdWVzdC5rbm93bkNvdXJzZUV2ZW50SWRzLFxuXHRcdGRpc2NvdmVyZWRFdmVudHM6IHt9LFxuXHRcdGNvdXJzZXNRdWV1ZWQ6IGZhbHNlLFxuXHRcdHNraXBDb3Vyc2VzOiByZXF1ZXN0LnNraXBDb3Vyc2VzID8/IGZhbHNlLFxuXHRcdGF0dGVtcHRzOiAwLFxuXHR9KVxuXG5cdGNvbnN0IHN0YXRlOiBSdW5TdGF0ZSA9IHtcblx0XHRzdGF0dXM6ICdydW5uaW5nJyxcblx0XHRpdGVtcyxcblx0XHRzdGFydGVkQXQ6IERhdGUubm93KCksXG5cdH1cblx0YXdhaXQgc2V0UnVuU3RhdGUoc3RhdGUpXG5cblx0dHJ5IHtcblx0XHRhd2FpdCBlbnN1cmVBdHRhY2hlZCh0YWIuaWQpXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oZGVzY3JpYmVFcnJvcihlcnJvcikpXG5cdH1cblxuXHRhd2FpdCBzZXRCYWRnZSgn4oCmJylcblx0c3RhcnRLZWVwYWxpdmUoKVxuXHRhd2FpdCBjaHJvbWUuYWxhcm1zXG5cdFx0LmNyZWF0ZShXQVRDSERPR19BTEFSTSwgeyBwZXJpb2RJbk1pbnV0ZXM6IFdBVENIRE9HX1BFUklPRF9NSU5VVEVTIH0pXG5cdFx0LmNhdGNoKCgpID0+IHt9KVxuXHRsb2coYHJ1biBzdGFydGVkOiAke2l0ZW1zLmxlbmd0aH0gaXRlbXMsIHNjcmFwZSB0YWIgJHt0YWIuaWR9YClcblx0cmV0dXJuIGFkdmFuY2UoKVxufVxuXG4vKipcbiAqIFVuc3RpY2sgYSBwYWdlIHdob3NlIGxvYWQgZXZlbnRzIG5ldmVyIGFycml2ZWQuXG4gKlxuICogVGhlIGRlYnVnZ2VyIGlzIHRoZSBvbmx5IHNvdXJjZSBvZiBjYXB0dXJlIGV2ZW50cywgYW5kIGlmIHRoZSBzZXJ2aWNlIHdvcmtlclxuICogd2FzIGFzbGVlcCB3aGVuIHRoZXkgZmlyZWQg4oCUIG9yIHRoZXkgd2VyZSBkcm9wcGVkIOKAlCBub3RoaW5nIGVsc2Ugd2lsbCBldmVyXG4gKiB0cmlnZ2VyLiBSZWxvYWRpbmcgcHJvZHVjZXMgYSBmcmVzaCBzZXQuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjaGVja0ZvclN0YWxsKCk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnIHx8ICFzdGF0ZS5jdXJyZW50S2V5KSByZXR1cm5cblxuXHRjb25zdCBpdGVtID0gc3RhdGUuaXRlbXMuZmluZCgoaSkgPT4gaS5rZXkgPT09IHN0YXRlLmN1cnJlbnRLZXkpXG5cdGlmIChpdGVtPy5zdGF0dXMgIT09ICdhY3RpdmUnKSByZXR1cm5cblxuXHRjb25zdCBhZ2UgPSBEYXRlLm5vdygpIC0gKGl0ZW0udXBkYXRlZEF0ID8/IDApXG5cdGlmIChhZ2UgPCBTVEFMTF9USU1FT1VUX01TKSByZXR1cm5cblxuXHRjb25zdCBhdHRlbXB0cyA9IChpdGVtLmF0dGVtcHRzID8/IDApICsgMVxuXHRpZiAoYXR0ZW1wdHMgPiBNQVhfQVRURU1QVFMpIHtcblx0XHRsb2coYGdpdmluZyB1cCBvbiAke2l0ZW0ubGFiZWx9IGFmdGVyICR7YXR0ZW1wdHN9IGF0dGVtcHRzYClcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0aXRlbS5rZXksXG5cdFx0XHQnZmFpbGVkJyxcblx0XHRcdGBObyByZXNwb25zZSBhZnRlciAke2F0dGVtcHRzfSBhdHRlbXB0cyDigJQgcGFnZSBuZXZlciBmaW5pc2hlZCBsb2FkaW5nLmAsXG5cdFx0XHRhdHRlbXB0cyxcblx0XHQpXG5cdFx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0XHRhd2FpdCBhZHZhbmNlKClcblx0XHRyZXR1cm5cblx0fVxuXG5cdGxvZyhcblx0XHRgJHtpdGVtLmxhYmVsfSBzdGFsbGVkIGZvciAke01hdGgucm91bmQoYWdlIC8gMTAwMCl9cyDigJQgcmVsb2FkaW5nIChhdHRlbXB0ICR7YXR0ZW1wdHN9KWAsXG5cdClcblx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRpdGVtLmtleSxcblx0XHQnYWN0aXZlJyxcblx0XHRgTm8gcmVzcG9uc2UgYWZ0ZXIgJHtNYXRoLnJvdW5kKGFnZSAvIDEwMDApfXMg4oCUIHJlbG9hZGluZyAoYXR0ZW1wdCAke2F0dGVtcHRzfSkuYCxcblx0XHRhdHRlbXB0cyxcblx0KVxuXHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRhd2FpdCByZXRyeUN1cnJlbnQoKVxufVxuXG4vKipcbiAqIFdpcGUgdGhlIHJ1biBhbmQgaXRzIGNhcHR1cmVkIGZpbGVzLlxuICpcbiAqIENhbGxlZCBvbmNlIHRoZSBhZG1pbiBwYWdlIGhhcyB1cGxvYWRlZCwgc28gcmVvcGVuaW5nIHRoZSBwYWdlIGRvZXNuJ3Qgb2ZmZXJcbiAqIHRvIHJlLWRlbGl2ZXIgcGFnZXMgd2hvc2UgZGF0YSBpcyBhbHJlYWR5IGluIHRoZSBkYXRhYmFzZS5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGZvcmdldFJ1bigpOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRzdG9wS2VlcGFsaXZlKClcblx0YXdhaXQgY2hyb21lLmFsYXJtcy5jbGVhcihXQVRDSERPR19BTEFSTSkuY2F0Y2goKCkgPT4ge30pXG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKHNlc3Npb24uc2NyYXBlVGFiSWQgIT09IHVuZGVmaW5lZCkge1xuXHRcdGF3YWl0IGRldGFjaChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXHRcdGF3YWl0IGNsZWFyTGFzdERvY3VtZW50KHNlc3Npb24uc2NyYXBlVGFiSWQpXG5cdH1cblx0YXdhaXQgcmVzZXRBbGwoKVxuXHRhd2FpdCBzZXRCYWRnZSgnJylcblx0bG9nKCdydW4gY2xlYXJlZCcpXG59XG5cbi8qKlxuICogUGljayB1cCBhIHJ1biB0aGF0IHN0b3BwZWQgZWFybHkg4oCUIGNhbmNlbGxlZCwgdGFiIGNsb3NlZCwgZGVidWdnZXIgZGV0YWNoZWQsXG4gKiBicm93c2VyIHJlc3RhcnRlZC5cbiAqXG4gKiBEZWxpYmVyYXRlbHkgbm90IGEgZnJlc2ggYHN0YXJ0UnVuYDogdGhhdCB3b3VsZCB3aXBlIHRoZSBjYXB0dXJlZCBwYWdlcyBhbmRcbiAqIHJlLWZldGNoIGV2ZXJ5dGhpbmcuIEluc3RlYWQgdGhlIGNhcHR1cmVkIGFuZCBza2lwcGVkIGl0ZW1zIGFyZSBsZWZ0IGFsb25lIGFuZFxuICogZXZlcnl0aGluZyBlbHNlIGdvZXMgYmFjayB0byBwZW5kaW5nLCBzbyBhIHNjcmFwZSBpbnRlcnJ1cHRlZCBhdCBwYWdlIDcgb2YgMThcbiAqIGNvc3RzIDExIG1vcmUgcGFnZSBsb2Fkcywgbm90IDE4LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVzdW1lUnVuKGFkbWluVGFiSWQ6IG51bWJlcik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3QgcHJldmlvdXMgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChwcmV2aW91cy5pdGVtcy5sZW5ndGggPT09IDApIHtcblx0XHRyZXR1cm4gZmFpbFJ1bignVGhlcmUgaXMgbm8gcnVuIHRvIHJlc3VtZS4nKVxuXHR9XG5cblx0Y29uc3QgaXRlbXM6IEl0ZW1TdGF0ZVtdID0gcHJldmlvdXMuaXRlbXMubWFwKChpdGVtKSA9PlxuXHRcdGl0ZW0uc3RhdHVzID09PSAnY2FwdHVyZWQnIHx8IGl0ZW0uc3RhdHVzID09PSAnc2tpcHBlZCdcblx0XHRcdD8gaXRlbVxuXHRcdFx0OiB7XG5cdFx0XHRcdFx0Li4uaXRlbSxcblx0XHRcdFx0XHRzdGF0dXM6ICdwZW5kaW5nJyBhcyBjb25zdCxcblx0XHRcdFx0XHRkZXRhaWw6IHVuZGVmaW5lZCxcblx0XHRcdFx0XHRhdHRlbXB0czogMCxcblx0XHRcdFx0XHRhd2FpdFVzZXI6IHVuZGVmaW5lZCxcblx0XHRcdFx0XHR1cGRhdGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRcdH0sXG5cdClcblxuXHRjb25zdCBvdXRzdGFuZGluZyA9IGl0ZW1zLmZpbHRlcigoaXRlbSkgPT4gaXRlbS5zdGF0dXMgPT09ICdwZW5kaW5nJykubGVuZ3RoXG5cdGlmIChvdXRzdGFuZGluZyA9PT0gMCkge1xuXHRcdHJldHVybiBmYWlsUnVuKCdFdmVyeSBwYWdlIGluIHRoYXQgcnVuIGlzIGFscmVhZHkgY2FwdHVyZWQgb3Igc2tpcHBlZC4nKVxuXHR9XG5cblx0Y29uc3QgdGFiID0gYXdhaXQgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiAnYWJvdXQ6YmxhbmsnLCBhY3RpdmU6IHRydWUgfSlcblx0aWYgKHRhYi5pZCA9PT0gdW5kZWZpbmVkKSB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBvcGVuIGEgc2NyYXBlIHRhYicpXG5cblx0Ly8gVGhlIHNlc3Npb24gY2FycmllcyB0aGUgZXZlbnRzIGRpc2NvdmVyZWQgYnkgYXRobGV0ZSBwYWdlcyB3ZSBhbHJlYWR5IGhhdmUsXG5cdC8vIHNvIHRoZSBjb3Vyc2UgaHVudCBzdGlsbCBrbm93cyBhYm91dCB0aGVtIHdpdGhvdXQgcmUtcGFyc2luZyBhbnl0aGluZy5cblx0YXdhaXQgdXBkYXRlU2Vzc2lvbigoc2Vzc2lvbikgPT4gKHtcblx0XHQuLi5zZXNzaW9uLFxuXHRcdGFkbWluVGFiSWQsXG5cdFx0c2NyYXBlVGFiSWQ6IHRhYi5pZCxcblx0XHRhdHRlbXB0czogMCxcblx0fSkpXG5cblx0YXdhaXQgc2V0UnVuU3RhdGUoe1xuXHRcdC4uLnByZXZpb3VzLFxuXHRcdHN0YXR1czogJ3J1bm5pbmcnLFxuXHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRpdGVtcyxcblx0XHRtZXNzYWdlOiB1bmRlZmluZWQsXG5cdFx0ZmluaXNoZWRBdDogdW5kZWZpbmVkLFxuXHR9KVxuXG5cdHRyeSB7XG5cdFx0YXdhaXQgZW5zdXJlQXR0YWNoZWQodGFiLmlkKVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBmYWlsUnVuKGRlc2NyaWJlRXJyb3IoZXJyb3IpKVxuXHR9XG5cblx0YXdhaXQgc2V0QmFkZ2UoJ+KApicpXG5cdHN0YXJ0S2VlcGFsaXZlKClcblx0YXdhaXQgY2hyb21lLmFsYXJtc1xuXHRcdC5jcmVhdGUoV0FUQ0hET0dfQUxBUk0sIHsgcGVyaW9kSW5NaW51dGVzOiBXQVRDSERPR19QRVJJT0RfTUlOVVRFUyB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcblx0bG9nKGByZXN1bWluZzogJHtvdXRzdGFuZGluZ30gb2YgJHtpdGVtcy5sZW5ndGh9IHBhZ2VzIHN0aWxsIG5lZWRlZGApXG5cdHJldHVybiBhZHZhbmNlKClcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGNhbmNlbFJ1bigpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0c3RvcEtlZXBhbGl2ZSgpXG5cdGF3YWl0IGNocm9tZS5hbGFybXMuY2xlYXIoV0FUQ0hET0dfQUxBUk0pLmNhdGNoKCgpID0+IHt9KVxuXG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRjb25zdCBjYW5jZWxsZWQ6IFJ1blN0YXRlID0ge1xuXHRcdC4uLnN0YXRlLFxuXHRcdHN0YXR1czogJ2NhbmNlbGxlZCcsXG5cdFx0Y3VycmVudEtleTogdW5kZWZpbmVkLFxuXHRcdGZpbmlzaGVkQXQ6IERhdGUubm93KCksXG5cdFx0bWVzc2FnZTogJ0NhbmNlbGxlZC4nLFxuXHR9XG5cdC8vIFN0YXR1cyBmaXJzdCwgdGhlbiB0aGUgdGFiIOKAlCBzZWUgZmluaXNoUnVuLlxuXHRhd2FpdCBzZXRSdW5TdGF0ZShjYW5jZWxsZWQpXG5cdGF3YWl0IGNsb3NlU2NyYXBlVGFiKClcblx0YXdhaXQgc2V0QmFkZ2UoJycpXG5cdGF3YWl0IGZvY3VzQWRtaW5UYWIoKVxuXHRhd2FpdCBub3RpZnlTdGF0ZShjYW5jZWxsZWQpXG5cdHJldHVybiBjYW5jZWxsZWRcbn1cblxuYXN5bmMgZnVuY3Rpb24gZmFpbFJ1bihtZXNzYWdlOiBzdHJpbmcpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdHN0b3BLZWVwYWxpdmUoKVxuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0Y29uc3QgZmFpbGVkOiBSdW5TdGF0ZSA9IHtcblx0XHQuLi5zdGF0ZSxcblx0XHRzdGF0dXM6ICdlcnJvcicsXG5cdFx0Y3VycmVudEtleTogdW5kZWZpbmVkLFxuXHRcdGZpbmlzaGVkQXQ6IERhdGUubm93KCksXG5cdFx0bWVzc2FnZSxcblx0fVxuXHRhd2FpdCBzZXRSdW5TdGF0ZShmYWlsZWQpXG5cdGF3YWl0IHNldEJhZGdlKCchJylcblx0YXdhaXQgbm90aWZ5U3RhdGUoZmFpbGVkKVxuXHRyZXR1cm4gZmFpbGVkXG59XG5cbi8vIOKUgOKUgCBNb3ZpbmcgdGhyb3VnaCB0aGUgcXVldWUg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKiBOYXZpZ2F0ZSB0byB0aGUgbmV4dCBwZW5kaW5nIGl0ZW0sIG9yIGZpbmlzaCBpZiB0aGVyZSBhcmUgbm9uZSBsZWZ0LiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFkdmFuY2UoKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnKSByZXR1cm4gc3RhdGVcblxuXHRjb25zdCBuZXh0ID0gc3RhdGUuaXRlbXMuZmluZCgoaXRlbSkgPT4gaXRlbS5zdGF0dXMgPT09ICdwZW5kaW5nJylcblxuXHRpZiAoIW5leHQpIHtcblx0XHQvLyBBdGhsZXRlIHBhZ2VzIGFyZSBkb25lIOKAlCBpcyB0aGVyZSBjb3Vyc2Ugd29yayB0byBhZGQgYmVmb3JlIGZpbmlzaGluZz9cblx0XHRjb25zdCBxdWV1ZWQgPSBhd2FpdCBxdWV1ZU5ld0NvdXJzZXMoKVxuXHRcdGlmIChxdWV1ZWQpIHJldHVybiBhZHZhbmNlKClcblx0XHRyZXR1cm4gZmluaXNoUnVuKClcblx0fVxuXG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKHNlc3Npb24uc2NyYXBlVGFiSWQgPT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBmYWlsUnVuKCdUaGUgc2NyYXBlIHRhYiBpcyBnb25lLicpXG5cdH1cblxuXHRhd2FpdCBjYW5jZWxTY2hlZHVsZWRSZXRyeSgpXG5cdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHMpID0+ICh7IC4uLnMsIGF0dGVtcHRzOiAwIH0pKVxuXHRhd2FpdCBjbGVhckxhc3REb2N1bWVudChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXG5cdGNvbnN0IHJ1bm5pbmc6IFJ1blN0YXRlID0ge1xuXHRcdC4uLnN0YXRlLFxuXHRcdGN1cnJlbnRLZXk6IG5leHQua2V5LFxuXHRcdGl0ZW1zOiBzdGF0ZS5pdGVtcy5tYXAoKGl0ZW0pID0+XG5cdFx0XHRpdGVtLmtleSA9PT0gbmV4dC5rZXlcblx0XHRcdFx0PyB7XG5cdFx0XHRcdFx0XHQuLi5pdGVtLFxuXHRcdFx0XHRcdFx0c3RhdHVzOiAnYWN0aXZlJyxcblx0XHRcdFx0XHRcdGRldGFpbDogJ0xvYWRpbmfigKYnLFxuXHRcdFx0XHRcdFx0YXR0ZW1wdHM6IDAsXG5cdFx0XHRcdFx0XHR1cGRhdGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHQ6IGl0ZW0sXG5cdFx0KSxcblx0XHRtZXNzYWdlOiB1bmRlZmluZWQsXG5cdH1cblx0YXdhaXQgc2V0UnVuU3RhdGUocnVubmluZylcblx0YXdhaXQgbm90aWZ5U3RhdGUocnVubmluZylcblxuXHRsb2coYOKGkiAke25leHQubGFiZWx9OiAke25leHQudXJsfWApXG5cblx0dHJ5IHtcblx0XHRhd2FpdCBlbnN1cmVBdHRhY2hlZChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXHRcdGF3YWl0IGNocm9tZS50YWJzLnVwZGF0ZShzZXNzaW9uLnNjcmFwZVRhYklkLCB7IHVybDogbmV4dC51cmwgfSlcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRyZXR1cm4gZmFpbFJ1bihkZXNjcmliZUVycm9yKGVycm9yKSlcblx0fVxuXG5cdHJldHVybiBydW5uaW5nXG59XG5cbi8qKlxuICogQ2FsbGVkIGZvciBldmVyeSBmaW5pc2hlZCBtYWluLWZyYW1lIGRvY3VtZW50IGluIHRoZSBzY3JhcGUgdGFiLlxuICpcbiAqIElnbm9yZXMgYW55dGhpbmcgdGhhdCBpc24ndCB0aGUgcGFnZSB0aGUgY3VycmVudCBpdGVtIGFza2VkIGZvciDigJQgcGFya3J1blxuICogcmVkaXJlY3RzLCBhbmQgYSBjaGFsbGVuZ2UgcGFnZSBjYW4gbmF2aWdhdGUgYSBmZXcgdGltZXMgYmVmb3JlIHNldHRsaW5nLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlRG9jdW1lbnRMb2FkZWQodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnIHx8ICFzdGF0ZS5jdXJyZW50S2V5KSByZXR1cm5cblxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0Y29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGkpID0+IGkua2V5ID09PSBzdGF0ZS5jdXJyZW50S2V5KVxuXHRpZiAoIWl0ZW0pIHJldHVyblxuXG5cdC8vIERlbGliZXJhdGVseSBub3QgcmVxdWlyaW5nIGBmaW5pc2hlZGA6IHRoaXMgcnVucyBmcm9tIHRoZSBkZWJ1Z2dlcidzXG5cdC8vIGxvYWRpbmdGaW5pc2hlZCBldmVudCAqYW5kKiBmcm9tIHRhYnMub25VcGRhdGVkLCBiZWNhdXNlIHRoZSBkZWJ1Z2dlciBldmVudHNcblx0Ly8gYXJlIG5vdCByZWxpYWJseSBkZWxpdmVyZWQg4oCUIGEgcnVuIHdvdWxkIG90aGVyd2lzZSBzaXQgb24gXCJMb2FkaW5n4oCmXCIgdW50aWxcblx0Ly8gdGhlIHdhdGNoZG9nIG5vdGljZWQuIFdoaWNoZXZlciB0cmlnZ2VyIGFycml2ZXMgZmlyc3Qgd2l0aCBhIHJlYWRhYmxlIGJvZHlcblx0Ly8gd2lucywgYW5kIGEgYm9keSB0aGF0IGlzbid0IHJlYWR5IHlldCBpcyBzaW1wbHkgd2FpdGVkIG91dC5cblx0Y29uc3QgZG9jdW1lbnQgPSBhd2FpdCBnZXRMYXN0RG9jdW1lbnQodGFiSWQpXG5cdGlmICghZG9jdW1lbnQgfHwgZG9jdW1lbnQuY29uc3VtZWQpIHJldHVyblxuXG5cdGxldCBjYXB0dXJlZDogQXdhaXRlZDxSZXR1cm5UeXBlPHR5cGVvZiByZWFkQm9keT4+XG5cdHRyeSB7XG5cdFx0Y2FwdHVyZWQgPSBhd2FpdCByZWFkQm9keSh0YWJJZCwgZG9jdW1lbnQpXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0aWYgKGlzQm9keU5vdFJlYWR5KGVycm9yKSkgcmV0dXJuXG5cblx0XHRjb25zdCBhdHRlbXB0cyA9IChcblx0XHRcdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHMpID0+ICh7IC4uLnMsIGF0dGVtcHRzOiBzLmF0dGVtcHRzICsgMSB9KSlcblx0XHQpLmF0dGVtcHRzXG5cdFx0bG9nKGAke2l0ZW0ubGFiZWx9OiBjb3VsZCBub3QgcmVhZCBib2R5IOKAlCAke2Rlc2NyaWJlRXJyb3IoZXJyb3IpfWApXG5cdFx0aWYgKGF0dGVtcHRzID49IE1BWF9BVFRFTVBUUykge1xuXHRcdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhpdGVtLmtleSwgJ2ZhaWxlZCcsIGRlc2NyaWJlRXJyb3IoZXJyb3IpLCBhdHRlbXB0cylcblx0XHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0XHRhd2FpdCBhZHZhbmNlKClcblx0XHR9XG5cdFx0cmV0dXJuXG5cdH1cblxuXHRjb25zdCBhdHRlbXB0cyA9IChcblx0XHRhd2FpdCB1cGRhdGVTZXNzaW9uKChzKSA9PiAoeyAuLi5zLCBhdHRlbXB0czogcy5hdHRlbXB0cyArIDEgfSkpXG5cdCkuYXR0ZW1wdHNcblxuXHRjb25zdCB2ZXJkaWN0ID0gdmFsaWRhdGUoaXRlbS5raW5kLCBpdGVtLmtleSwgY2FwdHVyZWQuc3RhdHVzLCBjYXB0dXJlZC5ib2R5KVxuXHRsb2coXG5cdFx0YCR7aXRlbS5sYWJlbH06IEhUVFAgJHtjYXB0dXJlZC5zdGF0dXN9LCAke2NhcHR1cmVkLmJvZHkubGVuZ3RofSBieXRlcyDihpIgJHt2ZXJkaWN0Lm91dGNvbWV9ICgke3ZlcmRpY3QuZGV0YWlsfSlgLFxuXHQpXG5cblx0aWYgKHZlcmRpY3Qub3V0Y29tZSA9PT0gJ2Jsb2NrZWQnKSB7XG5cdFx0Ly8gQSBjaGFsbGVuZ2Ugd2l0aCBzb21ldGhpbmcgb24gc2NyZWVuIHRvIHNvbHZlOiB3YWl0IGluZGVmaW5pdGVseSwgYW5kXG5cdFx0Ly8gY3J1Y2lhbGx5IGRvIE5PVCByZWxvYWQg4oCUIHRoYXQgd291bGQgd2lwZSBvdXQgYSBoYWxmLWZpbmlzaGVkIGNhcHRjaGEuXG5cdFx0Ly8gU29sdmluZyBpdCBuYXZpZ2F0ZXMgdGhlIHBhZ2UsIHdoaWNoIGJyaW5ncyB1cyBiYWNrIGhlcmUgYnkgaXRzZWxmLlxuXHRcdGlmICh2ZXJkaWN0LmF3YWl0VXNlcikge1xuXHRcdFx0bG9nKGAke2l0ZW0ubGFiZWx9OiB3YWl0aW5nIGZvciB0aGUgdXNlciB0byBjbGVhciBhIGNoYWxsZW5nZWApXG5cdFx0XHRhd2FpdCBjYW5jZWxTY2hlZHVsZWRSZXRyeSgpXG5cdFx0XHRhd2FpdCB1cGRhdGVSdW5TdGF0ZSgoY3VycmVudCkgPT4gKHtcblx0XHRcdFx0Li4uY3VycmVudCxcblx0XHRcdFx0aXRlbXM6IGN1cnJlbnQuaXRlbXMubWFwKChpKSA9PlxuXHRcdFx0XHRcdGkua2V5ID09PSBpdGVtLmtleVxuXHRcdFx0XHRcdFx0PyB7XG5cdFx0XHRcdFx0XHRcdFx0Li4uaSxcblx0XHRcdFx0XHRcdFx0XHRzdGF0dXM6ICdibG9ja2VkJyBhcyBjb25zdCxcblx0XHRcdFx0XHRcdFx0XHRkZXRhaWw6IHZlcmRpY3QuZGV0YWlsLFxuXHRcdFx0XHRcdFx0XHRcdGF0dGVtcHRzLFxuXHRcdFx0XHRcdFx0XHRcdGF3YWl0VXNlcjogdHJ1ZSxcblx0XHRcdFx0XHRcdFx0XHR1cGRhdGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdDogaSxcblx0XHRcdFx0KSxcblx0XHRcdH0pKVxuXHRcdFx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0XHRcdHJldHVyblxuXHRcdH1cblxuXHRcdGlmIChhdHRlbXB0cyA+PSBNQVhfQVRURU1QVFMpIHtcblx0XHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRcdGl0ZW0ua2V5LFxuXHRcdFx0XHQnZmFpbGVkJyxcblx0XHRcdFx0YCR7dmVyZGljdC5kZXRhaWx9IEdhdmUgdXAgYWZ0ZXIgJHthdHRlbXB0c30gYXR0ZW1wdHMuYCxcblx0XHRcdClcblx0XHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0XHRhd2FpdCBhZHZhbmNlKClcblx0XHRcdHJldHVyblxuXHRcdH1cblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0aXRlbS5rZXksXG5cdFx0XHQnYmxvY2tlZCcsXG5cdFx0XHRgJHt2ZXJkaWN0LmRldGFpbH0gKGF0dGVtcHQgJHthdHRlbXB0c30gb2YgJHtNQVhfQVRURU1QVFN9OyByZXRyeWluZyBhdXRvbWF0aWNhbGx5KWAsXG5cdFx0XHRhdHRlbXB0cyxcblx0XHQpXG5cdFx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0XHRhd2FpdCBzY2hlZHVsZVJldHJ5KClcblx0XHRyZXR1cm5cblx0fVxuXG5cdGlmICh2ZXJkaWN0Lm91dGNvbWUgPT09ICd1bnVzYWJsZScpIHtcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKGl0ZW0ua2V5LCAnZmFpbGVkJywgdmVyZGljdC5kZXRhaWwpXG5cdFx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0XHRhd2FpdCBhZHZhbmNlKClcblx0XHRyZXR1cm5cblx0fVxuXG5cdC8vIC0tLSBDYXB0dXJlZCBzb21ldGhpbmcgdXNhYmxlIC0tLVxuXG5cdC8vIENsYWltIGl0IGJlZm9yZSBkb2luZyBhbnl0aGluZyBlbHNlLCBzbyB0aGUgb3RoZXIgdHJpZ2dlciBib3dzIG91dC5cblx0YXdhaXQgbWFya0RvY3VtZW50Q29uc3VtZWQodGFiSWQsIGRvY3VtZW50KVxuXG5cdGlmIChpdGVtLmtpbmQgPT09ICdjb3Vyc2UnKSB7XG5cdFx0YXdhaXQgaGFuZGxlQ291cnNlUGFnZShpdGVtLCBjYXB0dXJlZC5ib2R5KVxuXHR9IGVsc2Uge1xuXHRcdGF3YWl0IGRlbGl2ZXIoe1xuXHRcdFx0a2luZDogaXRlbS5raW5kLFxuXHRcdFx0a2V5OiBpdGVtLmtleSxcblx0XHRcdG5hbWU6IGZpbGVOYW1lRm9yKGl0ZW0ua2luZCwgaXRlbS5rZXkpLFxuXHRcdFx0dGV4dDogY2FwdHVyZWQuYm9keSxcblx0XHR9KVxuXHRcdGlmIChpdGVtLmtpbmQgPT09ICdhdGhsZXRlJykgYXdhaXQgcmVjb3JkRXZlbnRzKGNhcHR1cmVkLmJvZHkpXG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhpdGVtLmtleSwgJ2NhcHR1cmVkJywgdmVyZGljdC5kZXRhaWwpXG5cdH1cblxuXHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRhd2FpdCBhZHZhbmNlKClcbn1cblxuLy8g4pSA4pSAIENvdXJzZXMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogQSBjb3Vyc2UgcGFnZSBvbmx5IHRlbGxzIHVzIHRoZSBtYXAgaWQ7IHRoZSBLTVogY29tZXMgZnJvbSBHb29nbGUsIHdoaWNoXG4gKiBzZXJ2ZXMgaXQgdG8gYSBwbGFpbiBmZXRjaCDigJQgbm8gbmF2aWdhdGlvbiwgbm8gY29va2llcy5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gaGFuZGxlQ291cnNlUGFnZShpdGVtOiBJdGVtU3RhdGUsIGh0bWw6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBtaWQgPSBleHRyYWN0TWFwTWlkKGh0bWwpXG5cdGlmICghbWlkKSB7XG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhpdGVtLmtleSwgJ2ZhaWxlZCcsICdObyBtYXAgaWQgb24gdGhlIGNvdXJzZSBwYWdlLicpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHR0cnkge1xuXHRcdGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goY291cnNlS216VXJsKG1pZCkpXG5cdFx0aWYgKCFyZXNwb25zZS5vaykgdGhyb3cgbmV3IEVycm9yKGBHb29nbGUgcmVwbGllZCAke3Jlc3BvbnNlLnN0YXR1c31gKVxuXG5cdFx0Y29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShhd2FpdCByZXNwb25zZS5hcnJheUJ1ZmZlcigpKVxuXHRcdGlmIChieXRlc1swXSAhPT0gMHg1MCB8fCBieXRlc1sxXSAhPT0gMHg0Yikge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKCdEb3dubG9hZGVkIGZpbGUgaXMgbm90IGEgS01aIGFyY2hpdmUnKVxuXHRcdH1cblxuXHRcdGF3YWl0IGRlbGl2ZXIoe1xuXHRcdFx0a2luZDogJ2NvdXJzZScsXG5cdFx0XHRrZXk6IGl0ZW0ua2V5LFxuXHRcdFx0bmFtZTogYCR7aXRlbS5rZXl9LmttemAsXG5cdFx0XHRiYXNlNjQ6IHRvQmFzZTY0KGJ5dGVzKSxcblx0XHR9KVxuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdjYXB0dXJlZCcsXG5cdFx0XHRgS01aIGRvd25sb2FkZWQgKCR7TWF0aC5yb3VuZChieXRlcy5sZW5ndGggLyAxMDI0KX0gS0IpYCxcblx0XHQpXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRcdGl0ZW0ua2V5LFxuXHRcdFx0J2ZhaWxlZCcsXG5cdFx0XHRgQ291bGRuJ3QgZG93bmxvYWQgdGhlIEtNWjogJHtkZXNjcmliZUVycm9yKGVycm9yKX1gLFxuXHRcdClcblx0fVxufVxuXG4vKiogUmVtZW1iZXIgZXZlcnkgZXZlbnQgYW4gYXRobGV0ZSBwYWdlIG1lbnRpb25zLCBmb3IgdGhlIGNvdXJzZSBodW50LiAqL1xuYXN5bmMgZnVuY3Rpb24gcmVjb3JkRXZlbnRzKGh0bWw6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBldmVudHMgPSBleHRyYWN0RXZlbnRzKHBhcnNlUnVuUmVzdWx0cyhodG1sKSlcblx0aWYgKGV2ZW50cy5sZW5ndGggPT09IDApIHJldHVyblxuXG5cdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHNlc3Npb24pID0+IHtcblx0XHRjb25zdCBkaXNjb3ZlcmVkID0geyAuLi5zZXNzaW9uLmRpc2NvdmVyZWRFdmVudHMgfVxuXHRcdGZvciAoY29uc3QgZXZlbnQgb2YgZXZlbnRzKSB7XG5cdFx0XHRpZiAoIWRpc2NvdmVyZWRbZXZlbnQuZXZlbnRJZF0pIHtcblx0XHRcdFx0ZGlzY292ZXJlZFtldmVudC5ldmVudElkXSA9IHsgbmFtZTogZXZlbnQubmFtZSwgdXJsOiBldmVudC51cmwgfVxuXHRcdFx0fVxuXHRcdH1cblx0XHRyZXR1cm4geyAuLi5zZXNzaW9uLCBkaXNjb3ZlcmVkRXZlbnRzOiBkaXNjb3ZlcmVkIH1cblx0fSlcbn1cblxuLyoqXG4gKiBFeHRlbmQgdGhlIHF1ZXVlIHdpdGggYSBjb3Vyc2UgcGFnZSBwZXIgZXZlbnQgdGhhdCBoYXMgbm8gbWFwIHlldC4gUnVucyBvbmNlLFxuICogYWZ0ZXIgdGhlIGF0aGxldGUgcGFnZXMsIHNpbmNlIHRoYXQncyB3aGVuIHdlIGtub3cgd2hpY2ggZXZlbnRzIGV4aXN0LlxuICovXG5hc3luYyBmdW5jdGlvbiBxdWV1ZU5ld0NvdXJzZXMoKTogUHJvbWlzZTxib29sZWFuPiB7XG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKHNlc3Npb24uY291cnNlc1F1ZXVlZCB8fCBzZXNzaW9uLnNraXBDb3Vyc2VzKSByZXR1cm4gZmFsc2VcblxuXHRhd2FpdCB1cGRhdGVTZXNzaW9uKChzKSA9PiAoeyAuLi5zLCBjb3Vyc2VzUXVldWVkOiB0cnVlIH0pKVxuXG5cdGNvbnN0IGtub3duID0gbmV3IFNldChzZXNzaW9uLmtub3duQ291cnNlRXZlbnRJZHMpXG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRjb25zdCBhbHJlYWR5UXVldWVkID0gbmV3IFNldChcblx0XHRzdGF0ZS5pdGVtcy5maWx0ZXIoKGkpID0+IGkua2luZCA9PT0gJ2NvdXJzZScpLm1hcCgoaSkgPT4gaS5rZXkpLFxuXHQpXG5cblx0Y29uc3QgaXRlbXM6IEl0ZW1TdGF0ZVtdID0gT2JqZWN0LmVudHJpZXMoc2Vzc2lvbi5kaXNjb3ZlcmVkRXZlbnRzKVxuXHRcdC5maWx0ZXIoKFtldmVudElkXSkgPT4gIWtub3duLmhhcyhldmVudElkKSAmJiAhYWxyZWFkeVF1ZXVlZC5oYXMoZXZlbnRJZCkpXG5cdFx0Lm1hcCgoW2V2ZW50SWQsIGV2ZW50XSkgPT4gKHtcblx0XHRcdGtpbmQ6ICdjb3Vyc2UnIGFzIGNvbnN0LFxuXHRcdFx0a2V5OiBldmVudElkLFxuXHRcdFx0bGFiZWw6IGAke2V2ZW50Lm5hbWV9IGNvdXJzZSBtYXBgLFxuXHRcdFx0dXJsOiBjb3Vyc2VQYWdlVXJsKGV2ZW50LnVybCksXG5cdFx0XHRzdGF0dXM6ICdwZW5kaW5nJyBhcyBjb25zdCxcblx0XHR9KSlcblx0XHQuc29ydCgoYSwgYikgPT4gYS5sYWJlbC5sb2NhbGVDb21wYXJlKGIubGFiZWwpKVxuXG5cdGlmIChpdGVtcy5sZW5ndGggPT09IDApIHJldHVybiBmYWxzZVxuXG5cdGNvbnN0IG5leHQgPSBhd2FpdCBhcHBlbmRJdGVtcyhpdGVtcylcblx0YXdhaXQgbm90aWZ5U3RhdGUobmV4dClcblx0cmV0dXJuIHRydWVcbn1cblxuLy8g4pSA4pSAIEZpbmlzaGluZyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuYXN5bmMgZnVuY3Rpb24gZmluaXNoUnVuKCk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRzdG9wS2VlcGFsaXZlKClcblx0YXdhaXQgY2hyb21lLmFsYXJtcy5jbGVhcihXQVRDSERPR19BTEFSTSkuY2F0Y2goKCkgPT4ge30pXG5cblx0Ly8gQW55dGhpbmcgbm90IGluIGEgdGVybWluYWwgc3RhdGUgYXQgdGhpcyBwb2ludCBuZXZlciBjb21wbGV0ZWQ7IGNhbGwgaXQgYVxuXHQvLyBmYWlsdXJlIHJhdGhlciB0aGFuIHF1aWV0bHkgcmVwb3J0aW5nIHN1Y2Nlc3MgZm9yIGEgcGFnZSB3ZSBuZXZlciBnb3QuXG5cdGNvbnN0IHNldHRsZWQgPSBhd2FpdCB1cGRhdGVSdW5TdGF0ZSgoY3VycmVudCkgPT4gKHtcblx0XHQuLi5jdXJyZW50LFxuXHRcdGl0ZW1zOiBjdXJyZW50Lml0ZW1zLm1hcCgoaXRlbSkgPT5cblx0XHRcdGl0ZW0uc3RhdHVzID09PSAnY2FwdHVyZWQnIHx8XG5cdFx0XHRpdGVtLnN0YXR1cyA9PT0gJ2ZhaWxlZCcgfHxcblx0XHRcdGl0ZW0uc3RhdHVzID09PSAnc2tpcHBlZCdcblx0XHRcdFx0PyBpdGVtXG5cdFx0XHRcdDoge1xuXHRcdFx0XHRcdFx0Li4uaXRlbSxcblx0XHRcdFx0XHRcdHN0YXR1czogJ2ZhaWxlZCcgYXMgY29uc3QsXG5cdFx0XHRcdFx0XHRkZXRhaWw6IGl0ZW0uZGV0YWlsID8/ICdOZXZlciBjb21wbGV0ZWQuJyxcblx0XHRcdFx0XHR9LFxuXHRcdCksXG5cdH0pKVxuXG5cdGNvbnN0IHN0YXRlID0gc2V0dGxlZFxuXHRjb25zdCBjYXB0dXJlZCA9IHN0YXRlLml0ZW1zLmZpbHRlcigoaSkgPT4gaS5zdGF0dXMgPT09ICdjYXB0dXJlZCcpLmxlbmd0aFxuXHRjb25zdCBmYWlsZWQgPSBzdGF0ZS5pdGVtcy5maWx0ZXIoKGkpID0+IGkuc3RhdHVzID09PSAnZmFpbGVkJykubGVuZ3RoXG5cblx0Y29uc3QgZG9uZTogUnVuU3RhdGUgPSB7XG5cdFx0Li4uc3RhdGUsXG5cdFx0c3RhdHVzOiAnZG9uZScsXG5cdFx0Y3VycmVudEtleTogdW5kZWZpbmVkLFxuXHRcdGZpbmlzaGVkQXQ6IERhdGUubm93KCksXG5cdFx0bWVzc2FnZTogZmFpbGVkXG5cdFx0XHQ/IGBDYXB0dXJlZCAke2NhcHR1cmVkfSBvZiAke3N0YXRlLml0ZW1zLmxlbmd0aH07ICR7ZmFpbGVkfSBmYWlsZWQuYFxuXHRcdFx0OiBgQ2FwdHVyZWQgYWxsICR7Y2FwdHVyZWR9IHBhZ2VzLmAsXG5cdH1cblx0Ly8gVGhlIHRlcm1pbmFsIHN0YXR1cyBpcyB3cml0dGVuICpiZWZvcmUqIHRoZSB0YWIgaXMgY2xvc2VkLiBDbG9zaW5nIGl0IGZpcnN0XG5cdC8vIGZpcmVzIHRhYnMub25SZW1vdmVkIHdoaWxlIHRoZSBydW4gc3RpbGwgcmVhZHMgYXMgXCJydW5uaW5nXCIsIGFuZCB0aGF0IGhhbmRsZXJcblx0Ly8gd291bGQgb3ZlcndyaXRlIHRoaXMgd2l0aCBcInRoZSBzY3JhcGUgdGFiIHdhcyBjbG9zZWRcIiDigJQgcmVwb3J0aW5nIGEgZmluaXNoZWRcblx0Ly8gc2NyYXBlIGFzIGNhbmNlbGxlZC5cblx0YXdhaXQgc2V0UnVuU3RhdGUoZG9uZSlcblx0YXdhaXQgY2xvc2VTY3JhcGVUYWIoKVxuXHRhd2FpdCBzZXRCYWRnZShmYWlsZWQgPyBTdHJpbmcoZmFpbGVkKSA6ICcnKVxuXHRhd2FpdCBmb2N1c0FkbWluVGFiKClcblx0YXdhaXQgbm90aWZ5U3RhdGUoZG9uZSlcblx0YXdhaXQgbm90aWZ5RmluaXNoZWQoZG9uZSlcblx0cmV0dXJuIGRvbmVcbn1cblxuLyoqIERldGFjaCBhbmQgY2xvc2UgdGhlIHNjcmFwZSB0YWIuIE9ubHkgY2FsbCBvbmNlIGEgdGVybWluYWwgc3RhdHVzIGlzIHN0b3JlZC4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNsb3NlU2NyYXBlVGFiKCk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCB7IHNjcmFwZVRhYklkIH0gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKHNjcmFwZVRhYklkID09PSB1bmRlZmluZWQpIHJldHVyblxuXHRhd2FpdCBkZXRhY2goc2NyYXBlVGFiSWQpXG5cdGF3YWl0IGNsZWFyTGFzdERvY3VtZW50KHNjcmFwZVRhYklkKVxuXHRhd2FpdCBjaHJvbWUudGFicy5yZW1vdmUoc2NyYXBlVGFiSWQpLmNhdGNoKCgpID0+IHt9KVxufVxuXG4vKiogVGhlIHJ1biBpcyBvdmVyIOKAlCBoYW5kIHRoZSBhZG1pbiBwYWdlIGZvY3VzIGJhY2suICovXG5hc3luYyBmdW5jdGlvbiBmb2N1c0FkbWluVGFiKCk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCB7IGFkbWluVGFiSWQgfSA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoYWRtaW5UYWJJZCA9PT0gdW5kZWZpbmVkKSByZXR1cm5cblx0dHJ5IHtcblx0XHRjb25zdCB0YWIgPSBhd2FpdCBjaHJvbWUudGFicy5nZXQoYWRtaW5UYWJJZClcblx0XHRhd2FpdCBjaHJvbWUudGFicy51cGRhdGUoYWRtaW5UYWJJZCwgeyBhY3RpdmU6IHRydWUgfSlcblx0XHRpZiAodGFiLndpbmRvd0lkICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdGF3YWl0IGNocm9tZS53aW5kb3dzLnVwZGF0ZSh0YWIud2luZG93SWQsIHsgZm9jdXNlZDogdHJ1ZSB9KVxuXHRcdH1cblx0fSBjYXRjaCB7XG5cdFx0Ly8gVGhlIGFkbWluIHRhYiB3YXMgY2xvc2VkOyBmaWxlcyBzdGF5IGluIHN0b3JhZ2UgZm9yIHRoZSBuZXh0IHZpc2l0LlxuXHR9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIG5vdGlmeUZpbmlzaGVkKHN0YXRlOiBSdW5TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCB7IGFkbWluVGFiSWQgfSA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoYWRtaW5UYWJJZCA9PT0gdW5kZWZpbmVkKSByZXR1cm5cblx0YXdhaXQgY2hyb21lLnRhYnNcblx0XHQuc2VuZE1lc3NhZ2UoYWRtaW5UYWJJZCwgeyB0eXBlOiAnZmluaXNoZWQnLCBzdGF0ZSB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcbn1cblxuLy8g4pSA4pSAIERlbGl2ZXJ5IOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKiogUGVyc2lzdCBhIGNhcHR1cmVkIGZpbGUgYW5kIHB1c2ggaXQgdG8gdGhlIGFkbWluIHBhZ2Ugc3RyYWlnaHQgYXdheS4gKi9cbmFzeW5jIGZ1bmN0aW9uIGRlbGl2ZXIoZmlsZTogQ2FwdHVyZWRGaWxlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IHB1dEZpbGUoZmlsZSlcblx0YXdhaXQgbm90aWZ5RmlsZShmaWxlKVxufVxuXG4vKiogUmUtc2VuZCBldmVyeXRoaW5nIGNhcHR1cmVkIHNvIGZhciwgZS5nLiBhZnRlciB0aGUgYWRtaW4gcGFnZSByZWxvYWRlZC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXNlbmRGaWxlcygpOiBQcm9taXNlPHZvaWQ+IHtcblx0Zm9yIChjb25zdCBmaWxlIG9mIGF3YWl0IGdldEZpbGVzKCkpIGF3YWl0IG5vdGlmeUZpbGUoZmlsZSlcbn1cblxuZnVuY3Rpb24gZmlsZU5hbWVGb3Ioa2luZDogQ2FwdHVyZWRGaWxlWydraW5kJ10sIGtleTogc3RyaW5nKTogc3RyaW5nIHtcblx0c3dpdGNoIChraW5kKSB7XG5cdFx0Y2FzZSAnYXRobGV0ZSc6XG5cdFx0XHRyZXR1cm4gYGF0aGxldGUtJHtrZXl9Lmh0bWxgXG5cdFx0Y2FzZSAnZXZlbnQnOlxuXHRcdFx0cmV0dXJuIGAke2tleX0tbGF0ZXN0LXJlc3VsdHMuaHRtbGBcblx0XHRjYXNlICdjbHVicyc6XG5cdFx0XHRyZXR1cm4gJ2xhcmdlc3QtY2x1YnMuaHRtbCdcblx0XHRkZWZhdWx0OlxuXHRcdFx0cmV0dXJuIGAke2tleX0ua216YFxuXHR9XG59XG5cbmZ1bmN0aW9uIHRvQmFzZTY0KGJ5dGVzOiBVaW50OEFycmF5KTogc3RyaW5nIHtcblx0bGV0IGJpbmFyeSA9ICcnXG5cdC8vIENodW5rZWQgdG8gc3RheSB3ZWxsIGNsZWFyIG9mIHRoZSBhcmd1bWVudCBsaW1pdCBvbiBsYXJnZSBhcmNoaXZlcy5cblx0Zm9yIChsZXQgaSA9IDA7IGkgPCBieXRlcy5sZW5ndGg7IGkgKz0gMHg4MDAwKSB7XG5cdFx0YmluYXJ5ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoLi4uYnl0ZXMuc3ViYXJyYXkoaSwgaSArIDB4ODAwMCkpXG5cdH1cblx0cmV0dXJuIGJ0b2EoYmluYXJ5KVxufVxuXG5hc3luYyBmdW5jdGlvbiBzZXRCYWRnZSh0ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0IH0pLmNhdGNoKCgpID0+IHt9KVxufVxuIiwiLyoqXG4gKiBBIG9uZS1hdC1hLXRpbWUgcXVldWUuXG4gKlxuICogQ2FwdHVyZXMgYXJlIHRyaWdnZXJlZCBmcm9tIHR3byBwbGFjZXMg4oCUIHRoZSBkZWJ1Z2dlcidzIGBsb2FkaW5nRmluaXNoZWRgIGFuZFxuICogYHRhYnMub25VcGRhdGVkYCDigJQgYmVjYXVzZSBuZWl0aGVyIGlzIHJlbGlhYmxlIGVub3VnaCBhbG9uZS4gVGhhdCBtZWFucyBib3RoXG4gKiBjYW4gZmlyZSBmb3IgdGhlIHNhbWUgcGFnZSBsb2FkLCBhbmQgaWYgdGhleSBpbnRlcmxlYXZlIHRoZXkgZWFjaCBjYXB0dXJlIGFuZFxuICogZWFjaCBjYWxsIGBhZHZhbmNlKClgLCB3aGljaCB3YWxrcyB0aGUgcXVldWUgdHdpY2UgYW5kIHNpbGVudGx5IHNraXBzIGFuIGl0ZW0uXG4gKlxuICogRXZlcnl0aGluZyB0aGF0IHJlYWRzLXRoZW4td3JpdGVzIHJ1biBzdGF0ZSBnb2VzIHRocm91Z2ggaGVyZSBzbyB0aGF0IGNhbid0XG4gKiBoYXBwZW4uIFRoZSBjaGFpbiBsaXZlcyBpbiBtb2R1bGUgc2NvcGUsIHdoaWNoIHJlc2V0cyB3aGVuIHRoZSBzZXJ2aWNlIHdvcmtlclxuICogcmVzdGFydHMg4oCUIGZpbmUsIGJlY2F1c2Ugb3JkZXJpbmcgb25seSBtYXR0ZXJzIHdpdGhpbiBhIGJ1cnN0IG9mIGV2ZW50cy5cbiAqL1xubGV0IGNoYWluOiBQcm9taXNlPHVua25vd24+ID0gUHJvbWlzZS5yZXNvbHZlKClcblxuZXhwb3J0IGZ1bmN0aW9uIHNlcmlhbDxUPih3b3JrOiAoKSA9PiBQcm9taXNlPFQ+KTogUHJvbWlzZTxUPiB7XG5cdGNvbnN0IG5leHQgPSBjaGFpbi50aGVuKHdvcmssIHdvcmspXG5cdC8vIFN3YWxsb3cgcmVqZWN0aW9ucyBvbiB0aGUgY2hhaW4gaXRzZWxmIHNvIG9uZSBmYWlsdXJlIGNhbid0IHBvaXNvbiB0aGUgcXVldWU7XG5cdC8vIHRoZSByZXR1cm5lZCBwcm9taXNlIHN0aWxsIHJlamVjdHMgZm9yIHRoZSBjYWxsZXIuXG5cdGNoYWluID0gbmV4dC5jYXRjaCgoKSA9PiB1bmRlZmluZWQpXG5cdHJldHVybiBuZXh0XG59XG4iLCIvKipcbiAqIFNlcnZpY2Ugd29ya2VyOiB0aGUgZXh0ZW5zaW9uJ3Mgb25seSBsb25nLWxpdmVkIGxvZ2ljLCBleGNlcHQgaXQgaXNuJ3RcbiAqIGxvbmctbGl2ZWQgYXQgYWxsIOKAlCBDaHJvbWUgdGVybWluYXRlcyBpdCB3aGVuZXZlciBpdCBnb2VzIGlkbGUuXG4gKlxuICogRXZlcnkgbGlzdGVuZXIgYmVsb3cgaXMgcmVnaXN0ZXJlZCBzeW5jaHJvbm91c2x5IGF0IHRoZSB0b3AgbGV2ZWwuIFRoYXQncyB3aGF0XG4gKiBtYWtlcyB0aGUgcnVuIHN1cnZpdmU6IGEgcmVnaXN0ZXJlZCBsaXN0ZW5lciBjYXVzZXMgQ2hyb21lIHRvICpzdGFydCogdGhlXG4gKiB3b3JrZXIgdG8gZGVsaXZlciBpdHMgZXZlbnQsIHNvIHRoZSBkZWJ1Z2dlciBldmVudHMgYW5kIG1lc3NhZ2VzIHRoYXQgZHJpdmUgYVxuICogcnVuIHdha2UgaXQgYmFjayB1cC4gQWxsIHN0YXRlIGxpdmVzIGluIGNocm9tZS5zdG9yYWdlIChzZWUgc3RhdGUudHMpLCBuZXZlclxuICogaW4gbW9kdWxlIHNjb3BlLlxuICovXG5pbXBvcnQge1xuXHR0eXBlIFBhZ2VNZXNzYWdlLFxuXHRTQ1JBUEVSX1BST1RPQ09MX1ZFUlNJT04sXG59IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcbmltcG9ydCB7IGRldGFjaCwgbm90ZURvY3VtZW50UmVzcG9uc2UsIG5vdGVMb2FkaW5nRmluaXNoZWQgfSBmcm9tICcuL2NhcHR1cmUnXG5pbXBvcnQge1xuXHRpc0Zyb21BZG1pblBhZ2UsXG5cdG9wZW5BZG1pblBhZ2UsXG5cdHJlbWVtYmVyQWRtaW5PcmlnaW4sXG59IGZyb20gJy4vb3BlbkFkbWluJ1xuaW1wb3J0IHtcblx0YWR2YW5jZSxcblx0Y2FuY2VsUnVuLFxuXHRjaGVja0ZvclN0YWxsLFxuXHRmb3JnZXRSdW4sXG5cdGhhbmRsZURvY3VtZW50TG9hZGVkLFxuXHRyZWNvdmVyTWlzc2VkQ2FwdHVyZSxcblx0cmVzZW5kRmlsZXMsXG5cdHJlc3VtZVJ1bixcblx0cmV0cnlDdXJyZW50LFxuXHRyZXRyeUlmU3RpbGxCbG9ja2VkLFxuXHRza2lwQ3VycmVudCxcblx0c3RhcnRSdW4sXG59IGZyb20gJy4vcnVuJ1xuaW1wb3J0IHsgc2VyaWFsIH0gZnJvbSAnLi9zZXJpYWwnXG5pbXBvcnQgeyBnZXRSdW5TdGF0ZSwgZ2V0U2Vzc2lvbiwgc2V0UnVuU3RhdGUgfSBmcm9tICcuL3N0YXRlJ1xuXG4vLyDilIDilIAgTWVzc2FnZXMgZnJvbSBjb250ZW50IHNjcmlwdHMg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmNocm9tZS5ydW50aW1lLm9uTWVzc2FnZS5hZGRMaXN0ZW5lcigobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpID0+IHtcblx0Ly8gTm90ZSB3aGVyZSB0aGUgYWRtaW4gcGFnZSBsaXZlcywgc28gdGhlIHRvb2xiYXIgaWNvbiBjYW4gcmVvcGVuIGl0LiBCcmlkZ2Vcblx0Ly8gdHJhZmZpYyBvbmx5IOKAlCB0aGUgb3ZlcmxheSdzIG1lc3NhZ2VzIGNvbWUgZnJvbSBwYXJrcnVuIHBhZ2VzLlxuXHRpZiAoaXNGcm9tQWRtaW5QYWdlKG1lc3NhZ2UpKSB7XG5cdFx0dm9pZCByZW1lbWJlckFkbWluT3JpZ2luKHNlbmRlci51cmwgPz8gc2VuZGVyLm9yaWdpbilcblx0fVxuXG5cdC8vIFJldHVybmluZyB0cnVlIGtlZXBzIHRoZSByZXNwb25zZSBjaGFubmVsIG9wZW4gZm9yIHRoZSBhc3luYyB3b3JrIGJlbG93LlxuXHRoYW5kbGVNZXNzYWdlKG1lc3NhZ2UgYXMgUGFnZU1lc3NhZ2UgfCB7IHR5cGU6IHN0cmluZyB9LCBzZW5kZXIpXG5cdFx0LnRoZW4oc2VuZFJlc3BvbnNlKVxuXHRcdC5jYXRjaCgoZXJyb3IpID0+IHNlbmRSZXNwb25zZSh7IGVycm9yOiBTdHJpbmcoZXJyb3IpIH0pKVxuXHRyZXR1cm4gdHJ1ZVxufSlcblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlTWVzc2FnZShcblx0bWVzc2FnZTogUGFnZU1lc3NhZ2UgfCB7IHR5cGU6IHN0cmluZyB9LFxuXHRzZW5kZXI6IHsgdGFiPzogeyBpZD86IG51bWJlciB9IH0sXG4pOiBQcm9taXNlPHVua25vd24+IHtcblx0c3dpdGNoIChtZXNzYWdlLnR5cGUpIHtcblx0XHRjYXNlICdwaW5nJzpcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdHR5cGU6ICdoZWxsbycsXG5cdFx0XHRcdHZlcnNpb246IFNDUkFQRVJfUFJPVE9DT0xfVkVSU0lPTixcblx0XHRcdFx0c3RhdGU6IGF3YWl0IGdldFJ1blN0YXRlKCksXG5cdFx0XHR9XG5cblx0XHRjYXNlICdzdGF0ZT8nOlxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGdldFJ1blN0YXRlKCkgfVxuXG5cdFx0Y2FzZSAnc3RhcnQnOiB7XG5cdFx0XHRjb25zdCBhZG1pblRhYklkID0gc2VuZGVyLnRhYj8uaWRcblx0XHRcdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVybiB7IGVycm9yOiAnTm8gY2FsbGluZyB0YWInIH1cblx0XHRcdGNvbnN0IHJlcXVlc3QgPSAobWVzc2FnZSBhcyBFeHRyYWN0PFBhZ2VNZXNzYWdlLCB7IHR5cGU6ICdzdGFydCcgfT4pXG5cdFx0XHRcdC5yZXF1ZXN0XG5cdFx0XHRjb25zdCBzdGF0ZSA9IGF3YWl0IHN0YXJ0UnVuKHJlcXVlc3QsIGFkbWluVGFiSWQpXG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZSB9XG5cdFx0fVxuXG5cdFx0Y2FzZSAncmVzdW1lJzoge1xuXHRcdFx0Y29uc3QgYWRtaW5UYWJJZCA9IHNlbmRlci50YWI/LmlkXG5cdFx0XHRpZiAoYWRtaW5UYWJJZCA9PT0gdW5kZWZpbmVkKSByZXR1cm4geyBlcnJvcjogJ05vIGNhbGxpbmcgdGFiJyB9XG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZTogYXdhaXQgcmVzdW1lUnVuKGFkbWluVGFiSWQpIH1cblx0XHR9XG5cblx0XHRjYXNlICdjYW5jZWwnOlxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGNhbmNlbFJ1bigpIH1cblxuXHRcdGNhc2UgJ3JldHJ5Jzpcblx0XHRcdHJldHVybiB7IHR5cGU6ICdzdGF0ZScsIHN0YXRlOiBhd2FpdCByZXRyeUN1cnJlbnQoKSB9XG5cblx0XHRjYXNlICdza2lwJzpcblx0XHRcdHJldHVybiB7IHR5cGU6ICdzdGF0ZScsIHN0YXRlOiBhd2FpdCBza2lwQ3VycmVudCgpIH1cblxuXHRcdGNhc2UgJ3Jlc2VuZCc6XG5cdFx0XHRhd2FpdCByZXNlbmRGaWxlcygpXG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZTogYXdhaXQgZ2V0UnVuU3RhdGUoKSB9XG5cblx0XHRjYXNlICdjbGVhcic6XG5cdFx0XHRhd2FpdCBmb3JnZXRSdW4oKVxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGdldFJ1blN0YXRlKCkgfVxuXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiB7IGVycm9yOiBgVW5rbm93biBtZXNzYWdlOiAke21lc3NhZ2UudHlwZX1gIH1cblx0fVxufVxuXG4vLyDilIDilIAgRGVidWdnZXIgZXZlbnRzOiBob3cgcGFnZXMgZ2V0IGNhcHR1cmVkIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIERlYnVnZ2VyIGV2ZW50cyBhcmUgaGFuZGxlZCBzdHJpY3RseSBvbmUgYXQgYSB0aW1lLlxuICpcbiAqIGByZXNwb25zZVJlY2VpdmVkYCByZWNvcmRzIHRoZSBtYWluIGRvY3VtZW50J3MgcmVxdWVzdCBJRCBhbmRcbiAqIGBsb2FkaW5nRmluaXNoZWRgIGxvb2tzIGl0IHVwLCBib3RoIHZpYSBhc3luYyBzdG9yYWdlLiBIYW5kbGVkIGNvbmN1cnJlbnRseSxcbiAqIHRoZSBsb29rdXAgY2FuIHJ1biBiZWZvcmUgdGhlIHdyaXRlIGxhbmRzIOKAlCBhbmQgYmVjYXVzZSBvbmx5IHRoZSBtYWluXG4gKiBkb2N1bWVudCdzIGBsb2FkaW5nRmluaXNoZWRgIHRyaWdnZXJzIGEgY2FwdHVyZSwgbWlzc2luZyB0aGF0IG9uZSBldmVudCBzdGFsbHNcbiAqIHRoZSBydW4gcGVybWFuZW50bHkgd2l0aCBub3RoaW5nIHRvIHNob3cgd2h5LiBUaGUgdHdvIGV2ZW50cyBhcnJpdmUgd2l0aGluXG4gKiBtaWNyb3NlY29uZHMgb2YgZWFjaCBvdGhlciBvbiBhIGZhc3QgcGFnZSwgc28gdGhpcyB3YXMgbG9zaW5nIHJhY2VzLlxuICovXG5jaHJvbWUuZGVidWdnZXIub25FdmVudC5hZGRMaXN0ZW5lcigoc291cmNlLCBtZXRob2QsIHBhcmFtcykgPT4ge1xuXHRpZiAoc291cmNlLnRhYklkID09PSB1bmRlZmluZWQgfHwgIXBhcmFtcykgcmV0dXJuXG5cdGNvbnN0IHRhYklkID0gc291cmNlLnRhYklkXG5cdHZvaWQgc2VyaWFsKCgpID0+IGhhbmRsZURlYnVnZ2VyRXZlbnQodGFiSWQsIG1ldGhvZCwgcGFyYW1zKSkuY2F0Y2goXG5cdFx0KGVycm9yKSA9PiB7XG5cdFx0XHRjb25zb2xlLmVycm9yKCdbcmVzdWx0cy1zY3JhcGVyXSBldmVudCBoYW5kbGluZyBmYWlsZWQnLCBtZXRob2QsIGVycm9yKVxuXHRcdH0sXG5cdClcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlYnVnZ2VyRXZlbnQoXG5cdHRhYklkOiBudW1iZXIsXG5cdG1ldGhvZDogc3RyaW5nLFxuXHRwYXJhbXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmIChtZXRob2QgPT09ICdOZXR3b3JrLnJlc3BvbnNlUmVjZWl2ZWQnKSB7XG5cdFx0YXdhaXQgbm90ZURvY3VtZW50UmVzcG9uc2UodGFiSWQsIHBhcmFtcylcblx0XHRyZXR1cm5cblx0fVxuXG5cdGlmIChtZXRob2QgPT09ICdOZXR3b3JrLmxvYWRpbmdGaW5pc2hlZCcpIHtcblx0XHRjb25zdCBkb2N1bWVudCA9IGF3YWl0IG5vdGVMb2FkaW5nRmluaXNoZWQodGFiSWQsIHBhcmFtcylcblx0XHQvLyBPbmx5IHRoZSBtYWluLWZyYW1lIGRvY3VtZW50IHByb2R1Y2VzIGEgbWF0Y2ggaGVyZTsgZXZlcnl0aGluZyBlbHNlIG9uXG5cdFx0Ly8gdGhlIHBhZ2UgZmluaXNoZXMgbG9hZGluZyB0b28gYW5kIGlzIGlnbm9yZWQuXG5cdFx0aWYgKGRvY3VtZW50KSBhd2FpdCBoYW5kbGVEb2N1bWVudExvYWRlZCh0YWJJZClcblx0fVxufVxuXG4vKipcbiAqIENocm9tZSBkZXRhY2hlcyB1cyBpZiB0aGUgdXNlciBvcGVucyBEZXZUb29scyBvbiB0aGUgc2NyYXBlIHRhYiwgb3IgY2xpY2tzXG4gKiBcImNhbmNlbFwiIG9uIHRoZSBkZWJ1Z2dpbmcgbm90aWNlLiBXaXRob3V0IHRoZSBkZWJ1Z2dlciB0aGVyZSdzIG5vIHdheSB0byByZWFkXG4gKiByYXcgSFRNTCwgc28gdGhlIHJ1biBjYW4ndCBjb250aW51ZS5cbiAqL1xuY2hyb21lLmRlYnVnZ2VyLm9uRGV0YWNoLmFkZExpc3RlbmVyKChzb3VyY2UsIHJlYXNvbikgPT4ge1xuXHR2b2lkIGhhbmRsZURldGFjaChzb3VyY2UudGFiSWQsIHJlYXNvbilcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURldGFjaCh0YWJJZDogbnVtYmVyLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuXG5cblx0YXdhaXQgc2V0UnVuU3RhdGUoe1xuXHRcdC4uLnN0YXRlLFxuXHRcdHN0YXR1czogJ2Vycm9yJyxcblx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0ZmluaXNoZWRBdDogRGF0ZS5ub3coKSxcblx0XHRtZXNzYWdlOiBgTG9zdCB0aGUgZGVidWdnZXIgY29ubmVjdGlvbiAoJHtyZWFzb259KS5gLFxuXHR9KVxuXHRhd2FpdCBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6ICchJyB9KS5jYXRjaCgoKSA9PiB7fSlcbn1cblxuLy8g4pSA4pSAIFRhYiBjbG9zZWQgbWlkLXJ1biDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuY2hyb21lLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKCh0YWJJZCkgPT4ge1xuXHQvLyBTZXJpYWxpc2VkIHdpdGggdGhlIHJlc3Qgb2YgdGhlIHN0YXRlIG1hY2hpbmU6IHRoaXMgdXNlZCB0byByYWNlIGZpbmlzaFJ1blxuXHQvLyBhbmQgY2xvYmJlciBhIGNvbXBsZXRlZCBydW4ncyBzdGF0dXMuXG5cdHZvaWQgc2VyaWFsKCgpID0+IGhhbmRsZVRhYlJlbW92ZWQodGFiSWQpKVxufSlcblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlVGFiUmVtb3ZlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuXG5cblx0aWYgKHNlc3Npb24uc2NyYXBlVGFiSWQgPT09IHRhYklkKSB7XG5cdFx0YXdhaXQgZGV0YWNoKHRhYklkKVxuXHRcdGF3YWl0IHNldFJ1blN0YXRlKHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0c3RhdHVzOiAnY2FuY2VsbGVkJyxcblx0XHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRcdGZpbmlzaGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRtZXNzYWdlOiAnVGhlIHNjcmFwZSB0YWIgd2FzIGNsb3NlZC4nLFxuXHRcdH0pXG5cdFx0YXdhaXQgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiAnJyB9KS5jYXRjaCgoKSA9PiB7fSlcblx0fVxufVxuXG4vLyDilIDilIAgUmVjb3Zlcnkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogSWYgdGhlIGJyb3dzZXIgcmVzdGFydGVkIG1pZC1ydW4gdGhlcmUncyBubyB0YWIgYW5kIG5vIGRlYnVnZ2VyIGxlZnQsIHNvIHRoZVxuICogcnVuIGNhbid0IGJlIHJlc3VtZWQg4oCUIGJ1dCB3aGF0ZXZlciB3YXMgY2FwdHVyZWQgaXMgc3RpbGwgaW4gc3RvcmFnZSBhbmQgdGhlXG4gKiBhZG1pbiBwYWdlIGNhbiBzdGlsbCBhc2sgZm9yIGl0LlxuICovXG5jaHJvbWUucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuXHR2b2lkIChhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdFx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnKSByZXR1cm5cblx0XHRhd2FpdCBzZXRSdW5TdGF0ZSh7XG5cdFx0XHQuLi5zdGF0ZSxcblx0XHRcdHN0YXR1czogJ2NhbmNlbGxlZCcsXG5cdFx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0XHRtZXNzYWdlOiAnSW50ZXJydXB0ZWQgd2hlbiB0aGUgYnJvd3NlciBjbG9zZWQuJyxcblx0XHR9KVxuXHR9KSgpXG59KVxuXG4vKipcbiAqIFRoZSBzY3JhcGUgdGFiIGZpbmlzaGVkIGxvYWRpbmcuXG4gKlxuICogVGhpcyBpcyB0aGUgZGVwZW5kYWJsZSB0cmlnZ2VyIOKAlCB1bmxpa2UgY2hyb21lLmRlYnVnZ2VyIGV2ZW50cywgdGFicy5vblVwZGF0ZWRcbiAqIGlzIGFsd2F5cyBkZWxpdmVyZWQgYW5kIGFsd2F5cyB3YWtlcyB0aGUgd29ya2VyLiBJdCBydW5zIHRoZSBzYW1lIGNhcHR1cmUgcGF0aCxcbiAqIHNvIHdoaWNoZXZlciBzaWduYWwgYXJyaXZlcyBmaXJzdCB3aXRoIGEgcmVhZGFibGUgYm9keSB3aW5zLlxuICovXG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBpbmZvKSA9PiB7XG5cdGlmIChpbmZvLnN0YXR1cyAhPT0gJ2NvbXBsZXRlJykgcmV0dXJuXG5cdHZvaWQgKGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0XHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycpIHJldHVyblxuXG5cdFx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRcdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0XHQvLyBObyBjdXJyZW50IGl0ZW0gbWVhbnMgdGhlIHdvcmtlciBkaWVkIGJldHdlZW4gaXRlbXM7IHBpY2sgdGhlIHF1ZXVlIGJhY2sgdXAuXG5cdFx0aWYgKCFzdGF0ZS5jdXJyZW50S2V5KSB7XG5cdFx0XHRhd2FpdCBzZXJpYWwoKCkgPT4gYWR2YW5jZSgpKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0YXdhaXQgc2VyaWFsKCgpID0+IGhhbmRsZURvY3VtZW50TG9hZGVkKHRhYklkKSlcblxuXHRcdC8vIFRoZSBwYWdlIGlzIGxvYWRlZC4gSWYgdGhhdCBkaWRuJ3QgcHJvZHVjZSBhIGNhcHR1cmUsIGl0cyBOZXR3b3JrIGV2ZW50c1xuXHRcdC8vIHdlcmUgbG9zdCBhbmQgbm8gYW1vdW50IG9mIHdhaXRpbmcgd2lsbCBicmluZyB0aGVtIGJhY2sg4oCUIHJlbG9hZCBub3dcblx0XHQvLyByYXRoZXIgdGhhbiBsZXR0aW5nIHRoZSB3YXRjaGRvZyBub3RpY2UgaW4gMjAgc2Vjb25kcy5cblx0XHRhd2FpdCBzZXJpYWwoKCkgPT4gcmVjb3Zlck1pc3NlZENhcHR1cmUodGFiSWQpKVxuXHR9KSgpXG59KVxuXG4vKipcbiAqIEEgYmxvY2tlZCBwYWdlIHRoYXQgbm9ib2R5IGhhcyBjbGVhcmVkLiBSZWxvYWQgaXQg4oCUIGEgZmxhdCA0MDMgb2Z0ZW4gcGFzc2VzIG9uXG4gKiBhIHNlY29uZCB0cnksIGFuZCBhIGNoYWxsZW5nZSB0aGUgdXNlciBhbHJlYWR5IHNvbHZlZCB3aWxsIGhhdmUgbmF2aWdhdGVkIGF3YXlcbiAqIGJ5IG5vdywgaW4gd2hpY2ggY2FzZSB0aGlzIGRvZXMgbm90aGluZy5cbiAqL1xuY2hyb21lLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xuXHRpZiAoYWxhcm0ubmFtZSA9PT0gJ3JldHJ5LWJsb2NrZWQnKSB7XG5cdFx0dm9pZCBzZXJpYWwoKCkgPT4gcmV0cnlJZlN0aWxsQmxvY2tlZCgpKVxuXHRcdHJldHVyblxuXHR9XG5cdC8vIFRoZSB3YXRjaGRvZzogY2F0Y2hlcyBhIHBhZ2Ugd2hvc2UgbG9hZCBldmVudHMgbmV2ZXIgYXJyaXZlZCwgd2hpY2ggd291bGRcblx0Ly8gb3RoZXJ3aXNlIGxlYXZlIHRoZSBydW4gc2l0dGluZyBvbiBcIkxvYWRpbmfigKZcIiBmb3JldmVyLlxuXHRpZiAoYWxhcm0ubmFtZSA9PT0gJ3dhdGNoZG9nJykge1xuXHRcdHZvaWQgc2VyaWFsKCgpID0+IGNoZWNrRm9yU3RhbGwoKSlcblx0fVxufSlcblxuLy8gTm8gZGVmYXVsdF9wb3B1cCBpbiB0aGUgbWFuaWZlc3QsIHNvIHRoZSBpY29uIGNsaWNrIGNvbWVzIGhlcmUuXG5jaHJvbWUuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdHZvaWQgb3BlbkFkbWluUGFnZSgpXG59KVxuXG5jaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6ICcjM2Y2ZDNhJyB9KS5jYXRjaCgoKSA9PiB7fSlcbiJdLCJuYW1lcyI6WyJvcmlnaW4iLCJzdGF0ZSIsImF0dGVtcHRzIl0sIm1hcHBpbmdzIjoiQUFlTyxNQUFNLDJCQUEyQjtBQXVFakMsU0FBUyxnQkFBMEI7QUFDekMsU0FBTyxFQUFFLFFBQVEsUUFBUSxPQUFPLENBQUEsRUFBQztBQUNsQztBQ25FQSxNQUFNLG1CQUFtQjtBQUV6QixNQUFNLFVBQVU7QUFvQ2hCLGVBQXNCLE9BQU8sT0FBOEI7QUFDMUQsTUFBSTtBQUNILFVBQU0sT0FBTyxTQUFTLE9BQU8sRUFBRSxNQUFBLEdBQVMsZ0JBQWdCO0FBQUEsRUFDekQsU0FBUyxPQUFPO0FBRWYsUUFBSSxDQUFDLG9CQUFvQixLQUFLLGNBQWMsS0FBSyxDQUFDLEVBQUcsT0FBTTtBQUFBLEVBQzVEO0FBSUEsUUFBTSxPQUFPLFNBQVMsWUFBWSxFQUFFLE1BQUEsR0FBUyxnQkFBZ0I7QUFDOUQ7QUFFQSxlQUFzQixPQUFPLE9BQThCO0FBQzFELE1BQUk7QUFDSCxVQUFNLE9BQU8sU0FBUyxPQUFPLEVBQUUsT0FBTztBQUFBLEVBQ3ZDLFFBQVE7QUFBQSxFQUVSO0FBQ0Q7QUFHQSxlQUFzQixlQUFlLE9BQThCO0FBQ2xFLE1BQUk7QUFDSCxVQUFNLE9BQU8sS0FBSztBQUFBLEVBQ25CLFNBQVMsT0FBTztBQUNmLFVBQU0sSUFBSTtBQUFBLE1BQ1QsbURBQW1ELGNBQWMsS0FBSyxDQUFDO0FBQUEsSUFBQTtBQUFBLEVBRXpFO0FBQ0Q7QUFRQSxlQUFzQixxQkFDckIsT0FDQSxRQUNnQjtBQUNoQixNQUFJLE9BQU8sU0FBUyxXQUFZO0FBRWhDLFFBQU0sV0FBVyxPQUFPO0FBQ3hCLFFBQU0sWUFBWSxPQUFPO0FBQ3pCLE1BQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxJQUFLO0FBUWxDLE1BQUksT0FBTyxZQUFZLE9BQU8sYUFBYSxVQUFXO0FBRXRELFFBQU0sZ0JBQWdCLE9BQU87QUFBQSxJQUM1QjtBQUFBLElBQ0EsS0FBSyxTQUFTO0FBQUEsSUFDZCxRQUFRLFNBQVMsVUFBVTtBQUFBLElBQzNCLFVBQVU7QUFBQSxFQUFBLENBQ1Y7QUFDRjtBQUVBLGVBQXNCLG9CQUNyQixPQUNBLFFBQ21DO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGdCQUFnQixLQUFLO0FBQ3hDLE1BQUksQ0FBQyxRQUFRLEtBQUssY0FBYyxPQUFPLFVBQVcsUUFBTztBQUV6RCxRQUFNLFdBQVcsRUFBRSxHQUFHLE1BQU0sVUFBVSxLQUFBO0FBQ3RDLFFBQU0sZ0JBQWdCLE9BQU8sUUFBUTtBQUNyQyxTQUFPO0FBQ1I7QUFVTyxTQUFTLGVBQWUsT0FBeUI7QUFDdkQsU0FBTyxtREFBbUQ7QUFBQSxJQUN6RCxjQUFjLEtBQUs7QUFBQSxFQUFBO0FBRXJCO0FBRUEsZUFBc0IsZ0JBQ3JCLE9BQ21DO0FBQ25DLFFBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBRXhDLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRTtBQUN2QixTQUFPLE9BQU8sR0FBRyxPQUFPLElBQUksS0FBSyxFQUFFLEtBQUs7QUFDekM7QUFFQSxlQUFlLGdCQUNkLE9BQ0EsT0FDZ0I7QUFDaEIsUUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLE9BQU8sSUFBSSxLQUFLLEVBQUUsR0FBRyxPQUFPO0FBQ2xFO0FBR0EsZUFBc0IscUJBQ3JCLE9BQ0EsVUFDZ0I7QUFDaEIsUUFBTSxnQkFBZ0IsT0FBTyxFQUFFLEdBQUcsVUFBVSxVQUFVLE1BQU07QUFDN0Q7QUFFQSxlQUFzQixrQkFBa0IsT0FBOEI7QUFDckUsUUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRTtBQUN4RDtBQUlBLGVBQXNCLFNBQ3JCLE9BQ0EsVUFDd0I7QUFDeEIsUUFBTSxTQUFTLE1BQU0sT0FBTyxTQUFTLFlBR2xDLEVBQUUsTUFBQSxHQUFTLDJCQUEyQixFQUFFLFdBQVcsU0FBUyxXQUFXO0FBRTFFLFNBQU87QUFBQSxJQUNOLEtBQUssU0FBUztBQUFBLElBQ2QsUUFBUSxTQUFTO0FBQUEsSUFDakIsTUFBTSxPQUFPLGdCQUFnQixhQUFhLE9BQU8sSUFBSSxJQUFJLE9BQU87QUFBQSxJQUNoRSxlQUFlLE9BQU87QUFBQSxFQUFBO0FBRXhCO0FBR0EsU0FBUyxhQUFhLFFBQXdCO0FBQzdDLFFBQU0sU0FBUyxLQUFLLE1BQU07QUFDMUIsUUFBTSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU07QUFDMUMsV0FBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsSUFBSyxPQUFNLENBQUMsSUFBSSxPQUFPLFdBQVcsQ0FBQztBQUN0RSxTQUFPLElBQUksWUFBQSxFQUFjLE9BQU8sS0FBSztBQUN0QztBQUVPLFNBQVMsY0FBYyxPQUF3QjtBQUNyRCxNQUFJLGlCQUFpQixNQUFPLFFBQU8sTUFBTTtBQUN6QyxNQUFJLE9BQU8sVUFBVSxTQUFVLFFBQU87QUFDdEMsU0FBTyxLQUFLLFVBQVUsS0FBSztBQUM1QjtBQ3ZNQSxNQUFNLGFBQWE7QUFDbkIsTUFBTSxZQUFZO0FBeUJYLFNBQVMsZ0JBQWdCLFNBQTJCO0FBQzFELFNBQ0MsT0FBTyxZQUFZLFlBQ25CLFlBQVksUUFDWCxRQUF5QixrQkFBa0I7QUFFOUM7QUFTQSxNQUFNLG1CQUFtQixDQUFDLHdCQUF3Qix1QkFBdUI7QUFTekUsZUFBc0Isb0JBQ3JCLFdBQ2dCO0FBQ2hCLE1BQUksQ0FBQyxVQUFXO0FBQ2hCLE1BQUk7QUFDSCxVQUFNLEVBQUUsT0FBQSxJQUFXLElBQUksSUFBSSxTQUFTO0FBQ3BDLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsVUFBVSxHQUFHLFFBQVE7QUFBQSxFQUN4RCxRQUFRO0FBQUEsRUFFUjtBQUNEO0FBRUEsZUFBZSxtQkFBMkM7QUFDekQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxJQUN6QztBQUFBLEVBQUE7QUFFRCxTQUFPLE9BQU8sbUJBQW1CO0FBQ2xDO0FBUUEsZUFBc0IsZ0JBQStCO0FBQ3BELFFBQU0sVUFBVSxDQUFDLE1BQU0sb0JBQW9CLEdBQUcsZ0JBQWdCLEVBQUU7QUFBQSxJQUMvRCxDQUFDQSxZQUE2QixDQUFDLENBQUNBO0FBQUFBLEVBQUE7QUFHakMsYUFBV0EsV0FBVSxTQUFTO0FBQzdCLFVBQU0sV0FBVyxNQUFNLE9BQU8sS0FDNUIsTUFBTSxFQUFFLEtBQUssR0FBR0EsT0FBTSxHQUFHLFNBQVMsSUFBQSxDQUFLLEVBQ3ZDLE1BQU0sTUFBTSxFQUFFO0FBRWhCLFVBQU0sTUFBTSxTQUFTLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFTO0FBQ25FLFFBQUksS0FBSyxPQUFPLFFBQVc7QUFDMUIsWUFBTSxPQUFPLEtBQUssT0FBTyxJQUFJLElBQUksRUFBRSxRQUFRLE1BQU07QUFDakQsVUFBSSxJQUFJLGFBQWEsUUFBVztBQUMvQixjQUFNLE9BQU8sUUFBUSxPQUFPLElBQUksVUFBVSxFQUFFLFNBQVMsTUFBTTtBQUFBLE1BQzVEO0FBQ0E7QUFBQSxJQUNEO0FBQUEsRUFDRDtBQUVBLFFBQU0sU0FBUyxRQUFRLENBQUM7QUFDeEIsUUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssR0FBRyxNQUFNLEdBQUcsU0FBUyxJQUFJLFFBQVEsS0FBQSxDQUFNO0FBQ3hFO0FDaEVBLE1BQU0saUJBQWlCLG9CQUFJLElBQUksQ0FBQyxhQUFhLFlBQVksWUFBWSxDQUFDO0FBRS9ELE1BQU0sb0JBQTRDO0FBQUEsRUFDeEQsa0JBQWtCO0FBQUEsRUFDbEIsaUJBQWlCO0FBQUEsRUFDakIsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2Qsa0JBQWtCO0FBQUEsRUFDbEIsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsaUJBQWlCO0FBQUEsRUFDakIsY0FBYztBQUFBLEVBQ2Qsa0JBQWtCO0FBQUEsRUFDbEIsY0FBYztBQUNmO0FBRUEsU0FBUyxrQkFBa0IsS0FBYSxTQUF5QjtBQUNoRSxNQUFJO0FBQ0gsVUFBTSxXQUFXLElBQUksSUFBSSxHQUFHLEVBQUUsU0FBUyxRQUFRLFVBQVUsRUFBRTtBQUMzRCxRQUFJLGFBQWEsbUJBQW1CLGVBQWUsSUFBSSxPQUFPLEdBQUc7QUFDaEUsYUFBTztBQUFBLElBQ1I7QUFDQSxXQUFPLGtCQUFrQixRQUFRLEtBQUs7QUFBQSxFQUN2QyxRQUFRO0FBQ1AsV0FBTztBQUFBLEVBQ1I7QUFDRDtBQU1PLFNBQVMsY0FBYyxZQUFzQztBQUNuRSxRQUFNLDJCQUFXLElBQUE7QUFFakIsYUFBVyxVQUFVLFlBQVk7QUFDaEMsUUFBSSxDQUFDLE9BQU8sWUFBWSxDQUFDLE9BQU8sTUFBTztBQUN2QyxRQUFJLEtBQUssSUFBSSxPQUFPLEtBQUssRUFBRztBQUk1QixVQUFNLFdBQVcsT0FBTyxTQUFTO0FBQUEsTUFDaEM7QUFBQSxJQUFBO0FBRUQsUUFBSSxDQUFDLFNBQVU7QUFFZixVQUFNLFVBQVUsR0FBRyxTQUFTLENBQUMsQ0FBQztBQUU5QixTQUFLLElBQUksT0FBTyxPQUFPO0FBQUEsTUFDdEIsU0FBUyxPQUFPO0FBQUEsTUFDaEIsTUFBTSxPQUFPO0FBQUEsTUFDYixLQUFLO0FBQUEsTUFDTCxTQUFTLGtCQUFrQixPQUFPLFVBQVUsT0FBTyxLQUFLO0FBQUEsSUFBQSxDQUN4RDtBQUFBLEVBQ0Y7QUFFQSxTQUFPLE1BQU0sS0FBSyxLQUFLLE9BQUEsQ0FBUTtBQUNoQztBQUlBLFNBQVMsVUFBVSxNQUFzQjtBQUN4QyxTQUFPLEtBQUssUUFBUSxZQUFZLEVBQUUsRUFBRSxLQUFBO0FBQ3JDO0FBSUEsTUFBTSxXQUFtQztBQUFBLEVBQ3hDLFNBQVM7QUFBQSxFQUNULFFBQVE7QUFBQSxFQUNSLFFBQVE7QUFBQSxFQUNSLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFDWDtBQUVBLFNBQVMsZUFBZSxNQUFzQjtBQUM3QyxTQUFPLEtBQ0wsUUFBUSx3Q0FBd0MsQ0FBQyxNQUFNLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFDdkU7QUFBQSxJQUFRO0FBQUEsSUFBYSxDQUFDLEdBQUcsU0FDekIsT0FBTyxjQUFjLE9BQU8sU0FBUyxNQUFNLEVBQUUsQ0FBQztBQUFBLEVBQUEsRUFFOUMsUUFBUSxXQUFXLEdBQUc7QUFDekI7QUFJTyxTQUFTLGdCQUFnQixNQUEwQjtBQUt6RCxRQUFNLFVBQVUsS0FBSyxNQUFNLHNCQUFzQixJQUFJLENBQUMsS0FBSztBQUMzRCxRQUFNLFVBQVUsUUFBUSxNQUFNLG1CQUFtQjtBQUNqRCxRQUFNLGNBQWMsZUFBZSxVQUFVLE9BQU8sQ0FBQyxFQUNuRCxRQUFRLG1CQUFtQixFQUFFLEVBQzdCLEtBQUE7QUFDRixRQUFNLE9BQU8sV0FBVyxjQUFjLGNBQWM7QUFJcEQsUUFBTSxhQUFhLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQUE7QUFFRCxRQUFNLFlBQVksYUFBYSxPQUFPLFNBQVMsV0FBVyxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQ3BFLFFBQU0sa0JBQWtCLGFBQWEsQ0FBQyxJQUNuQyxPQUFPLFNBQVMsV0FBVyxDQUFDLEdBQUcsRUFBRSxJQUNqQztBQUVILFNBQU87QUFBQSxJQUNOO0FBQUEsSUFDQSxXQUFXLFVBQVUsUUFBUSxDQUFDLElBQUk7QUFBQSxJQUNsQztBQUFBLElBQ0E7QUFBQSxFQUFBO0FBRUY7QUFZQSxTQUFTLGtCQUFrQixNQUF3QjtBQUNsRCxRQUFNLGFBQXVCLENBQUE7QUFFN0IsUUFBTSxlQUFlLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQUE7QUFFRCxNQUFJLGFBQWMsWUFBVyxLQUFLLGFBQWEsQ0FBQyxDQUFDO0FBRWpELFFBQU0sU0FBUztBQUFBLElBQ2QsR0FBRyxLQUFLLFNBQVMsb0RBQW9EO0FBQUEsRUFBQTtBQUV0RSxhQUFXLFNBQVMsT0FBTyxXQUFXO0FBQ3JDLFVBQU0sUUFBUSxNQUFNLENBQUMsRUFBRSxNQUFNLGtDQUFrQztBQUMvRCxlQUFXLEtBQUssUUFBUSxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzVDO0FBRUEsU0FBTztBQUNSO0FBRU8sU0FBUyxnQkFBZ0IsTUFBMkI7QUFDMUQsYUFBVyxTQUFTLGtCQUFrQixJQUFJLEdBQUc7QUFDNUMsVUFBTSxVQUFVLGdCQUFnQixLQUFLO0FBQ3JDLFFBQUksUUFBUSxTQUFTLEVBQUcsUUFBTztBQUFBLEVBQ2hDO0FBQ0EsU0FBTyxDQUFBO0FBQ1I7QUFFQSxTQUFTLGdCQUFnQixPQUE0QjtBQUNwRCxRQUFNLFVBQXVCLENBQUE7QUFHN0IsUUFBTSxXQUFXO0FBRWpCLGFBQVcsWUFBWSxNQUFNLFNBQVMsUUFBUSxHQUFHO0FBQ2hELFVBQU0sTUFBTSxTQUFTLENBQUM7QUFHdEIsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sUUFBa0IsQ0FBQTtBQUN4QixlQUFXLGFBQWEsSUFBSSxTQUFTLFNBQVMsR0FBRztBQUNoRCxZQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFBQSxJQUN4QjtBQUdBLFFBQUksTUFBTSxTQUFTLEVBQUc7QUFHdEIsVUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUU7QUFBQSxNQUMvQjtBQUFBLElBQUE7QUFFRCxVQUFNLFdBQVcsaUJBQWlCLGVBQWUsQ0FBQyxFQUFFLFNBQVM7QUFDN0QsVUFBTSxZQUFZLGlCQUNmLGVBQWUsZUFBZSxDQUFDLENBQUMsRUFBRSxLQUFBLElBQ2xDLGVBQWUsVUFBVSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBSXJDLFFBQUksQ0FBQyxjQUFjLEtBQUssUUFBUSxFQUFHO0FBR25DLFVBQU0sZUFBZSxTQUFTLE1BQU0sc0JBQXNCO0FBQzFELFVBQU0sUUFBUSxlQUNYLGFBQWEsQ0FBQyxJQUNkLFVBQVUsY0FBYyxRQUFRLGNBQWMsRUFBRTtBQUtuRCxVQUFNLE9BQU8sZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDO0FBR3JDLFVBQU0sY0FBYyxPQUFPLFNBQVMsVUFBVSxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSztBQUdoRSxVQUFNLFdBQVcsT0FBTyxTQUFTLFVBQVUsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUs7QUFHN0QsVUFBTSxPQUFPLFVBQVUsTUFBTSxDQUFDLENBQUM7QUFHL0IsVUFBTSxXQUFXLFVBQVUsTUFBTSxDQUFDLENBQUM7QUFFbkMsUUFBSSxhQUFhLE1BQU07QUFDdEIsY0FBUSxLQUFLO0FBQUEsUUFDWjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUFBLENBQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRDtBQUVBLFNBQU87QUFDUjtBQUdBLFNBQVMsZ0JBQWdCLE1BQXNCO0FBQzlDLFFBQU0sTUFBTSxLQUFLLE1BQU0sNkJBQTZCO0FBQ3BELE1BQUksSUFBSyxRQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBRTdDLFFBQU0sTUFBTSxLQUFLLE1BQU0sdUJBQXVCO0FBQzlDLE1BQUksSUFBSyxRQUFPLElBQUksQ0FBQztBQUVyQixTQUFPLFVBQVUsSUFBSTtBQUN0QjtBQWdCTyxTQUFTLGtCQUFrQixNQUFrQztBQUNuRSxRQUFNLFVBQThCLENBQUE7QUFFcEMsUUFBTSxhQUFhLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQUE7QUFFRCxNQUFJLENBQUMsV0FBWSxRQUFPO0FBRXhCLFFBQU0sUUFBUSxXQUFXLENBQUM7QUFFMUIsYUFBVyxZQUFZLE1BQU0sU0FBUyw2QkFBNkIsR0FBRztBQUNyRSxVQUFNLFFBQWtCLENBQUE7QUFDeEIsZUFBVyxhQUFhLFNBQVMsQ0FBQyxFQUFFO0FBQUEsTUFDbkM7QUFBQSxJQUFBLEdBQ0U7QUFDRixZQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFBQSxJQUN4QjtBQUVBLFFBQUksTUFBTSxTQUFTLEVBQUc7QUFFdEIsVUFBTSxPQUFPLGVBQWUsVUFBVSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9DLFFBQUksQ0FBQyxLQUFNO0FBRVgsVUFBTSxjQUFjLE1BQU0sQ0FBQyxFQUFFLE1BQU0sb0JBQW9CO0FBQ3ZELFVBQU0sVUFBVSxPQUFPLFNBQVMsVUFBVSxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUU7QUFDdkQsVUFBTSxTQUFTLE9BQU8sU0FBUyxVQUFVLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRTtBQUV0RCxRQUFJLE9BQU8sTUFBTSxPQUFPLEtBQUssT0FBTyxNQUFNLE1BQU0sRUFBRztBQUVuRCxZQUFRLEtBQUs7QUFBQSxNQUNaLFFBQVEsY0FBYyxZQUFZLENBQUMsSUFBSTtBQUFBLE1BQ3ZDO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBLENBQ0E7QUFBQSxFQUNGO0FBRUEsU0FBTztBQUNSO0FBdUNPLFNBQVMsZUFBZSxNQUFzQjtBQUNwRCxRQUFNLFFBQVEsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFBQTtBQUVELFNBQU8sUUFBUSxNQUFNLENBQUMsSUFBSTtBQUMzQjtBQW9CTyxTQUFTLG1CQUFtQixNQUE2QjtBQUMvRCxRQUFNLFFBQVE7QUFBQSxJQUNiLFVBQVUsS0FBSyxNQUFNLDJCQUEyQixJQUFJLENBQUMsS0FBSyxFQUFFO0FBQUEsRUFBQTtBQUk3RCxRQUFNLFVBQVUsS0FBSyxNQUFNLGdDQUFnQyxJQUFJLENBQUMsS0FBSztBQUVyRSxRQUFNLGNBQWMsS0FBSyxNQUFNLDRCQUE0QjtBQUUzRCxTQUFPO0FBQUEsSUFDTjtBQUFBLElBQ0E7QUFBQSxJQUNBLGFBQWEsY0FBYyxPQUFPLFNBQVMsWUFBWSxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQUEsSUFDakUsTUFBTSxlQUFlLElBQUk7QUFBQSxFQUFBO0FBRTNCO0FDOVhPLFNBQVMsY0FBYyxjQUE4QjtBQUMzRCxTQUFPLEdBQUcsVUFBVSxZQUFZLENBQUM7QUFDbEM7QUFHTyxTQUFTLGFBQWEsS0FBcUI7QUFDakQsU0FBTyx5Q0FBeUMsR0FBRztBQUNwRDtBQVVBLFNBQVMsVUFBVSxLQUFxQjtBQUN2QyxTQUFPLElBQUksUUFBUSxPQUFPLEVBQUU7QUFDN0I7QUFTcUMsT0FBTyxLQUFLLGlCQUFpQixFQUFFO0FBQUEsRUFDbkUsQ0FBQyxXQUFXLENBQUMsT0FBTyxNQUFNLE1BQU0sU0FBUyxNQUFNLElBQUk7QUFDcEQ7QUNwREEsTUFBTSxtQkFBbUI7QUFFekIsSUFBSSxRQUErQztBQUU1QyxTQUFTLGlCQUF1QjtBQUN0QyxNQUFJLE1BQU87QUFDWCxVQUFRLFlBQVksTUFBTTtBQUV6QixTQUFLLE9BQU8sUUFBUSxnQkFBQSxFQUFrQixNQUFNLE1BQU0sTUFBUztBQUFBLEVBQzVELEdBQUcsZ0JBQWdCO0FBQ3BCO0FBRU8sU0FBUyxnQkFBc0I7QUFDckMsTUFBSSxDQUFDLE1BQU87QUFDWixnQkFBYyxLQUFLO0FBQ25CLFVBQVE7QUFDVDtBQ2RBLE1BQU0sVUFBVTtBQUNoQixNQUFNLFlBQVk7QUFDbEIsTUFBTSxjQUFjO0FBaUJwQixTQUFTLGVBQTJCO0FBQ25DLFNBQU87QUFBQSxJQUNOLHFCQUFxQixDQUFBO0FBQUEsSUFDckIsa0JBQWtCLENBQUE7QUFBQSxJQUNsQixlQUFlO0FBQUEsSUFDZixhQUFhO0FBQUEsSUFDYixVQUFVO0FBQUEsRUFBQTtBQUVaO0FBSUEsZUFBc0IsY0FBaUM7QUFDdEQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBd0IsT0FBTztBQUN6RSxTQUFPLE9BQU8sT0FBTyxjQUFBO0FBQ3RCO0FBRUEsZUFBc0IsWUFBWSxPQUFnQztBQUNqRSxRQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLE9BQU8sR0FBRyxPQUFPO0FBQ3BEO0FBR0EsZUFBc0IsZUFDckIsUUFDb0I7QUFDcEIsUUFBTSxPQUFPLE9BQU8sTUFBTSxhQUFhO0FBQ3ZDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDUjtBQUVBLGVBQXNCLGNBQ3JCLEtBQ0EsUUFDQSxRQUNBLFVBQ29CO0FBQ3BCLFNBQU8sZUFBZSxDQUFDLFdBQVc7QUFBQSxJQUNqQyxHQUFHO0FBQUEsSUFDSCxPQUFPLE1BQU0sTUFBTTtBQUFBLE1BQUksQ0FBQyxTQUN2QixLQUFLLFFBQVEsTUFDVjtBQUFBLFFBQ0EsR0FBRztBQUFBLFFBQ0g7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVLFlBQVksS0FBSztBQUFBLFFBQzNCLFdBQVcsS0FBSyxJQUFBO0FBQUEsTUFBSSxJQUVwQjtBQUFBLElBQUE7QUFBQSxFQUNKLEVBQ0M7QUFDSDtBQUVBLGVBQXNCLFlBQVksT0FBdUM7QUFDeEUsU0FBTyxlQUFlLENBQUMsV0FBVztBQUFBLElBQ2pDLEdBQUc7QUFBQSxJQUNILE9BQU8sQ0FBQyxHQUFHLE1BQU0sT0FBTyxHQUFHLEtBQUs7QUFBQSxFQUFBLEVBQy9CO0FBQ0g7QUFJQSxlQUFzQixhQUFrQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLElBQ3pDO0FBQUEsRUFBQTtBQUVELFNBQU8sT0FBTyxXQUFXLGFBQUE7QUFDMUI7QUFFQSxlQUFzQixXQUFXLFNBQW9DO0FBQ3BFLFFBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsV0FBVyxHQUFHLFNBQVM7QUFDMUQ7QUFFQSxlQUFzQixjQUNyQixRQUNzQjtBQUN0QixRQUFNLE9BQU8sT0FBTyxNQUFNLFlBQVk7QUFDdEMsUUFBTSxXQUFXLElBQUk7QUFDckIsU0FBTztBQUNSO0FBSUEsZUFBc0IsV0FBb0M7QUFDekQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxJQUN6QztBQUFBLEVBQUE7QUFFRCxTQUFPLE9BQU8sU0FBUyxDQUFBO0FBQ3hCO0FBR0EsZUFBc0IsUUFBUSxNQUFtQztBQUNoRSxRQUFNLFFBQVEsTUFBTSxTQUFBO0FBQ3BCLFFBQU0sV0FBVyxNQUFNO0FBQUEsSUFDdEIsQ0FBQyxNQUFNLEVBQUUsU0FBUyxLQUFLLFFBQVEsRUFBRSxRQUFRLEtBQUs7QUFBQSxFQUFBO0FBRS9DLE1BQUksYUFBYSxHQUFJLE9BQU0sS0FBSyxJQUFJO0FBQUEsTUFDL0IsT0FBTSxRQUFRLElBQUk7QUFDdkIsUUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxTQUFTLEdBQUcsT0FBTztBQUN0RDtBQUlBLGVBQXNCLFdBQTBCO0FBQy9DLFFBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxDQUFDLFNBQVMsV0FBVyxXQUFXLENBQUM7QUFDcEU7QUNsSUEsZUFBc0IsWUFBWSxPQUFnQztBQUNqRSxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLFFBQU0sVUFBVSxFQUFFLE1BQU0sU0FBa0IsTUFBQTtBQUUxQyxhQUFXLFNBQVMsQ0FBQyxRQUFRLFlBQVksUUFBUSxXQUFXLEdBQUc7QUFDOUQsUUFBSSxVQUFVLE9BQVc7QUFDekIsVUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPLE9BQU8sRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUM3RDtBQUNEO0FBRUEsZUFBc0IsV0FBVyxNQUFtQztBQUNuRSxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsUUFBTSxPQUFPLEtBQ1gsWUFBWSxZQUFZLEVBQUUsTUFBTSxRQUFpQixLQUFBLENBQU0sRUFDdkQsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2pCO0FDVUEsTUFBTSxvQkFBb0I7QUFBQSxFQUN6QjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNEO0FBRUEsU0FBUyxtQkFBbUIsTUFBdUI7QUFDbEQsUUFBTSxXQUFXLEtBQUssTUFBTSxHQUFHLEdBQU8sRUFBRSxZQUFBO0FBQ3hDLFNBQU8sa0JBQWtCLEtBQUssQ0FBQyxXQUFXLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFDcEU7QUFFTyxTQUFTLFNBQ2YsTUFDQSxLQUNBLFFBQ0EsTUFDVTtBQUtWLE1BQUksVUFBVSxLQUFLO0FBQ2xCLFVBQU0sWUFBWSxtQkFBbUIsSUFBSTtBQUN6QyxXQUFPO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxXQUFXO0FBQUEsTUFDWCxRQUFRLFlBQ0wsbUJBQW1CLE1BQU0sa0dBQ3pCLG1CQUFtQixNQUFNO0FBQUEsSUFBQTtBQUFBLEVBRTlCO0FBR0EsTUFBSSxtQkFBbUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLEdBQUc7QUFDbkUsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLE1BQ1gsUUFDQztBQUFBLElBQUE7QUFBQSxFQUVIO0FBRUEsVUFBUSxNQUFBO0FBQUEsSUFDUCxLQUFLO0FBQ0osYUFBTyxnQkFBZ0IsS0FBSyxJQUFJO0FBQUEsSUFDakMsS0FBSztBQUNKLGFBQU8sY0FBYyxLQUFLLElBQUk7QUFBQSxJQUMvQixLQUFLO0FBQ0osYUFBTyxjQUFjLElBQUk7QUFBQSxJQUMxQixLQUFLO0FBQ0osYUFBTyxlQUFlLElBQUk7QUFBQSxFQUFBO0FBRTdCO0FBTUEsU0FBUyxpQkFDUixNQUNBLEtBQ0EsTUFDVTtBQUNWLFVBQVEsTUFBQTtBQUFBLElBQ1AsS0FBSztBQUNKLGFBQU8sZ0JBQWdCLElBQUksRUFBRSxTQUFTO0FBQUEsSUFDdkMsS0FBSztBQUNKLGFBQU8sbUJBQW1CLElBQUksRUFBRSxjQUFjO0FBQUEsSUFDL0MsS0FBSztBQUNKLGFBQU8sa0JBQWtCLElBQUksRUFBRSxTQUFTO0FBQUEsSUFDekMsS0FBSztBQUNKLGFBQU8sY0FBYyxJQUFJLE1BQU07QUFBQSxFQUFBO0FBRWxDO0FBRUEsU0FBUyxnQkFBZ0IsV0FBbUIsTUFBdUI7QUFDbEUsUUFBTSxTQUFTLGdCQUFnQixJQUFJO0FBQ25DLFFBQU0sVUFBVSxnQkFBZ0IsSUFBSTtBQUVwQyxNQUFJLE9BQU8sU0FBUyxhQUFhLFFBQVEsV0FBVyxHQUFHO0FBQ3RELFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFVjtBQUNBLE1BQUksT0FBTyxhQUFhLE9BQU8sY0FBYyxXQUFXO0FBQ3ZELFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVEsdUJBQXVCLE9BQU8sU0FBUyxjQUFjLFNBQVM7QUFBQSxJQUFBO0FBQUEsRUFFeEU7QUFDQSxNQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3pCLFdBQU8sRUFBRSxTQUFTLFlBQVksUUFBUSxvQ0FBQTtBQUFBLEVBQ3ZDO0FBRUEsU0FBTztBQUFBLElBQ04sU0FBUztBQUFBLElBQ1QsUUFBUSxHQUFHLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTTtBQUFBLEVBQUE7QUFFNUM7QUFFQSxTQUFTLGNBQWMsU0FBaUIsTUFBdUI7QUFDOUQsUUFBTSxPQUFPLG1CQUFtQixJQUFJO0FBRXBDLE1BQUksQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLE1BQU07QUFDcEMsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsUUFBUTtBQUFBLElBQUE7QUFBQSxFQUVWO0FBQ0EsTUFBSSxLQUFLLFdBQVcsS0FBSyxZQUFZLFNBQVM7QUFDN0MsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsUUFBUSxnQkFBZ0IsS0FBSyxPQUFPLGdCQUFnQixPQUFPO0FBQUEsSUFBQTtBQUFBLEVBRTdEO0FBSUEsU0FBTyxFQUFFLFNBQVMsTUFBTSxRQUFRLElBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUE7QUFDcEU7QUFFQSxTQUFTLGNBQWMsTUFBdUI7QUFDN0MsUUFBTSxRQUFRLGtCQUFrQixJQUFJO0FBQ3BDLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdkIsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsUUFBUTtBQUFBLElBQUE7QUFBQSxFQUVWO0FBQ0EsU0FBTyxFQUFFLFNBQVMsTUFBTSxRQUFRLEdBQUcsTUFBTSxNQUFNLFNBQUE7QUFDaEQ7QUFNTyxTQUFTLGNBQWMsTUFBNkI7QUFDMUQsUUFBTSxRQUFRLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQUE7QUFFRCxTQUFPLFFBQVEsTUFBTSxDQUFDLElBQUk7QUFDM0I7QUFFQSxTQUFTLGVBQWUsTUFBdUI7QUFDOUMsTUFBSSxjQUFjLElBQUksR0FBRztBQUN4QixXQUFPLEVBQUUsU0FBUyxNQUFNLFFBQVEseUJBQUE7QUFBQSxFQUNqQztBQUdBLFFBQU0sbUJBQW1CLFdBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxTQUFTO0FBQ2hFLFNBQU8sbUJBQ0o7QUFBQSxJQUNBLFNBQVM7QUFBQSxJQUNULFFBQVE7QUFBQSxFQUFBLElBRVI7QUFBQSxJQUNBLFNBQVM7QUFBQSxJQUNULFFBQVE7QUFBQSxFQUFBO0FBRVo7QUNoS0EsTUFBTSxlQUFlO0FBTXJCLE1BQU0sbUJBQW1CO0FBR3pCLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sMEJBQTBCO0FBRWhDLFNBQVMsT0FBTyxNQUF1QjtBQUN0QyxVQUFRLElBQUkscUJBQXFCLEdBQUcsSUFBSTtBQUN6QztBQVNBLE1BQU0sY0FBYztBQUNwQixNQUFNLHNCQUFzQjtBQUU1QixlQUFlLGdCQUErQjtBQUM3QyxRQUFNLE9BQU8sT0FDWCxPQUFPLGFBQWEsRUFBRSxnQkFBZ0Isb0JBQUEsQ0FBcUIsRUFDM0QsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2pCO0FBRUEsZUFBZSx1QkFBc0M7QUFDcEQsUUFBTSxPQUFPLE9BQU8sTUFBTSxXQUFXLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ3REO0FBR0EsZUFBc0IsZUFBa0M7QUFDdkQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZLFFBQU87QUFFNUQsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVO0FBQy9ELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxDQUFDLFFBQVEsUUFBUSxnQkFBZ0IsT0FBVyxRQUFPO0FBRXZELFFBQU0scUJBQUE7QUFDTixRQUFNLGtCQUFrQixRQUFRLFdBQVc7QUFFM0MsTUFBSTtBQUNILFVBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsVUFBTSxPQUFPLEtBQUssT0FBTyxRQUFRLGFBQWEsRUFBRSxLQUFLLEtBQUssS0FBSztBQUFBLEVBQ2hFLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBQ0EsU0FBTztBQUNSO0FBR0EsZUFBc0IsY0FBaUM7QUFDdEQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZLFFBQU87QUFFNUQsUUFBTSxxQkFBQTtBQUNOLFFBQU0sY0FBYyxNQUFNLFlBQVksV0FBVyxVQUFVO0FBQzNELFFBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsU0FBTyxRQUFBO0FBQ1I7QUFXQSxlQUFzQixxQkFBcUIsT0FBOEI7QUFDeEUsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZO0FBRXJELFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUMvRCxNQUFJLE1BQU0sV0FBVyxTQUFVO0FBRy9CLFFBQU0sV0FBVyxNQUFNLGdCQUFnQixLQUFLO0FBQzVDLE1BQUksWUFBWSxDQUFDLFNBQVMsU0FBVTtBQUVwQyxRQUFNLFlBQVksS0FBSyxZQUFZLEtBQUs7QUFDeEMsTUFBSSxXQUFXLGNBQWM7QUFDNUIsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLDBEQUEwRCxRQUFRO0FBQUEsTUFDbEU7QUFBQSxJQUFBO0FBRUQsVUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFNLFFBQUE7QUFDTjtBQUFBLEVBQ0Q7QUFFQTtBQUFBLElBQ0MsR0FBRyxLQUFLLEtBQUssMERBQTBELFFBQVE7QUFBQSxFQUFBO0FBRWhGLFFBQU07QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFBO0FBRUQsUUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxRQUFNLGFBQUE7QUFDUDtBQUdBLGVBQXNCLHNCQUFxQztBQUMxRCxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLE1BQUksTUFBTSxXQUFXLGFBQWEsQ0FBQyxNQUFNLFdBQVk7QUFFckQsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVO0FBQy9ELE1BQUksTUFBTSxXQUFXLFVBQVc7QUFHaEMsTUFBSSxLQUFLLFdBQVc7QUFDbkIsUUFBSSxHQUFHLEtBQUssS0FBSyw2Q0FBNkM7QUFDOUQ7QUFBQSxFQUNEO0FBRUEsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsWUFBWSxjQUFjO0FBQ3JDLFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxHQUFHLEtBQUssVUFBVSxVQUFVLGtCQUFrQixRQUFRLFFBQVE7QUFBQSxJQUFBO0FBRS9ELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxRQUFBO0FBQ047QUFBQSxFQUNEO0FBRUEsUUFBTSxhQUFBO0FBQ1A7QUFJQSxlQUFzQixTQUNyQixTQUNBLFlBQ29CO0FBQ3BCLFFBQU0sU0FBQTtBQUVOLFFBQU0sUUFBcUIsUUFBUSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsSUFDdkQsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLEVBQUEsRUFDUDtBQUVGLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdkIsVUFBTUMsU0FBa0I7QUFBQSxNQUN2QixRQUFRO0FBQUEsTUFDUixPQUFPLENBQUE7QUFBQSxNQUNQLFNBQVM7QUFBQSxJQUFBO0FBRVYsVUFBTSxZQUFZQSxNQUFLO0FBQ3ZCLFdBQU9BO0FBQUFBLEVBQ1I7QUFJQSxRQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssZUFBZSxRQUFRLE1BQU07QUFDekUsTUFBSSxJQUFJLE9BQU8sT0FBVyxPQUFNLElBQUksTUFBTSw2QkFBNkI7QUFFdkUsUUFBTSxXQUFXO0FBQUEsSUFDaEI7QUFBQSxJQUNBLGFBQWEsSUFBSTtBQUFBLElBQ2pCLHFCQUFxQixRQUFRO0FBQUEsSUFDN0Isa0JBQWtCLENBQUE7QUFBQSxJQUNsQixlQUFlO0FBQUEsSUFDZixhQUFhLFFBQVEsZUFBZTtBQUFBLElBQ3BDLFVBQVU7QUFBQSxFQUFBLENBQ1Y7QUFFRCxRQUFNLFFBQWtCO0FBQUEsSUFDdkIsUUFBUTtBQUFBLElBQ1I7QUFBQSxJQUNBLFdBQVcsS0FBSyxJQUFBO0FBQUEsRUFBSTtBQUVyQixRQUFNLFlBQVksS0FBSztBQUV2QixNQUFJO0FBQ0gsVUFBTSxlQUFlLElBQUksRUFBRTtBQUFBLEVBQzVCLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEsUUFBTSxTQUFTLEdBQUc7QUFDbEIsaUJBQUE7QUFDQSxRQUFNLE9BQU8sT0FDWCxPQUFPLGdCQUFnQixFQUFFLGlCQUFpQix3QkFBQSxDQUF5QixFQUNuRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDaEIsTUFBSSxnQkFBZ0IsTUFBTSxNQUFNLHNCQUFzQixJQUFJLEVBQUUsRUFBRTtBQUM5RCxTQUFPLFFBQUE7QUFDUjtBQVNBLGVBQXNCLGdCQUErQjtBQUNwRCxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLE1BQUksTUFBTSxXQUFXLGFBQWEsQ0FBQyxNQUFNLFdBQVk7QUFFckQsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVO0FBQy9ELE1BQUksTUFBTSxXQUFXLFNBQVU7QUFFL0IsUUFBTSxNQUFNLEtBQUssSUFBQSxLQUFTLEtBQUssYUFBYTtBQUM1QyxNQUFJLE1BQU0saUJBQWtCO0FBRTVCLFFBQU0sWUFBWSxLQUFLLFlBQVksS0FBSztBQUN4QyxNQUFJLFdBQVcsY0FBYztBQUM1QixRQUFJLGdCQUFnQixLQUFLLEtBQUssVUFBVSxRQUFRLFdBQVc7QUFDM0QsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLHFCQUFxQixRQUFRO0FBQUEsTUFDN0I7QUFBQSxJQUFBO0FBRUQsVUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFNLFFBQUE7QUFDTjtBQUFBLEVBQ0Q7QUFFQTtBQUFBLElBQ0MsR0FBRyxLQUFLLEtBQUssZ0JBQWdCLEtBQUssTUFBTSxNQUFNLEdBQUksQ0FBQywwQkFBMEIsUUFBUTtBQUFBLEVBQUE7QUFFdEYsUUFBTTtBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0w7QUFBQSxJQUNBLHFCQUFxQixLQUFLLE1BQU0sTUFBTSxHQUFJLENBQUMsMEJBQTBCLFFBQVE7QUFBQSxJQUM3RTtBQUFBLEVBQUE7QUFFRCxRQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFFBQU0sYUFBQTtBQUNQO0FBUUEsZUFBc0IsWUFBMkI7QUFDaEQsUUFBTSxxQkFBQTtBQUNOLGdCQUFBO0FBQ0EsUUFBTSxPQUFPLE9BQU8sTUFBTSxjQUFjLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ3hELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxRQUFRLGdCQUFnQixRQUFXO0FBQ3RDLFVBQU0sT0FBTyxRQUFRLFdBQVc7QUFDaEMsVUFBTSxrQkFBa0IsUUFBUSxXQUFXO0FBQUEsRUFDNUM7QUFDQSxRQUFNLFNBQUE7QUFDTixRQUFNLFNBQVMsRUFBRTtBQUNqQixNQUFJLGFBQWE7QUFDbEI7QUFXQSxlQUFzQixVQUFVLFlBQXVDO0FBQ3RFLFFBQU0sV0FBVyxNQUFNLFlBQUE7QUFDdkIsTUFBSSxTQUFTLE1BQU0sV0FBVyxHQUFHO0FBQ2hDLFdBQU8sUUFBUSw0QkFBNEI7QUFBQSxFQUM1QztBQUVBLFFBQU0sUUFBcUIsU0FBUyxNQUFNO0FBQUEsSUFBSSxDQUFDLFNBQzlDLEtBQUssV0FBVyxjQUFjLEtBQUssV0FBVyxZQUMzQyxPQUNBO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxRQUFRO0FBQUEsTUFDUixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsTUFDVixXQUFXO0FBQUEsTUFDWCxXQUFXLEtBQUssSUFBQTtBQUFBLElBQUk7QUFBQSxFQUNyQjtBQUdILFFBQU0sY0FBYyxNQUFNLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxTQUFTLEVBQUU7QUFDdEUsTUFBSSxnQkFBZ0IsR0FBRztBQUN0QixXQUFPLFFBQVEsd0RBQXdEO0FBQUEsRUFDeEU7QUFFQSxRQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssZUFBZSxRQUFRLE1BQU07QUFDekUsTUFBSSxJQUFJLE9BQU8sT0FBVyxPQUFNLElBQUksTUFBTSw2QkFBNkI7QUFJdkUsUUFBTSxjQUFjLENBQUMsYUFBYTtBQUFBLElBQ2pDLEdBQUc7QUFBQSxJQUNIO0FBQUEsSUFDQSxhQUFhLElBQUk7QUFBQSxJQUNqQixVQUFVO0FBQUEsRUFBQSxFQUNUO0FBRUYsUUFBTSxZQUFZO0FBQUEsSUFDakIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBLFNBQVM7QUFBQSxJQUNULFlBQVk7QUFBQSxFQUFBLENBQ1o7QUFFRCxNQUFJO0FBQ0gsVUFBTSxlQUFlLElBQUksRUFBRTtBQUFBLEVBQzVCLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEsUUFBTSxTQUFTLEdBQUc7QUFDbEIsaUJBQUE7QUFDQSxRQUFNLE9BQU8sT0FDWCxPQUFPLGdCQUFnQixFQUFFLGlCQUFpQix3QkFBQSxDQUF5QixFQUNuRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDaEIsTUFBSSxhQUFhLFdBQVcsT0FBTyxNQUFNLE1BQU0scUJBQXFCO0FBQ3BFLFNBQU8sUUFBQTtBQUNSO0FBRUEsZUFBc0IsWUFBK0I7QUFDcEQsUUFBTSxxQkFBQTtBQUNOLGdCQUFBO0FBQ0EsUUFBTSxPQUFPLE9BQU8sTUFBTSxjQUFjLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBRXhELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsUUFBTSxZQUFzQjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFlBQVksS0FBSyxJQUFBO0FBQUEsSUFDakIsU0FBUztBQUFBLEVBQUE7QUFHVixRQUFNLFlBQVksU0FBUztBQUMzQixRQUFNLGVBQUE7QUFDTixRQUFNLFNBQVMsRUFBRTtBQUNqQixRQUFNLGNBQUE7QUFDTixRQUFNLFlBQVksU0FBUztBQUMzQixTQUFPO0FBQ1I7QUFFQSxlQUFlLFFBQVEsU0FBb0M7QUFDMUQsZ0JBQUE7QUFDQSxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLFFBQU0sU0FBbUI7QUFBQSxJQUN4QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZO0FBQUEsSUFDWixZQUFZLEtBQUssSUFBQTtBQUFBLElBQ2pCO0FBQUEsRUFBQTtBQUVELFFBQU0sWUFBWSxNQUFNO0FBQ3hCLFFBQU0sU0FBUyxHQUFHO0FBQ2xCLFFBQU0sWUFBWSxNQUFNO0FBQ3hCLFNBQU87QUFDUjtBQUtBLGVBQXNCLFVBQTZCO0FBQ2xELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsVUFBVyxRQUFPO0FBRXZDLFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxXQUFXLFNBQVM7QUFFakUsTUFBSSxDQUFDLE1BQU07QUFFVixVQUFNLFNBQVMsTUFBTSxnQkFBQTtBQUNyQixRQUFJLGVBQWUsUUFBQTtBQUNuQixXQUFPLFVBQUE7QUFBQSxFQUNSO0FBRUEsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsZ0JBQWdCLFFBQVc7QUFDdEMsV0FBTyxRQUFRLHlCQUF5QjtBQUFBLEVBQ3pDO0FBRUEsUUFBTSxxQkFBQTtBQUNOLFFBQU0sY0FBYyxDQUFDLE9BQU8sRUFBRSxHQUFHLEdBQUcsVUFBVSxJQUFJO0FBQ2xELFFBQU0sa0JBQWtCLFFBQVEsV0FBVztBQUUzQyxRQUFNLFVBQW9CO0FBQUEsSUFDekIsR0FBRztBQUFBLElBQ0gsWUFBWSxLQUFLO0FBQUEsSUFDakIsT0FBTyxNQUFNLE1BQU07QUFBQSxNQUFJLENBQUMsU0FDdkIsS0FBSyxRQUFRLEtBQUssTUFDZjtBQUFBLFFBQ0EsR0FBRztBQUFBLFFBQ0gsUUFBUTtBQUFBLFFBQ1IsUUFBUTtBQUFBLFFBQ1IsVUFBVTtBQUFBLFFBQ1YsV0FBVyxLQUFLLElBQUE7QUFBQSxNQUFJLElBRXBCO0FBQUEsSUFBQTtBQUFBLElBRUosU0FBUztBQUFBLEVBQUE7QUFFVixRQUFNLFlBQVksT0FBTztBQUN6QixRQUFNLFlBQVksT0FBTztBQUV6QixNQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQUU7QUFFbEMsTUFBSTtBQUNILFVBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsVUFBTSxPQUFPLEtBQUssT0FBTyxRQUFRLGFBQWEsRUFBRSxLQUFLLEtBQUssS0FBSztBQUFBLEVBQ2hFLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEsU0FBTztBQUNSO0FBUUEsZUFBc0IscUJBQXFCLE9BQThCO0FBQ3hFLFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU0sV0FBWTtBQUVyRCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLE1BQUksUUFBUSxnQkFBZ0IsTUFBTztBQUVuQyxRQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxNQUFNLFVBQVU7QUFDL0QsTUFBSSxDQUFDLEtBQU07QUFPWCxRQUFNLFdBQVcsTUFBTSxnQkFBZ0IsS0FBSztBQUM1QyxNQUFJLENBQUMsWUFBWSxTQUFTLFNBQVU7QUFFcEMsTUFBSTtBQUNKLE1BQUk7QUFDSCxlQUFXLE1BQU0sU0FBUyxPQUFPLFFBQVE7QUFBQSxFQUMxQyxTQUFTLE9BQU87QUFDZixRQUFJLGVBQWUsS0FBSyxFQUFHO0FBRTNCLFVBQU1DLGFBQ0wsTUFBTSxjQUFjLENBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxVQUFVLEVBQUUsV0FBVyxFQUFBLEVBQUksR0FDOUQ7QUFDRixRQUFJLEdBQUcsS0FBSyxLQUFLLDJCQUEyQixjQUFjLEtBQUssQ0FBQyxFQUFFO0FBQ2xFLFFBQUlBLGFBQVksY0FBYztBQUM3QixZQUFNLGNBQWMsS0FBSyxLQUFLLFVBQVUsY0FBYyxLQUFLLEdBQUdBLFNBQVE7QUFDdEUsWUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxZQUFNLFFBQUE7QUFBQSxJQUNQO0FBQ0E7QUFBQSxFQUNEO0FBRUEsUUFBTSxZQUNMLE1BQU0sY0FBYyxDQUFDLE9BQU8sRUFBRSxHQUFHLEdBQUcsVUFBVSxFQUFFLFdBQVcsRUFBQSxFQUFJLEdBQzlEO0FBRUYsUUFBTSxVQUFVLFNBQVMsS0FBSyxNQUFNLEtBQUssS0FBSyxTQUFTLFFBQVEsU0FBUyxJQUFJO0FBQzVFO0FBQUEsSUFDQyxHQUFHLEtBQUssS0FBSyxVQUFVLFNBQVMsTUFBTSxLQUFLLFNBQVMsS0FBSyxNQUFNLFlBQVksUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBQUEsRUFBQTtBQUc5RyxNQUFJLFFBQVEsWUFBWSxXQUFXO0FBSWxDLFFBQUksUUFBUSxXQUFXO0FBQ3RCLFVBQUksR0FBRyxLQUFLLEtBQUssNkNBQTZDO0FBQzlELFlBQU0scUJBQUE7QUFDTixZQUFNLGVBQWUsQ0FBQyxhQUFhO0FBQUEsUUFDbEMsR0FBRztBQUFBLFFBQ0gsT0FBTyxRQUFRLE1BQU07QUFBQSxVQUFJLENBQUMsTUFDekIsRUFBRSxRQUFRLEtBQUssTUFDWjtBQUFBLFlBQ0EsR0FBRztBQUFBLFlBQ0gsUUFBUTtBQUFBLFlBQ1IsUUFBUSxRQUFRO0FBQUEsWUFDaEI7QUFBQSxZQUNBLFdBQVc7QUFBQSxZQUNYLFdBQVcsS0FBSyxJQUFBO0FBQUEsVUFBSSxJQUVwQjtBQUFBLFFBQUE7QUFBQSxNQUNKLEVBQ0M7QUFDRixZQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDO0FBQUEsSUFDRDtBQUVBLFFBQUksWUFBWSxjQUFjO0FBQzdCLFlBQU07QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMO0FBQUEsUUFDQSxHQUFHLFFBQVEsTUFBTSxrQkFBa0IsUUFBUTtBQUFBLE1BQUE7QUFFNUMsWUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxZQUFNLFFBQUE7QUFDTjtBQUFBLElBQ0Q7QUFDQSxVQUFNO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0EsR0FBRyxRQUFRLE1BQU0sYUFBYSxRQUFRLE9BQU8sWUFBWTtBQUFBLE1BQ3pEO0FBQUEsSUFBQTtBQUVELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxjQUFBO0FBQ047QUFBQSxFQUNEO0FBRUEsTUFBSSxRQUFRLFlBQVksWUFBWTtBQUNuQyxVQUFNLGNBQWMsS0FBSyxLQUFLLFVBQVUsUUFBUSxNQUFNO0FBQ3RELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxRQUFBO0FBQ047QUFBQSxFQUNEO0FBS0EsUUFBTSxxQkFBcUIsT0FBTyxRQUFRO0FBRTFDLE1BQUksS0FBSyxTQUFTLFVBQVU7QUFDM0IsVUFBTSxpQkFBaUIsTUFBTSxTQUFTLElBQUk7QUFBQSxFQUMzQyxPQUFPO0FBQ04sVUFBTSxRQUFRO0FBQUEsTUFDYixNQUFNLEtBQUs7QUFBQSxNQUNYLEtBQUssS0FBSztBQUFBLE1BQ1YsTUFBTSxZQUFZLEtBQUssTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxNQUFNLFNBQVM7QUFBQSxJQUFBLENBQ2Y7QUFDRCxRQUFJLEtBQUssU0FBUyxVQUFXLE9BQU0sYUFBYSxTQUFTLElBQUk7QUFDN0QsVUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFFBQVEsTUFBTTtBQUFBLEVBQ3pEO0FBRUEsUUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxRQUFNLFFBQUE7QUFDUDtBQVFBLGVBQWUsaUJBQWlCLE1BQWlCLE1BQTZCO0FBQzdFLFFBQU0sTUFBTSxjQUFjLElBQUk7QUFDOUIsTUFBSSxDQUFDLEtBQUs7QUFDVCxVQUFNLGNBQWMsS0FBSyxLQUFLLFVBQVUsK0JBQStCO0FBQ3ZFO0FBQUEsRUFDRDtBQUVBLE1BQUk7QUFDSCxVQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWEsR0FBRyxDQUFDO0FBQzlDLFFBQUksQ0FBQyxTQUFTLEdBQUksT0FBTSxJQUFJLE1BQU0sa0JBQWtCLFNBQVMsTUFBTSxFQUFFO0FBRXJFLFVBQU0sUUFBUSxJQUFJLFdBQVcsTUFBTSxTQUFTLGFBQWE7QUFDekQsUUFBSSxNQUFNLENBQUMsTUFBTSxNQUFRLE1BQU0sQ0FBQyxNQUFNLElBQU07QUFDM0MsWUFBTSxJQUFJLE1BQU0sc0NBQXNDO0FBQUEsSUFDdkQ7QUFFQSxVQUFNLFFBQVE7QUFBQSxNQUNiLE1BQU07QUFBQSxNQUNOLEtBQUssS0FBSztBQUFBLE1BQ1YsTUFBTSxHQUFHLEtBQUssR0FBRztBQUFBLE1BQ2pCLFFBQVEsU0FBUyxLQUFLO0FBQUEsSUFBQSxDQUN0QjtBQUNELFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxtQkFBbUIsS0FBSyxNQUFNLE1BQU0sU0FBUyxJQUFJLENBQUM7QUFBQSxJQUFBO0FBQUEsRUFFcEQsU0FBUyxPQUFPO0FBQ2YsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLDhCQUE4QixjQUFjLEtBQUssQ0FBQztBQUFBLElBQUE7QUFBQSxFQUVwRDtBQUNEO0FBR0EsZUFBZSxhQUFhLE1BQTZCO0FBQ3hELFFBQU0sU0FBUyxjQUFjLGdCQUFnQixJQUFJLENBQUM7QUFDbEQsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUV6QixRQUFNLGNBQWMsQ0FBQyxZQUFZO0FBQ2hDLFVBQU0sYUFBYSxFQUFFLEdBQUcsUUFBUSxpQkFBQTtBQUNoQyxlQUFXLFNBQVMsUUFBUTtBQUMzQixVQUFJLENBQUMsV0FBVyxNQUFNLE9BQU8sR0FBRztBQUMvQixtQkFBVyxNQUFNLE9BQU8sSUFBSSxFQUFFLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFBO0FBQUEsTUFDNUQ7QUFBQSxJQUNEO0FBQ0EsV0FBTyxFQUFFLEdBQUcsU0FBUyxrQkFBa0IsV0FBQTtBQUFBLEVBQ3hDLENBQUM7QUFDRjtBQU1BLGVBQWUsa0JBQW9DO0FBQ2xELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxRQUFRLGlCQUFpQixRQUFRLFlBQWEsUUFBTztBQUV6RCxRQUFNLGNBQWMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLGVBQWUsT0FBTztBQUUxRCxRQUFNLFFBQVEsSUFBSSxJQUFJLFFBQVEsbUJBQW1CO0FBQ2pELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsUUFBTSxnQkFBZ0IsSUFBSTtBQUFBLElBQ3pCLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRztBQUFBLEVBQUE7QUFHaEUsUUFBTSxRQUFxQixPQUFPLFFBQVEsUUFBUSxnQkFBZ0IsRUFDaEUsT0FBTyxDQUFDLENBQUMsT0FBTyxNQUFNLENBQUMsTUFBTSxJQUFJLE9BQU8sS0FBSyxDQUFDLGNBQWMsSUFBSSxPQUFPLENBQUMsRUFDeEUsSUFBSSxDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU87QUFBQSxJQUMzQixNQUFNO0FBQUEsSUFDTixLQUFLO0FBQUEsSUFDTCxPQUFPLEdBQUcsTUFBTSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxjQUFjLE1BQU0sR0FBRztBQUFBLElBQzVCLFFBQVE7QUFBQSxFQUFBLEVBQ1AsRUFDRCxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsTUFBTSxjQUFjLEVBQUUsS0FBSyxDQUFDO0FBRS9DLE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUUvQixRQUFNLE9BQU8sTUFBTSxZQUFZLEtBQUs7QUFDcEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNSO0FBSUEsZUFBZSxZQUErQjtBQUM3QyxRQUFNLHFCQUFBO0FBQ04sZ0JBQUE7QUFDQSxRQUFNLE9BQU8sT0FBTyxNQUFNLGNBQWMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFJeEQsUUFBTSxVQUFVLE1BQU0sZUFBZSxDQUFDLGFBQWE7QUFBQSxJQUNsRCxHQUFHO0FBQUEsSUFDSCxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQUksQ0FBQyxTQUN6QixLQUFLLFdBQVcsY0FDaEIsS0FBSyxXQUFXLFlBQ2hCLEtBQUssV0FBVyxZQUNiLE9BQ0E7QUFBQSxRQUNBLEdBQUc7QUFBQSxRQUNILFFBQVE7QUFBQSxRQUNSLFFBQVEsS0FBSyxVQUFVO0FBQUEsTUFBQTtBQUFBLElBQ3hCO0FBQUEsRUFDSCxFQUNDO0FBRUYsUUFBTSxRQUFRO0FBQ2QsUUFBTSxXQUFXLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFFBQU0sU0FBUyxNQUFNLE1BQU0sT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLFFBQVEsRUFBRTtBQUVoRSxRQUFNLE9BQWlCO0FBQUEsSUFDdEIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osWUFBWSxLQUFLLElBQUE7QUFBQSxJQUNqQixTQUFTLFNBQ04sWUFBWSxRQUFRLE9BQU8sTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLGFBQ3hELGdCQUFnQixRQUFRO0FBQUEsRUFBQTtBQU01QixRQUFNLFlBQVksSUFBSTtBQUN0QixRQUFNLGVBQUE7QUFDTixRQUFNLFNBQVMsU0FBUyxPQUFPLE1BQU0sSUFBSSxFQUFFO0FBQzNDLFFBQU0sY0FBQTtBQUNOLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFFBQU0sZUFBZSxJQUFJO0FBQ3pCLFNBQU87QUFDUjtBQUdBLGVBQWUsaUJBQWdDO0FBQzlDLFFBQU0sRUFBRSxnQkFBZ0IsTUFBTSxXQUFBO0FBQzlCLE1BQUksZ0JBQWdCLE9BQVc7QUFDL0IsUUFBTSxPQUFPLFdBQVc7QUFDeEIsUUFBTSxrQkFBa0IsV0FBVztBQUNuQyxRQUFNLE9BQU8sS0FBSyxPQUFPLFdBQVcsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDckQ7QUFHQSxlQUFlLGdCQUErQjtBQUM3QyxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsTUFBSTtBQUNILFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxJQUFJLFVBQVU7QUFDNUMsVUFBTSxPQUFPLEtBQUssT0FBTyxZQUFZLEVBQUUsUUFBUSxNQUFNO0FBQ3JELFFBQUksSUFBSSxhQUFhLFFBQVc7QUFDL0IsWUFBTSxPQUFPLFFBQVEsT0FBTyxJQUFJLFVBQVUsRUFBRSxTQUFTLE1BQU07QUFBQSxJQUM1RDtBQUFBLEVBQ0QsUUFBUTtBQUFBLEVBRVI7QUFDRDtBQUVBLGVBQWUsZUFBZSxPQUFnQztBQUM3RCxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsUUFBTSxPQUFPLEtBQ1gsWUFBWSxZQUFZLEVBQUUsTUFBTSxZQUFZLE1BQUEsQ0FBTyxFQUNuRCxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDakI7QUFLQSxlQUFlLFFBQVEsTUFBbUM7QUFDekQsUUFBTSxRQUFRLElBQUk7QUFDbEIsUUFBTSxXQUFXLElBQUk7QUFDdEI7QUFHQSxlQUFzQixjQUE2QjtBQUNsRCxhQUFXLFFBQVEsTUFBTSxTQUFBLEVBQVksT0FBTSxXQUFXLElBQUk7QUFDM0Q7QUFFQSxTQUFTLFlBQVksTUFBNEIsS0FBcUI7QUFDckUsVUFBUSxNQUFBO0FBQUEsSUFDUCxLQUFLO0FBQ0osYUFBTyxXQUFXLEdBQUc7QUFBQSxJQUN0QixLQUFLO0FBQ0osYUFBTyxHQUFHLEdBQUc7QUFBQSxJQUNkLEtBQUs7QUFDSixhQUFPO0FBQUEsSUFDUjtBQUNDLGFBQU8sR0FBRyxHQUFHO0FBQUEsRUFBQTtBQUVoQjtBQUVBLFNBQVMsU0FBUyxPQUEyQjtBQUM1QyxNQUFJLFNBQVM7QUFFYixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLE9BQVE7QUFDOUMsY0FBVSxPQUFPLGFBQWEsR0FBRyxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQU0sQ0FBQztBQUFBLEVBQy9EO0FBQ0EsU0FBTyxLQUFLLE1BQU07QUFDbkI7QUFFQSxlQUFlLFNBQVMsTUFBNkI7QUFDcEQsUUFBTSxPQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDMUQ7QUNqeUJBLElBQUksUUFBMEIsUUFBUSxRQUFBO0FBRS9CLFNBQVMsT0FBVSxNQUFvQztBQUM3RCxRQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUdsQyxVQUFRLEtBQUssTUFBTSxNQUFNLE1BQVM7QUFDbEMsU0FBTztBQUNSO0FDbUJBLE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFFBQVEsaUJBQWlCO0FBR3ZFLE1BQUksZ0JBQWdCLE9BQU8sR0FBRztBQUM3QixTQUFLLG9CQUFvQixPQUFPLE9BQU8sT0FBTyxNQUFNO0FBQUEsRUFDckQ7QUFHQSxnQkFBYyxTQUEyQyxNQUFNLEVBQzdELEtBQUssWUFBWSxFQUNqQixNQUFNLENBQUMsVUFBVSxhQUFhLEVBQUUsT0FBTyxPQUFPLEtBQUssRUFBQSxDQUFHLENBQUM7QUFDekQsU0FBTztBQUNSLENBQUM7QUFFRCxlQUFlLGNBQ2QsU0FDQSxRQUNtQjtBQUNuQixVQUFRLFFBQVEsTUFBQTtBQUFBLElBQ2YsS0FBSztBQUNKLGFBQU87QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFNBQVM7QUFBQSxRQUNULE9BQU8sTUFBTSxZQUFBO0FBQUEsTUFBWTtBQUFBLElBRzNCLEtBQUs7QUFDSixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxjQUFZO0FBQUEsSUFFbEQsS0FBSyxTQUFTO0FBQ2IsWUFBTSxhQUFhLE9BQU8sS0FBSztBQUMvQixVQUFJLGVBQWUsT0FBVyxRQUFPLEVBQUUsT0FBTyxpQkFBQTtBQUM5QyxZQUFNLFVBQVcsUUFDZjtBQUNGLFlBQU0sUUFBUSxNQUFNLFNBQVMsU0FBUyxVQUFVO0FBQ2hELGFBQU8sRUFBRSxNQUFNLFNBQVMsTUFBQTtBQUFBLElBQ3pCO0FBQUEsSUFFQSxLQUFLLFVBQVU7QUFDZCxZQUFNLGFBQWEsT0FBTyxLQUFLO0FBQy9CLFVBQUksZUFBZSxPQUFXLFFBQU8sRUFBRSxPQUFPLGlCQUFBO0FBQzlDLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLFVBQVUsVUFBVSxFQUFBO0FBQUEsSUFDMUQ7QUFBQSxJQUVBLEtBQUs7QUFDSixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxZQUFVO0FBQUEsSUFFaEQsS0FBSztBQUNKLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLGVBQWE7QUFBQSxJQUVuRCxLQUFLO0FBQ0osYUFBTyxFQUFFLE1BQU0sU0FBUyxPQUFPLE1BQU0sY0FBWTtBQUFBLElBRWxELEtBQUs7QUFDSixZQUFNLFlBQUE7QUFDTixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxjQUFZO0FBQUEsSUFFbEQsS0FBSztBQUNKLFlBQU0sVUFBQTtBQUNOLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLGNBQVk7QUFBQSxJQUVsRDtBQUNDLGFBQU8sRUFBRSxPQUFPLG9CQUFvQixRQUFRLElBQUksR0FBQTtBQUFBLEVBQUc7QUFFdEQ7QUFjQSxPQUFPLFNBQVMsUUFBUSxZQUFZLENBQUMsUUFBUSxRQUFRLFdBQVc7QUFDL0QsTUFBSSxPQUFPLFVBQVUsVUFBYSxDQUFDLE9BQVE7QUFDM0MsUUFBTSxRQUFRLE9BQU87QUFDckIsT0FBSyxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sUUFBUSxNQUFNLENBQUMsRUFBRTtBQUFBLElBQzdELENBQUMsVUFBVTtBQUNWLGNBQVEsTUFBTSwyQ0FBMkMsUUFBUSxLQUFLO0FBQUEsSUFDdkU7QUFBQSxFQUFBO0FBRUYsQ0FBQztBQUVELGVBQWUsb0JBQ2QsT0FDQSxRQUNBLFFBQ2dCO0FBQ2hCLE1BQUksV0FBVyw0QkFBNEI7QUFDMUMsVUFBTSxxQkFBcUIsT0FBTyxNQUFNO0FBQ3hDO0FBQUEsRUFDRDtBQUVBLE1BQUksV0FBVywyQkFBMkI7QUFDekMsVUFBTSxXQUFXLE1BQU0sb0JBQW9CLE9BQU8sTUFBTTtBQUd4RCxRQUFJLFNBQVUsT0FBTSxxQkFBcUIsS0FBSztBQUFBLEVBQy9DO0FBQ0Q7QUFPQSxPQUFPLFNBQVMsU0FBUyxZQUFZLENBQUMsUUFBUSxXQUFXO0FBQ3hELE9BQUssYUFBYSxPQUFPLE9BQU8sTUFBTTtBQUN2QyxDQUFDO0FBRUQsZUFBZSxhQUFhLE9BQWUsUUFBK0I7QUFDekUsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsZ0JBQWdCLE1BQU87QUFFbkMsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxVQUFXO0FBRWhDLFFBQU0sWUFBWTtBQUFBLElBQ2pCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFlBQVksS0FBSyxJQUFBO0FBQUEsSUFDakIsU0FBUyxpQ0FBaUMsTUFBTTtBQUFBLEVBQUEsQ0FDaEQ7QUFDRCxRQUFNLE9BQU8sT0FBTyxhQUFhLEVBQUUsTUFBTSxJQUFBLENBQUssRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0Q7QUFJQSxPQUFPLEtBQUssVUFBVSxZQUFZLENBQUMsVUFBVTtBQUc1QyxPQUFLLE9BQU8sTUFBTSxpQkFBaUIsS0FBSyxDQUFDO0FBQzFDLENBQUM7QUFFRCxlQUFlLGlCQUFpQixPQUE4QjtBQUM3RCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsVUFBVztBQUVoQyxNQUFJLFFBQVEsZ0JBQWdCLE9BQU87QUFDbEMsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxZQUFZO0FBQUEsTUFDakIsR0FBRztBQUFBLE1BQ0gsUUFBUTtBQUFBLE1BQ1IsWUFBWTtBQUFBLE1BQ1osWUFBWSxLQUFLLElBQUE7QUFBQSxNQUNqQixTQUFTO0FBQUEsSUFBQSxDQUNUO0FBQ0QsVUFBTSxPQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sR0FBQSxDQUFJLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQUEsRUFDOUQ7QUFDRDtBQVNBLE9BQU8sUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxRQUFNLFlBQVk7QUFDakIsVUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixRQUFJLE1BQU0sV0FBVyxVQUFXO0FBQ2hDLFVBQU0sWUFBWTtBQUFBLE1BQ2pCLEdBQUc7QUFBQSxNQUNILFFBQVE7QUFBQSxNQUNSLFlBQVk7QUFBQSxNQUNaLFNBQVM7QUFBQSxJQUFBLENBQ1Q7QUFBQSxFQUNGLEdBQUE7QUFDRCxDQUFDO0FBU0QsT0FBTyxLQUFLLFVBQVUsWUFBWSxDQUFDLE9BQU8sU0FBUztBQUNsRCxNQUFJLEtBQUssV0FBVyxXQUFZO0FBQ2hDLFFBQU0sWUFBWTtBQUNqQixVQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLFFBQUksTUFBTSxXQUFXLFVBQVc7QUFFaEMsVUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixRQUFJLFFBQVEsZ0JBQWdCLE1BQU87QUFHbkMsUUFBSSxDQUFDLE1BQU0sWUFBWTtBQUN0QixZQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCO0FBQUEsSUFDRDtBQUVBLFVBQU0sT0FBTyxNQUFNLHFCQUFxQixLQUFLLENBQUM7QUFLOUMsVUFBTSxPQUFPLE1BQU0scUJBQXFCLEtBQUssQ0FBQztBQUFBLEVBQy9DLEdBQUE7QUFDRCxDQUFDO0FBT0QsT0FBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsaUJBQWlCO0FBQ25DLFNBQUssT0FBTyxNQUFNLHFCQUFxQjtBQUN2QztBQUFBLEVBQ0Q7QUFHQSxNQUFJLE1BQU0sU0FBUyxZQUFZO0FBQzlCLFNBQUssT0FBTyxNQUFNLGVBQWU7QUFBQSxFQUNsQztBQUNELENBQUM7QUFHRCxPQUFPLE9BQU8sVUFBVSxZQUFZLE1BQU07QUFDekMsT0FBSyxjQUFBO0FBQ04sQ0FBQztBQUVELE9BQU8sT0FBTyx3QkFBd0IsRUFBRSxPQUFPLFdBQVcsRUFBRSxNQUFNLE1BQU07QUFBQyxDQUFDOyJ9
