const SCRAPER_PROTOCOL_VERSION = 1;
function emptyRunState() {
  return { status: "idle", items: [] };
}
const DEBUGGER_VERSION = "1.3";
const DOC_KEY = "lastDocument";
async function attach(tabId) {
  try {
    await chrome.debugger.attach({ tabId }, DEBUGGER_VERSION);
  } catch (error) {
    if (!/already attached/i.test(describeError(error))) throw error;
  }
  await chrome.debugger.sendCommand({ tabId }, "Network.enable");
}
async function detach(tabId) {
  try {
    await chrome.debugger.detach({ tabId });
  } catch {
  }
}
async function ensureAttached(tabId) {
  try {
    await attach(tabId);
  } catch (error) {
    throw new Error(
      `Couldn't attach the debugger to the scrape tab: ${describeError(error)}. If DevTools is open on it, close them and press Scrape again.`
    );
  }
}
async function noteDocumentResponse(tabId, params) {
  if (params.type !== "Document") return;
  const response = params.response;
  const requestId = params.requestId;
  if (!requestId || !response?.url) return;
  if (params.loaderId && params.loaderId !== requestId) return;
  await setLastDocument(tabId, {
    requestId,
    url: response.url,
    status: response.status ?? 0,
    finished: false
  });
}
async function noteLoadingFinished(tabId, params) {
  const last = await getLastDocument(tabId);
  if (!last || last.requestId !== params.requestId) return null;
  const finished = { ...last, finished: true };
  await setLastDocument(tabId, finished);
  return finished;
}
function isBodyNotReady(error) {
  return /no resource with given identifier|no data found/i.test(
    describeError(error)
  );
}
async function getLastDocument(tabId) {
  const stored = await chrome.storage.local.get(`${DOC_KEY}:${tabId}`);
  return stored[`${DOC_KEY}:${tabId}`] ?? null;
}
async function setLastDocument(tabId, value) {
  await chrome.storage.local.set({ [`${DOC_KEY}:${tabId}`]: value });
}
async function markDocumentConsumed(tabId, document) {
  await setLastDocument(tabId, { ...document, consumed: true });
}
async function clearLastDocument(tabId) {
  await chrome.storage.local.remove(`${DOC_KEY}:${tabId}`);
}
async function readBody(tabId, document) {
  const result = await chrome.debugger.sendCommand({ tabId }, "Network.getResponseBody", { requestId: document.requestId });
  return {
    url: document.url,
    status: document.status,
    body: result.base64Encoded ? decodeBase64(result.body) : result.body,
    base64Encoded: result.base64Encoded
  };
}
function decodeBase64(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}
function describeError(error) {
  if (error instanceof Error) return error.message;
  if (typeof error === "string") return error;
  return JSON.stringify(error);
}
const ORIGIN_KEY = "lastAdminOrigin";
const PAGE_PATH = "/admin/process-results";
function isFromAdminPage(message) {
  return typeof message === "object" && message !== null && message.fromAdminPage === true;
}
const FALLBACK_ORIGINS = ["https://scoopbus.run", "http://localhost:3005"];
async function rememberAdminOrigin(senderUrl) {
  if (!senderUrl) return;
  try {
    const { origin } = new URL(senderUrl);
    await chrome.storage.local.set({ [ORIGIN_KEY]: origin });
  } catch {
  }
}
async function knownAdminOrigin() {
  const stored = await chrome.storage.local.get(
    ORIGIN_KEY
  );
  return stored.lastAdminOrigin ?? null;
}
async function openAdminPage() {
  const origins = [await knownAdminOrigin(), ...FALLBACK_ORIGINS].filter(
    (origin2) => !!origin2
  );
  for (const origin2 of origins) {
    const existing = await chrome.tabs.query({ url: `${origin2}${PAGE_PATH}*` }).catch(() => []);
    const tab = existing.find((candidate) => candidate.id !== void 0);
    if (tab?.id !== void 0) {
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId !== void 0) {
        await chrome.windows.update(tab.windowId, { focused: true });
      }
      return;
    }
  }
  const origin = origins[0];
  await chrome.tabs.create({ url: `${origin}${PAGE_PATH}`, active: true });
}
const NAMIBIA_EVENTS = /* @__PURE__ */ new Set(["walvisbay", "windhoek", "swakopmund"]);
const DOMAIN_TO_COUNTRY = {
  "parkrun.com.au": "AU",
  "parkrun.co.at": "AT",
  "parkrun.ca": "CA",
  "parkrun.dk": "DK",
  "parkrun.fi": "FI",
  "parkrun.com.de": "DE",
  "parkrun.ie": "IE",
  "parkrun.it": "IT",
  "parkrun.jp": "JP",
  "parkrun.lt": "LT",
  "parkrun.my": "MY",
  "parkrun.co.nl": "NL",
  "parkrun.co.nz": "NZ",
  "parkrun.no": "NO",
  "parkrun.pl": "PL",
  "parkrun.sg": "SG",
  "parkrun.co.za": "ZA",
  "parkrun.se": "SE",
  "parkrun.org.uk": "UK",
  "parkrun.us": "US"
};
function getCountryFromUrl(url, eventId) {
  try {
    const hostname = new URL(url).hostname.replace(/^www\./, "");
    if (hostname === "parkrun.co.za" && NAMIBIA_EVENTS.has(eventId)) {
      return "NA";
    }
    return DOMAIN_TO_COUNTRY[hostname] ?? "??";
  } catch {
    return "??";
  }
}
function extractEvents(runResults) {
  const seen = /* @__PURE__ */ new Map();
  for (const result of runResults) {
    if (!result.eventUrl || !result.event) continue;
    if (seen.has(result.event)) continue;
    const urlMatch = result.eventUrl.match(
      /^(https?:\/\/[^/]+\/[^/]+)\/results\/?\d*\/?$/
    );
    if (!urlMatch) continue;
    const baseUrl = `${urlMatch[1]}/`;
    seen.set(result.event, {
      eventId: result.event,
      name: result.eventName,
      url: baseUrl,
      country: getCountryFromUrl(result.eventUrl, result.event)
    });
  }
  return Array.from(seen.values());
}
function stripTags(html) {
  return html.replace(/<[^>]*>/g, "").trim();
}
const ENTITIES = {
  "&amp;": "&",
  "&lt;": "<",
  "&gt;": ">",
  "&quot;": '"',
  "&#039;": "'",
  "&apos;": "'",
  "&nbsp;": " "
};
function decodeEntities(text) {
  return text.replace(/&(?:amp|lt|gt|quot|#039|apos|nbsp);/g, (m) => ENTITIES[m] ?? m).replace(
    /&#(\d+);/g,
    (_, code) => String.fromCodePoint(Number.parseInt(code, 10))
  ).replace(/\u00a0/g, " ");
}
function parseRunnerData(html) {
  const heading = html.match(/<h2>([\s\S]*?)<\/h2>/)?.[1] ?? "";
  const idMatch = heading.match(/\(\s*A?(\d+)\s*\)/);
  const headingName = decodeEntities(stripTags(heading)).replace(/\(\s*A?\d+\s*\)/, "").trim();
  const name = idMatch && headingName ? headingName : "Unknown";
  const totalMatch = html.match(
    /<h3>\s*(\d+)\s*parkruns?\s*(?:&amp;|&)?\s*(?:(\d+)\s*junior\s*parkruns?\s*)?total/i
  );
  const totalRuns = totalMatch ? Number.parseInt(totalMatch[1], 10) : 0;
  const totalJuniorRuns = totalMatch?.[2] ? Number.parseInt(totalMatch[2], 10) : 0;
  return {
    name,
    parkrunId: idMatch ? idMatch[1] : "",
    totalRuns,
    totalJuniorRuns
  };
}
function findResultTbodies(html) {
  const candidates = [];
  const captionMatch = html.match(
    /All\s+Results\s*<\/caption>[\s\S]*?<tbody[^>]*>([\s\S]*?)<\/tbody>/i
  );
  if (captionMatch) candidates.push(captionMatch[1]);
  const tables = [
    ...html.matchAll(/<table[^>]*id="results"[^>]*>([\s\S]*?)<\/table>/gi)
  ];
  for (const table of tables.reverse()) {
    const tbody = table[1].match(/<tbody[^>]*>([\s\S]*?)<\/tbody>/i);
    candidates.push(tbody ? tbody[1] : table[1]);
  }
  return candidates;
}
function parseRunResults(html) {
  for (const tbody of findResultTbodies(html)) {
    const results = parseResultRows(tbody);
    if (results.length > 0) return results;
  }
  return [];
}
function parseResultRows(tbody) {
  const results = [];
  const rowRegex = /<tr[^>]*>([\s\S]*?)<\/tr>/gi;
  for (const rowMatch of tbody.matchAll(rowRegex)) {
    const row = rowMatch[1];
    const cellRegex = /<td[^>]*>([\s\S]*?)<\/td>/gi;
    const cells = [];
    for (const cellMatch of row.matchAll(cellRegex)) {
      cells.push(cellMatch[1]);
    }
    if (cells.length < 6) continue;
    const eventLinkMatch = cells[0].match(
      /<a\s+href="([^"]+)"[^>]*>([^<]+)<\/a>/
    );
    const eventUrl = eventLinkMatch ? eventLinkMatch[1].trim() : "";
    const eventName = eventLinkMatch ? decodeEntities(eventLinkMatch[2]).trim() : decodeEntities(stripTags(cells[0]));
    if (!/\/results\//.test(eventUrl)) continue;
    const eventIdMatch = eventUrl.match(/\/([^/]+)\/results\//);
    const event = eventIdMatch ? eventIdMatch[1] : eventName.toLowerCase().replace(/[^a-z0-9]/g, "");
    const date = parseResultDate(cells[1]);
    const eventNumber = Number.parseInt(stripTags(cells[2]), 10) || 0;
    const position = Number.parseInt(stripTags(cells[3]), 10) || 0;
    const time = stripTags(cells[4]);
    const ageGrade = stripTags(cells[5]);
    if (eventName && time) {
      results.push({
        event,
        eventName,
        eventUrl,
        eventNumber,
        position,
        time,
        ageGrade,
        date
      });
    }
  }
  return results;
}
function parseResultDate(cell) {
  const dmy = cell.match(/>(\d{2})\/(\d{2})\/(\d{4})</);
  if (dmy) return `${dmy[3]}-${dmy[2]}-${dmy[1]}`;
  const iso = cell.match(/>(\d{4}-\d{2}-\d{2})</);
  if (iso) return iso[1];
  return stripTags(cell);
}
function parseLargestClubs(html) {
  const entries = [];
  const tableMatch = html.match(
    /<table[^>]*id="results"[^>]*>[\s\S]*?<tbody[^>]*>([\s\S]*?)<\/tbody>/i
  );
  if (!tableMatch) return entries;
  const tbody = tableMatch[1];
  for (const rowMatch of tbody.matchAll(/<tr[^>]*>([\s\S]*?)<\/tr>/gi)) {
    const cells = [];
    for (const cellMatch of rowMatch[1].matchAll(
      /<td[^>]*>([\s\S]*?)<\/td>/gi
    )) {
      cells.push(cellMatch[1]);
    }
    if (cells.length < 4) continue;
    const name = decodeEntities(stripTags(cells[0]));
    if (!name) continue;
    const clubIdMatch = cells[0].match(/#featureClub=(\d+)/);
    const members = Number.parseInt(stripTags(cells[2]), 10);
    const events = Number.parseInt(stripTags(cells[3]), 10);
    if (Number.isNaN(members) || Number.isNaN(events)) continue;
    entries.push({
      clubId: clubIdMatch ? clubIdMatch[1] : void 0,
      name,
      members,
      events
    });
  }
  return entries;
}
function parseEventDate(html) {
  const match = html.match(
    /<span\s+class="format-date">(\d{4}-\d{2}-\d{2})<\/span>/
  );
  return match ? match[1] : "";
}
function parseEventPageMeta(html) {
  const title = decodeEntities(
    stripTags(html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/)?.[1] ?? "")
  );
  const eventId = html.match(/href="\/([^/"]+)\/parkrunner\//)?.[1] ?? "";
  const numberMatch = html.match(/<span>\s*#(\d+)\s*<\/span>/);
  return {
    eventId,
    title,
    eventNumber: numberMatch ? Number.parseInt(numberMatch[1], 10) : 0,
    date: parseEventDate(html)
  };
}
function coursePageUrl(eventBaseUrl) {
  return `${trimSlash(eventBaseUrl)}/course/`;
}
function courseKmzUrl(mid) {
  return `https://www.google.com/maps/d/kml?mid=${mid}`;
}
function trimSlash(url) {
  return url.replace(/\/$/, "");
}
Object.keys(DOMAIN_TO_COUNTRY).flatMap(
  (domain) => [`*://${domain}/*`, `*://*.${domain}/*`]
);
const PING_INTERVAL_MS = 2e4;
let timer = null;
function startKeepalive() {
  if (timer) return;
  timer = setInterval(() => {
    void chrome.runtime.getPlatformInfo().catch(() => void 0);
  }, PING_INTERVAL_MS);
}
function stopKeepalive() {
  if (!timer) return;
  clearInterval(timer);
  timer = null;
}
const RUN_KEY = "run";
const FILES_KEY = "files";
const SESSION_KEY = "session";
function emptySession() {
  return {
    knownCourseEventIds: [],
    discoveredEvents: {},
    coursesQueued: false,
    skipCourses: false,
    attempts: 0
  };
}
async function getRunState() {
  const stored = await chrome.storage.local.get(RUN_KEY);
  return stored.run ?? emptyRunState();
}
async function setRunState(state) {
  await chrome.storage.local.set({ [RUN_KEY]: state });
}
async function updateRunState(change) {
  const next = change(await getRunState());
  await setRunState(next);
  return next;
}
async function setItemStatus(key, status, detail, attempts) {
  return updateRunState((state) => ({
    ...state,
    items: state.items.map(
      (item) => item.key === key ? {
        ...item,
        status,
        detail,
        attempts: attempts ?? item.attempts,
        updatedAt: Date.now()
      } : item
    )
  }));
}
async function appendItems(items) {
  return updateRunState((state) => ({
    ...state,
    items: [...state.items, ...items]
  }));
}
async function getSession() {
  const stored = await chrome.storage.local.get(
    SESSION_KEY
  );
  return stored.session ?? emptySession();
}
async function setSession(session) {
  await chrome.storage.local.set({ [SESSION_KEY]: session });
}
async function updateSession(change) {
  const next = change(await getSession());
  await setSession(next);
  return next;
}
async function getFiles() {
  const stored = await chrome.storage.local.get(
    FILES_KEY
  );
  return stored.files ?? [];
}
async function putFile(file) {
  const files = await getFiles();
  const existing = files.findIndex(
    (f) => f.kind === file.kind && f.key === file.key
  );
  if (existing === -1) files.push(file);
  else files[existing] = file;
  await chrome.storage.local.set({ [FILES_KEY]: files });
}
async function resetAll() {
  await chrome.storage.local.remove([RUN_KEY, FILES_KEY, SESSION_KEY]);
}
async function notifyState(state) {
  const session = await getSession();
  const message = { type: "state", state };
  for (const tabId of [session.adminTabId, session.scrapeTabId]) {
    if (tabId === void 0) continue;
    await chrome.tabs.sendMessage(tabId, message).catch(() => {
    });
  }
}
async function notifyFile(file) {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  await chrome.tabs.sendMessage(adminTabId, { type: "file", file }).catch(() => {
  });
}
const CHALLENGE_MARKERS = [
  "/cdn-cgi/challenge-platform",
  "confirm you are human",
  "verify you are human",
  "are you a robot",
  "captcha",
  "turnstile",
  "cf_chl",
  "cf-challenge",
  "checking your browser",
  "just a moment"
];
function looksLikeChallenge(html) {
  const haystack = html.slice(0, 2e5).toLowerCase();
  return CHALLENGE_MARKERS.some((marker) => haystack.includes(marker));
}
function validate(kind, key, status, html) {
  if (status >= 400) {
    const challenge = looksLikeChallenge(html);
    return {
      outcome: "blocked",
      awaitUser: challenge,
      detail: challenge ? `parkrun replied ${status} and is asking you to prove you're human — solve it in the scrape tab and the run carries on.` : `parkrun replied ${status} — retrying.`
    };
  }
  if (looksLikeChallenge(html) && !parsesAsRealPage(kind, key, html)) {
    return {
      outcome: "blocked",
      awaitUser: true,
      detail: "parkrun is asking you to prove you're human — solve it in the scrape tab and the run carries on."
    };
  }
  switch (kind) {
    case "athlete":
      return validateAthlete(key, html);
    case "event":
      return validateEvent(key, html);
    case "clubs":
      return validateClubs(html);
    case "course":
      return validateCourse(html);
  }
}
function parsesAsRealPage(kind, key, html) {
  switch (kind) {
    case "athlete":
      return parseRunResults(html).length > 0;
    case "event":
      return parseEventPageMeta(html).eventNumber > 0;
    case "clubs":
      return parseLargestClubs(html).length > 0;
    case "course":
      return extractMapMid(html) !== null;
  }
}
function validateAthlete(parkrunId, html) {
  const runner = parseRunnerData(html);
  const results = parseRunResults(html);
  if (runner.name === "Unknown" && results.length === 0) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the page — it may be a bot check. Retrying."
    };
  }
  if (runner.parkrunId && runner.parkrunId !== parkrunId) {
    return {
      outcome: "unusable",
      detail: `Page is for athlete ${runner.parkrunId}, expected ${parkrunId}.`
    };
  }
  if (results.length === 0) {
    return { outcome: "unusable", detail: "No run results found on the page." };
  }
  return {
    outcome: "ok",
    detail: `${runner.name} · ${results.length} results`
  };
}
function validateEvent(eventId, html) {
  const meta = parseEventPageMeta(html);
  if (!meta.eventNumber || !meta.date) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the event number or date — it may be a bot check."
    };
  }
  if (meta.eventId && meta.eventId !== eventId) {
    return {
      outcome: "unusable",
      detail: `Page is for "${meta.eventId}", expected "${eventId}".`
    };
  }
  return { outcome: "ok", detail: `#${meta.eventNumber} · ${meta.date}` };
}
function validateClubs(html) {
  const clubs = parseLargestClubs(html);
  if (clubs.length === 0) {
    return {
      outcome: "blocked",
      detail: "Couldn't read the league table — it may be a bot check."
    };
  }
  return { outcome: "ok", detail: `${clubs.length} clubs` };
}
function extractMapMid(html) {
  const match = html.match(
    /src="https:\/\/www\.google\.com\/maps\/d\/[^"]*?[?&]mid=([^&"]+)/
  );
  return match ? match[1] : null;
}
function validateCourse(html) {
  if (extractMapMid(html)) {
    return { outcome: "ok", detail: "Found the embedded map" };
  }
  const looksLikeParkrun = /parkrun/i.test(html) && html.length > 2e4;
  return looksLikeParkrun ? {
    outcome: "unusable",
    detail: "No Google map embedded on this course page."
  } : {
    outcome: "blocked",
    detail: "Couldn't read the course page — it may be a bot check."
  };
}
const MAX_ATTEMPTS = 8;
const STALL_TIMEOUT_MS = 2e4;
const WATCHDOG_ALARM = "watchdog";
const WATCHDOG_PERIOD_MINUTES = 0.5;
function log(...args) {
  console.log("[results-scraper]", ...args);
}
const RETRY_ALARM = "retry-blocked";
const RETRY_DELAY_MINUTES = 1;
async function scheduleRetry() {
  await chrome.alarms.create(RETRY_ALARM, { delayInMinutes: RETRY_DELAY_MINUTES }).catch(() => {
  });
}
async function cancelScheduledRetry() {
  await chrome.alarms.clear(RETRY_ALARM).catch(() => {
  });
}
async function retryCurrent() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return state;
  const item = state.items.find((i) => i.key === state.currentKey);
  const session = await getSession();
  if (!item || session.scrapeTabId === void 0) return state;
  await cancelScheduledRetry();
  await clearLastDocument(session.scrapeTabId);
  try {
    await ensureAttached(session.scrapeTabId);
    await chrome.tabs.update(session.scrapeTabId, { url: item.url });
  } catch (error) {
    return failRun(describeError(error));
  }
  return state;
}
async function skipCurrent() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return state;
  await cancelScheduledRetry();
  await setItemStatus(state.currentKey, "skipped", "Skipped.");
  await notifyState(await getRunState());
  return advance();
}
async function recoverMissedCapture(tabId) {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "active") return;
  const document = await getLastDocument(tabId);
  if (document && !document.consumed) return;
  const attempts = (item.attempts ?? 0) + 1;
  if (attempts > MAX_ATTEMPTS) {
    await setItemStatus(
      item.key,
      "failed",
      `Page loaded but its response was never captured, after ${attempts} attempts.`,
      attempts
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  log(
    `${item.label}: loaded but no response captured — reloading (attempt ${attempts})`
  );
  await setItemStatus(
    item.key,
    "active",
    "Page loaded but the capture was missed — reloading.",
    attempts
  );
  await notifyState(await getRunState());
  await retryCurrent();
}
async function retryIfStillBlocked() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "blocked") return;
  if (item.awaitUser) {
    log(`${item.label}: still waiting for the user; not reloading`);
    return;
  }
  const session = await getSession();
  if (session.attempts >= MAX_ATTEMPTS) {
    await setItemStatus(
      item.key,
      "failed",
      `${item.detail ?? "Blocked."} Gave up after ${session.attempts} attempts.`
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  await retryCurrent();
}
async function startRun(request, adminTabId) {
  await resetAll();
  const items = request.items.map((item) => ({
    ...item,
    status: "pending"
  }));
  if (items.length === 0) {
    const state2 = {
      status: "error",
      items: [],
      message: "Nothing to scrape."
    };
    await setRunState(state2);
    return state2;
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open a scrape tab");
  await setSession({
    adminTabId,
    scrapeTabId: tab.id,
    knownCourseEventIds: request.knownCourseEventIds,
    discoveredEvents: {},
    coursesQueued: false,
    skipCourses: request.skipCourses ?? false,
    attempts: 0
  });
  const state = {
    status: "running",
    items,
    startedAt: Date.now()
  };
  await setRunState(state);
  try {
    await ensureAttached(tab.id);
  } catch (error) {
    return failRun(describeError(error));
  }
  await setBadge("…");
  startKeepalive();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MINUTES }).catch(() => {
  });
  log(`run started: ${items.length} items, scrape tab ${tab.id}`);
  return advance();
}
async function checkForStall() {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (item?.status !== "active") return;
  const age = Date.now() - (item.updatedAt ?? 0);
  if (age < STALL_TIMEOUT_MS) return;
  const attempts = (item.attempts ?? 0) + 1;
  if (attempts > MAX_ATTEMPTS) {
    log(`giving up on ${item.label} after ${attempts} attempts`);
    await setItemStatus(
      item.key,
      "failed",
      `No response after ${attempts} attempts — page never finished loading.`,
      attempts
    );
    await notifyState(await getRunState());
    await advance();
    return;
  }
  log(
    `${item.label} stalled for ${Math.round(age / 1e3)}s — reloading (attempt ${attempts})`
  );
  await setItemStatus(
    item.key,
    "active",
    `No response after ${Math.round(age / 1e3)}s — reloading (attempt ${attempts}).`,
    attempts
  );
  await notifyState(await getRunState());
  await retryCurrent();
}
async function forgetRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const session = await getSession();
  if (session.scrapeTabId !== void 0) {
    await detach(session.scrapeTabId);
    await clearLastDocument(session.scrapeTabId);
  }
  await resetAll();
  await setBadge("");
  log("run cleared");
}
async function resumeRun(adminTabId) {
  const previous = await getRunState();
  if (previous.items.length === 0) {
    return failRun("There is no run to resume.");
  }
  const items = previous.items.map(
    (item) => item.status === "captured" || item.status === "skipped" ? item : {
      ...item,
      status: "pending",
      detail: void 0,
      attempts: 0,
      awaitUser: void 0,
      updatedAt: Date.now()
    }
  );
  const outstanding = items.filter((item) => item.status === "pending").length;
  if (outstanding === 0) {
    return failRun("Every page in that run is already captured or skipped.");
  }
  const tab = await chrome.tabs.create({ url: "about:blank", active: true });
  if (tab.id === void 0) throw new Error("Could not open a scrape tab");
  await updateSession((session) => ({
    ...session,
    adminTabId,
    scrapeTabId: tab.id,
    attempts: 0
  }));
  await setRunState({
    ...previous,
    status: "running",
    currentKey: void 0,
    items,
    message: void 0,
    finishedAt: void 0
  });
  try {
    await ensureAttached(tab.id);
  } catch (error) {
    return failRun(describeError(error));
  }
  await setBadge("…");
  startKeepalive();
  await chrome.alarms.create(WATCHDOG_ALARM, { periodInMinutes: WATCHDOG_PERIOD_MINUTES }).catch(() => {
  });
  log(`resuming: ${outstanding} of ${items.length} pages still needed`);
  return advance();
}
async function cancelRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const state = await getRunState();
  const cancelled = {
    ...state,
    status: "cancelled",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: "Cancelled."
  };
  await setRunState(cancelled);
  await closeScrapeTab();
  await setBadge("");
  await focusAdminTab();
  await notifyState(cancelled);
  return cancelled;
}
async function failRun(message) {
  stopKeepalive();
  const state = await getRunState();
  const failed = {
    ...state,
    status: "error",
    currentKey: void 0,
    finishedAt: Date.now(),
    message
  };
  await setRunState(failed);
  await setBadge("!");
  await notifyState(failed);
  return failed;
}
async function advance() {
  const state = await getRunState();
  if (state.status !== "running") return state;
  const next = state.items.find((item) => item.status === "pending");
  if (!next) {
    const queued = await queueNewCourses();
    if (queued) return advance();
    return finishRun();
  }
  const session = await getSession();
  if (session.scrapeTabId === void 0) {
    return failRun("The scrape tab is gone.");
  }
  await cancelScheduledRetry();
  await updateSession((s) => ({ ...s, attempts: 0 }));
  await clearLastDocument(session.scrapeTabId);
  const running = {
    ...state,
    currentKey: next.key,
    items: state.items.map(
      (item) => item.key === next.key ? {
        ...item,
        status: "active",
        detail: "Loading…",
        attempts: 0,
        updatedAt: Date.now()
      } : item
    ),
    message: void 0
  };
  await setRunState(running);
  await notifyState(running);
  log(`→ ${next.label}: ${next.url}`);
  try {
    await ensureAttached(session.scrapeTabId);
    await chrome.tabs.update(session.scrapeTabId, { url: next.url });
  } catch (error) {
    return failRun(describeError(error));
  }
  return running;
}
async function handleDocumentLoaded(tabId) {
  const state = await getRunState();
  if (state.status !== "running" || !state.currentKey) return;
  const session = await getSession();
  if (session.scrapeTabId !== tabId) return;
  const item = state.items.find((i) => i.key === state.currentKey);
  if (!item) return;
  const document = await getLastDocument(tabId);
  if (!document || document.consumed) return;
  let captured;
  try {
    captured = await readBody(tabId, document);
  } catch (error) {
    if (isBodyNotReady(error)) return;
    const attempts2 = (await updateSession((s) => ({ ...s, attempts: s.attempts + 1 }))).attempts;
    log(`${item.label}: could not read body — ${describeError(error)}`);
    if (attempts2 >= MAX_ATTEMPTS) {
      await setItemStatus(item.key, "failed", describeError(error), attempts2);
      await notifyState(await getRunState());
      await advance();
    }
    return;
  }
  const attempts = (await updateSession((s) => ({ ...s, attempts: s.attempts + 1 }))).attempts;
  const verdict = validate(item.kind, item.key, captured.status, captured.body);
  log(
    `${item.label}: HTTP ${captured.status}, ${captured.body.length} bytes → ${verdict.outcome} (${verdict.detail})`
  );
  if (verdict.outcome === "blocked") {
    if (verdict.awaitUser) {
      log(`${item.label}: waiting for the user to clear a challenge`);
      await cancelScheduledRetry();
      await updateRunState((current) => ({
        ...current,
        items: current.items.map(
          (i) => i.key === item.key ? {
            ...i,
            status: "blocked",
            detail: verdict.detail,
            attempts,
            awaitUser: true,
            updatedAt: Date.now()
          } : i
        )
      }));
      await notifyState(await getRunState());
      return;
    }
    if (attempts >= MAX_ATTEMPTS) {
      await setItemStatus(
        item.key,
        "failed",
        `${verdict.detail} Gave up after ${attempts} attempts.`
      );
      await notifyState(await getRunState());
      await advance();
      return;
    }
    await setItemStatus(
      item.key,
      "blocked",
      `${verdict.detail} (attempt ${attempts} of ${MAX_ATTEMPTS}; retrying automatically)`,
      attempts
    );
    await notifyState(await getRunState());
    await scheduleRetry();
    return;
  }
  if (verdict.outcome === "unusable") {
    await setItemStatus(item.key, "failed", verdict.detail);
    await notifyState(await getRunState());
    await advance();
    return;
  }
  await markDocumentConsumed(tabId, document);
  if (item.kind === "course") {
    await handleCoursePage(item, captured.body);
  } else {
    await deliver({
      kind: item.kind,
      key: item.key,
      name: fileNameFor(item.kind, item.key),
      text: captured.body
    });
    if (item.kind === "athlete") await recordEvents(captured.body);
    await setItemStatus(item.key, "captured", verdict.detail);
  }
  await notifyState(await getRunState());
  await advance();
}
async function handleCoursePage(item, html) {
  const mid = extractMapMid(html);
  if (!mid) {
    await setItemStatus(item.key, "failed", "No map id on the course page.");
    return;
  }
  try {
    const response = await fetch(courseKmzUrl(mid));
    if (!response.ok) throw new Error(`Google replied ${response.status}`);
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (bytes[0] !== 80 || bytes[1] !== 75) {
      throw new Error("Downloaded file is not a KMZ archive");
    }
    await deliver({
      kind: "course",
      key: item.key,
      name: `${item.key}.kmz`,
      base64: toBase64(bytes)
    });
    await setItemStatus(
      item.key,
      "captured",
      `KMZ downloaded (${Math.round(bytes.length / 1024)} KB)`
    );
  } catch (error) {
    await setItemStatus(
      item.key,
      "failed",
      `Couldn't download the KMZ: ${describeError(error)}`
    );
  }
}
async function recordEvents(html) {
  const events = extractEvents(parseRunResults(html));
  if (events.length === 0) return;
  await updateSession((session) => {
    const discovered = { ...session.discoveredEvents };
    for (const event of events) {
      if (!discovered[event.eventId]) {
        discovered[event.eventId] = { name: event.name, url: event.url };
      }
    }
    return { ...session, discoveredEvents: discovered };
  });
}
async function queueNewCourses() {
  const session = await getSession();
  if (session.coursesQueued || session.skipCourses) return false;
  await updateSession((s) => ({ ...s, coursesQueued: true }));
  const known = new Set(session.knownCourseEventIds);
  const state = await getRunState();
  const alreadyQueued = new Set(
    state.items.filter((i) => i.kind === "course").map((i) => i.key)
  );
  const items = Object.entries(session.discoveredEvents).filter(([eventId]) => !known.has(eventId) && !alreadyQueued.has(eventId)).map(([eventId, event]) => ({
    kind: "course",
    key: eventId,
    label: `${event.name} course map`,
    url: coursePageUrl(event.url),
    status: "pending"
  })).sort((a, b) => a.label.localeCompare(b.label));
  if (items.length === 0) return false;
  const next = await appendItems(items);
  await notifyState(next);
  return true;
}
async function finishRun() {
  await cancelScheduledRetry();
  stopKeepalive();
  await chrome.alarms.clear(WATCHDOG_ALARM).catch(() => {
  });
  const settled = await updateRunState((current) => ({
    ...current,
    items: current.items.map(
      (item) => item.status === "captured" || item.status === "failed" || item.status === "skipped" ? item : {
        ...item,
        status: "failed",
        detail: item.detail ?? "Never completed."
      }
    )
  }));
  const state = settled;
  const captured = state.items.filter((i) => i.status === "captured").length;
  const failed = state.items.filter((i) => i.status === "failed").length;
  const done = {
    ...state,
    status: "done",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: failed ? `Captured ${captured} of ${state.items.length}; ${failed} failed.` : `Captured all ${captured} pages.`
  };
  await setRunState(done);
  await closeScrapeTab();
  await setBadge(failed ? String(failed) : "");
  await focusAdminTab();
  await notifyState(done);
  await notifyFinished(done);
  return done;
}
async function closeScrapeTab() {
  const { scrapeTabId } = await getSession();
  if (scrapeTabId === void 0) return;
  await detach(scrapeTabId);
  await clearLastDocument(scrapeTabId);
  await chrome.tabs.remove(scrapeTabId).catch(() => {
  });
  await updateSession((session) => ({ ...session, scrapeTabId: void 0 }));
}
async function focusAdminTab() {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  try {
    const tab = await chrome.tabs.get(adminTabId);
    await chrome.tabs.update(adminTabId, { active: true });
    if (tab.windowId !== void 0) {
      await chrome.windows.update(tab.windowId, { focused: true });
    }
  } catch {
  }
}
async function notifyFinished(state) {
  const { adminTabId } = await getSession();
  if (adminTabId === void 0) return;
  await chrome.tabs.sendMessage(adminTabId, { type: "finished", state }).catch(() => {
  });
}
async function deliver(file) {
  await putFile(file);
  await notifyFile(file);
}
async function resendFiles() {
  for (const file of await getFiles()) await notifyFile(file);
}
function fileNameFor(kind, key) {
  switch (kind) {
    case "athlete":
      return `athlete-${key}.html`;
    case "event":
      return `${key}-latest-results.html`;
    case "clubs":
      return "largest-clubs.html";
    default:
      return `${key}.kmz`;
  }
}
function toBase64(bytes) {
  let binary = "";
  for (let i = 0; i < bytes.length; i += 32768) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
  }
  return btoa(binary);
}
async function setBadge(text) {
  await chrome.action.setBadgeText({ text }).catch(() => {
  });
}
let chain = Promise.resolve();
function serial(work) {
  const next = chain.then(work, work);
  chain = next.catch(() => void 0);
  return next;
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (isFromAdminPage(message)) {
    void rememberAdminOrigin(sender.url ?? sender.origin);
  }
  handleMessage(message, sender).then(sendResponse).catch((error) => sendResponse({ error: String(error) }));
  return true;
});
async function handleMessage(message, sender) {
  switch (message.type) {
    case "ping":
      return {
        type: "hello",
        version: SCRAPER_PROTOCOL_VERSION,
        state: await getRunState()
      };
    /**
     * Asked by the overlay, which is injected into every parkrun page — but
     * only the scrape tab is part of a run. A run's state outlives the run
     * (the admin page can still ask for its files), so answering every tab
     * meant a page opened by hand days later still got "Scrape complete".
     */
    case "state?": {
      const { scrapeTabId } = await getSession();
      const inScrapeTab = sender.tab?.id !== void 0 && sender.tab.id === scrapeTabId;
      return {
        type: "state",
        state: inScrapeTab ? await getRunState() : emptyRunState()
      };
    }
    case "start": {
      const adminTabId = sender.tab?.id;
      if (adminTabId === void 0) return { error: "No calling tab" };
      const request = message.request;
      const state = await startRun(request, adminTabId);
      return { type: "state", state };
    }
    case "resume": {
      const adminTabId = sender.tab?.id;
      if (adminTabId === void 0) return { error: "No calling tab" };
      return { type: "state", state: await resumeRun(adminTabId) };
    }
    case "cancel":
      return { type: "state", state: await cancelRun() };
    case "retry":
      return { type: "state", state: await retryCurrent() };
    case "skip":
      return { type: "state", state: await skipCurrent() };
    case "resend":
      await resendFiles();
      return { type: "state", state: await getRunState() };
    case "clear":
      await forgetRun();
      return { type: "state", state: await getRunState() };
    default:
      return { error: `Unknown message: ${message.type}` };
  }
}
chrome.debugger.onEvent.addListener((source, method, params) => {
  if (source.tabId === void 0 || !params) return;
  const tabId = source.tabId;
  void serial(() => handleDebuggerEvent(tabId, method, params)).catch(
    (error) => {
      console.error("[results-scraper] event handling failed", method, error);
    }
  );
});
async function handleDebuggerEvent(tabId, method, params) {
  if (method === "Network.responseReceived") {
    await noteDocumentResponse(tabId, params);
    return;
  }
  if (method === "Network.loadingFinished") {
    const document = await noteLoadingFinished(tabId, params);
    if (document) await handleDocumentLoaded(tabId);
  }
}
chrome.debugger.onDetach.addListener((source, reason) => {
  void handleDetach(source.tabId, reason);
});
async function handleDetach(tabId, reason) {
  const session = await getSession();
  if (session.scrapeTabId !== tabId) return;
  const state = await getRunState();
  if (state.status !== "running") return;
  await setRunState({
    ...state,
    status: "error",
    currentKey: void 0,
    finishedAt: Date.now(),
    message: `Lost the debugger connection (${reason}).`
  });
  await chrome.action.setBadgeText({ text: "!" }).catch(() => {
  });
}
chrome.tabs.onRemoved.addListener((tabId) => {
  void serial(() => handleTabRemoved(tabId));
});
async function handleTabRemoved(tabId) {
  const session = await getSession();
  const state = await getRunState();
  if (state.status !== "running") return;
  if (session.scrapeTabId === tabId) {
    await detach(tabId);
    await setRunState({
      ...state,
      status: "cancelled",
      currentKey: void 0,
      finishedAt: Date.now(),
      message: "The scrape tab was closed."
    });
    await chrome.action.setBadgeText({ text: "" }).catch(() => {
    });
  }
}
chrome.runtime.onStartup.addListener(() => {
  void (async () => {
    const state = await getRunState();
    if (state.status !== "running") return;
    await setRunState({
      ...state,
      status: "cancelled",
      currentKey: void 0,
      message: "Interrupted when the browser closed."
    });
  })();
});
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== "complete") return;
  void (async () => {
    const state = await getRunState();
    if (state.status !== "running") return;
    const session = await getSession();
    if (session.scrapeTabId !== tabId) return;
    if (!state.currentKey) {
      await serial(() => advance());
      return;
    }
    await serial(() => handleDocumentLoaded(tabId));
    await serial(() => recoverMissedCapture(tabId));
  })();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "retry-blocked") {
    void serial(() => retryIfStillBlocked());
    return;
  }
  if (alarm.name === "watchdog") {
    void serial(() => checkForStall());
  }
});
chrome.action.onClicked.addListener(() => {
  void openAdminPage();
});
chrome.action.setBadgeBackgroundColor({ color: "#3f6d3a" }).catch(() => {
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFja2dyb3VuZC5qcyIsInNvdXJjZXMiOlsiLi4vLi4vbGlicy9zaGFyZWQvc2NyYXBlci1wcm90b2NvbC50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9jYXB0dXJlLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL29wZW5BZG1pbi50cyIsIi4uLy4uL2xpYnMvc2hhcmVkL3BhcmtydW4tcGFyc2Vycy50cyIsIi4uLy4uL2xpYnMvc2hhcmVkL3BhcmtydW4tdXJscy50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9rZWVwYWxpdmUudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvc3RhdGUudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvbWVzc2FnaW5nLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL3ZhbGlkYXRlLnRzIiwiLi4vLi4vYXBwcy9yZXN1bHRzLXNjcmFwZXIvc3JjL3J1bi50cyIsIi4uLy4uL2FwcHMvcmVzdWx0cy1zY3JhcGVyL3NyYy9zZXJpYWwudHMiLCIuLi8uLi9hcHBzL3Jlc3VsdHMtc2NyYXBlci9zcmMvYmFja2dyb3VuZC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFRoZSBjb250cmFjdCBiZXR3ZWVuIHRoZSBQcm9jZXNzIFJlc3VsdHMgYWRtaW4gcGFnZSBhbmQgdGhlIHJlc3VsdHMtc2NyYXBlclxuICogQ2hyb21lIGV4dGVuc2lvbi5cbiAqXG4gKiBUaGUgcGFnZSBpcyB0aGUgYnJhaW46IGl0IGtub3dzIHdobyB3ZSB0cmFjaywgd2hpY2ggcGFnZXMgYXJlIG5lZWRlZCBhbmQgd2hpY2hcbiAqIGNvdXJzZXMgd2UgYWxyZWFkeSBoYXZlLCBhbmQgaXQgYnVpbGRzIHRoZSB3b3JrIGxpc3QuIFRoZSBleHRlbnNpb24gaXMgdGhlXG4gKiBleGVjdXRvcjogaXQgbmF2aWdhdGVzLCBjYXB0dXJlcyByYXcgSFRNTCwgYW5kIHN0cmVhbXMgZmlsZXMgYmFjay4gTmVpdGhlclxuICogc2lkZSBoYXJkY29kZXMgdGhlIG90aGVyJ3Mga25vd2xlZGdlLCBzbyBhZGRpbmcgYSBydW5uZXIgb3IgYW4gZXZlbnQgbmVlZHMgbm9cbiAqIGV4dGVuc2lvbiBjaGFuZ2UuXG4gKlxuICogTWVzc2FnZXMgdHJhdmVsIHBhZ2Ug4oaUIGNvbnRlbnQgc2NyaXB0IGJ5IHdpbmRvdy5wb3N0TWVzc2FnZSAod3JhcHBlZCBpbiBhblxuICogZW52ZWxvcGUgc28gd2UgaWdub3JlIGV2ZXJ5dGhpbmcgZWxzZSBvbiB0aGUgY2hhbm5lbCkgYW5kIGNvbnRlbnQgc2NyaXB0IOKGlFxuICogc2VydmljZSB3b3JrZXIgYnkgY2hyb21lLnJ1bnRpbWUgbWVzc2FnaW5nLlxuICovXG5cbmV4cG9ydCBjb25zdCBTQ1JBUEVSX1BST1RPQ09MX1ZFUlNJT04gPSAxXG5cbi8qKiBFbnZlbG9wZSBtYXJrZXIsIHNvIHBvc3RNZXNzYWdlIHRyYWZmaWMgZnJvbSBhbnl0aGluZyBlbHNlIGlzIGlnbm9yZWQuICovXG5leHBvcnQgY29uc3QgU0NSQVBFUl9FTlZFTE9QRSA9ICdzY29vcGJ1cy1yZXN1bHRzLXNjcmFwZXInXG5cbi8vIOKUgOKUgCBXb3JrIGxpc3Qg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKiBXaGljaCB1cGxvYWQgZmllbGQgYSBjYXB0dXJlZCBmaWxlIGJlbG9uZ3MgdG8uICovXG5leHBvcnQgdHlwZSBDYXB0dXJlS2luZCA9ICdhdGhsZXRlJyB8ICdldmVudCcgfCAnY2x1YnMnIHwgJ2NvdXJzZSdcblxuLyoqIFRoZSBzaW5nbGUgZm9ybSBzbG90IHRoYXQgaG9sZHMgdGhlIGxhcmdlc3QtY2x1YnMgcGFnZS4gKi9cbmV4cG9ydCBjb25zdCBDTFVCU19LRVkgPSAnY2x1YnMnXG5cbmV4cG9ydCBpbnRlcmZhY2UgV29ya0l0ZW0ge1xuXHRraW5kOiBDYXB0dXJlS2luZFxuXHQvKiogTWF0Y2hlcyB0aGUgZm9ybSBzbG90OiBwYXJrcnVuSWQsIGV2ZW50SWQsIG9yIENMVUJTX0tFWS4gKi9cblx0a2V5OiBzdHJpbmdcblx0LyoqIEh1bWFuIGxhYmVsIGZvciB0aGUgcHJvZ3Jlc3MgVUksIGUuZy4gXCJKb3NoXCIgb3IgXCJIYWdhIEZ1bGwgUmVzdWx0c1wiLiAqL1xuXHRsYWJlbDogc3RyaW5nXG5cdHVybDogc3RyaW5nXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuUmVxdWVzdCB7XG5cdGl0ZW1zOiBXb3JrSXRlbVtdXG5cdC8qKlxuXHQgKiBFdmVudCBJRHMgdGhhdCBhbHJlYWR5IGhhdmUgY291cnNlIGRhdGEuIEFueXRoaW5nIGFuIGF0aGxldGUgcGFnZSB0dXJucyB1cFxuXHQgKiB0aGF0IGlzbid0IGluIGhlcmUgZ2V0cyBpdHMgY291cnNlIHBhZ2UgcXVldWVkIG1pZC1ydW4uXG5cdCAqL1xuXHRrbm93bkNvdXJzZUV2ZW50SWRzOiBzdHJpbmdbXVxuXHQvKiogU2tpcCB0aGUgbWlkLXJ1biBodW50IGZvciBuZXcgY291cnNlIG1hcHMuICovXG5cdHNraXBDb3Vyc2VzPzogYm9vbGVhblxufVxuXG4vLyDilIDilIAgUnVuIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgdHlwZSBJdGVtU3RhdHVzID1cblx0fCAncGVuZGluZydcblx0fCAnYWN0aXZlJ1xuXHQvKiogTG9hZGVkLCBidXQgYmxvY2tlZCDigJQgdXN1YWxseSBhIGNhcHRjaGEgb3IgYm90IGNoZWNrIGF3YWl0aW5nIHRoZSB1c2VyLiAqL1xuXHR8ICdibG9ja2VkJ1xuXHR8ICdjYXB0dXJlZCdcblx0fCAnZmFpbGVkJ1xuXHR8ICdza2lwcGVkJ1xuXG5leHBvcnQgaW50ZXJmYWNlIEl0ZW1TdGF0ZSBleHRlbmRzIFdvcmtJdGVtIHtcblx0c3RhdHVzOiBJdGVtU3RhdHVzXG5cdC8qKiBPbmUtbGluZSBkZXRhaWwgZm9yIHRoZSBVSTogd2hhdCB3YXMgcGFyc2VkLCBvciB3aHkgaXQgZmFpbGVkLiAqL1xuXHRkZXRhaWw/OiBzdHJpbmdcblx0LyoqIEhvdyBtYW55IHRpbWVzIHRoaXMgcGFnZSBoYXMgYmVlbiBsb2FkZWQsIGZvciBzdGFsbHMgYW5kIHJldHJpZXMuICovXG5cdGF0dGVtcHRzPzogbnVtYmVyXG5cdC8qKiBFcG9jaCBtcyB3aGVuIHRoaXMgaXRlbSBsYXN0IGNoYW5nZWQsIHNvIGEgd2F0Y2hkb2cgY2FuIHNwb3QgYSBzdGFsbC4gKi9cblx0dXBkYXRlZEF0PzogbnVtYmVyXG5cdC8qKlxuXHQgKiBUaGVyZSdzIGFuIGludGVyYWN0aXZlIGNoYWxsZW5nZSBvbiBzY3JlZW4uIE5vdGhpbmcgbWF5IHJlbG9hZCB0aGUgcGFnZSBvclxuXHQgKiB0aW1lIHRoZSBpdGVtIG91dCB3aGlsZSB0aGlzIGlzIHNldCDigJQgdGhlIHBlcnNvbiBpcyBtaWQtY2FwdGNoYS5cblx0ICovXG5cdGF3YWl0VXNlcj86IGJvb2xlYW5cbn1cblxuZXhwb3J0IHR5cGUgUnVuU3RhdHVzID0gJ2lkbGUnIHwgJ3J1bm5pbmcnIHwgJ2RvbmUnIHwgJ2NhbmNlbGxlZCcgfCAnZXJyb3InXG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuU3RhdGUge1xuXHRzdGF0dXM6IFJ1blN0YXR1c1xuXHRpdGVtczogSXRlbVN0YXRlW11cblx0LyoqIEtleSBvZiB0aGUgaXRlbSBiZWluZyB3b3JrZWQgb24sIGlmIGFueS4gKi9cblx0Y3VycmVudEtleT86IHN0cmluZ1xuXHRtZXNzYWdlPzogc3RyaW5nXG5cdHN0YXJ0ZWRBdD86IG51bWJlclxuXHRmaW5pc2hlZEF0PzogbnVtYmVyXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBlbXB0eVJ1blN0YXRlKCk6IFJ1blN0YXRlIHtcblx0cmV0dXJuIHsgc3RhdHVzOiAnaWRsZScsIGl0ZW1zOiBbXSB9XG59XG5cbi8vIOKUgOKUgCBDYXB0dXJlZCBmaWxlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGludGVyZmFjZSBDYXB0dXJlZEZpbGUge1xuXHRraW5kOiBDYXB0dXJlS2luZFxuXHRrZXk6IHN0cmluZ1xuXHQvKiogRmlsZW5hbWUgaGFuZGVkIHRvIHRoZSBmb3JtLCBzbyBpdCByZWFkcyBsaWtlIGEgbm9ybWFsIHVwbG9hZC4gKi9cblx0bmFtZTogc3RyaW5nXG5cdC8qKiBVVEYtOCB0ZXh0IGZvciBIVE1MIHBhZ2VzLiAqL1xuXHR0ZXh0Pzogc3RyaW5nXG5cdC8qKiBCYXNlNjQgZm9yIGJpbmFyeSBwYXlsb2FkcyAoS01aKS4gKi9cblx0YmFzZTY0Pzogc3RyaW5nXG59XG5cbi8vIOKUgOKUgCBNZXNzYWdlcyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IHR5cGUgUGFnZU1lc3NhZ2UgPVxuXHQvKiogSXMgdGhlIGV4dGVuc2lvbiBpbnN0YWxsZWQ/ICovXG5cdHwgeyB0eXBlOiAncGluZycgfVxuXHR8IHsgdHlwZTogJ3N0YXJ0JzsgcmVxdWVzdDogUnVuUmVxdWVzdCB9XG5cdHwgeyB0eXBlOiAnY2FuY2VsJyB9XG5cdC8qKlxuXHQgKiBQaWNrIGFuIGludGVycnVwdGVkIHJ1biBiYWNrIHVwLiBFdmVyeXRoaW5nIGFscmVhZHkgY2FwdHVyZWQgaXMga2VwdDsgb25seVxuXHQgKiB0aGUgcGFnZXMgdGhhdCBuZXZlciBsYW5kZWQgYXJlIHF1ZXVlZCBhZ2Fpbi5cblx0ICovXG5cdHwgeyB0eXBlOiAncmVzdW1lJyB9XG5cdC8qKiBSZWxvYWQgdGhlIHBhZ2Ugd2UncmUgc3R1Y2sgb24uICovXG5cdHwgeyB0eXBlOiAncmV0cnknIH1cblx0LyoqIEdpdmUgdXAgb24gdGhlIGN1cnJlbnQgcGFnZSBhbmQgbW92ZSB0byB0aGUgbmV4dC4gKi9cblx0fCB7IHR5cGU6ICdza2lwJyB9XG5cdC8qKiBSZS1kZWxpdmVyIGV2ZXJ5dGhpbmcgY2FwdHVyZWQgc28gZmFyIChhZnRlciBhIHBhZ2UgcmVsb2FkKS4gKi9cblx0fCB7IHR5cGU6ICdyZXNlbmQnIH1cblx0LyoqXG5cdCAqIFRocm93IHRoZSBydW4gYXdheS4gU2VudCBvbmNlIGFuIHVwbG9hZCBoYXMgbGFuZGVkLCBzbyBhIHJlbG9hZCBkb2Vzbid0XG5cdCAqIHJlc3VycmVjdCBhIHNjcmFwZSB3aG9zZSBkYXRhIGlzIGFscmVhZHkgaW4gdGhlIGRhdGFiYXNlLlxuXHQgKi9cblx0fCB7IHR5cGU6ICdjbGVhcicgfVxuXG5leHBvcnQgdHlwZSBFeHRlbnNpb25NZXNzYWdlID1cblx0fCB7IHR5cGU6ICdoZWxsbyc7IHZlcnNpb246IG51bWJlcjsgc3RhdGU6IFJ1blN0YXRlIH1cblx0fCB7IHR5cGU6ICdzdGF0ZSc7IHN0YXRlOiBSdW5TdGF0ZSB9XG5cdHwgeyB0eXBlOiAnZmlsZSc7IGZpbGU6IENhcHR1cmVkRmlsZSB9XG5cdHwgeyB0eXBlOiAnZmluaXNoZWQnOyBzdGF0ZTogUnVuU3RhdGUgfVxuXG4vKipcbiAqIEV2ZXJ5IG1lc3NhZ2UgdGhlIHBhZ2UgbWF5IHNlbmQsIGFzIGEgcnVudGltZSBsaXN0LlxuICpcbiAqIFRoZSBicmlkZ2UgY29udGVudCBzY3JpcHQgZm9yd2FyZHMgb25seSB0aGVzZSwgc28gaXQgbmVlZHMgdGhlIHNldCBhdCBydW50aW1lXG4gKiDigJQgYW5kIGl0IHVzZWQgdG8ga2VlcCBpdHMgb3duIGNvcHksIHdoaWNoIHNpbGVudGx5IGZlbGwgYmVoaW5kIGFzIG1lc3NhZ2VzXG4gKiB3ZXJlIGFkZGVkOiBgcmV0cnlgLCBgc2tpcGAsIGByZXN1bWVgIGFuZCBgY2xlYXJgIHdlcmUgYWxsIGJlaW5nIGRyb3BwZWRcbiAqIHdpdGhvdXQgYSB0cmFjZS4gVGhlIGV4aGF1c3RpdmVuZXNzIGNoZWNrIGJlbG93IG1ha2VzIGxlYXZpbmcgb25lIG91dCBhXG4gKiBjb21waWxlIGVycm9yIGluc3RlYWQuXG4gKi9cbmV4cG9ydCBjb25zdCBQQUdFX01FU1NBR0VfVFlQRVMgPSBbXG5cdCdwaW5nJyxcblx0J3N0YXJ0Jyxcblx0J3Jlc3VtZScsXG5cdCdyZXRyeScsXG5cdCdza2lwJyxcblx0J2NhbmNlbCcsXG5cdCdyZXNlbmQnLFxuXHQnY2xlYXInLFxuXSBhcyBjb25zdFxuXG5leHBvcnQgdHlwZSBQYWdlTWVzc2FnZVR5cGUgPSAodHlwZW9mIFBBR0VfTUVTU0FHRV9UWVBFUylbbnVtYmVyXVxuXG4vKiogRmFpbHMgdG8gY29tcGlsZSBpZiBQQUdFX01FU1NBR0VfVFlQRVMgYW5kIFBhZ2VNZXNzYWdlIGRyaWZ0IGFwYXJ0LiAqL1xudHlwZSBBc3NlcnRTYW1lTWVzc2FnZVR5cGVzID0gUGFnZU1lc3NhZ2VbJ3R5cGUnXSBleHRlbmRzIFBhZ2VNZXNzYWdlVHlwZVxuXHQ/IFBhZ2VNZXNzYWdlVHlwZSBleHRlbmRzIFBhZ2VNZXNzYWdlWyd0eXBlJ11cblx0XHQ/IHRydWVcblx0XHQ6IG5ldmVyXG5cdDogbmV2ZXJcbmNvbnN0IF9tZXNzYWdlVHlwZXNNYXRjaDogQXNzZXJ0U2FtZU1lc3NhZ2VUeXBlcyA9IHRydWVcbnZvaWQgX21lc3NhZ2VUeXBlc01hdGNoXG5cbmV4cG9ydCBmdW5jdGlvbiBpc1BhZ2VNZXNzYWdlVHlwZSh2YWx1ZTogc3RyaW5nKTogdmFsdWUgaXMgUGFnZU1lc3NhZ2VUeXBlIHtcblx0cmV0dXJuIChQQUdFX01FU1NBR0VfVFlQRVMgYXMgcmVhZG9ubHkgc3RyaW5nW10pLmluY2x1ZGVzKHZhbHVlKVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIFNjcmFwZXJFbnZlbG9wZTxUPiB7XG5cdGNoYW5uZWw6IHR5cGVvZiBTQ1JBUEVSX0VOVkVMT1BFXG5cdGRpcmVjdGlvbjogJ3RvLWV4dGVuc2lvbicgfCAndG8tcGFnZSdcblx0cGF5bG9hZDogVFxufVxuXG5leHBvcnQgZnVuY3Rpb24gd3JhcEZvckV4dGVuc2lvbihcblx0cGF5bG9hZDogUGFnZU1lc3NhZ2UsXG4pOiBTY3JhcGVyRW52ZWxvcGU8UGFnZU1lc3NhZ2U+IHtcblx0cmV0dXJuIHsgY2hhbm5lbDogU0NSQVBFUl9FTlZFTE9QRSwgZGlyZWN0aW9uOiAndG8tZXh0ZW5zaW9uJywgcGF5bG9hZCB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB3cmFwRm9yUGFnZShcblx0cGF5bG9hZDogRXh0ZW5zaW9uTWVzc2FnZSxcbik6IFNjcmFwZXJFbnZlbG9wZTxFeHRlbnNpb25NZXNzYWdlPiB7XG5cdHJldHVybiB7IGNoYW5uZWw6IFNDUkFQRVJfRU5WRUxPUEUsIGRpcmVjdGlvbjogJ3RvLXBhZ2UnLCBwYXlsb2FkIH1cbn1cblxuZnVuY3Rpb24gaXNFbnZlbG9wZShkYXRhOiB1bmtub3duKTogZGF0YSBpcyBTY3JhcGVyRW52ZWxvcGU8dW5rbm93bj4ge1xuXHRyZXR1cm4gKFxuXHRcdHR5cGVvZiBkYXRhID09PSAnb2JqZWN0JyAmJlxuXHRcdGRhdGEgIT09IG51bGwgJiZcblx0XHQoZGF0YSBhcyB7IGNoYW5uZWw/OiB1bmtub3duIH0pLmNoYW5uZWwgPT09IFNDUkFQRVJfRU5WRUxPUEVcblx0KVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcmVhZFBhZ2VNZXNzYWdlKGRhdGE6IHVua25vd24pOiBQYWdlTWVzc2FnZSB8IG51bGwge1xuXHRpZiAoIWlzRW52ZWxvcGUoZGF0YSkgfHwgZGF0YS5kaXJlY3Rpb24gIT09ICd0by1leHRlbnNpb24nKSByZXR1cm4gbnVsbFxuXHRyZXR1cm4gZGF0YS5wYXlsb2FkIGFzIFBhZ2VNZXNzYWdlXG59XG5cbmV4cG9ydCBmdW5jdGlvbiByZWFkRXh0ZW5zaW9uTWVzc2FnZShkYXRhOiB1bmtub3duKTogRXh0ZW5zaW9uTWVzc2FnZSB8IG51bGwge1xuXHRpZiAoIWlzRW52ZWxvcGUoZGF0YSkgfHwgZGF0YS5kaXJlY3Rpb24gIT09ICd0by1wYWdlJykgcmV0dXJuIG51bGxcblx0cmV0dXJuIGRhdGEucGF5bG9hZCBhcyBFeHRlbnNpb25NZXNzYWdlXG59XG4iLCIvKipcbiAqIFJhdyByZXNwb25zZS1ib2R5IGNhcHR1cmUgdmlhIGNocm9tZS5kZWJ1Z2dlci5cbiAqXG4gKiBUaGlzIGlzIHRoZSBvbmx5IHdheSBhbiBNVjMgZXh0ZW5zaW9uIGNhbiByZWFkIGEgbmF2aWdhdGlvbidzICpyYXcqIEhUTUwuXG4gKiBJdCBtYXR0ZXJzIGJlY2F1c2UgcGFya3J1bidzIGNvb2tpZS1jb25zZW50IHNjcmlwdCByZXdyaXRlcyB0aGUgRE9NOiBjb3Vyc2VcbiAqIHBhZ2VzIGxvc2UgdGhlIEdvb2dsZSBNYXBzIGlmcmFtZSBlbnRpcmVseSwgc28gYSBET00gc2NyYXBlIGhhcyBubyBtYXAgaWQgdG9cbiAqIGZpbmQgKHNlZSBhcHBzL2FwaS9saWIvbWFwLXNjcmFwZXIudHMpLiBBdGhsZXRlIGFuZCBldmVudCBwYWdlcyBwYXJzZSBlaXRoZXJcbiAqIHdheSwgYnV0IHRoZXJlJ3Mgbm8gcmVhc29uIHRvIGhhdmUgdHdvIGNvZGUgcGF0aHMuXG4gKlxuICogVGhpbmdzIHRoYXQgd2VyZSB0cmllZCBhbmQgZG9uJ3Qgd29yazpcbiAqICAtIGBQYWdlLmdldFJlc291cmNlQ29udGVudGAg4oaSIFwiQ29udGVudCB1bmF2YWlsYWJsZS4gUmVzb3VyY2Ugd2FzIG5vdCBjYWNoZWRcIixcbiAqICAgIGV2ZW4gd2l0aCB0aGUgTmV0d29yayBkb21haW4gZW5hYmxlZC5cbiAqICAtIE5hdmlnYXRpbmcgdG8gYSBgdmlldy1zb3VyY2U6YCBVUkwg4oaSIHRoZSB0YWIgZG9lcyBsb2FkLCBidXQgc2NyaXB0XG4gKiAgICBpbmplY3Rpb24gaW50byBpdCBoYW5ncyBmb3JldmVyLCBzbyB0aGUgdGV4dCBjYW4gbmV2ZXIgYmUgcmVhZCBiYWNrLlxuICpcbiAqIFdoYXQgZG9lcyB3b3JrIGlzIHdhdGNoaW5nIE5ldHdvcmsgZXZlbnRzIGZvciB0aGUgbWFpbi1mcmFtZSBkb2N1bWVudCBhbmRcbiAqIGFza2luZyBmb3IgaXRzIGJvZHkgb25jZSBpdCBmaW5pc2hlcyBsb2FkaW5nLiBEb2N1bWVudCByZXF1ZXN0IElEcyBhcmUgd3JpdHRlblxuICogdG8gc3RvcmFnZSBhcyB0aGV5J3JlIHNlZW4sIHNvIGEgYm9keSBjYW4gc3RpbGwgYmUgZmV0Y2hlZCBhZnRlciB0aGUgc2VydmljZVxuICogd29ya2VyIGhhcyBiZWVuIHJlc3RhcnRlZC5cbiAqL1xuXG5jb25zdCBERUJVR0dFUl9WRVJTSU9OID0gJzEuMydcblxuY29uc3QgRE9DX0tFWSA9ICdsYXN0RG9jdW1lbnQnXG5cbmV4cG9ydCBpbnRlcmZhY2UgRG9jdW1lbnRSZXNwb25zZSB7XG5cdHJlcXVlc3RJZDogc3RyaW5nXG5cdHVybDogc3RyaW5nXG5cdHN0YXR1czogbnVtYmVyXG5cdC8qKiBUcnVlIG9uY2UgbG9hZGluZ0ZpbmlzaGVkIGhhcyBiZWVuIHNlZW4sIGkuZS4gdGhlIGJvZHkgaXMgYXZhaWxhYmxlLiAqL1xuXHRmaW5pc2hlZDogYm9vbGVhblxuXHQvKipcblx0ICogU2V0IG9uY2UgdGhpcyByZXNwb25zZSBoYXMgYmVlbiBjYXB0dXJlZC4gQm90aCBjYXB0dXJlIHRyaWdnZXJzIGNhbiBmaXJlIGZvclxuXHQgKiB0aGUgc2FtZSBsb2FkOyB3aXRob3V0IHRoaXMgdGhlIHBhZ2UgaXMgY2FwdHVyZWQgdHdpY2UgYW5kIHRoZSBxdWV1ZSBpc1xuXHQgKiBhZHZhbmNlZCB0d2ljZSwgd2hpY2ggc2tpcHMgdGhlIG5leHQgaXRlbS5cblx0ICovXG5cdGNvbnN1bWVkPzogYm9vbGVhblxufVxuXG5leHBvcnQgaW50ZXJmYWNlIENhcHR1cmVkQm9keSB7XG5cdHVybDogc3RyaW5nXG5cdHN0YXR1czogbnVtYmVyXG5cdGJvZHk6IHN0cmluZ1xuXHRiYXNlNjRFbmNvZGVkOiBib29sZWFuXG59XG5cbi8vIOKUgOKUgCBBdHRhY2ggLyBkZXRhY2gg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogQXR0YWNoIGFuZCBlbmFibGUgdGhlIE5ldHdvcmsgZG9tYWluLCBpZGVtcG90ZW50bHkuXG4gKlxuICogRGVsaWJlcmF0ZWx5IGRvZXMgKm5vdCogY29uc3VsdCBgY2hyb21lLmRlYnVnZ2VyLmdldFRhcmdldHMoKWAgdG8gZGVjaWRlXG4gKiB3aGV0aGVyIHRvIGF0dGFjaDogaXRzIGBhdHRhY2hlZGAgZmxhZyBpcyB0cnVlIHdoZW4gKmFueSogQ0RQIGNsaWVudCBpc1xuICogY29ubmVjdGVkLCBpbmNsdWRpbmcgdGhlIHVzZXIncyBEZXZUb29scyBhbmQgYW55IGF1dG9tYXRpb24gZHJpdmluZyB0aGVcbiAqIGJyb3dzZXIuIFRydXN0aW5nIGl0IG1lYW5zIHNpbGVudGx5IHNraXBwaW5nIG91ciBvd24gYXR0YWNoIGFuZCB0aGVuIGNhcHR1cmluZ1xuICogbm90aGluZy4gSW5zdGVhZCB3ZSBhbHdheXMgdHJ5LCBhbmQgbGV0IHRoZSBmb2xsb3ctdXAgY29tbWFuZCB0ZWxsIHVzIHdoZXRoZXJcbiAqIHdlIHJlYWxseSBob2xkIHRoZSBzZXNzaW9uIOKAlCBpZiBzb21lb25lIGVsc2UgZG9lcywgYE5ldHdvcmsuZW5hYmxlYCBmYWlscyBhbmRcbiAqIHRoZSBlcnJvciBzdXJmYWNlcy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGF0dGFjaCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdHRyeSB7XG5cdFx0YXdhaXQgY2hyb21lLmRlYnVnZ2VyLmF0dGFjaCh7IHRhYklkIH0sIERFQlVHR0VSX1ZFUlNJT04pXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0Ly8gXCJBbHJlYWR5IGF0dGFjaGVkXCIgaXMgZXhwZWN0ZWQgd2hlbiBpdCdzIG91ciBvd24gc2Vzc2lvbiBiZWluZyByZXVzZWQuXG5cdFx0aWYgKCEvYWxyZWFkeSBhdHRhY2hlZC9pLnRlc3QoZGVzY3JpYmVFcnJvcihlcnJvcikpKSB0aHJvdyBlcnJvclxuXHR9XG5cblx0Ly8gTmV0d29yayBtdXN0IGJlIGVuYWJsZWQgZm9yIHJlc3BvbnNlIGJvZGllcyB0byBiZSByZXRhaW5lZCBhdCBhbGwuIFRoaXMgaXNcblx0Ly8gYWxzbyB0aGUgcmVhbCB0ZXN0IG9mIHdoZXRoZXIgdGhlIHNlc3Npb24gaXMgb3Vycy5cblx0YXdhaXQgY2hyb21lLmRlYnVnZ2VyLnNlbmRDb21tYW5kKHsgdGFiSWQgfSwgJ05ldHdvcmsuZW5hYmxlJylcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGRldGFjaCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdHRyeSB7XG5cdFx0YXdhaXQgY2hyb21lLmRlYnVnZ2VyLmRldGFjaCh7IHRhYklkIH0pXG5cdH0gY2F0Y2gge1xuXHRcdC8vIEFscmVhZHkgZ29uZSDigJQgdGhlIHRhYiB3YXMgY2xvc2VkLCBvciBDaHJvbWUgZGV0YWNoZWQgdXMuXG5cdH1cbn1cblxuLyoqIFJlLWF0dGFjaCBpZiBhIHNlcnZpY2Ugd29ya2VyIHJlc3RhcnQgb3IgYSBkZXRhY2ggbG9zdCB0aGUgc2Vzc2lvbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBlbnN1cmVBdHRhY2hlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdHRyeSB7XG5cdFx0YXdhaXQgYXR0YWNoKHRhYklkKVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHRocm93IG5ldyBFcnJvcihcblx0XHRcdGBDb3VsZG4ndCBhdHRhY2ggdGhlIGRlYnVnZ2VyIHRvIHRoZSBzY3JhcGUgdGFiOiAke2Rlc2NyaWJlRXJyb3IoZXJyb3IpfS4gSWYgRGV2VG9vbHMgaXMgb3BlbiBvbiBpdCwgY2xvc2UgdGhlbSBhbmQgcHJlc3MgU2NyYXBlIGFnYWluLmAsXG5cdFx0KVxuXHR9XG59XG5cbi8vIOKUgOKUgCBUcmFja2luZyB0aGUgbWFpbi1mcmFtZSBkb2N1bWVudCDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqXG4gKiBOb3RlIGEgbWFpbi1mcmFtZSBkb2N1bWVudCByZXNwb25zZS4gUmVkaXJlY3QgY2hhaW5zIHByb2R1Y2Ugc2V2ZXJhbCwgc28gdGhlXG4gKiBtb3N0IHJlY2VudCBvbmUgd2lucy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5vdGVEb2N1bWVudFJlc3BvbnNlKFxuXHR0YWJJZDogbnVtYmVyLFxuXHRwYXJhbXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmIChwYXJhbXMudHlwZSAhPT0gJ0RvY3VtZW50JykgcmV0dXJuXG5cblx0Y29uc3QgcmVzcG9uc2UgPSBwYXJhbXMucmVzcG9uc2UgYXMgeyB1cmw/OiBzdHJpbmc7IHN0YXR1cz86IG51bWJlciB9XG5cdGNvbnN0IHJlcXVlc3RJZCA9IHBhcmFtcy5yZXF1ZXN0SWQgYXMgc3RyaW5nXG5cdGlmICghcmVxdWVzdElkIHx8ICFyZXNwb25zZT8udXJsKSByZXR1cm5cblxuXHQvLyBTdWJmcmFtZSBkb2N1bWVudHMgKGFkcywgZW1iZWRzKSBhbHNvIGFycml2ZSBoZXJlOyBvbmx5IHRoZSBtYWluIGZyYW1lJ3Ncblx0Ly8gZG9jdW1lbnQgaGFzIGEgZnJhbWVJZCBtYXRjaGluZyB0aGUgdGFiJ3Mgb3duIHRvcCBmcmFtZS4gYGZyYW1lSWRgIGlzXG5cdC8vIHByZXNlbnQgb24gcmVzcG9uc2VSZWNlaXZlZCwgYW5kIHRoZSBtYWluIGZyYW1lJ3MgaWQgZXF1YWxzIHRoZSB0YWIgdGFyZ2V0LFxuXHQvLyB3aGljaCB3ZSBjYW4ndCBjb21wYXJlIGRpcmVjdGx5IOKAlCBzbyBmaWx0ZXIgb24gdGhlIGxvYWRlcklkIGluc3RlYWQ6IHRoZVxuXHQvLyBtYWluLWZyYW1lIG5hdmlnYXRpb24gaXMgdGhlIG9uZSB3aG9zZSBsb2FkZXJJZCBtYXRjaGVzIGl0cyBvd24gcmVxdWVzdElkLlxuXHQvLyBDaHJvbWUgc2V0cyB0aGVzZSBlcXVhbCBmb3IgbWFpbi1mcmFtZSBkb2N1bWVudCByZXF1ZXN0cy5cblx0aWYgKHBhcmFtcy5sb2FkZXJJZCAmJiBwYXJhbXMubG9hZGVySWQgIT09IHJlcXVlc3RJZCkgcmV0dXJuXG5cblx0YXdhaXQgc2V0TGFzdERvY3VtZW50KHRhYklkLCB7XG5cdFx0cmVxdWVzdElkLFxuXHRcdHVybDogcmVzcG9uc2UudXJsLFxuXHRcdHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzID8/IDAsXG5cdFx0ZmluaXNoZWQ6IGZhbHNlLFxuXHR9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbm90ZUxvYWRpbmdGaW5pc2hlZChcblx0dGFiSWQ6IG51bWJlcixcblx0cGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPixcbik6IFByb21pc2U8RG9jdW1lbnRSZXNwb25zZSB8IG51bGw+IHtcblx0Y29uc3QgbGFzdCA9IGF3YWl0IGdldExhc3REb2N1bWVudCh0YWJJZClcblx0aWYgKCFsYXN0IHx8IGxhc3QucmVxdWVzdElkICE9PSBwYXJhbXMucmVxdWVzdElkKSByZXR1cm4gbnVsbFxuXG5cdGNvbnN0IGZpbmlzaGVkID0geyAuLi5sYXN0LCBmaW5pc2hlZDogdHJ1ZSB9XG5cdGF3YWl0IHNldExhc3REb2N1bWVudCh0YWJJZCwgZmluaXNoZWQpXG5cdHJldHVybiBmaW5pc2hlZFxufVxuXG4vKipcbiAqIFRydWUgd2hlbiBgTmV0d29yay5nZXRSZXNwb25zZUJvZHlgIGZhaWxlZCBvbmx5IGJlY2F1c2UgdGhlIGJvZHkgaXNuJ3QgdGhlcmVcbiAqIHlldCwgYXMgb3Bwb3NlZCB0byBiZWluZyBnb25lIGZvciBnb29kLlxuICpcbiAqIFdvcnRoIGRpc3Rpbmd1aXNoaW5nIGJlY2F1c2Ugd2UgYWxzbyB0cnkgdG8gcmVhZCBib2RpZXMgb2ZmIGB0YWJzLm9uVXBkYXRlZGAsXG4gKiB3aGljaCBjYW4gbGFuZCBtYXJnaW5hbGx5IGJlZm9yZSB0aGUgYm9keSBpcyBhdmFpbGFibGUuIEEgXCJub3QgcmVhZHlcIiBpc1xuICogc29tZXRoaW5nIHRvIHdhaXQgb3V0OyBhbnl0aGluZyBlbHNlIG1lYW5zIHRoaXMgYXR0ZW1wdCBpcyBzcGVudC5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzQm9keU5vdFJlYWR5KGVycm9yOiB1bmtub3duKTogYm9vbGVhbiB7XG5cdHJldHVybiAvbm8gcmVzb3VyY2Ugd2l0aCBnaXZlbiBpZGVudGlmaWVyfG5vIGRhdGEgZm91bmQvaS50ZXN0KFxuXHRcdGRlc2NyaWJlRXJyb3IoZXJyb3IpLFxuXHQpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRMYXN0RG9jdW1lbnQoXG5cdHRhYklkOiBudW1iZXIsXG4pOiBQcm9taXNlPERvY3VtZW50UmVzcG9uc2UgfCBudWxsPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDxcblx0XHRSZWNvcmQ8c3RyaW5nLCBEb2N1bWVudFJlc3BvbnNlPlxuXHQ+KGAke0RPQ19LRVl9OiR7dGFiSWR9YClcblx0cmV0dXJuIHN0b3JlZFtgJHtET0NfS0VZfToke3RhYklkfWBdID8/IG51bGxcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0TGFzdERvY3VtZW50KFxuXHR0YWJJZDogbnVtYmVyLFxuXHR2YWx1ZTogRG9jdW1lbnRSZXNwb25zZSxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbYCR7RE9DX0tFWX06JHt0YWJJZH1gXTogdmFsdWUgfSlcbn1cblxuLyoqIE1hcmsgdGhlIGN1cnJlbnQgZG9jdW1lbnQgYXMgY2FwdHVyZWQsIHNvIGEgc2Vjb25kIHRyaWdnZXIgaXMgYSBuby1vcC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBtYXJrRG9jdW1lbnRDb25zdW1lZChcblx0dGFiSWQ6IG51bWJlcixcblx0ZG9jdW1lbnQ6IERvY3VtZW50UmVzcG9uc2UsXG4pOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgc2V0TGFzdERvY3VtZW50KHRhYklkLCB7IC4uLmRvY3VtZW50LCBjb25zdW1lZDogdHJ1ZSB9KVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2xlYXJMYXN0RG9jdW1lbnQodGFiSWQ6IG51bWJlcik6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5yZW1vdmUoYCR7RE9DX0tFWX06JHt0YWJJZH1gKVxufVxuXG4vLyDilIDilIAgUmVhZGluZyB0aGUgYm9keSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlYWRCb2R5KFxuXHR0YWJJZDogbnVtYmVyLFxuXHRkb2N1bWVudDogRG9jdW1lbnRSZXNwb25zZSxcbik6IFByb21pc2U8Q2FwdHVyZWRCb2R5PiB7XG5cdGNvbnN0IHJlc3VsdCA9IGF3YWl0IGNocm9tZS5kZWJ1Z2dlci5zZW5kQ29tbWFuZDx7XG5cdFx0Ym9keTogc3RyaW5nXG5cdFx0YmFzZTY0RW5jb2RlZDogYm9vbGVhblxuXHR9Pih7IHRhYklkIH0sICdOZXR3b3JrLmdldFJlc3BvbnNlQm9keScsIHsgcmVxdWVzdElkOiBkb2N1bWVudC5yZXF1ZXN0SWQgfSlcblxuXHRyZXR1cm4ge1xuXHRcdHVybDogZG9jdW1lbnQudXJsLFxuXHRcdHN0YXR1czogZG9jdW1lbnQuc3RhdHVzLFxuXHRcdGJvZHk6IHJlc3VsdC5iYXNlNjRFbmNvZGVkID8gZGVjb2RlQmFzZTY0KHJlc3VsdC5ib2R5KSA6IHJlc3VsdC5ib2R5LFxuXHRcdGJhc2U2NEVuY29kZWQ6IHJlc3VsdC5iYXNlNjRFbmNvZGVkLFxuXHR9XG59XG5cbi8qKiBDaHJvbWUgaGFuZHMgYmFjayBiYXNlNjQgZm9yIGFueXRoaW5nIGl0IGRvZXNuJ3QgY29uc2lkZXIgdGV4dC4gKi9cbmZ1bmN0aW9uIGRlY29kZUJhc2U2NChiYXNlNjQ6IHN0cmluZyk6IHN0cmluZyB7XG5cdGNvbnN0IGJpbmFyeSA9IGF0b2IoYmFzZTY0KVxuXHRjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGJpbmFyeS5sZW5ndGgpXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYmluYXJ5Lmxlbmd0aDsgaSsrKSBieXRlc1tpXSA9IGJpbmFyeS5jaGFyQ29kZUF0KGkpXG5cdHJldHVybiBuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUoYnl0ZXMpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZXNjcmliZUVycm9yKGVycm9yOiB1bmtub3duKTogc3RyaW5nIHtcblx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBlcnJvci5tZXNzYWdlXG5cdGlmICh0eXBlb2YgZXJyb3IgPT09ICdzdHJpbmcnKSByZXR1cm4gZXJyb3Jcblx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KGVycm9yKVxufVxuIiwiLyoqXG4gKiBDbGlja2luZyB0aGUgdG9vbGJhciBpY29uIG9wZW5zIHRoZSBQcm9jZXNzIFJlc3VsdHMgcGFnZS5cbiAqXG4gKiBXaGljaCBvcmlnaW4gdGhhdCBpcyBkZXBlbmRzIG9uIHdoZXJlIHRoZSBzaXRlIGlzIGJlaW5nIHNlcnZlZCDigJQgbG9jYWxob3N0IGluXG4gKiBkZXZlbG9wbWVudCwgc2Nvb3BidXMucnVuIGluIHByb2R1Y3Rpb24g4oCUIHNvIHRoZSBicmlkZ2UgcmVjb3JkcyB0aGUgb3JpZ2luIGl0XG4gKiBsYXN0IHRhbGtlZCB0byBhbmQgdGhhdCdzIHdoYXQgZ2V0cyBvcGVuZWQuIEZhbGxpbmcgYmFjayB0byBhIGd1ZXNzIG9ubHkgd2hlblxuICogd2UndmUgbmV2ZXIgc2VlbiBvbmUuXG4gKi9cblxuY29uc3QgT1JJR0lOX0tFWSA9ICdsYXN0QWRtaW5PcmlnaW4nXG5jb25zdCBQQUdFX1BBVEggPSAnL2FkbWluL3Byb2Nlc3MtcmVzdWx0cydcblxuLyoqIEZpZWxkIHRoZSBicmlkZ2UgYWRkcyB0byBzYXkgYSBtZXNzYWdlIGNhbWUgZnJvbSBhbiBhZG1pbiBwYWdlLiAqL1xuaW50ZXJmYWNlIEFkbWluUGFnZVRhZyB7XG5cdGZyb21BZG1pblBhZ2U/OiB0cnVlXG59XG5cbi8qKlxuICogVGFnIGEgbWVzc2FnZSBhcyBjb21pbmcgZnJvbSB0aGUgYWRtaW4gcGFnZS4gQ2FsbGVkIGJ5IHRoZSBicmlkZ2Ugb25seS5cbiAqXG4gKiBUaGUgb3ZlcmxheSBjb250ZW50IHNjcmlwdCBzZW5kcyBgY2FuY2VsYCwgYHJldHJ5YCBhbmQgYHNraXBgIHRvbyDigJQgdGhlIHNhbWVcbiAqIHR5cGVzIHRoZSBhZG1pbiBwYWdlIHNlbmRzIOKAlCBzbyBhIG1lc3NhZ2UncyB0eXBlIHNheXMgbm90aGluZyBhYm91dCB3aGVyZSBpdFxuICogY2FtZSBmcm9tLCBhbmQgcmVtZW1iZXJpbmcgdGhlIHNlbmRlciBvZiAqYW55KiBtZXNzYWdlIG1lYW50IHRoZSBpY29uXG4gKiBcImxlYXJuZWRcIiBwYXJrcnVuLm9yZy51ayB0aGUgbW9tZW50IGEgc2NyYXBlIHN0YXJ0ZWQuIFRoZSBicmlkZ2UgcnVucyBvbiBhZG1pblxuICogb3JpZ2lucyBhbmQgbm93aGVyZSBlbHNlLCBzbyBpdHMgb3duIHRhZyBpcyB0aGUgZGVwZW5kYWJsZSBzaWduYWwuXG4gKlxuICogU3ByZWFkIGZpcnN0IHNvIGEgcGFnZSB0aGF0IHB1dHMgYGZyb21BZG1pblBhZ2VgIGluIGl0cyBvd24gbWVzc2FnZSBjYW4ndFxuICogdW5zZXQgaXQuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiB0YWdGcm9tQWRtaW5QYWdlPFQgZXh0ZW5kcyBvYmplY3Q+KFxuXHRtZXNzYWdlOiBULFxuKTogVCAmIEFkbWluUGFnZVRhZyB7XG5cdHJldHVybiB7IC4uLm1lc3NhZ2UsIGZyb21BZG1pblBhZ2U6IHRydWUgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gaXNGcm9tQWRtaW5QYWdlKG1lc3NhZ2U6IHVua25vd24pOiBib29sZWFuIHtcblx0cmV0dXJuIChcblx0XHR0eXBlb2YgbWVzc2FnZSA9PT0gJ29iamVjdCcgJiZcblx0XHRtZXNzYWdlICE9PSBudWxsICYmXG5cdFx0KG1lc3NhZ2UgYXMgQWRtaW5QYWdlVGFnKS5mcm9tQWRtaW5QYWdlID09PSB0cnVlXG5cdClcbn1cblxuLyoqXG4gKiBVc2VkIG9ubHkgYmVmb3JlIHRoZSBicmlkZ2UgaGFzIGV2ZXIgYW5ub3VuY2VkIGl0c2VsZiBmcm9tIGEgcmVhbCBwYWdlLlxuICpcbiAqIFByb2R1Y3Rpb24gZmlyc3Q6IG9uIGEgZnJlc2ggaW5zdGFsbCB0aGUgbGl2ZSBzaXRlIGlzIHRoZSBzYWZlIGd1ZXNzLCBhbmQgYVxuICogZGV2IHdpbGwgaGF2ZSBsb2FkZWQgbG9jYWxob3N0IHdpdGhpbiBzZWNvbmRzLCBhZnRlciB3aGljaCB0aGUgcmVtZW1iZXJlZFxuICogb3JpZ2luIHRha2VzIG92ZXIuIE9uZSBidWlsZCBzZXJ2ZXMgYm90aCDigJQgdGhlIG1hbmlmZXN0IGdyYW50cyBib3RoIG9yaWdpbnMuXG4gKi9cbmNvbnN0IEZBTExCQUNLX09SSUdJTlMgPSBbJ2h0dHBzOi8vc2Nvb3BidXMucnVuJywgJ2h0dHA6Ly9sb2NhbGhvc3Q6MzAwNSddXG5cbi8qKlxuICogUmVtZW1iZXIgd2hlcmUgdGhlIGFkbWluIHBhZ2UgbGl2ZXMsIGZyb20gYW55IG1lc3NhZ2UgdGhlIGJyaWRnZSBzZW5kcy5cbiAqXG4gKiBFdmVyeSBhZG1pbiBwYWdlIGFubm91bmNlcyBpdHNlbGYgd2l0aCBhIGBwaW5nYCBvbiBsb2FkLCBzbyBzaW1wbHkgb3BlbmluZ1xuICogbG9jYWxob3N0OjMwMDUgaXMgZW5vdWdoIHRvIHBvaW50IHRoZSBpY29uIHRoZXJlLCBhbmQgb3BlbmluZyB0aGUgbGl2ZSBzaXRlXG4gKiBwb2ludHMgaXQgYmFjay5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlbWVtYmVyQWRtaW5PcmlnaW4oXG5cdHNlbmRlclVybDogc3RyaW5nIHwgdW5kZWZpbmVkLFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmICghc2VuZGVyVXJsKSByZXR1cm5cblx0dHJ5IHtcblx0XHRjb25zdCB7IG9yaWdpbiB9ID0gbmV3IFVSTChzZW5kZXJVcmwpXG5cdFx0YXdhaXQgY2hyb21lLnN0b3JhZ2UubG9jYWwuc2V0KHsgW09SSUdJTl9LRVldOiBvcmlnaW4gfSlcblx0fSBjYXRjaCB7XG5cdFx0Ly8gTm90IGEgVVJMIHdlIGNhbiB1c2U7IGtlZXAgd2hhdGV2ZXIgd2UgaGFkLlxuXHR9XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGtub3duQWRtaW5PcmlnaW4oKTogUHJvbWlzZTxzdHJpbmcgfCBudWxsPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDx7IGxhc3RBZG1pbk9yaWdpbj86IHN0cmluZyB9Pihcblx0XHRPUklHSU5fS0VZLFxuXHQpXG5cdHJldHVybiBzdG9yZWQubGFzdEFkbWluT3JpZ2luID8/IG51bGxcbn1cblxuLyoqXG4gKiBGb2N1cyBhbiBleGlzdGluZyBQcm9jZXNzIFJlc3VsdHMgdGFiIGlmIHRoZXJlIGlzIG9uZSwgb3RoZXJ3aXNlIG9wZW4gaXQuXG4gKlxuICogUmV1c2luZyB0aGUgdGFiIG1hdHRlcnM6IGEgc2NyYXBlJ3MgY2FwdHVyZWQgZmlsZXMgYXJlIGhlbGQgYnkgdGhlIHBhZ2UsIHNvXG4gKiBvcGVuaW5nIGEgc2Vjb25kIGNvcHkgd291bGQgc2hvdyBhbiBlbXB0eSBvbmUgbmV4dCB0byB0aGUgb25lIGRvaW5nIHRoZSB3b3JrLlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gb3BlbkFkbWluUGFnZSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgb3JpZ2lucyA9IFthd2FpdCBrbm93bkFkbWluT3JpZ2luKCksIC4uLkZBTExCQUNLX09SSUdJTlNdLmZpbHRlcihcblx0XHQob3JpZ2luKTogb3JpZ2luIGlzIHN0cmluZyA9PiAhIW9yaWdpbixcblx0KVxuXG5cdGZvciAoY29uc3Qgb3JpZ2luIG9mIG9yaWdpbnMpIHtcblx0XHRjb25zdCBleGlzdGluZyA9IGF3YWl0IGNocm9tZS50YWJzXG5cdFx0XHQucXVlcnkoeyB1cmw6IGAke29yaWdpbn0ke1BBR0VfUEFUSH0qYCB9KVxuXHRcdFx0LmNhdGNoKCgpID0+IFtdKVxuXG5cdFx0Y29uc3QgdGFiID0gZXhpc3RpbmcuZmluZCgoY2FuZGlkYXRlKSA9PiBjYW5kaWRhdGUuaWQgIT09IHVuZGVmaW5lZClcblx0XHRpZiAodGFiPy5pZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRhd2FpdCBjaHJvbWUudGFicy51cGRhdGUodGFiLmlkLCB7IGFjdGl2ZTogdHJ1ZSB9KVxuXHRcdFx0aWYgKHRhYi53aW5kb3dJZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRcdGF3YWl0IGNocm9tZS53aW5kb3dzLnVwZGF0ZSh0YWIud2luZG93SWQsIHsgZm9jdXNlZDogdHJ1ZSB9KVxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXHR9XG5cblx0Y29uc3Qgb3JpZ2luID0gb3JpZ2luc1swXVxuXHRhd2FpdCBjaHJvbWUudGFicy5jcmVhdGUoeyB1cmw6IGAke29yaWdpbn0ke1BBR0VfUEFUSH1gLCBhY3RpdmU6IHRydWUgfSlcbn1cbiIsIi8vIFNoYXJlZCBQYXJrcnVuIEhUTUwgcGFyc2luZyBsb2dpYy5cbi8vIFVzZWQgYnkgdGhlIHNjcmFwaW5nIHNjcmlwdHMgKGFwcHMvYXBpL3NjcmlwdHMpIGFuZCBieSB0aGUgUHJvY2VzcyBSZXN1bHRzXG4vLyBhZG1pbiBwYWdlLCB3aGljaCBydW5zIHRoZXNlIHNhbWUgcGFyc2VycyBvdmVyIGhhbmQtZG93bmxvYWRlZCBwYWdlcy5cbi8vXG4vLyBQYXJzZXM6IC9wYXJrcnVubmVyL3tpZH0vYWxsLyDihpIgcnVubmVyIGluZm8gKyBhbGwgcnVuIHJlc3VsdHNcbi8vXG4vLyBUd28gZmxhdm91cnMgb2YgSFRNTCByZWFjaCB0aGVzZSBwYXJzZXJzOiB0aGUgRE9NIHNlcmlhbGlzZWQgYnkgUGxheXdyaWdodFxuLy8gKGVudGl0aWVzIGxpa2UgJm5ic3A7LCBFbmdsaXNoIFVJIHdoZW4gZmV0Y2hlZCBmcm9tIHBhcmtydW4ub3JnLnVrKSBhbmQgcGFnZVxuLy8gc291cmNlIHNhdmVkIHN0cmFpZ2h0IGZyb20gYSBicm93c2VyIChsaXRlcmFsIG5vbi1icmVha2luZyBzcGFjZXMsIGFuZCBhbnlcbi8vIHBhcmtydW4gbG9jYWxlJ3MgVUkgdGV4dCkuIEV2ZXJ5dGhpbmcgaGVyZSBrZXlzIG9mZiBzdHJ1Y3R1cmUgcmF0aGVyIHRoYW5cbi8vIHdvcmRpbmcgc28gYm90aCB3b3JrLlxuXG4vLyAtLS0gVHlwZXMgLS0tXG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVubmVySW5mbyB7XG5cdG5hbWU6IHN0cmluZ1xuXHQvKiogQXRobGV0ZSBJRCByZWFkIGJhY2sgb2ZmIHRoZSBwYWdlLCBlLmcuIFwiODA3MDgyMVwiLiBFbXB0eSBpZiBub3QgZm91bmQuICovXG5cdHBhcmtydW5JZDogc3RyaW5nXG5cdHRvdGFsUnVuczogbnVtYmVyXG5cdHRvdGFsSnVuaW9yUnVuczogbnVtYmVyXG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUnVuUmVzdWx0IHtcblx0ZXZlbnQ6IHN0cmluZyAvLyBldmVudElkLCBlLmcuIFwiaGFnYVwiXG5cdGV2ZW50TmFtZTogc3RyaW5nIC8vIGRpc3BsYXkgbmFtZSwgZS5nLiBcIkhhZ2FcIiAodXNlZCBieSBleHRyYWN0RXZlbnRzLCBub3Qgc3RvcmVkIGluIHJ1blJlc3VsdHMpXG5cdGV2ZW50VXJsOiBzdHJpbmcgLy8gZS5nLiBcImh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzLzM5NC9cIlxuXHRldmVudE51bWJlcjogbnVtYmVyXG5cdHBvc2l0aW9uOiBudW1iZXJcblx0dGltZTogc3RyaW5nXG5cdGFnZUdyYWRlOiBzdHJpbmdcblx0ZGF0ZTogc3RyaW5nIC8vIFlZWVktTU0tRERcbn1cblxuZXhwb3J0IGludGVyZmFjZSBFdmVudEluZm8ge1xuXHRldmVudElkOiBzdHJpbmcgLy8gZS5nLiBcImhhZ2FcIlxuXHRuYW1lOiBzdHJpbmcgLy8gZS5nLiBcIkhhZ2FcIlxuXHR1cmw6IHN0cmluZyAvLyBlLmcuIFwiaHR0cHM6Ly93d3cucGFya3J1bi5zZS9oYWdhL3Jlc3VsdHMvXCJcblx0Y291bnRyeTogc3RyaW5nIC8vIGUuZy4gXCJTRVwiXG59XG5cbi8vIC0tLSBDb3VudHJ5IGNvZGUgbWFwcGluZyBmcm9tIHBhcmtydW4gZG9tYWluIC0tLVxuXG5jb25zdCBOQU1JQklBX0VWRU5UUyA9IG5ldyBTZXQoWyd3YWx2aXNiYXknLCAnd2luZGhvZWsnLCAnc3dha29wbXVuZCddKVxuXG5leHBvcnQgY29uc3QgRE9NQUlOX1RPX0NPVU5UUlk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7XG5cdCdwYXJrcnVuLmNvbS5hdSc6ICdBVScsXG5cdCdwYXJrcnVuLmNvLmF0JzogJ0FUJyxcblx0J3BhcmtydW4uY2EnOiAnQ0EnLFxuXHQncGFya3J1bi5kayc6ICdESycsXG5cdCdwYXJrcnVuLmZpJzogJ0ZJJyxcblx0J3BhcmtydW4uY29tLmRlJzogJ0RFJyxcblx0J3BhcmtydW4uaWUnOiAnSUUnLFxuXHQncGFya3J1bi5pdCc6ICdJVCcsXG5cdCdwYXJrcnVuLmpwJzogJ0pQJyxcblx0J3BhcmtydW4ubHQnOiAnTFQnLFxuXHQncGFya3J1bi5teSc6ICdNWScsXG5cdCdwYXJrcnVuLmNvLm5sJzogJ05MJyxcblx0J3BhcmtydW4uY28ubnonOiAnTlonLFxuXHQncGFya3J1bi5ubyc6ICdOTycsXG5cdCdwYXJrcnVuLnBsJzogJ1BMJyxcblx0J3BhcmtydW4uc2cnOiAnU0cnLFxuXHQncGFya3J1bi5jby56YSc6ICdaQScsXG5cdCdwYXJrcnVuLnNlJzogJ1NFJyxcblx0J3BhcmtydW4ub3JnLnVrJzogJ1VLJyxcblx0J3BhcmtydW4udXMnOiAnVVMnLFxufVxuXG5mdW5jdGlvbiBnZXRDb3VudHJ5RnJvbVVybCh1cmw6IHN0cmluZywgZXZlbnRJZDogc3RyaW5nKTogc3RyaW5nIHtcblx0dHJ5IHtcblx0XHRjb25zdCBob3N0bmFtZSA9IG5ldyBVUkwodXJsKS5ob3N0bmFtZS5yZXBsYWNlKC9ed3d3XFwuLywgJycpXG5cdFx0aWYgKGhvc3RuYW1lID09PSAncGFya3J1bi5jby56YScgJiYgTkFNSUJJQV9FVkVOVFMuaGFzKGV2ZW50SWQpKSB7XG5cdFx0XHRyZXR1cm4gJ05BJ1xuXHRcdH1cblx0XHRyZXR1cm4gRE9NQUlOX1RPX0NPVU5UUllbaG9zdG5hbWVdID8/ICc/Pydcblx0fSBjYXRjaCB7XG5cdFx0cmV0dXJuICc/Pydcblx0fVxufVxuXG4vKipcbiAqIEV4dHJhY3QgdW5pcXVlIGV2ZW50IGluZm8gZnJvbSBwYXJzZWQgcnVuIHJlc3VsdHMuXG4gKiBEZXJpdmVzIGV2ZW50SWQsIG5hbWUsIGJhc2UgVVJMLCBhbmQgY291bnRyeSBmcm9tIHRoZSByZXN1bHQgVVJMcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3RFdmVudHMocnVuUmVzdWx0czogUnVuUmVzdWx0W10pOiBFdmVudEluZm9bXSB7XG5cdGNvbnN0IHNlZW4gPSBuZXcgTWFwPHN0cmluZywgRXZlbnRJbmZvPigpXG5cblx0Zm9yIChjb25zdCByZXN1bHQgb2YgcnVuUmVzdWx0cykge1xuXHRcdGlmICghcmVzdWx0LmV2ZW50VXJsIHx8ICFyZXN1bHQuZXZlbnQpIGNvbnRpbnVlXG5cdFx0aWYgKHNlZW4uaGFzKHJlc3VsdC5ldmVudCkpIGNvbnRpbnVlXG5cblx0XHQvLyBVUkwgbG9va3MgbGlrZSBodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvcmVzdWx0cy8zOTQvXG5cdFx0Ly8gV2Ugd2FudCBiYXNlOiBodHRwczovL3d3dy5wYXJrcnVuLnNlL2hhZ2EvXG5cdFx0Y29uc3QgdXJsTWF0Y2ggPSByZXN1bHQuZXZlbnRVcmwubWF0Y2goXG5cdFx0XHQvXihodHRwcz86XFwvXFwvW14vXStcXC9bXi9dKylcXC9yZXN1bHRzXFwvP1xcZCpcXC8/JC8sXG5cdFx0KVxuXHRcdGlmICghdXJsTWF0Y2gpIGNvbnRpbnVlXG5cblx0XHRjb25zdCBiYXNlVXJsID0gYCR7dXJsTWF0Y2hbMV19L2BcblxuXHRcdHNlZW4uc2V0KHJlc3VsdC5ldmVudCwge1xuXHRcdFx0ZXZlbnRJZDogcmVzdWx0LmV2ZW50LFxuXHRcdFx0bmFtZTogcmVzdWx0LmV2ZW50TmFtZSxcblx0XHRcdHVybDogYmFzZVVybCxcblx0XHRcdGNvdW50cnk6IGdldENvdW50cnlGcm9tVXJsKHJlc3VsdC5ldmVudFVybCwgcmVzdWx0LmV2ZW50KSxcblx0XHR9KVxuXHR9XG5cblx0cmV0dXJuIEFycmF5LmZyb20oc2Vlbi52YWx1ZXMoKSlcbn1cblxuLy8gLS0tIEhlbHBlcjogc3RyaXAgSFRNTCB0YWdzIC0tLVxuXG5mdW5jdGlvbiBzdHJpcFRhZ3MoaHRtbDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGh0bWwucmVwbGFjZSgvPFtePl0qPi9nLCAnJykudHJpbSgpXG59XG5cbi8vIC0tLSBIZWxwZXI6IGRlY29kZSB0aGUgaGFuZGZ1bCBvZiBlbnRpdGllcyBwYXJrcnVuIGVtaXRzIGluIGNsdWIgbmFtZXMgLS0tXG5cbmNvbnN0IEVOVElUSUVTOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuXHQnJmFtcDsnOiAnJicsXG5cdCcmbHQ7JzogJzwnLFxuXHQnJmd0Oyc6ICc+Jyxcblx0JyZxdW90Oyc6ICdcIicsXG5cdCcmIzAzOTsnOiBcIidcIixcblx0JyZhcG9zOyc6IFwiJ1wiLFxuXHQnJm5ic3A7JzogJyAnLFxufVxuXG5mdW5jdGlvbiBkZWNvZGVFbnRpdGllcyh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gdGV4dFxuXHRcdC5yZXBsYWNlKC8mKD86YW1wfGx0fGd0fHF1b3R8IzAzOXxhcG9zfG5ic3ApOy9nLCAobSkgPT4gRU5USVRJRVNbbV0gPz8gbSlcblx0XHQucmVwbGFjZSgvJiMoXFxkKyk7L2csIChfLCBjb2RlKSA9PlxuXHRcdFx0U3RyaW5nLmZyb21Db2RlUG9pbnQoTnVtYmVyLnBhcnNlSW50KGNvZGUsIDEwKSksXG5cdFx0KVxuXHRcdC5yZXBsYWNlKC9cXHUwMGEwL2csICcgJylcbn1cblxuLy8gLS0tIFBhcnNlIHJ1bm5lciBpbmZvIGZyb20gdGhlIC9hbGwvIHBhZ2UgLS0tXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVJ1bm5lckRhdGEoaHRtbDogc3RyaW5nKTogUnVubmVySW5mbyB7XG5cdC8vIE5hbWU6IDxoMj5Kb3NoIFRIT01QU09OJm5ic3A7PHNwYW4gdGl0bGU9XCJwYXJrcnVuIElEXCI+KEE4MDcwODIxKTwvc3Bhbj48L2gyPlxuXHQvLyBUaGUgSUQgc3BhbiBoYXMgdG8gYmUgdGhlcmUgZm9yIHVzIHRvIHRydXN0IHRoZSBoZWFkaW5nIOKAlCBhIGJsb2NrZWQgb3Jcblx0Ly8gZXJyb3IgcGFnZSBjYW4gY2FycnkgYW4gdW5yZWxhdGVkIDxoMj4sIGFuZCBjYWxsZXJzIHVzZSB0aGUgXCJVbmtub3duXCJcblx0Ly8gbmFtZSBhcyB0aGVpciBzaWduYWwgdG8gcmV0cnkuXG5cdGNvbnN0IGhlYWRpbmcgPSBodG1sLm1hdGNoKC88aDI+KFtcXHNcXFNdKj8pPFxcL2gyPi8pPy5bMV0gPz8gJydcblx0Y29uc3QgaWRNYXRjaCA9IGhlYWRpbmcubWF0Y2goL1xcKFxccypBPyhcXGQrKVxccypcXCkvKVxuXHRjb25zdCBoZWFkaW5nTmFtZSA9IGRlY29kZUVudGl0aWVzKHN0cmlwVGFncyhoZWFkaW5nKSlcblx0XHQucmVwbGFjZSgvXFwoXFxzKkE/XFxkK1xccypcXCkvLCAnJylcblx0XHQudHJpbSgpXG5cdGNvbnN0IG5hbWUgPSBpZE1hdGNoICYmIGhlYWRpbmdOYW1lID8gaGVhZGluZ05hbWUgOiAnVW5rbm93bidcblxuXHQvLyBUb3RhbCBydW5zOiA8aDM+MTM2IHBhcmtydW5zIHRvdGFsPC9oMz4gIG9yICA8aDM+XFxuICAxMzYgcGFya3J1bnMgdG90YWx0XFxuPC9oMz5cblx0Ly8gV2l0aCBqdW5pb3IgcGFya3J1bnM6IDxoMz4xMCBwYXJrcnVucyAmYW1wOyA0IGp1bmlvciBwYXJrcnVucyB0b3RhbHQ8L2gzPlxuXHRjb25zdCB0b3RhbE1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvPGgzPlxccyooXFxkKylcXHMqcGFya3J1bnM/XFxzKig/OiZhbXA7fCYpP1xccyooPzooXFxkKylcXHMqanVuaW9yXFxzKnBhcmtydW5zP1xccyopP3RvdGFsL2ksXG5cdClcblx0Y29uc3QgdG90YWxSdW5zID0gdG90YWxNYXRjaCA/IE51bWJlci5wYXJzZUludCh0b3RhbE1hdGNoWzFdLCAxMCkgOiAwXG5cdGNvbnN0IHRvdGFsSnVuaW9yUnVucyA9IHRvdGFsTWF0Y2g/LlsyXVxuXHRcdD8gTnVtYmVyLnBhcnNlSW50KHRvdGFsTWF0Y2hbMl0sIDEwKVxuXHRcdDogMFxuXG5cdHJldHVybiB7XG5cdFx0bmFtZSxcblx0XHRwYXJrcnVuSWQ6IGlkTWF0Y2ggPyBpZE1hdGNoWzFdIDogJycsXG5cdFx0dG90YWxSdW5zLFxuXHRcdHRvdGFsSnVuaW9yUnVucyxcblx0fVxufVxuXG4vLyAtLS0gUGFyc2UgYWxsIHJ1biByZXN1bHRzIGZyb20gdGhlIC9hbGwvIHBhZ2UgLS0tXG5cbi8qKlxuICogVGhlIGA8dGJvZHk+YCBibG9ja3MgdGhhdCBjb3VsZCBob2xkIHRoZSBhbGwtcmVzdWx0cyB0YWJsZSwgYmVzdCBjYW5kaWRhdGVcbiAqIGZpcnN0LiBUaGUgcGFnZSBhbHNvIGNhcnJpZXMgYSBzdW1tYXJ5LXN0YXRpc3RpY3MgYW5kIGEgeWVhcmx5LWJlc3RzIHRhYmxlXG4gKiB3aXRoIHRoZSBzYW1lIGBpZD1cInJlc3VsdHNcImAsIGFuZCB0aGUgY2FwdGlvbiBuYW1pbmcgdGhlIHJpZ2h0IG9uZSBpc1xuICogbG9jYWxpc2VkIChcIkFsbCBSZXN1bHRzXCIgLyBcIuKAkyBBbGxhIHJlc3VsdGF0XCIpLCBzbyB3ZSB0cnkgdGhlIEVuZ2xpc2ggY2FwdGlvblxuICogZmlyc3QgYW5kIHRoZW4gZmFsbCBiYWNrIHRvIGV2ZXJ5IHJlc3VsdHMgdGFibGUsIGxhc3Qgb25lIGZpcnN0ICh0aGVcbiAqIGFsbC1yZXN1bHRzIHRhYmxlIGlzIHRoZSBsYXN0IG9uIHRoZSBwYWdlKS5cbiAqL1xuZnVuY3Rpb24gZmluZFJlc3VsdFRib2RpZXMoaHRtbDogc3RyaW5nKTogc3RyaW5nW10ge1xuXHRjb25zdCBjYW5kaWRhdGVzOiBzdHJpbmdbXSA9IFtdXG5cblx0Y29uc3QgY2FwdGlvbk1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvQWxsXFxzK1Jlc3VsdHNcXHMqPFxcL2NhcHRpb24+W1xcc1xcU10qPzx0Ym9keVtePl0qPihbXFxzXFxTXSo/KTxcXC90Ym9keT4vaSxcblx0KVxuXHRpZiAoY2FwdGlvbk1hdGNoKSBjYW5kaWRhdGVzLnB1c2goY2FwdGlvbk1hdGNoWzFdKVxuXG5cdGNvbnN0IHRhYmxlcyA9IFtcblx0XHQuLi5odG1sLm1hdGNoQWxsKC88dGFibGVbXj5dKmlkPVwicmVzdWx0c1wiW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RhYmxlPi9naSksXG5cdF1cblx0Zm9yIChjb25zdCB0YWJsZSBvZiB0YWJsZXMucmV2ZXJzZSgpKSB7XG5cdFx0Y29uc3QgdGJvZHkgPSB0YWJsZVsxXS5tYXRjaCgvPHRib2R5W14+XSo+KFtcXHNcXFNdKj8pPFxcL3Rib2R5Pi9pKVxuXHRcdGNhbmRpZGF0ZXMucHVzaCh0Ym9keSA/IHRib2R5WzFdIDogdGFibGVbMV0pXG5cdH1cblxuXHRyZXR1cm4gY2FuZGlkYXRlc1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VSdW5SZXN1bHRzKGh0bWw6IHN0cmluZyk6IFJ1blJlc3VsdFtdIHtcblx0Zm9yIChjb25zdCB0Ym9keSBvZiBmaW5kUmVzdWx0VGJvZGllcyhodG1sKSkge1xuXHRcdGNvbnN0IHJlc3VsdHMgPSBwYXJzZVJlc3VsdFJvd3ModGJvZHkpXG5cdFx0aWYgKHJlc3VsdHMubGVuZ3RoID4gMCkgcmV0dXJuIHJlc3VsdHNcblx0fVxuXHRyZXR1cm4gW11cbn1cblxuZnVuY3Rpb24gcGFyc2VSZXN1bHRSb3dzKHRib2R5OiBzdHJpbmcpOiBSdW5SZXN1bHRbXSB7XG5cdGNvbnN0IHJlc3VsdHM6IFJ1blJlc3VsdFtdID0gW11cblxuXHQvLyBNYXRjaCBlYWNoIHJvdzogPHRyIGNsYXNzPVwiLi4uXCI+PHRkPi4uLjwvdGQ+PHRkPi4uLjwvdGQ+Li4uPC90cj5cblx0Y29uc3Qgcm93UmVnZXggPSAvPHRyW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RyPi9naVxuXG5cdGZvciAoY29uc3Qgcm93TWF0Y2ggb2YgdGJvZHkubWF0Y2hBbGwocm93UmVnZXgpKSB7XG5cdFx0Y29uc3Qgcm93ID0gcm93TWF0Y2hbMV1cblxuXHRcdC8vIEV4dHJhY3QgY2VsbHNcblx0XHRjb25zdCBjZWxsUmVnZXggPSAvPHRkW14+XSo+KFtcXHNcXFNdKj8pPFxcL3RkPi9naVxuXHRcdGNvbnN0IGNlbGxzOiBzdHJpbmdbXSA9IFtdXG5cdFx0Zm9yIChjb25zdCBjZWxsTWF0Y2ggb2Ygcm93Lm1hdGNoQWxsKGNlbGxSZWdleCkpIHtcblx0XHRcdGNlbGxzLnB1c2goY2VsbE1hdGNoWzFdKVxuXHRcdH1cblxuXHRcdC8vIENvbHVtbnM6IEV2ZW50LCBSdW4gRGF0ZSwgUnVuIE51bWJlciwgUG9zLCBUaW1lLCBBZ2UgR3JhZGUsIFBCP1xuXHRcdGlmIChjZWxscy5sZW5ndGggPCA2KSBjb250aW51ZVxuXG5cdFx0Ly8gRXZlbnQgbmFtZSArIFVSTDogPGEgaHJlZj1cImh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzLzM5NC9cIj5IYWdhPC9hPlxuXHRcdGNvbnN0IGV2ZW50TGlua01hdGNoID0gY2VsbHNbMF0ubWF0Y2goXG5cdFx0XHQvPGFcXHMraHJlZj1cIihbXlwiXSspXCJbXj5dKj4oW148XSspPFxcL2E+Lyxcblx0XHQpXG5cdFx0Y29uc3QgZXZlbnRVcmwgPSBldmVudExpbmtNYXRjaCA/IGV2ZW50TGlua01hdGNoWzFdLnRyaW0oKSA6ICcnXG5cdFx0Y29uc3QgZXZlbnROYW1lID0gZXZlbnRMaW5rTWF0Y2hcblx0XHRcdD8gZGVjb2RlRW50aXRpZXMoZXZlbnRMaW5rTWF0Y2hbMl0pLnRyaW0oKVxuXHRcdFx0OiBkZWNvZGVFbnRpdGllcyhzdHJpcFRhZ3MoY2VsbHNbMF0pKVxuXG5cdFx0Ly8gT25seSB0aGUgYWxsLXJlc3VsdHMgdGFibGUgbGlua3MgZWFjaCByb3cgdG8gYW4gZXZlbnQncyByZXN1bHRzIHBhZ2Ug4oCUXG5cdFx0Ly8gdGhpcyBpcyB3aGF0IHJ1bGVzIG91dCB0aGUgc3RhdGlzdGljcyB0YWJsZXMgc2hhcmluZyBpZD1cInJlc3VsdHNcIi5cblx0XHRpZiAoIS9cXC9yZXN1bHRzXFwvLy50ZXN0KGV2ZW50VXJsKSkgY29udGludWVcblxuXHRcdC8vIERlcml2ZSBldmVudElkIGZyb20gVVJMIChlLmcuIFwiaGFnYVwiIGZyb20gXCIuLi4vaGFnYS9yZXN1bHRzLzM5NC9cIilcblx0XHRjb25zdCBldmVudElkTWF0Y2ggPSBldmVudFVybC5tYXRjaCgvXFwvKFteL10rKVxcL3Jlc3VsdHNcXC8vKVxuXHRcdGNvbnN0IGV2ZW50ID0gZXZlbnRJZE1hdGNoXG5cdFx0XHQ/IGV2ZW50SWRNYXRjaFsxXVxuXHRcdFx0OiBldmVudE5hbWUudG9Mb3dlckNhc2UoKS5yZXBsYWNlKC9bXmEtejAtOV0vZywgJycpXG5cblx0XHQvLyBSdW4gRGF0ZTogPGEgaHJlZj1cIi4uLlwiPjxzcGFuIGNsYXNzPVwiZm9ybWF0LWRhdGVcIj4wNy8wMy8yMDI2PC9zcGFuPjwvYT5cblx0XHQvLyBTYXZlZCBwYWdlcyBtYXkgY2FycnkgYW4gYWxyZWFkeS1JU08gZGF0ZSBpbnN0ZWFkLCBkZXBlbmRpbmcgb24gd2hpY2hcblx0XHQvLyBsb2NhbGUgcmVmb3JtYXR0ZWQgdGhlIGNlbGwuXG5cdFx0Y29uc3QgZGF0ZSA9IHBhcnNlUmVzdWx0RGF0ZShjZWxsc1sxXSlcblxuXHRcdC8vIFJ1biBOdW1iZXI6IDxhIGhyZWY9XCIuLi5cIj4zOTQ8L2E+XG5cdFx0Y29uc3QgZXZlbnROdW1iZXIgPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzJdKSwgMTApIHx8IDBcblxuXHRcdC8vIFBvc2l0aW9uXG5cdFx0Y29uc3QgcG9zaXRpb24gPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzNdKSwgMTApIHx8IDBcblxuXHRcdC8vIFRpbWUgKGUuZy4gXCIxOTozOVwiIG9yIFwiMDE6MDg6MzBcIilcblx0XHRjb25zdCB0aW1lID0gc3RyaXBUYWdzKGNlbGxzWzRdKVxuXG5cdFx0Ly8gQWdlIEdyYWRlIChlLmcuIFwiNjcuMDklXCIpXG5cdFx0Y29uc3QgYWdlR3JhZGUgPSBzdHJpcFRhZ3MoY2VsbHNbNV0pXG5cblx0XHRpZiAoZXZlbnROYW1lICYmIHRpbWUpIHtcblx0XHRcdHJlc3VsdHMucHVzaCh7XG5cdFx0XHRcdGV2ZW50LFxuXHRcdFx0XHRldmVudE5hbWUsXG5cdFx0XHRcdGV2ZW50VXJsLFxuXHRcdFx0XHRldmVudE51bWJlcixcblx0XHRcdFx0cG9zaXRpb24sXG5cdFx0XHRcdHRpbWUsXG5cdFx0XHRcdGFnZUdyYWRlLFxuXHRcdFx0XHRkYXRlLFxuXHRcdFx0fSlcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gcmVzdWx0c1xufVxuXG4vKiogUmVhZCBhIHJ1biBkYXRlIGNlbGwgYXMgWVlZWS1NTS1ERC4gQWNjZXB0cyBERC9NTS9ZWVlZIGFuZCBZWVlZLU1NLURELiAqL1xuZnVuY3Rpb24gcGFyc2VSZXN1bHREYXRlKGNlbGw6IHN0cmluZyk6IHN0cmluZyB7XG5cdGNvbnN0IGRteSA9IGNlbGwubWF0Y2goLz4oXFxkezJ9KVxcLyhcXGR7Mn0pXFwvKFxcZHs0fSk8Lylcblx0aWYgKGRteSkgcmV0dXJuIGAke2RteVszXX0tJHtkbXlbMl19LSR7ZG15WzFdfWBcblxuXHRjb25zdCBpc28gPSBjZWxsLm1hdGNoKC8+KFxcZHs0fS1cXGR7Mn0tXFxkezJ9KTwvKVxuXHRpZiAoaXNvKSByZXR1cm4gaXNvWzFdXG5cblx0cmV0dXJuIHN0cmlwVGFncyhjZWxsKVxufVxuXG4vLyAtLS0gUGFyc2UgdGhlIFwibGFyZ2VzdCBjbHVic1wiIGxlYWd1ZSB0YWJsZSAtLS1cbi8vIFBhcnNlcyBodHRwczovL3d3dy5wYXJrcnVuLnNlL3Jlc3VsdHMvbGFyZ2VzdGNsdWJzL1xuLy8gQ29sdW1uczogS2x1YmIgfCAoc3BhY2VyKSB8IEFudGFsIGRlbHRhZ2FyZSB8IEFudGFsIHN0YXJ0ZXIgfCBLbHViYmVucyBoZW1zaWRhXG5cbmV4cG9ydCBpbnRlcmZhY2UgTGFyZ2VzdENsdWJFbnRyeSB7XG5cdC8qKiBwYXJrcnVuJ3MgaW50ZXJuYWwgY2x1YiBpZCwgZnJvbSB0aGUgYCNmZWF0dXJlQ2x1Yj01MDMxMGAgYW5jaG9yLiAqL1xuXHRjbHViSWQ/OiBzdHJpbmdcblx0bmFtZTogc3RyaW5nXG5cdC8qKiBcIkFudGFsIGRlbHRhZ2FyZVwiIOKAlCBkaXN0aW5jdCBjbHViIG1lbWJlcnMgd2hvIGhhdmUgcnVuLiAqL1xuXHRtZW1iZXJzOiBudW1iZXJcblx0LyoqIFwiQW50YWwgc3RhcnRlclwiIOKAlCB0b3RhbCBydW5zIHN0YXJ0ZWQgYnkgY2x1YiBtZW1iZXJzLiAqL1xuXHRldmVudHM6IG51bWJlclxufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VMYXJnZXN0Q2x1YnMoaHRtbDogc3RyaW5nKTogTGFyZ2VzdENsdWJFbnRyeVtdIHtcblx0Y29uc3QgZW50cmllczogTGFyZ2VzdENsdWJFbnRyeVtdID0gW11cblxuXHRjb25zdCB0YWJsZU1hdGNoID0gaHRtbC5tYXRjaChcblx0XHQvPHRhYmxlW14+XSppZD1cInJlc3VsdHNcIltePl0qPltcXHNcXFNdKj88dGJvZHlbXj5dKj4oW1xcc1xcU10qPyk8XFwvdGJvZHk+L2ksXG5cdClcblx0aWYgKCF0YWJsZU1hdGNoKSByZXR1cm4gZW50cmllc1xuXG5cdGNvbnN0IHRib2R5ID0gdGFibGVNYXRjaFsxXVxuXG5cdGZvciAoY29uc3Qgcm93TWF0Y2ggb2YgdGJvZHkubWF0Y2hBbGwoLzx0cltePl0qPihbXFxzXFxTXSo/KTxcXC90cj4vZ2kpKSB7XG5cdFx0Y29uc3QgY2VsbHM6IHN0cmluZ1tdID0gW11cblx0XHRmb3IgKGNvbnN0IGNlbGxNYXRjaCBvZiByb3dNYXRjaFsxXS5tYXRjaEFsbChcblx0XHRcdC88dGRbXj5dKj4oW1xcc1xcU10qPyk8XFwvdGQ+L2dpLFxuXHRcdCkpIHtcblx0XHRcdGNlbGxzLnB1c2goY2VsbE1hdGNoWzFdKVxuXHRcdH1cblxuXHRcdGlmIChjZWxscy5sZW5ndGggPCA0KSBjb250aW51ZVxuXG5cdFx0Y29uc3QgbmFtZSA9IGRlY29kZUVudGl0aWVzKHN0cmlwVGFncyhjZWxsc1swXSkpXG5cdFx0aWYgKCFuYW1lKSBjb250aW51ZVxuXG5cdFx0Y29uc3QgY2x1YklkTWF0Y2ggPSBjZWxsc1swXS5tYXRjaCgvI2ZlYXR1cmVDbHViPShcXGQrKS8pXG5cdFx0Y29uc3QgbWVtYmVycyA9IE51bWJlci5wYXJzZUludChzdHJpcFRhZ3MoY2VsbHNbMl0pLCAxMClcblx0XHRjb25zdCBldmVudHMgPSBOdW1iZXIucGFyc2VJbnQoc3RyaXBUYWdzKGNlbGxzWzNdKSwgMTApXG5cblx0XHRpZiAoTnVtYmVyLmlzTmFOKG1lbWJlcnMpIHx8IE51bWJlci5pc05hTihldmVudHMpKSBjb250aW51ZVxuXG5cdFx0ZW50cmllcy5wdXNoKHtcblx0XHRcdGNsdWJJZDogY2x1YklkTWF0Y2ggPyBjbHViSWRNYXRjaFsxXSA6IHVuZGVmaW5lZCxcblx0XHRcdG5hbWUsXG5cdFx0XHRtZW1iZXJzLFxuXHRcdFx0ZXZlbnRzLFxuXHRcdH0pXG5cdH1cblxuXHRyZXR1cm4gZW50cmllc1xufVxuXG4vLyAtLS0gVHlwZXMgZm9yIGV2ZW50IHBhZ2UgcGFyc2luZyAtLS1cblxuZXhwb3J0IGludGVyZmFjZSBFdmVudEhpc3RvcnlFbnRyeSB7XG5cdGV2ZW50TnVtYmVyOiBudW1iZXJcblx0ZGF0ZTogc3RyaW5nIC8vIFlZWVktTU0tRERcbn1cblxuZXhwb3J0IGludGVyZmFjZSBWb2x1bnRlZXJFbnRyeSB7XG5cdHBhcmtydW5JZDogc3RyaW5nXG5cdHJvbGVzOiBzdHJpbmdbXVxufVxuXG4vLyAtLS0gUGFyc2UgZXZlbnQgaGlzdG9yeSBwYWdlIC0tLVxuLy8gUGFyc2VzIGh0dHBzOi8vd3d3LnBhcmtydW4uc2UvaGFnYS9yZXN1bHRzL2V2ZW50aGlzdG9yeS9cbi8vIEVhY2ggcm93OiA8dHIgY2xhc3M9XCJSZXN1bHRzLXRhYmxlLXJvd1wiIGRhdGEtcGFya3J1bj1cIjM5NlwiIGRhdGEtZGF0ZT1cIjIwMjYtMDMtMjFcIiAuLi4+XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUV2ZW50SGlzdG9yeShodG1sOiBzdHJpbmcpOiBFdmVudEhpc3RvcnlFbnRyeVtdIHtcblx0Y29uc3QgZW50cmllczogRXZlbnRIaXN0b3J5RW50cnlbXSA9IFtdXG5cblx0Y29uc3Qgcm93UmVnZXggPVxuXHRcdC88dHJcXHMrY2xhc3M9XCJSZXN1bHRzLXRhYmxlLXJvd1wiW14+XSpkYXRhLXBhcmtydW49XCIoXFxkKylcIltePl0qZGF0YS1kYXRlPVwiKFxcZHs0fS1cXGR7Mn0tXFxkezJ9KVwiW14+XSo+L2dpXG5cblx0Zm9yIChjb25zdCBtYXRjaCBvZiBodG1sLm1hdGNoQWxsKHJvd1JlZ2V4KSkge1xuXHRcdGVudHJpZXMucHVzaCh7XG5cdFx0XHRldmVudE51bWJlcjogTnVtYmVyLnBhcnNlSW50KG1hdGNoWzFdLCAxMCksXG5cdFx0XHRkYXRlOiBtYXRjaFsyXSxcblx0XHR9KVxuXHR9XG5cblx0Ly8gU29ydCBkZXNjZW5kaW5nIGJ5IGV2ZW50IG51bWJlciAobW9zdCByZWNlbnQgZmlyc3QpXG5cdGVudHJpZXMuc29ydCgoYSwgYikgPT4gYi5ldmVudE51bWJlciAtIGEuZXZlbnROdW1iZXIpXG5cdHJldHVybiBlbnRyaWVzXG59XG5cbi8vIC0tLSBQYXJzZSBldmVudCBkYXRlIGZyb20gYSBzaW5nbGUgZXZlbnQgcmVzdWx0cyBwYWdlIC0tLVxuLy8gV2l0aCBTd2VkaXNoIGxvY2FsZSAoc3YtU0UpIHRoZSBmb3JtYXQtZGF0ZSBzcGFuIGNvbnRhaW5zIFlZWVktTU0tREQuXG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUV2ZW50RGF0ZShodG1sOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRjb25zdCBtYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0LzxzcGFuXFxzK2NsYXNzPVwiZm9ybWF0LWRhdGVcIj4oXFxkezR9LVxcZHsyfS1cXGR7Mn0pPFxcL3NwYW4+Lyxcblx0KVxuXHRyZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6ICcnXG59XG5cbi8vIC0tLSBQYXJzZSB0aGUgaWRlbnRpdHkgb2YgYSBzaW5nbGUgZXZlbnQgcmVzdWx0cyBwYWdlIC0tLVxuLy8gVGhlIHNjcmFwaW5nIHNjcmlwdHMgYWxyZWFkeSBrbm93IHdoaWNoIGV2ZW50IHBhZ2UgdGhleSBhc2tlZCBmb3I7IHRoZSBtYW51YWxcbi8vIHVwbG9hZCBwYWdlIGhhcyB0byByZWFkIGl0IGJhY2sgb2ZmIHRoZSBmaWxlIGl0IHdhcyBoYW5kZWQuXG4vL1xuLy8gICA8aDE+SGFnYSBwYXJrcnVuPC9oMT5cbi8vICAgPGgzPjxzcGFuIGNsYXNzPVwiZm9ybWF0LWRhdGVcIj4yMDI2LTA4LTAxPC9zcGFuPiDigKYgPHNwYW4+IzQxNTwvc3Bhbj48L2gzPlxuXG5leHBvcnQgaW50ZXJmYWNlIEV2ZW50UGFnZU1ldGEge1xuXHQvKiogZXZlbnRJZCBmcm9tIHRoZSBpbi1wYWdlIGF0aGxldGUgbGlua3MsIGUuZy4gXCJoYWdhXCIuIEVtcHR5IGlmIG5vdCBmb3VuZC4gKi9cblx0ZXZlbnRJZDogc3RyaW5nXG5cdC8qKiBFdmVudCB0aXRsZSwgZS5nLiBcIkhhZ2EgcGFya3J1blwiLiBFbXB0eSBpZiBub3QgZm91bmQuICovXG5cdHRpdGxlOiBzdHJpbmdcblx0LyoqIEV2ZW50IG51bWJlciwgZS5nLiA0MTUuIFplcm8gaWYgbm90IGZvdW5kLiAqL1xuXHRldmVudE51bWJlcjogbnVtYmVyXG5cdC8qKiBZWVlZLU1NLURELCBvciBlbXB0eSBpZiBub3QgZm91bmQuICovXG5cdGRhdGU6IHN0cmluZ1xufVxuXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VFdmVudFBhZ2VNZXRhKGh0bWw6IHN0cmluZyk6IEV2ZW50UGFnZU1ldGEge1xuXHRjb25zdCB0aXRsZSA9IGRlY29kZUVudGl0aWVzKFxuXHRcdHN0cmlwVGFncyhodG1sLm1hdGNoKC88aDFbXj5dKj4oW1xcc1xcU10qPyk8XFwvaDE+Lyk/LlsxXSA/PyAnJyksXG5cdClcblxuXHQvLyBBdGhsZXRlIGxpbmtzIG9uIHRoZSBwYWdlIGFyZSBldmVudC1yZWxhdGl2ZTogL2hhZ2EvcGFya3J1bm5lci82MTQ4Nzk0XG5cdGNvbnN0IGV2ZW50SWQgPSBodG1sLm1hdGNoKC9ocmVmPVwiXFwvKFteL1wiXSspXFwvcGFya3J1bm5lclxcLy8pPy5bMV0gPz8gJydcblxuXHRjb25zdCBudW1iZXJNYXRjaCA9IGh0bWwubWF0Y2goLzxzcGFuPlxccyojKFxcZCspXFxzKjxcXC9zcGFuPi8pXG5cblx0cmV0dXJuIHtcblx0XHRldmVudElkLFxuXHRcdHRpdGxlLFxuXHRcdGV2ZW50TnVtYmVyOiBudW1iZXJNYXRjaCA/IE51bWJlci5wYXJzZUludChudW1iZXJNYXRjaFsxXSwgMTApIDogMCxcblx0XHRkYXRlOiBwYXJzZUV2ZW50RGF0ZShodG1sKSxcblx0fVxufVxuXG4vLyAtLS0gUGFyc2Ugdm9sdW50ZWVycyBmcm9tIGEgc2luZ2xlIGV2ZW50IHJlc3VsdHMgcGFnZSAtLS1cbi8vIEZpbmRzIHRyYWNrZWQgYXRobGV0ZXMgaW4gdGhlIFZvbHVudGVlcnMtdGFibGUgYW5kIGV4dHJhY3RzIHRoZWlyIHJvbGVzLlxuLy8gRWFjaCB2b2x1bnRlZXIgcm93OiA8dHIgY2xhc3M9XCJWb2x1bnRlZXJzLXRhYmxlLXJvd1wiIC4uLiBkYXRhLXJvbGU9XCJGdW5rdGlvbsOkcixSZXN1bHRhdHNhbnN2YXJpZyxcIiAuLi4+XG4vLyAgIHdpdGggPGEgaHJlZj1cIi9oYWdhL3BhcmtydW5uZXIve3BhcmtydW5JZH1cIiAuLi4+XG5cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZUV2ZW50Vm9sdW50ZWVycyhcblx0aHRtbDogc3RyaW5nLFxuXHR0cmFja2VkSWRzOiBTZXQ8c3RyaW5nPixcbik6IFZvbHVudGVlckVudHJ5W10ge1xuXHRjb25zdCB2b2x1bnRlZXJzOiBWb2x1bnRlZXJFbnRyeVtdID0gW11cblxuXHQvLyBGaW5kIHRoZSB2b2x1bnRlZXJzIHRhYmxlIHNlY3Rpb25cblx0Y29uc3QgdGFibGVNYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0L2NsYXNzPVwiVm9sdW50ZWVycy10YWJsZVteXCJdKmpzLVZvbHVudGVlcnNUYWJsZVteXCJdKlwiW1xcc1xcU10qPzx0Ym9keVtePl0qPihbXFxzXFxTXSo/KTxcXC90Ym9keT4vaSxcblx0KVxuXHRpZiAoIXRhYmxlTWF0Y2gpIHJldHVybiB2b2x1bnRlZXJzXG5cblx0Y29uc3QgdGJvZHkgPSB0YWJsZU1hdGNoWzFdXG5cblx0Ly8gTWF0Y2ggZWFjaCB2b2x1bnRlZXIgcm93XG5cdGNvbnN0IHJvd1JlZ2V4ID1cblx0XHQvPHRyXFxzK2NsYXNzPVwiVm9sdW50ZWVycy10YWJsZS1yb3dcIltePl0qZGF0YS1yb2xlPVwiKFteXCJdKilcIltePl0qPihbXFxzXFxTXSo/KTxcXC90cj4vZ2lcblxuXHRmb3IgKGNvbnN0IG1hdGNoIG9mIHRib2R5Lm1hdGNoQWxsKHJvd1JlZ2V4KSkge1xuXHRcdGNvbnN0IGRhdGFSb2xlID0gbWF0Y2hbMV1cblx0XHRjb25zdCByb3dIdG1sID0gbWF0Y2hbMl1cblxuXHRcdC8vIEV4dHJhY3QgcGFya3J1bklkIGZyb20gdGhlIGxpbmtcblx0XHRjb25zdCBpZE1hdGNoID0gcm93SHRtbC5tYXRjaCgvXFwvcGFya3J1bm5lclxcLyhcXGQrKS8pXG5cdFx0aWYgKCFpZE1hdGNoKSBjb250aW51ZVxuXG5cdFx0Y29uc3QgcGFya3J1bklkID0gaWRNYXRjaFsxXVxuXHRcdGlmICghdHJhY2tlZElkcy5oYXMocGFya3J1bklkKSkgY29udGludWVcblxuXHRcdC8vIFBhcnNlIHJvbGVzIGZyb20gZGF0YS1yb2xlIChjb21tYS1zZXBhcmF0ZWQsIHRyYWlsaW5nIGNvbW1hKVxuXHRcdGNvbnN0IHJvbGVzID0gZGF0YVJvbGVcblx0XHRcdC5zcGxpdCgnLCcpXG5cdFx0XHQubWFwKChyKSA9PiByLnRyaW0oKSlcblx0XHRcdC5maWx0ZXIoKHIpID0+IHIubGVuZ3RoID4gMClcblxuXHRcdHZvbHVudGVlcnMucHVzaCh7IHBhcmtydW5JZCwgcm9sZXMgfSlcblx0fVxuXG5cdHJldHVybiB2b2x1bnRlZXJzXG59XG4iLCIvKipcbiAqIFRoZSBwYXJrcnVuIHBhZ2VzIG91ciBkYXRhIGNvbWVzIGZyb20uXG4gKlxuICogU2hhcmVkIGJ5IHRoZSBhZG1pbiB1cGxvYWQgZm9ybSAod2hpY2ggbGlua3MgdG8gZWFjaCBwYWdlIHlvdSBuZWVkIHRvIGRvd25sb2FkKVxuICogYW5kIHRoZSByZXN1bHRzLXNjcmFwZXIgZXh0ZW5zaW9uICh3aGljaCBuYXZpZ2F0ZXMgdG8gdGhlbSksIHNvIHRoZSB0d28gYWx3YXlzXG4gKiBhZ3JlZSBvbiB3aGF0IHRvIGZldGNoLiBUaGUgUGxheXdyaWdodCBzY3JpcHRzIHByZWRhdGUgdGhpcyBtb2R1bGUgYW5kIHN0aWxsXG4gKiBidWlsZCBhdGhsZXRlIFVSTHMgdGhlbXNlbHZlcy5cbiAqL1xuaW1wb3J0IHsgRE9NQUlOX1RPX0NPVU5UUlkgfSBmcm9tICcuL3BhcmtydW4tcGFyc2VycydcblxuLyoqXG4gKiBXaGljaCBwYXJrcnVuIHNpdGUgdG8gcmVhZCBhdGhsZXRlIGhpc3RvcnkgZnJvbS5cbiAqXG4gKiBFdmVyeSBjb3VudHJ5J3Mgc2l0ZSBzZXJ2ZXMgdGhlIHNhbWUgYXRobGV0ZSBwYWdlcywgc28gdGhpcyBpcyBhIGZyZWUgY2hvaWNlLFxuICogYW5kIGl0J3MgdGhlIFN3ZWRpc2ggb25lIGJlY2F1c2UgdGhhdCdzIHdoZXJlIGV2ZXJ5dGhpbmcgZWxzZSB3ZSBmZXRjaCBsaXZlcyDigJRcbiAqIHRoZSBjbHViJ3MgZXZlbnRzIGFuZCB0aGUgbGVhZ3VlIHRhYmxlIGFyZSBib3RoIG9uIGBwYXJrcnVuLnNlYC4gS2VlcGluZyBhdGhsZXRlXG4gKiBwYWdlcyB0aGVyZSBtZWFucyBhIHdob2xlIHNjcmFwZSBzdGF5cyBvbiBvbmUgb3JpZ2luLCB3aGljaCBtYXR0ZXJzIGZvciBhbnlcbiAqIHNjcmFwZXIgd29ya2luZyBmcm9tIGluc2lkZSBhIHBhZ2UgcmF0aGVyIHRoYW4gdGhyb3VnaCBob3N0IHBlcm1pc3Npb25zOiB0aGVcbiAqIHNhbWUtb3JpZ2luIHBvbGljeSBtYWtlcyBvbmUgb3JpZ2luIHJlYWRhYmxlIGFuZCB0aGUgcmVzdCBub3QuXG4gKlxuICogU3dlZGlzaCBwYWdlcyBhcmUgYSBzdXBwb3J0ZWQgcGFyc2VyIHBhdGggcmF0aGVyIHRoYW4gYSBsdWNreSBvbmU6IHRoZSB0b3RhbC1ydW5zXG4gKiByZWdleCBtYXRjaGVzIFwidG90YWx0XCIgYXMgd2VsbCBhcyBcInRvdGFsXCIsIGFuZCBgZmluZFJlc3VsdFRib2RpZXNgIGhhbmRsZXMgdGhlXG4gKiBsb2NhbGlzZWQgXCJBbGxhIHJlc3VsdGF0XCIgY2FwdGlvbiBieSBmYWxsaW5nIGJhY2sgdG8gdGhlIGxhc3QgcmVzdWx0cyB0YWJsZS5cbiAqIFZlcmlmaWVkIGFnYWluc3QgYSByZWFsIGBwYXJrcnVuLnNlYCBhdGhsZXRlIHBhZ2Ug4oCUIDE1NSByZXN1bHRzIHBhcnNlZC5cbiAqXG4gKiBOb3RlIHRoaXMgY29uc3RhbnQgZG9lcyBub3QgcmVhY2ggdGhlIFBsYXl3cmlnaHQgc2NyaXB0cywgd2hpY2ggYnVpbGQgdGhlIHNhbWVcbiAqIFVSTCBhZ2FpbnN0IGBwYXJrcnVuLm9yZy51a2AgYnkgaGFuZCAoYGFwcHMvYXBpL3NjcmlwdHMvZmV0Y2gtcmVzdWx0cy50c2ApLlxuICovXG5leHBvcnQgY29uc3QgQVRITEVURV9TSVRFID0gJ2h0dHBzOi8vd3d3LnBhcmtydW4uc2UnXG5cbi8qKlxuICogQW4gYXRobGV0ZSdzIGZ1bGwgcnVuIGhpc3Rvcnkg4oCUIHJlcXVlc3RlZCBieSB0aGUgZXh0ZW5zaW9uIGFuZCBsaW5rZWQgdG8gYnkgdGhlXG4gKiBtYW51YWwgdXBsb2FkIGZvcm0uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBhdGhsZXRlUGFnZVVybChwYXJrcnVuSWQ6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiBgJHtBVEhMRVRFX1NJVEV9L3BhcmtydW5uZXIvJHtwYXJrcnVuSWR9L2FsbC9gXG59XG5cbi8qKlxuICogQW4gZXZlbnQncyBtb3N0IHJlY2VudCByZXN1bHRzLiBmZXRjaC1wYXJrcnVuLnRzIHdhbGtzIHRoZSBldmVudCBoaXN0b3J5IHRvXG4gKiBmaW5kIGV2ZXJ5IHVuc2NyYXBlZCBudW1iZXI7IGJ5IGhhbmQgeW91IHdhbnQgdGhlIGxhdGVzdCBvbmUsIHdoaWNoIHBhcmtydW5cbiAqIHNlcnZlcyBhdCBhIHN0YWJsZSBVUkwuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBsYXRlc3RSZXN1bHRzVXJsKGV2ZW50QmFzZVVybDogc3RyaW5nKTogc3RyaW5nIHtcblx0cmV0dXJuIGAke3RyaW1TbGFzaChldmVudEJhc2VVcmwpfS9yZXN1bHRzL2xhdGVzdHJlc3VsdHMvYFxufVxuXG4vKiogQSBudW1iZXJlZCBldmVudCByZXN1bHRzIHBhZ2UsIGUuZy4g4oCmL2hhZ2EvcmVzdWx0cy80MTUvICovXG5leHBvcnQgZnVuY3Rpb24gZXZlbnRSZXN1bHRzVXJsKFxuXHRldmVudEJhc2VVcmw6IHN0cmluZyxcblx0ZXZlbnROdW1iZXI6IG51bWJlcixcbik6IHN0cmluZyB7XG5cdHJldHVybiBgJHt0cmltU2xhc2goZXZlbnRCYXNlVXJsKX0vcmVzdWx0cy8ke2V2ZW50TnVtYmVyfS9gXG59XG5cbi8qKiBBbiBldmVudCdzIGNvdXJzZSBwYWdlLCB3aGljaCBlbWJlZHMgdGhlIEdvb2dsZSBtYXAgaG9sZGluZyB0aGUgS01aLiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGNvdXJzZVBhZ2VVcmwoZXZlbnRCYXNlVXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gYCR7dHJpbVNsYXNoKGV2ZW50QmFzZVVybCl9L2NvdXJzZS9gXG59XG5cbi8qKiBUaGUgR29vZ2xlIE15IE1hcHMgS01aIGV4cG9ydCBmb3IgYSBtYXAgaWQgZm91bmQgb24gYSBjb3Vyc2UgcGFnZS4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3Vyc2VLbXpVcmwobWlkOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gYGh0dHBzOi8vd3d3Lmdvb2dsZS5jb20vbWFwcy9kL2ttbD9taWQ9JHttaWR9YFxufVxuXG4vKiogVGhlIGVtYmVkIFVSTCwgdXNlZCB0byByZXNvbHZlIGxlZ2FjeSBtYXAgaWRzIHZpYSB0aGVpciByZWRpcmVjdC4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjb3Vyc2VNYXBFbWJlZFVybChtaWQ6IHN0cmluZyk6IHN0cmluZyB7XG5cdHJldHVybiBgaHR0cHM6Ly93d3cuZ29vZ2xlLmNvbS9tYXBzL2QvZW1iZWQ/bWlkPSR7bWlkfWBcbn1cblxuLyoqIFRoZSBsZWFndWUgdGFibGUgZmV0Y2gtbGFyZ2VzdC1jbHVicy50cyBzY3JhcGVzLiAqL1xuZXhwb3J0IGNvbnN0IExBUkdFU1RfQ0xVQlNfVVJMID0gJ2h0dHBzOi8vd3d3LnBhcmtydW4uc2UvcmVzdWx0cy9sYXJnZXN0Y2x1YnMvJ1xuXG5mdW5jdGlvbiB0cmltU2xhc2godXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuXHRyZXR1cm4gdXJsLnJlcGxhY2UoL1xcLyQvLCAnJylcbn1cblxuLy8gLS0tIEhvc3QgcGF0dGVybnMsIGZvciB0aGUgZXh0ZW5zaW9uJ3MgbWFuaWZlc3QgLS0tXG5cbi8qKlxuICogTWF0Y2ggcGF0dGVybnMgY292ZXJpbmcgZXZlcnkgcGFya3J1biBzaXRlIHdlIGtub3cgYWJvdXQsIHBsdXMgR29vZ2xlIE1hcHMuXG4gKiBNYXRjaCBwYXR0ZXJucyBjYW4ndCB3aWxkY2FyZCBhIFRMRCwgc28gdGhlc2UgaGF2ZSB0byBiZSBlbnVtZXJhdGVkIOKAlCBoZW5jZVxuICogZGVyaXZpbmcgdGhlbSBmcm9tIHRoZSBjb3VudHJ5IG1hcCB0aGUgcGFyc2VycyBhbHJlYWR5IG1haW50YWluLlxuICovXG5leHBvcnQgY29uc3QgUEFSS1JVTl9IT1NUX1BBVFRFUk5TID0gT2JqZWN0LmtleXMoRE9NQUlOX1RPX0NPVU5UUlkpLmZsYXRNYXAoXG5cdChkb21haW4pID0+IFtgKjovLyR7ZG9tYWlufS8qYCwgYCo6Ly8qLiR7ZG9tYWlufS8qYF0sXG4pXG5cbmV4cG9ydCBjb25zdCBHT09HTEVfTUFQU19IT1NUX1BBVFRFUk5TID0gWycqOi8vKi5nb29nbGUuY29tL21hcHMvKiddXG4iLCIvKipcbiAqIEtlZXBzIHRoZSBzZXJ2aWNlIHdvcmtlciBhbGl2ZSBmb3IgdGhlIGR1cmF0aW9uIG9mIGEgcnVuLlxuICpcbiAqIENhcHR1cmUgZGVwZW5kcyBvbiBgY2hyb21lLmRlYnVnZ2VyYCBOZXR3b3JrIGV2ZW50cywgYW5kIHRob3NlIGFyZSBvbmx5XG4gKiBkZWxpdmVyZWQgdG8gYSAqcnVubmluZyogd29ya2VyIOKAlCB1bmxpa2UgdGFicy9hbGFybXMvbWVzc2FnZXMsIGEgZGVidWdnZXIgZXZlbnRcbiAqIGRvZXMgbm90IHdha2UgYSB3b3JrZXIgQ2hyb21lIGhhcyByZXRpcmVkLiBNaXNzIHRoZSBgcmVzcG9uc2VSZWNlaXZlZGAgZm9yIGFcbiAqIHBhZ2UgYW5kIHRoZXJlIGlzIG5vIHJlcXVlc3QgSUQgbGVmdCB0byBmZXRjaCBpdHMgYm9keSB3aXRoLCBzbyB0aGUgcGFnZSBsb2Fkc1xuICogZmluZSBpbiB0aGUgdGFiIGFuZCB0aGUgZXh0ZW5zaW9uIGhhcyBub3RoaW5nLiBUaGF0IHdhcyB0aGUgXCJubyByZXNwb25zZSwgdGhlblxuICogcmVsb2FkcyBhZnRlciAzMHNcIiBzeW1wdG9tLlxuICpcbiAqIENhbGxpbmcgaW50byBhIGNocm9tZSBBUEkgcmVzZXRzIHRoZSBpZGxlIHRpbWVyLCBzbyBhIHNsb3cgc2VsZi1waW5nIGhvbGRzIHRoZVxuICogd29ya2VyIG9wZW4uIFRoaXMgY29zdHMgbm90aGluZyBhbmQgbmVlZHMgbm8gZXh0cmEgcGVybWlzc2lvbiDigJQgYnV0IGl0IG9ubHlcbiAqIHdvcmtzIHdoaWxlIHRoZSB3b3JrZXIgaXMgYWxpdmUsIHNvIGBiYWNrZ3JvdW5kLnRzYCBzdGlsbCByZWNvdmVycyBmcm9tIGEgY29sZFxuICogc3RhcnQgb24gaXRzIG93bi5cbiAqL1xuXG4vKiogQ29tZm9ydGFibHkgaW5zaWRlIENocm9tZSdzIDMwcyBpZGxlIHRpbWVvdXQuICovXG5jb25zdCBQSU5HX0lOVEVSVkFMX01TID0gMjBfMDAwXG5cbmxldCB0aW1lcjogUmV0dXJuVHlwZTx0eXBlb2Ygc2V0SW50ZXJ2YWw+IHwgbnVsbCA9IG51bGxcblxuZXhwb3J0IGZ1bmN0aW9uIHN0YXJ0S2VlcGFsaXZlKCk6IHZvaWQge1xuXHRpZiAodGltZXIpIHJldHVyblxuXHR0aW1lciA9IHNldEludGVydmFsKCgpID0+IHtcblx0XHQvLyBUaGUgY2FsbCBpdHNlbGYgaXMgdGhlIHBvaW50OyB0aGUgcmVzdWx0IGlzIGlycmVsZXZhbnQuXG5cdFx0dm9pZCBjaHJvbWUucnVudGltZS5nZXRQbGF0Zm9ybUluZm8oKS5jYXRjaCgoKSA9PiB1bmRlZmluZWQpXG5cdH0sIFBJTkdfSU5URVJWQUxfTVMpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBzdG9wS2VlcGFsaXZlKCk6IHZvaWQge1xuXHRpZiAoIXRpbWVyKSByZXR1cm5cblx0Y2xlYXJJbnRlcnZhbCh0aW1lcilcblx0dGltZXIgPSBudWxsXG59XG4iLCIvKipcbiAqIFJ1biBzdGF0ZSBhbmQgY2FwdHVyZWQgZmlsZXMsIHBlcnNpc3RlZCBpbiBjaHJvbWUuc3RvcmFnZS5sb2NhbC5cbiAqXG4gKiBFdmVyeXRoaW5nIGxpdmVzIGluIHN0b3JhZ2UgcmF0aGVyIHRoYW4gaW4gbW9kdWxlIHNjb3BlIGJlY2F1c2UgYW4gTVYzIHNlcnZpY2VcbiAqIHdvcmtlciBpcyB0ZXJtaW5hdGVkIHdoZW5ldmVyIGl0IGdvZXMgaWRsZSDigJQgd2hpY2ggaXQgd2lsbCwgcmVwZWF0ZWRseSwgYWNyb3NzXG4gKiBhIHJ1biB0aGF0IHdhaXRzIG9uIHBhZ2UgbG9hZHMgYW5kIGNhcHRjaGFzLiBFYWNoIHdha2UtdXAgcmVhZHMgc3RhdGUgYmFjayBhbmRcbiAqIGNhcnJpZXMgb24uXG4gKlxuICogYHVubGltaXRlZFN0b3JhZ2VgIGlzIGRlY2xhcmVkIGluIHRoZSBtYW5pZmVzdDogZmlmdGVlbiBhdGhsZXRlIHBhZ2VzIGlzIHdlbGxcbiAqIHBhc3QgY2hyb21lLnN0b3JhZ2UubG9jYWwncyB1c3VhbCAxMCBNQiBjYXAuXG4gKi9cbmltcG9ydCB0eXBlIHtcblx0Q2FwdHVyZWRGaWxlLFxuXHRJdGVtU3RhdGUsXG5cdEl0ZW1TdGF0dXMsXG5cdFJ1blN0YXRlLFxufSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5pbXBvcnQgeyBlbXB0eVJ1blN0YXRlIH0gZnJvbSAnQHNoYXJlZC9zY3JhcGVyLXByb3RvY29sJ1xuXG5jb25zdCBSVU5fS0VZID0gJ3J1bidcbmNvbnN0IEZJTEVTX0tFWSA9ICdmaWxlcydcbmNvbnN0IFNFU1NJT05fS0VZID0gJ3Nlc3Npb24nXG5cbi8qKiBCb29ra2VlcGluZyB0aGUgVUkgbmV2ZXIgc2Vlcy4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgUnVuU2Vzc2lvbiB7XG5cdGFkbWluVGFiSWQ/OiBudW1iZXJcblx0c2NyYXBlVGFiSWQ/OiBudW1iZXJcblx0LyoqIEV2ZW50IElEcyB0aGF0IGFscmVhZHkgaGFkIGNvdXJzZSBkYXRhIGJlZm9yZSB0aGUgcnVuIHN0YXJ0ZWQuICovXG5cdGtub3duQ291cnNlRXZlbnRJZHM6IHN0cmluZ1tdXG5cdC8qKiBFdmVudHMgZm91bmQgb24gYXRobGV0ZSBwYWdlczogZXZlbnRJZCDihpIgYmFzZSBVUkwgYW5kIGRpc3BsYXkgbmFtZS4gKi9cblx0ZGlzY292ZXJlZEV2ZW50czogUmVjb3JkPHN0cmluZywgeyBuYW1lOiBzdHJpbmc7IHVybDogc3RyaW5nIH0+XG5cdC8qKiBTZXQgb25jZSB0aGUgcXVldWUgaGFzIGJlZW4gZXh0ZW5kZWQgd2l0aCBjb3Vyc2UgcGFnZXMuICovXG5cdGNvdXJzZXNRdWV1ZWQ6IGJvb2xlYW5cblx0c2tpcENvdXJzZXM6IGJvb2xlYW5cblx0LyoqIENvbnNlY3V0aXZlIGNhcHR1cmUgYXR0ZW1wdHMgZm9yIHRoZSBjdXJyZW50IGl0ZW0sIHRvIHN0b3AgbG9vcHMuICovXG5cdGF0dGVtcHRzOiBudW1iZXJcbn1cblxuZnVuY3Rpb24gZW1wdHlTZXNzaW9uKCk6IFJ1blNlc3Npb24ge1xuXHRyZXR1cm4ge1xuXHRcdGtub3duQ291cnNlRXZlbnRJZHM6IFtdLFxuXHRcdGRpc2NvdmVyZWRFdmVudHM6IHt9LFxuXHRcdGNvdXJzZXNRdWV1ZWQ6IGZhbHNlLFxuXHRcdHNraXBDb3Vyc2VzOiBmYWxzZSxcblx0XHRhdHRlbXB0czogMCxcblx0fVxufVxuXG4vLyDilIDilIAgUnVuIHN0YXRlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0UnVuU3RhdGUoKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQ8eyBydW4/OiBSdW5TdGF0ZSB9PihSVU5fS0VZKVxuXHRyZXR1cm4gc3RvcmVkLnJ1biA/PyBlbXB0eVJ1blN0YXRlKClcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHNldFJ1blN0YXRlKHN0YXRlOiBSdW5TdGF0ZSk6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5zZXQoeyBbUlVOX0tFWV06IHN0YXRlIH0pXG59XG5cbi8qKiBBcHBseSBhIGNoYW5nZSB0byB0aGUgc3RvcmVkIHN0YXRlIGFuZCByZXR1cm4gd2hhdCB3YXMgd3JpdHRlbi4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB1cGRhdGVSdW5TdGF0ZShcblx0Y2hhbmdlOiAoc3RhdGU6IFJ1blN0YXRlKSA9PiBSdW5TdGF0ZSxcbik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3QgbmV4dCA9IGNoYW5nZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRhd2FpdCBzZXRSdW5TdGF0ZShuZXh0KVxuXHRyZXR1cm4gbmV4dFxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0SXRlbVN0YXR1cyhcblx0a2V5OiBzdHJpbmcsXG5cdHN0YXR1czogSXRlbVN0YXR1cyxcblx0ZGV0YWlsPzogc3RyaW5nLFxuXHRhdHRlbXB0cz86IG51bWJlcixcbik6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0cmV0dXJuIHVwZGF0ZVJ1blN0YXRlKChzdGF0ZSkgPT4gKHtcblx0XHQuLi5zdGF0ZSxcblx0XHRpdGVtczogc3RhdGUuaXRlbXMubWFwKChpdGVtKSA9PlxuXHRcdFx0aXRlbS5rZXkgPT09IGtleVxuXHRcdFx0XHQ/IHtcblx0XHRcdFx0XHRcdC4uLml0ZW0sXG5cdFx0XHRcdFx0XHRzdGF0dXMsXG5cdFx0XHRcdFx0XHRkZXRhaWwsXG5cdFx0XHRcdFx0XHRhdHRlbXB0czogYXR0ZW1wdHMgPz8gaXRlbS5hdHRlbXB0cyxcblx0XHRcdFx0XHRcdHVwZGF0ZWRBdDogRGF0ZS5ub3coKSxcblx0XHRcdFx0XHR9XG5cdFx0XHRcdDogaXRlbSxcblx0XHQpLFxuXHR9KSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFwcGVuZEl0ZW1zKGl0ZW1zOiBJdGVtU3RhdGVbXSk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0cmV0dXJuIHVwZGF0ZVJ1blN0YXRlKChzdGF0ZSkgPT4gKHtcblx0XHQuLi5zdGF0ZSxcblx0XHRpdGVtczogWy4uLnN0YXRlLml0ZW1zLCAuLi5pdGVtc10sXG5cdH0pKVxufVxuXG4vLyDilIDilIAgU2Vzc2lvbiDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGdldFNlc3Npb24oKTogUHJvbWlzZTxSdW5TZXNzaW9uPiB7XG5cdGNvbnN0IHN0b3JlZCA9IGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLmdldDx7IHNlc3Npb24/OiBSdW5TZXNzaW9uIH0+KFxuXHRcdFNFU1NJT05fS0VZLFxuXHQpXG5cdHJldHVybiBzdG9yZWQuc2Vzc2lvbiA/PyBlbXB0eVNlc3Npb24oKVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0U2Vzc2lvbihzZXNzaW9uOiBSdW5TZXNzaW9uKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtTRVNTSU9OX0tFWV06IHNlc3Npb24gfSlcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHVwZGF0ZVNlc3Npb24oXG5cdGNoYW5nZTogKHNlc3Npb246IFJ1blNlc3Npb24pID0+IFJ1blNlc3Npb24sXG4pOiBQcm9taXNlPFJ1blNlc3Npb24+IHtcblx0Y29uc3QgbmV4dCA9IGNoYW5nZShhd2FpdCBnZXRTZXNzaW9uKCkpXG5cdGF3YWl0IHNldFNlc3Npb24obmV4dClcblx0cmV0dXJuIG5leHRcbn1cblxuLy8g4pSA4pSAIENhcHR1cmVkIGZpbGVzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0RmlsZXMoKTogUHJvbWlzZTxDYXB0dXJlZEZpbGVbXT4ge1xuXHRjb25zdCBzdG9yZWQgPSBhd2FpdCBjaHJvbWUuc3RvcmFnZS5sb2NhbC5nZXQ8eyBmaWxlcz86IENhcHR1cmVkRmlsZVtdIH0+KFxuXHRcdEZJTEVTX0tFWSxcblx0KVxuXHRyZXR1cm4gc3RvcmVkLmZpbGVzID8/IFtdXG59XG5cbi8qKiBTdG9yZSBhIGNhcHR1cmVkIGZpbGUsIHJlcGxhY2luZyBhbnkgZWFybGllciBjYXB0dXJlIGZvciB0aGUgc2FtZSBzbG90LiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHB1dEZpbGUoZmlsZTogQ2FwdHVyZWRGaWxlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IGZpbGVzID0gYXdhaXQgZ2V0RmlsZXMoKVxuXHRjb25zdCBleGlzdGluZyA9IGZpbGVzLmZpbmRJbmRleChcblx0XHQoZikgPT4gZi5raW5kID09PSBmaWxlLmtpbmQgJiYgZi5rZXkgPT09IGZpbGUua2V5LFxuXHQpXG5cdGlmIChleGlzdGluZyA9PT0gLTEpIGZpbGVzLnB1c2goZmlsZSlcblx0ZWxzZSBmaWxlc1tleGlzdGluZ10gPSBmaWxlXG5cdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnNldCh7IFtGSUxFU19LRVldOiBmaWxlcyB9KVxufVxuXG4vLyDilIDilIAgTGlmZWN5Y2xlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVzZXRBbGwoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5zdG9yYWdlLmxvY2FsLnJlbW92ZShbUlVOX0tFWSwgRklMRVNfS0VZLCBTRVNTSU9OX0tFWV0pXG59XG4iLCIvKipcbiAqIFB1c2hpbmcgdXBkYXRlcyBvdXQgb2YgdGhlIHNlcnZpY2Ugd29ya2VyLlxuICpcbiAqIFByb2dyZXNzIGdvZXMgdG8gdHdvIHBsYWNlczogdGhlIGFkbWluIHRhYiAod2hpY2ggZHJhd3MgdGhlIHBhbmVsIHRoYXRcbiAqIHJlcGxhY2VkIHRoZSBmb3JtKSBhbmQgd2hhdGV2ZXIgcGFnZSBpcyBjdXJyZW50bHkgaW4gdGhlIHNjcmFwZSB0YWIgKHdoaWNoXG4gKiBzaG93cyB0aGUgZmxvYXRpbmcgb3ZlcmxheSkuIEJvdGggYXJlIGJlc3QtZWZmb3J0IOKAlCBhIHRhYiB3aXRoIG5vIGNvbnRlbnRcbiAqIHNjcmlwdCBsb2FkZWQgeWV0IGp1c3QgaXNuJ3QgbGlzdGVuaW5nLCBhbmQgdGhhdCdzIGZpbmUsIGJlY2F1c2UgYm90aCBhbHNvXG4gKiByZWFkIHRoZSBjdXJyZW50IHN0YXRlIGZyb20gc3RvcmFnZSB3aGVuIHRoZXkgc3RhcnQgdXAuXG4gKi9cbmltcG9ydCB0eXBlIHsgQ2FwdHVyZWRGaWxlLCBSdW5TdGF0ZSB9IGZyb20gJ0BzaGFyZWQvc2NyYXBlci1wcm90b2NvbCdcbmltcG9ydCB7IGdldFNlc3Npb24gfSBmcm9tICcuL3N0YXRlJ1xuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbm90aWZ5U3RhdGUoc3RhdGU6IFJ1blN0YXRlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0Y29uc3QgbWVzc2FnZSA9IHsgdHlwZTogJ3N0YXRlJyBhcyBjb25zdCwgc3RhdGUgfVxuXG5cdGZvciAoY29uc3QgdGFiSWQgb2YgW3Nlc3Npb24uYWRtaW5UYWJJZCwgc2Vzc2lvbi5zY3JhcGVUYWJJZF0pIHtcblx0XHRpZiAodGFiSWQgPT09IHVuZGVmaW5lZCkgY29udGludWVcblx0XHRhd2FpdCBjaHJvbWUudGFicy5zZW5kTWVzc2FnZSh0YWJJZCwgbWVzc2FnZSkuY2F0Y2goKCkgPT4ge30pXG5cdH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIG5vdGlmeUZpbGUoZmlsZTogQ2FwdHVyZWRGaWxlKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHsgYWRtaW5UYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVyblxuXHRhd2FpdCBjaHJvbWUudGFic1xuXHRcdC5zZW5kTWVzc2FnZShhZG1pblRhYklkLCB7IHR5cGU6ICdmaWxlJyBhcyBjb25zdCwgZmlsZSB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcbn1cbiIsIi8qKlxuICogRGVjaWRlcyB3aGF0IHdlIGFjdHVhbGx5IGdvdCBiYWNrLlxuICpcbiAqIFJhdGhlciB0aGFuIHBhdHRlcm4tbWF0Y2hpbmcgYm90LWNoZWNrIHBhZ2VzICh3aGljaCBjaGFuZ2UpLCB0aGUgdGVzdCBpc1xuICogd2hldGhlciB0aGUgcmVwbydzIG93biBwYXJzZXJzIGNhbiByZWFkIHRoZSBwYWdlLiBJZiB0aGV5IGNhbiwgaXQncyB0aGUgcmVhbFxuICogdGhpbmc7IGlmIHRoZXkgY2FuJ3QgYW5kIHRoZSBzdGF0dXMgbG9va3MgbGlrZSBhIGJsb2NrLCB0aGUgdXNlciBuZWVkcyB0b1xuICogc29sdmUgc29tZXRoaW5nLiBUaGF0IHdheSBhIHJlZGVzaWduZWQgY2hhbGxlbmdlIHBhZ2Ugc3RpbGwgbGFuZHMgaW4gdGhlIHJpZ2h0XG4gKiBzdGF0ZSwgYW5kIGEgcmVkZXNpZ25lZCAqcGFya3J1biogcGFnZSBmYWlscyBsb3VkbHkgaW5zdGVhZCBvZiBzaWxlbnRseVxuICogaW5nZXN0aW5nIG5vdGhpbmcuXG4gKi9cbmltcG9ydCB7XG5cdHBhcnNlRXZlbnRQYWdlTWV0YSxcblx0cGFyc2VMYXJnZXN0Q2x1YnMsXG5cdHBhcnNlUnVuUmVzdWx0cyxcblx0cGFyc2VSdW5uZXJEYXRhLFxufSBmcm9tICdAc2hhcmVkL3BhcmtydW4tcGFyc2VycydcbmltcG9ydCB0eXBlIHsgQ2FwdHVyZUtpbmQgfSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5cbmV4cG9ydCB0eXBlIFZlcmRpY3QgPVxuXHQvKiogVGhlIHBhZ2UgcGFyc2VkIOKAlCBjYXB0dXJlIGl0LiAqL1xuXHR8IHsgb3V0Y29tZTogJ29rJzsgZGV0YWlsOiBzdHJpbmcgfVxuXHQvKipcblx0ICogQSBib3QgY2hlY2sgb3IgYSB3b2JibGUuIFJldHJ5YWJsZSwgYW5kIHJldHJpZWQgYXV0b21hdGljYWxseS5cblx0ICpcblx0ICogYGF3YWl0VXNlcmAgbWFya3MgdGhlIG9uZXMgd2l0aCBzb21ldGhpbmcgb24gc2NyZWVuIGZvciBhIGh1bWFuIHRvIHNvbHZlIOKAlFxuXHQgKiB0aG9zZSBtdXN0IG5ldmVyIGJlIHJlbG9hZGVkIGZyb20gdW5kZXIgdGhlbSwgYW5kIG11c3QgbmV2ZXIgdGltZSBvdXQuXG5cdCAqL1xuXHR8IHsgb3V0Y29tZTogJ2Jsb2NrZWQnOyBkZXRhaWw6IHN0cmluZzsgYXdhaXRVc2VyPzogYm9vbGVhbiB9XG5cdC8qKiBMb2FkZWQgZmluZSBidXQgaXNuJ3Qgd2hhdCB3ZSBhc2tlZCBmb3IsIG9yIHBhcmtydW4gY2hhbmdlZCBzaGFwZS4gKi9cblx0fCB7IG91dGNvbWU6ICd1bnVzYWJsZSc7IGRldGFpbDogc3RyaW5nIH1cblxuLyoqXG4gKiBGaW5nZXJwcmludHMgb2YgYW4gaW50ZXJhY3RpdmUgY2hhbGxlbmdlIOKAlCBzb21ldGhpbmcgYSBwZXJzb24gaGFzIHRvIGNsaWNrXG4gKiB0aHJvdWdoLCBhcyBvcHBvc2VkIHRvIGEgdHJhbnNpZW50IGVycm9yLlxuICpcbiAqIHBhcmtydW4ncyBpbWFnZSBjYXB0Y2hhIChcIkxldCdzIGNvbmZpcm0geW91IGFyZSBodW1hbiDigJQgY2hvb3NlIGFsbCB0aGVcbiAqIGNsb2Nrc1wiKSBhcnJpdmVzIGFzIEhUVFAgNDA1LCBzbyB0aGUgc3RhdHVzIGFsb25lIHRlbGxzIHlvdSBub3RoaW5nIHVzZWZ1bC5cbiAqL1xuY29uc3QgQ0hBTExFTkdFX01BUktFUlMgPSBbXG5cdCcvY2RuLWNnaS9jaGFsbGVuZ2UtcGxhdGZvcm0nLFxuXHQnY29uZmlybSB5b3UgYXJlIGh1bWFuJyxcblx0J3ZlcmlmeSB5b3UgYXJlIGh1bWFuJyxcblx0J2FyZSB5b3UgYSByb2JvdCcsXG5cdCdjYXB0Y2hhJyxcblx0J3R1cm5zdGlsZScsXG5cdCdjZl9jaGwnLFxuXHQnY2YtY2hhbGxlbmdlJyxcblx0J2NoZWNraW5nIHlvdXIgYnJvd3NlcicsXG5cdCdqdXN0IGEgbW9tZW50Jyxcbl1cblxuZnVuY3Rpb24gbG9va3NMaWtlQ2hhbGxlbmdlKGh0bWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuXHRjb25zdCBoYXlzdGFjayA9IGh0bWwuc2xpY2UoMCwgMjAwXzAwMCkudG9Mb3dlckNhc2UoKVxuXHRyZXR1cm4gQ0hBTExFTkdFX01BUktFUlMuc29tZSgobWFya2VyKSA9PiBoYXlzdGFjay5pbmNsdWRlcyhtYXJrZXIpKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gdmFsaWRhdGUoXG5cdGtpbmQ6IENhcHR1cmVLaW5kLFxuXHRrZXk6IHN0cmluZyxcblx0c3RhdHVzOiBudW1iZXIsXG5cdGh0bWw6IHN0cmluZyxcbik6IFZlcmRpY3Qge1xuXHQvLyBBbnkgZXJyb3Igc3RhdHVzIGlzIHRyZWF0ZWQgYXMgcmV0cnlhYmxlIHJhdGhlciB0aGFuIGZhdGFsLiBCb3QgY2hlY2tzIGNvbWVcblx0Ly8gYmFjayB3aXRoIGFsbCBzb3J0cyDigJQgNDAzLCA0MDUsIDQyOSwgNTAzIOKAlCBhbmQgZmFpbGluZyBhbiBpdGVtIG91dHJpZ2h0IG9uXG5cdC8vIG9uZSB0aHJvd3MgYXdheSBhIHBhZ2UgdGhlIHVzZXIgY291bGQgaGF2ZSB1bmxvY2tlZCBpbiB0d28gY2xpY2tzLiBUaGVcblx0Ly8gYXR0ZW1wdCBsaW1pdCBzdG9wcyB0aGlzIGxvb3BpbmcgZm9yZXZlciwgYW5kIFNraXAgaXMgYWx3YXlzIGF2YWlsYWJsZS5cblx0aWYgKHN0YXR1cyA+PSA0MDApIHtcblx0XHRjb25zdCBjaGFsbGVuZ2UgPSBsb29rc0xpa2VDaGFsbGVuZ2UoaHRtbClcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0YXdhaXRVc2VyOiBjaGFsbGVuZ2UsXG5cdFx0XHRkZXRhaWw6IGNoYWxsZW5nZVxuXHRcdFx0XHQ/IGBwYXJrcnVuIHJlcGxpZWQgJHtzdGF0dXN9IGFuZCBpcyBhc2tpbmcgeW91IHRvIHByb3ZlIHlvdSdyZSBodW1hbiDigJQgc29sdmUgaXQgaW4gdGhlIHNjcmFwZSB0YWIgYW5kIHRoZSBydW4gY2FycmllcyBvbi5gXG5cdFx0XHRcdDogYHBhcmtydW4gcmVwbGllZCAke3N0YXR1c30g4oCUIHJldHJ5aW5nLmAsXG5cdFx0fVxuXHR9XG5cblx0Ly8gQSAyMDAgY2FuIHN0aWxsIGJlIGEgY2hhbGxlbmdlIHBhZ2UuXG5cdGlmIChsb29rc0xpa2VDaGFsbGVuZ2UoaHRtbCkgJiYgIXBhcnNlc0FzUmVhbFBhZ2Uoa2luZCwga2V5LCBodG1sKSkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAnYmxvY2tlZCcsXG5cdFx0XHRhd2FpdFVzZXI6IHRydWUsXG5cdFx0XHRkZXRhaWw6XG5cdFx0XHRcdFwicGFya3J1biBpcyBhc2tpbmcgeW91IHRvIHByb3ZlIHlvdSdyZSBodW1hbiDigJQgc29sdmUgaXQgaW4gdGhlIHNjcmFwZSB0YWIgYW5kIHRoZSBydW4gY2FycmllcyBvbi5cIixcblx0XHR9XG5cdH1cblxuXHRzd2l0Y2ggKGtpbmQpIHtcblx0XHRjYXNlICdhdGhsZXRlJzpcblx0XHRcdHJldHVybiB2YWxpZGF0ZUF0aGxldGUoa2V5LCBodG1sKVxuXHRcdGNhc2UgJ2V2ZW50Jzpcblx0XHRcdHJldHVybiB2YWxpZGF0ZUV2ZW50KGtleSwgaHRtbClcblx0XHRjYXNlICdjbHVicyc6XG5cdFx0XHRyZXR1cm4gdmFsaWRhdGVDbHVicyhodG1sKVxuXHRcdGNhc2UgJ2NvdXJzZSc6XG5cdFx0XHRyZXR1cm4gdmFsaWRhdGVDb3Vyc2UoaHRtbClcblx0fVxufVxuXG4vKipcbiAqIFdoZXRoZXIgdGhlIHBhZ2UgaXMgZ2VudWluZWx5IHRoZSBvbmUgd2UgYXNrZWQgZm9yLiBVc2VkIHRvIHN0b3AgYSBjaGFsbGVuZ2VcbiAqIG1hcmtlciBpbiwgc2F5LCBhbiBhbmFseXRpY3Mgc25pcHBldCBmcm9tIHJlamVjdGluZyBhIHBlcmZlY3RseSBnb29kIHBhZ2UuXG4gKi9cbmZ1bmN0aW9uIHBhcnNlc0FzUmVhbFBhZ2UoXG5cdGtpbmQ6IENhcHR1cmVLaW5kLFxuXHRrZXk6IHN0cmluZyxcblx0aHRtbDogc3RyaW5nLFxuKTogYm9vbGVhbiB7XG5cdHN3aXRjaCAoa2luZCkge1xuXHRcdGNhc2UgJ2F0aGxldGUnOlxuXHRcdFx0cmV0dXJuIHBhcnNlUnVuUmVzdWx0cyhodG1sKS5sZW5ndGggPiAwXG5cdFx0Y2FzZSAnZXZlbnQnOlxuXHRcdFx0cmV0dXJuIHBhcnNlRXZlbnRQYWdlTWV0YShodG1sKS5ldmVudE51bWJlciA+IDBcblx0XHRjYXNlICdjbHVicyc6XG5cdFx0XHRyZXR1cm4gcGFyc2VMYXJnZXN0Q2x1YnMoaHRtbCkubGVuZ3RoID4gMFxuXHRcdGNhc2UgJ2NvdXJzZSc6XG5cdFx0XHRyZXR1cm4gZXh0cmFjdE1hcE1pZChodG1sKSAhPT0gbnVsbFxuXHR9XG59XG5cbmZ1bmN0aW9uIHZhbGlkYXRlQXRobGV0ZShwYXJrcnVuSWQ6IHN0cmluZywgaHRtbDogc3RyaW5nKTogVmVyZGljdCB7XG5cdGNvbnN0IHJ1bm5lciA9IHBhcnNlUnVubmVyRGF0YShodG1sKVxuXHRjb25zdCByZXN1bHRzID0gcGFyc2VSdW5SZXN1bHRzKGh0bWwpXG5cblx0aWYgKHJ1bm5lci5uYW1lID09PSAnVW5rbm93bicgJiYgcmVzdWx0cy5sZW5ndGggPT09IDApIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0ZGV0YWlsOiBcIkNvdWxkbid0IHJlYWQgdGhlIHBhZ2Ug4oCUIGl0IG1heSBiZSBhIGJvdCBjaGVjay4gUmV0cnlpbmcuXCIsXG5cdFx0fVxuXHR9XG5cdGlmIChydW5uZXIucGFya3J1bklkICYmIHJ1bm5lci5wYXJrcnVuSWQgIT09IHBhcmtydW5JZCkge1xuXHRcdHJldHVybiB7XG5cdFx0XHRvdXRjb21lOiAndW51c2FibGUnLFxuXHRcdFx0ZGV0YWlsOiBgUGFnZSBpcyBmb3IgYXRobGV0ZSAke3J1bm5lci5wYXJrcnVuSWR9LCBleHBlY3RlZCAke3BhcmtydW5JZH0uYCxcblx0XHR9XG5cdH1cblx0aWYgKHJlc3VsdHMubGVuZ3RoID09PSAwKSB7XG5cdFx0cmV0dXJuIHsgb3V0Y29tZTogJ3VudXNhYmxlJywgZGV0YWlsOiAnTm8gcnVuIHJlc3VsdHMgZm91bmQgb24gdGhlIHBhZ2UuJyB9XG5cdH1cblxuXHRyZXR1cm4ge1xuXHRcdG91dGNvbWU6ICdvaycsXG5cdFx0ZGV0YWlsOiBgJHtydW5uZXIubmFtZX0gwrcgJHtyZXN1bHRzLmxlbmd0aH0gcmVzdWx0c2AsXG5cdH1cbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVFdmVudChldmVudElkOiBzdHJpbmcsIGh0bWw6IHN0cmluZyk6IFZlcmRpY3Qge1xuXHRjb25zdCBtZXRhID0gcGFyc2VFdmVudFBhZ2VNZXRhKGh0bWwpXG5cblx0aWYgKCFtZXRhLmV2ZW50TnVtYmVyIHx8ICFtZXRhLmRhdGUpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0ZGV0YWlsOiBcIkNvdWxkbid0IHJlYWQgdGhlIGV2ZW50IG51bWJlciBvciBkYXRlIOKAlCBpdCBtYXkgYmUgYSBib3QgY2hlY2suXCIsXG5cdFx0fVxuXHR9XG5cdGlmIChtZXRhLmV2ZW50SWQgJiYgbWV0YS5ldmVudElkICE9PSBldmVudElkKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG91dGNvbWU6ICd1bnVzYWJsZScsXG5cdFx0XHRkZXRhaWw6IGBQYWdlIGlzIGZvciBcIiR7bWV0YS5ldmVudElkfVwiLCBleHBlY3RlZCBcIiR7ZXZlbnRJZH1cIi5gLFxuXHRcdH1cblx0fVxuXG5cdC8vIFZvbHVudGVlciBjb3VudHMgYXJlbid0IGNoZWNrZWQ6IGFuIGV2ZW50IHdoZXJlIG5vYm9keSB3ZSB0cmFjayB2b2x1bnRlZXJlZFxuXHQvLyBpcyBhIHBlcmZlY3RseSBnb29kIGNhcHR1cmUuIFRoZSBwYWdlIGRlY2lkZXMgd2hhdCdzIGluIGl0LlxuXHRyZXR1cm4geyBvdXRjb21lOiAnb2snLCBkZXRhaWw6IGAjJHttZXRhLmV2ZW50TnVtYmVyfSDCtyAke21ldGEuZGF0ZX1gIH1cbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVDbHVicyhodG1sOiBzdHJpbmcpOiBWZXJkaWN0IHtcblx0Y29uc3QgY2x1YnMgPSBwYXJzZUxhcmdlc3RDbHVicyhodG1sKVxuXHRpZiAoY2x1YnMubGVuZ3RoID09PSAwKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdG91dGNvbWU6ICdibG9ja2VkJyxcblx0XHRcdGRldGFpbDogXCJDb3VsZG4ndCByZWFkIHRoZSBsZWFndWUgdGFibGUg4oCUIGl0IG1heSBiZSBhIGJvdCBjaGVjay5cIixcblx0XHR9XG5cdH1cblx0cmV0dXJuIHsgb3V0Y29tZTogJ29rJywgZGV0YWlsOiBgJHtjbHVicy5sZW5ndGh9IGNsdWJzYCB9XG59XG5cbi8qKlxuICogQ291cnNlIHBhZ2VzIGFyZSB2YWxpZGF0ZWQgYnkgZmluZGluZyB0aGUgR29vZ2xlIG1hcCwgc2luY2UgdGhhdCdzIHRoZSBvbmx5XG4gKiBwYXJ0IHdlIHVzZS4gU2FtZSByZWdleCBhcyBhcHBzL2FwaS9saWIvbWFwLXNjcmFwZXIudHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBleHRyYWN0TWFwTWlkKGh0bWw6IHN0cmluZyk6IHN0cmluZyB8IG51bGwge1xuXHRjb25zdCBtYXRjaCA9IGh0bWwubWF0Y2goXG5cdFx0L3NyYz1cImh0dHBzOlxcL1xcL3d3d1xcLmdvb2dsZVxcLmNvbVxcL21hcHNcXC9kXFwvW15cIl0qP1s/Jl1taWQ9KFteJlwiXSspLyxcblx0KVxuXHRyZXR1cm4gbWF0Y2ggPyBtYXRjaFsxXSA6IG51bGxcbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVDb3Vyc2UoaHRtbDogc3RyaW5nKTogVmVyZGljdCB7XG5cdGlmIChleHRyYWN0TWFwTWlkKGh0bWwpKSB7XG5cdFx0cmV0dXJuIHsgb3V0Y29tZTogJ29rJywgZGV0YWlsOiAnRm91bmQgdGhlIGVtYmVkZGVkIG1hcCcgfVxuXHR9XG5cdC8vIEEgYm90IGNoZWNrIGhhcyBubyBtYXAgZWl0aGVyIOKAlCBidXQgbmVpdGhlciBkb2VzIGEgY291cnNlIHBhZ2Ugd2l0aG91dCBvbmUsXG5cdC8vIHdoaWNoIGlzIGEgcmVhbCBhbmQgcGVybWFuZW50IGNvbmRpdGlvbi4gRGlzdGluZ3Vpc2ggb24gcGFnZSBzaGFwZS5cblx0Y29uc3QgbG9va3NMaWtlUGFya3J1biA9IC9wYXJrcnVuL2kudGVzdChodG1sKSAmJiBodG1sLmxlbmd0aCA+IDIwXzAwMFxuXHRyZXR1cm4gbG9va3NMaWtlUGFya3J1blxuXHRcdD8ge1xuXHRcdFx0XHRvdXRjb21lOiAndW51c2FibGUnLFxuXHRcdFx0XHRkZXRhaWw6ICdObyBHb29nbGUgbWFwIGVtYmVkZGVkIG9uIHRoaXMgY291cnNlIHBhZ2UuJyxcblx0XHRcdH1cblx0XHQ6IHtcblx0XHRcdFx0b3V0Y29tZTogJ2Jsb2NrZWQnLFxuXHRcdFx0XHRkZXRhaWw6IFwiQ291bGRuJ3QgcmVhZCB0aGUgY291cnNlIHBhZ2Ug4oCUIGl0IG1heSBiZSBhIGJvdCBjaGVjay5cIixcblx0XHRcdH1cbn1cbiIsIi8qKlxuICogVGhlIHJ1bjogd2FsayB0aGUgd29yayBsaXN0LCBjYXB0dXJlIGVhY2ggcGFnZSwgZGlzY292ZXIgbmV3IGNvdXJzZXMsIGZpbmlzaC5cbiAqXG4gKiBEcml2ZW4gZW50aXJlbHkgYnkgZXZlbnRzIHJhdGhlciB0aGFuIGEgbG9vcCwgYmVjYXVzZSB0aGUgc2VydmljZSB3b3JrZXIgaXNcbiAqIHRlcm1pbmF0ZWQgYmV0d2VlbiBwYWdlIGxvYWRzLiBFdmVyeSBtYWluLWZyYW1lIGRvY3VtZW50IGxvYWQgaW4gdGhlIHNjcmFwZVxuICogdGFiIGNhbGxzIGBoYW5kbGVEb2N1bWVudExvYWRlZGAsIHdoaWNoIGRlY2lkZXMgd2hldGhlciB0aGF0IHdhcyB0aGUgcGFnZSB3ZVxuICogd2VyZSB3YWl0aW5nIGZvci4gVGhhdCdzIGFsc28gaG93IGNhcHRjaGFzIHJlc29sdmUgdGhlbXNlbHZlczogc29sdmluZyBvbmVcbiAqIG5hdmlnYXRlcyBhZ2Fpbiwgd2hpY2ggbGFuZHMgaGVyZSBhZ2Fpbi5cbiAqL1xuaW1wb3J0IHsgZXh0cmFjdEV2ZW50cywgcGFyc2VSdW5SZXN1bHRzIH0gZnJvbSAnQHNoYXJlZC9wYXJrcnVuLXBhcnNlcnMnXG5pbXBvcnQgeyBjb3Vyc2VLbXpVcmwsIGNvdXJzZVBhZ2VVcmwgfSBmcm9tICdAc2hhcmVkL3BhcmtydW4tdXJscydcbmltcG9ydCB0eXBlIHtcblx0Q2FwdHVyZWRGaWxlLFxuXHRJdGVtU3RhdGUsXG5cdFJ1blJlcXVlc3QsXG5cdFJ1blN0YXRlLFxufSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5pbXBvcnQge1xuXHRjbGVhckxhc3REb2N1bWVudCxcblx0ZGVzY3JpYmVFcnJvcixcblx0ZGV0YWNoLFxuXHRlbnN1cmVBdHRhY2hlZCxcblx0Z2V0TGFzdERvY3VtZW50LFxuXHRpc0JvZHlOb3RSZWFkeSxcblx0bWFya0RvY3VtZW50Q29uc3VtZWQsXG5cdHJlYWRCb2R5LFxufSBmcm9tICcuL2NhcHR1cmUnXG5pbXBvcnQgeyBzdGFydEtlZXBhbGl2ZSwgc3RvcEtlZXBhbGl2ZSB9IGZyb20gJy4va2VlcGFsaXZlJ1xuaW1wb3J0IHsgbm90aWZ5RmlsZSwgbm90aWZ5U3RhdGUgfSBmcm9tICcuL21lc3NhZ2luZydcbmltcG9ydCB7XG5cdGFwcGVuZEl0ZW1zLFxuXHRnZXRGaWxlcyxcblx0Z2V0UnVuU3RhdGUsXG5cdGdldFNlc3Npb24sXG5cdHB1dEZpbGUsXG5cdHJlc2V0QWxsLFxuXHRzZXRJdGVtU3RhdHVzLFxuXHRzZXRSdW5TdGF0ZSxcblx0c2V0U2Vzc2lvbixcblx0dXBkYXRlUnVuU3RhdGUsXG5cdHVwZGF0ZVNlc3Npb24sXG59IGZyb20gJy4vc3RhdGUnXG5pbXBvcnQgeyBleHRyYWN0TWFwTWlkLCB2YWxpZGF0ZSB9IGZyb20gJy4vdmFsaWRhdGUnXG5cbi8qKiBHaXZlIHVwIG9uIGFuIGl0ZW0gYWZ0ZXIgdGhpcyBtYW55IGZhaWxlZCBhdHRlbXB0cyBhdCB0aGUgc2FtZSBVUkwuICovXG5jb25zdCBNQVhfQVRURU1QVFMgPSA4XG5cbi8qKlxuICogQSBwYWdlIHRoYXQgaGFzIGJlZW4gYGFjdGl2ZWAgdGhpcyBsb25nIHdpdGhvdXQgcHJvZHVjaW5nIGEgY2FwdHVyZSBoYXNcbiAqIGFsbW9zdCBjZXJ0YWlubHkgaGFkIGl0cyBsb2FkIGV2ZW50cyBtaXNzZWQg4oCUIHJlbG9hZCBpdCByYXRoZXIgdGhhbiBoYW5nLlxuICovXG5jb25zdCBTVEFMTF9USU1FT1VUX01TID0gMjBfMDAwXG5cbi8qKiBIb3cgb2Z0ZW4gdGhlIHdhdGNoZG9nIGxvb2tzIGZvciBhIHN0YWxsZWQgcGFnZS4gKi9cbmNvbnN0IFdBVENIRE9HX0FMQVJNID0gJ3dhdGNoZG9nJ1xuY29uc3QgV0FUQ0hET0dfUEVSSU9EX01JTlVURVMgPSAwLjVcblxuZnVuY3Rpb24gbG9nKC4uLmFyZ3M6IHVua25vd25bXSk6IHZvaWQge1xuXHRjb25zb2xlLmxvZygnW3Jlc3VsdHMtc2NyYXBlcl0nLCAuLi5hcmdzKVxufVxuXG4vKipcbiAqIEhvdyBsb25nIGEgYmxvY2tlZCBwYWdlIHNpdHMgYmVmb3JlIHdlIHJlbG9hZCBpdCBvdXJzZWx2ZXMuXG4gKlxuICogQSBDbG91ZGZsYXJlIGludGVyc3RpdGlhbCByZWxvYWRzIGl0c2VsZiBvbmNlIGl0cyBjaGVjayBwYXNzZXMsIHNvIHRob3NlIGNsZWFyXG4gKiB3aXRob3V0IGhlbHAuIEEgZmxhdCA0MDMgZG9lc24ndCwgYW5kIHdvdWxkIG90aGVyd2lzZSB3YWl0IGZvcmV2ZXIuIExvbmdcbiAqIGVub3VnaCBub3QgdG8geWFuayB0aGUgcGFnZSBvdXQgZnJvbSB1bmRlciBzb21lb25lIG1pZC1jYXB0Y2hhLlxuICovXG5jb25zdCBSRVRSWV9BTEFSTSA9ICdyZXRyeS1ibG9ja2VkJ1xuY29uc3QgUkVUUllfREVMQVlfTUlOVVRFUyA9IDFcblxuYXN5bmMgZnVuY3Rpb24gc2NoZWR1bGVSZXRyeSgpOiBQcm9taXNlPHZvaWQ+IHtcblx0YXdhaXQgY2hyb21lLmFsYXJtc1xuXHRcdC5jcmVhdGUoUkVUUllfQUxBUk0sIHsgZGVsYXlJbk1pbnV0ZXM6IFJFVFJZX0RFTEFZX01JTlVURVMgfSlcblx0XHQuY2F0Y2goKCkgPT4ge30pXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGNhbmNlbFNjaGVkdWxlZFJldHJ5KCk6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBjaHJvbWUuYWxhcm1zLmNsZWFyKFJFVFJZX0FMQVJNKS5jYXRjaCgoKSA9PiB7fSlcbn1cblxuLyoqIFJlbG9hZCB3aGF0ZXZlciBwYWdlIHRoZSBydW4gaXMgc3R1Y2sgb24uICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmV0cnlDdXJyZW50KCk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuIHN0YXRlXG5cblx0Y29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGkpID0+IGkua2V5ID09PSBzdGF0ZS5jdXJyZW50S2V5KVxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmICghaXRlbSB8fCBzZXNzaW9uLnNjcmFwZVRhYklkID09PSB1bmRlZmluZWQpIHJldHVybiBzdGF0ZVxuXG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0YXdhaXQgY2xlYXJMYXN0RG9jdW1lbnQoc2Vzc2lvbi5zY3JhcGVUYWJJZClcblxuXHR0cnkge1xuXHRcdGF3YWl0IGVuc3VyZUF0dGFjaGVkKHNlc3Npb24uc2NyYXBlVGFiSWQpXG5cdFx0YXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKHNlc3Npb24uc2NyYXBlVGFiSWQsIHsgdXJsOiBpdGVtLnVybCB9KVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBmYWlsUnVuKGRlc2NyaWJlRXJyb3IoZXJyb3IpKVxuXHR9XG5cdHJldHVybiBzdGF0ZVxufVxuXG4vKiogQWJhbmRvbiB0aGUgY3VycmVudCBwYWdlIGFuZCBjYXJyeSBvbiB3aXRoIHRoZSBuZXh0IG9uZS4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBza2lwQ3VycmVudCgpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycgfHwgIXN0YXRlLmN1cnJlbnRLZXkpIHJldHVybiBzdGF0ZVxuXG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0YXdhaXQgc2V0SXRlbVN0YXR1cyhzdGF0ZS5jdXJyZW50S2V5LCAnc2tpcHBlZCcsICdTa2lwcGVkLicpXG5cdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdHJldHVybiBhZHZhbmNlKClcbn1cblxuLyoqXG4gKiBUaGUgc2NyYXBlIHRhYiBmaW5pc2hlZCBsb2FkaW5nIGJ1dCB3ZSBoYXZlIG5vIGNhcHR1cmVkIGJvZHkgZm9yIGl0LlxuICpcbiAqIFRoYXQgbWVhbnMgdGhlIGRlYnVnZ2VyJ3MgTmV0d29yayBldmVudHMgZm9yIHRoaXMgbmF2aWdhdGlvbiBuZXZlciByZWFjaGVkIHVzIOKAlFxuICogYSB3b3JrZXIgdGhhdCB3YXMgYXNsZWVwIGF0IHRoZSB3cm9uZyBtb21lbnQsIG1vc3Qgb2Z0ZW4uIFRoZXJlJ3Mgbm8gd2F5IHRvIGFza1xuICogZm9yIGEgYm9keSBhZnRlciB0aGUgZmFjdCwgc28gdGhlIG9ubHkgcmVjb3ZlcnkgaXMgdG8gbG9hZCB0aGUgcGFnZSBhZ2FpbiB3aXRoXG4gKiB0aGUgd29ya2VyIG5vdyBkZW1vbnN0cmFibHkgYXdha2UuIERvaW5nIGl0IGhlcmUgcmF0aGVyIHRoYW4gbGVhdmluZyBpdCB0byB0aGVcbiAqIHdhdGNoZG9nIHR1cm5zIGEgMjAtc2Vjb25kIHN0YWxsIGludG8gYWJvdXQgYSBzZWNvbmQuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZWNvdmVyTWlzc2VkQ2FwdHVyZSh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHN0YXRlID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycgfHwgIXN0YXRlLmN1cnJlbnRLZXkpIHJldHVyblxuXG5cdGNvbnN0IGl0ZW0gPSBzdGF0ZS5pdGVtcy5maW5kKChpKSA9PiBpLmtleSA9PT0gc3RhdGUuY3VycmVudEtleSlcblx0aWYgKGl0ZW0/LnN0YXR1cyAhPT0gJ2FjdGl2ZScpIHJldHVyblxuXG5cdC8vIElmIGEgYm9keSBpcyB3YWl0aW5nLCB0aGUgbm9ybWFsIHBhdGggaGFzIGl0IOKAlCBub3RoaW5nIHRvIHJlY292ZXIuXG5cdGNvbnN0IGRvY3VtZW50ID0gYXdhaXQgZ2V0TGFzdERvY3VtZW50KHRhYklkKVxuXHRpZiAoZG9jdW1lbnQgJiYgIWRvY3VtZW50LmNvbnN1bWVkKSByZXR1cm5cblxuXHRjb25zdCBhdHRlbXB0cyA9IChpdGVtLmF0dGVtcHRzID8/IDApICsgMVxuXHRpZiAoYXR0ZW1wdHMgPiBNQVhfQVRURU1QVFMpIHtcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0aXRlbS5rZXksXG5cdFx0XHQnZmFpbGVkJyxcblx0XHRcdGBQYWdlIGxvYWRlZCBidXQgaXRzIHJlc3BvbnNlIHdhcyBuZXZlciBjYXB0dXJlZCwgYWZ0ZXIgJHthdHRlbXB0c30gYXR0ZW1wdHMuYCxcblx0XHRcdGF0dGVtcHRzLFxuXHRcdClcblx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdGF3YWl0IGFkdmFuY2UoKVxuXHRcdHJldHVyblxuXHR9XG5cblx0bG9nKFxuXHRcdGAke2l0ZW0ubGFiZWx9OiBsb2FkZWQgYnV0IG5vIHJlc3BvbnNlIGNhcHR1cmVkIOKAlCByZWxvYWRpbmcgKGF0dGVtcHQgJHthdHRlbXB0c30pYCxcblx0KVxuXHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdGl0ZW0ua2V5LFxuXHRcdCdhY3RpdmUnLFxuXHRcdCdQYWdlIGxvYWRlZCBidXQgdGhlIGNhcHR1cmUgd2FzIG1pc3NlZCDigJQgcmVsb2FkaW5nLicsXG5cdFx0YXR0ZW1wdHMsXG5cdClcblx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0YXdhaXQgcmV0cnlDdXJyZW50KClcbn1cblxuLyoqIEZpcmVkIGJ5IHRoZSBhbGFybTogbnVkZ2UgYSBwYWdlIHRoYXQncyBzdGlsbCBzdHVjay4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiByZXRyeUlmU3RpbGxCbG9ja2VkKCk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnIHx8ICFzdGF0ZS5jdXJyZW50S2V5KSByZXR1cm5cblxuXHRjb25zdCBpdGVtID0gc3RhdGUuaXRlbXMuZmluZCgoaSkgPT4gaS5rZXkgPT09IHN0YXRlLmN1cnJlbnRLZXkpXG5cdGlmIChpdGVtPy5zdGF0dXMgIT09ICdibG9ja2VkJykgcmV0dXJuXG5cblx0Ly8gTmV2ZXIgcmVsb2FkIGEgcGFnZSB0aGUgdXNlciBpcyBwYXJ0LXdheSB0aHJvdWdoIHNvbHZpbmcuXG5cdGlmIChpdGVtLmF3YWl0VXNlcikge1xuXHRcdGxvZyhgJHtpdGVtLmxhYmVsfTogc3RpbGwgd2FpdGluZyBmb3IgdGhlIHVzZXI7IG5vdCByZWxvYWRpbmdgKVxuXHRcdHJldHVyblxuXHR9XG5cblx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoc2Vzc2lvbi5hdHRlbXB0cyA+PSBNQVhfQVRURU1QVFMpIHtcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0aXRlbS5rZXksXG5cdFx0XHQnZmFpbGVkJyxcblx0XHRcdGAke2l0ZW0uZGV0YWlsID8/ICdCbG9ja2VkLid9IEdhdmUgdXAgYWZ0ZXIgJHtzZXNzaW9uLmF0dGVtcHRzfSBhdHRlbXB0cy5gLFxuXHRcdClcblx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdGF3YWl0IGFkdmFuY2UoKVxuXHRcdHJldHVyblxuXHR9XG5cblx0YXdhaXQgcmV0cnlDdXJyZW50KClcbn1cblxuLy8g4pSA4pSAIFN0YXJ0aW5nIGFuZCBzdG9wcGluZyDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHN0YXJ0UnVuKFxuXHRyZXF1ZXN0OiBSdW5SZXF1ZXN0LFxuXHRhZG1pblRhYklkOiBudW1iZXIsXG4pOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGF3YWl0IHJlc2V0QWxsKClcblxuXHRjb25zdCBpdGVtczogSXRlbVN0YXRlW10gPSByZXF1ZXN0Lml0ZW1zLm1hcCgoaXRlbSkgPT4gKHtcblx0XHQuLi5pdGVtLFxuXHRcdHN0YXR1czogJ3BlbmRpbmcnLFxuXHR9KSlcblxuXHRpZiAoaXRlbXMubGVuZ3RoID09PSAwKSB7XG5cdFx0Y29uc3Qgc3RhdGU6IFJ1blN0YXRlID0ge1xuXHRcdFx0c3RhdHVzOiAnZXJyb3InLFxuXHRcdFx0aXRlbXM6IFtdLFxuXHRcdFx0bWVzc2FnZTogJ05vdGhpbmcgdG8gc2NyYXBlLicsXG5cdFx0fVxuXHRcdGF3YWl0IHNldFJ1blN0YXRlKHN0YXRlKVxuXHRcdHJldHVybiBzdGF0ZVxuXHR9XG5cblx0Ly8gQSBkZWRpY2F0ZWQgdGFiIGtlZXBzIHRoZSBhZG1pbiBwYWdlIGFsaXZlLCBzbyBpdCBjYW4gc2hvdyBwcm9ncmVzcyBhbmRcblx0Ly8gdGFrZSBmaWxlcyBhcyB0aGV5IGFycml2ZS5cblx0Y29uc3QgdGFiID0gYXdhaXQgY2hyb21lLnRhYnMuY3JlYXRlKHsgdXJsOiAnYWJvdXQ6YmxhbmsnLCBhY3RpdmU6IHRydWUgfSlcblx0aWYgKHRhYi5pZCA9PT0gdW5kZWZpbmVkKSB0aHJvdyBuZXcgRXJyb3IoJ0NvdWxkIG5vdCBvcGVuIGEgc2NyYXBlIHRhYicpXG5cblx0YXdhaXQgc2V0U2Vzc2lvbih7XG5cdFx0YWRtaW5UYWJJZCxcblx0XHRzY3JhcGVUYWJJZDogdGFiLmlkLFxuXHRcdGtub3duQ291cnNlRXZlbnRJZHM6IHJlcXVlc3Qua25vd25Db3Vyc2VFdmVudElkcyxcblx0XHRkaXNjb3ZlcmVkRXZlbnRzOiB7fSxcblx0XHRjb3Vyc2VzUXVldWVkOiBmYWxzZSxcblx0XHRza2lwQ291cnNlczogcmVxdWVzdC5za2lwQ291cnNlcyA/PyBmYWxzZSxcblx0XHRhdHRlbXB0czogMCxcblx0fSlcblxuXHRjb25zdCBzdGF0ZTogUnVuU3RhdGUgPSB7XG5cdFx0c3RhdHVzOiAncnVubmluZycsXG5cdFx0aXRlbXMsXG5cdFx0c3RhcnRlZEF0OiBEYXRlLm5vdygpLFxuXHR9XG5cdGF3YWl0IHNldFJ1blN0YXRlKHN0YXRlKVxuXG5cdHRyeSB7XG5cdFx0YXdhaXQgZW5zdXJlQXR0YWNoZWQodGFiLmlkKVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdHJldHVybiBmYWlsUnVuKGRlc2NyaWJlRXJyb3IoZXJyb3IpKVxuXHR9XG5cblx0YXdhaXQgc2V0QmFkZ2UoJ+KApicpXG5cdHN0YXJ0S2VlcGFsaXZlKClcblx0YXdhaXQgY2hyb21lLmFsYXJtc1xuXHRcdC5jcmVhdGUoV0FUQ0hET0dfQUxBUk0sIHsgcGVyaW9kSW5NaW51dGVzOiBXQVRDSERPR19QRVJJT0RfTUlOVVRFUyB9KVxuXHRcdC5jYXRjaCgoKSA9PiB7fSlcblx0bG9nKGBydW4gc3RhcnRlZDogJHtpdGVtcy5sZW5ndGh9IGl0ZW1zLCBzY3JhcGUgdGFiICR7dGFiLmlkfWApXG5cdHJldHVybiBhZHZhbmNlKClcbn1cblxuLyoqXG4gKiBVbnN0aWNrIGEgcGFnZSB3aG9zZSBsb2FkIGV2ZW50cyBuZXZlciBhcnJpdmVkLlxuICpcbiAqIFRoZSBkZWJ1Z2dlciBpcyB0aGUgb25seSBzb3VyY2Ugb2YgY2FwdHVyZSBldmVudHMsIGFuZCBpZiB0aGUgc2VydmljZSB3b3JrZXJcbiAqIHdhcyBhc2xlZXAgd2hlbiB0aGV5IGZpcmVkIOKAlCBvciB0aGV5IHdlcmUgZHJvcHBlZCDigJQgbm90aGluZyBlbHNlIHdpbGwgZXZlclxuICogdHJpZ2dlci4gUmVsb2FkaW5nIHByb2R1Y2VzIGEgZnJlc2ggc2V0LlxuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY2hlY2tGb3JTdGFsbCgpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuXG5cblx0Y29uc3QgaXRlbSA9IHN0YXRlLml0ZW1zLmZpbmQoKGkpID0+IGkua2V5ID09PSBzdGF0ZS5jdXJyZW50S2V5KVxuXHRpZiAoaXRlbT8uc3RhdHVzICE9PSAnYWN0aXZlJykgcmV0dXJuXG5cblx0Y29uc3QgYWdlID0gRGF0ZS5ub3coKSAtIChpdGVtLnVwZGF0ZWRBdCA/PyAwKVxuXHRpZiAoYWdlIDwgU1RBTExfVElNRU9VVF9NUykgcmV0dXJuXG5cblx0Y29uc3QgYXR0ZW1wdHMgPSAoaXRlbS5hdHRlbXB0cyA/PyAwKSArIDFcblx0aWYgKGF0dGVtcHRzID4gTUFYX0FUVEVNUFRTKSB7XG5cdFx0bG9nKGBnaXZpbmcgdXAgb24gJHtpdGVtLmxhYmVsfSBhZnRlciAke2F0dGVtcHRzfSBhdHRlbXB0c2ApXG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRcdGl0ZW0ua2V5LFxuXHRcdFx0J2ZhaWxlZCcsXG5cdFx0XHRgTm8gcmVzcG9uc2UgYWZ0ZXIgJHthdHRlbXB0c30gYXR0ZW1wdHMg4oCUIHBhZ2UgbmV2ZXIgZmluaXNoZWQgbG9hZGluZy5gLFxuXHRcdFx0YXR0ZW1wdHMsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRsb2coXG5cdFx0YCR7aXRlbS5sYWJlbH0gc3RhbGxlZCBmb3IgJHtNYXRoLnJvdW5kKGFnZSAvIDEwMDApfXMg4oCUIHJlbG9hZGluZyAoYXR0ZW1wdCAke2F0dGVtcHRzfSlgLFxuXHQpXG5cdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0aXRlbS5rZXksXG5cdFx0J2FjdGl2ZScsXG5cdFx0YE5vIHJlc3BvbnNlIGFmdGVyICR7TWF0aC5yb3VuZChhZ2UgLyAxMDAwKX1zIOKAlCByZWxvYWRpbmcgKGF0dGVtcHQgJHthdHRlbXB0c30pLmAsXG5cdFx0YXR0ZW1wdHMsXG5cdClcblx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0YXdhaXQgcmV0cnlDdXJyZW50KClcbn1cblxuLyoqXG4gKiBXaXBlIHRoZSBydW4gYW5kIGl0cyBjYXB0dXJlZCBmaWxlcy5cbiAqXG4gKiBDYWxsZWQgb25jZSB0aGUgYWRtaW4gcGFnZSBoYXMgdXBsb2FkZWQsIHNvIHJlb3BlbmluZyB0aGUgcGFnZSBkb2Vzbid0IG9mZmVyXG4gKiB0byByZS1kZWxpdmVyIHBhZ2VzIHdob3NlIGRhdGEgaXMgYWxyZWFkeSBpbiB0aGUgZGF0YWJhc2UuXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBmb3JnZXRSdW4oKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0c3RvcEtlZXBhbGl2ZSgpXG5cdGF3YWl0IGNocm9tZS5hbGFybXMuY2xlYXIoV0FUQ0hET0dfQUxBUk0pLmNhdGNoKCgpID0+IHt9KVxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB1bmRlZmluZWQpIHtcblx0XHRhd2FpdCBkZXRhY2goc2Vzc2lvbi5zY3JhcGVUYWJJZClcblx0XHRhd2FpdCBjbGVhckxhc3REb2N1bWVudChzZXNzaW9uLnNjcmFwZVRhYklkKVxuXHR9XG5cdGF3YWl0IHJlc2V0QWxsKClcblx0YXdhaXQgc2V0QmFkZ2UoJycpXG5cdGxvZygncnVuIGNsZWFyZWQnKVxufVxuXG4vKipcbiAqIFBpY2sgdXAgYSBydW4gdGhhdCBzdG9wcGVkIGVhcmx5IOKAlCBjYW5jZWxsZWQsIHRhYiBjbG9zZWQsIGRlYnVnZ2VyIGRldGFjaGVkLFxuICogYnJvd3NlciByZXN0YXJ0ZWQuXG4gKlxuICogRGVsaWJlcmF0ZWx5IG5vdCBhIGZyZXNoIGBzdGFydFJ1bmA6IHRoYXQgd291bGQgd2lwZSB0aGUgY2FwdHVyZWQgcGFnZXMgYW5kXG4gKiByZS1mZXRjaCBldmVyeXRoaW5nLiBJbnN0ZWFkIHRoZSBjYXB0dXJlZCBhbmQgc2tpcHBlZCBpdGVtcyBhcmUgbGVmdCBhbG9uZSBhbmRcbiAqIGV2ZXJ5dGhpbmcgZWxzZSBnb2VzIGJhY2sgdG8gcGVuZGluZywgc28gYSBzY3JhcGUgaW50ZXJydXB0ZWQgYXQgcGFnZSA3IG9mIDE4XG4gKiBjb3N0cyAxMSBtb3JlIHBhZ2UgbG9hZHMsIG5vdCAxOC5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIHJlc3VtZVJ1bihhZG1pblRhYklkOiBudW1iZXIpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGNvbnN0IHByZXZpb3VzID0gYXdhaXQgZ2V0UnVuU3RhdGUoKVxuXHRpZiAocHJldmlvdXMuaXRlbXMubGVuZ3RoID09PSAwKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oJ1RoZXJlIGlzIG5vIHJ1biB0byByZXN1bWUuJylcblx0fVxuXG5cdGNvbnN0IGl0ZW1zOiBJdGVtU3RhdGVbXSA9IHByZXZpb3VzLml0ZW1zLm1hcCgoaXRlbSkgPT5cblx0XHRpdGVtLnN0YXR1cyA9PT0gJ2NhcHR1cmVkJyB8fCBpdGVtLnN0YXR1cyA9PT0gJ3NraXBwZWQnXG5cdFx0XHQ/IGl0ZW1cblx0XHRcdDoge1xuXHRcdFx0XHRcdC4uLml0ZW0sXG5cdFx0XHRcdFx0c3RhdHVzOiAncGVuZGluZycgYXMgY29uc3QsXG5cdFx0XHRcdFx0ZGV0YWlsOiB1bmRlZmluZWQsXG5cdFx0XHRcdFx0YXR0ZW1wdHM6IDAsXG5cdFx0XHRcdFx0YXdhaXRVc2VyOiB1bmRlZmluZWQsXG5cdFx0XHRcdFx0dXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHR9LFxuXHQpXG5cblx0Y29uc3Qgb3V0c3RhbmRpbmcgPSBpdGVtcy5maWx0ZXIoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzID09PSAncGVuZGluZycpLmxlbmd0aFxuXHRpZiAob3V0c3RhbmRpbmcgPT09IDApIHtcblx0XHRyZXR1cm4gZmFpbFJ1bignRXZlcnkgcGFnZSBpbiB0aGF0IHJ1biBpcyBhbHJlYWR5IGNhcHR1cmVkIG9yIHNraXBwZWQuJylcblx0fVxuXG5cdGNvbnN0IHRhYiA9IGF3YWl0IGNocm9tZS50YWJzLmNyZWF0ZSh7IHVybDogJ2Fib3V0OmJsYW5rJywgYWN0aXZlOiB0cnVlIH0pXG5cdGlmICh0YWIuaWQgPT09IHVuZGVmaW5lZCkgdGhyb3cgbmV3IEVycm9yKCdDb3VsZCBub3Qgb3BlbiBhIHNjcmFwZSB0YWInKVxuXG5cdC8vIFRoZSBzZXNzaW9uIGNhcnJpZXMgdGhlIGV2ZW50cyBkaXNjb3ZlcmVkIGJ5IGF0aGxldGUgcGFnZXMgd2UgYWxyZWFkeSBoYXZlLFxuXHQvLyBzbyB0aGUgY291cnNlIGh1bnQgc3RpbGwga25vd3MgYWJvdXQgdGhlbSB3aXRob3V0IHJlLXBhcnNpbmcgYW55dGhpbmcuXG5cdGF3YWl0IHVwZGF0ZVNlc3Npb24oKHNlc3Npb24pID0+ICh7XG5cdFx0Li4uc2Vzc2lvbixcblx0XHRhZG1pblRhYklkLFxuXHRcdHNjcmFwZVRhYklkOiB0YWIuaWQsXG5cdFx0YXR0ZW1wdHM6IDAsXG5cdH0pKVxuXG5cdGF3YWl0IHNldFJ1blN0YXRlKHtcblx0XHQuLi5wcmV2aW91cyxcblx0XHRzdGF0dXM6ICdydW5uaW5nJyxcblx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0aXRlbXMsXG5cdFx0bWVzc2FnZTogdW5kZWZpbmVkLFxuXHRcdGZpbmlzaGVkQXQ6IHVuZGVmaW5lZCxcblx0fSlcblxuXHR0cnkge1xuXHRcdGF3YWl0IGVuc3VyZUF0dGFjaGVkKHRhYi5pZClcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRyZXR1cm4gZmFpbFJ1bihkZXNjcmliZUVycm9yKGVycm9yKSlcblx0fVxuXG5cdGF3YWl0IHNldEJhZGdlKCfigKYnKVxuXHRzdGFydEtlZXBhbGl2ZSgpXG5cdGF3YWl0IGNocm9tZS5hbGFybXNcblx0XHQuY3JlYXRlKFdBVENIRE9HX0FMQVJNLCB7IHBlcmlvZEluTWludXRlczogV0FUQ0hET0dfUEVSSU9EX01JTlVURVMgfSlcblx0XHQuY2F0Y2goKCkgPT4ge30pXG5cdGxvZyhgcmVzdW1pbmc6ICR7b3V0c3RhbmRpbmd9IG9mICR7aXRlbXMubGVuZ3RofSBwYWdlcyBzdGlsbCBuZWVkZWRgKVxuXHRyZXR1cm4gYWR2YW5jZSgpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBjYW5jZWxSdW4oKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRhd2FpdCBjYW5jZWxTY2hlZHVsZWRSZXRyeSgpXG5cdHN0b3BLZWVwYWxpdmUoKVxuXHRhd2FpdCBjaHJvbWUuYWxhcm1zLmNsZWFyKFdBVENIRE9HX0FMQVJNKS5jYXRjaCgoKSA9PiB7fSlcblxuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0Y29uc3QgY2FuY2VsbGVkOiBSdW5TdGF0ZSA9IHtcblx0XHQuLi5zdGF0ZSxcblx0XHRzdGF0dXM6ICdjYW5jZWxsZWQnLFxuXHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRmaW5pc2hlZEF0OiBEYXRlLm5vdygpLFxuXHRcdG1lc3NhZ2U6ICdDYW5jZWxsZWQuJyxcblx0fVxuXHQvLyBTdGF0dXMgZmlyc3QsIHRoZW4gdGhlIHRhYiDigJQgc2VlIGZpbmlzaFJ1bi5cblx0YXdhaXQgc2V0UnVuU3RhdGUoY2FuY2VsbGVkKVxuXHRhd2FpdCBjbG9zZVNjcmFwZVRhYigpXG5cdGF3YWl0IHNldEJhZGdlKCcnKVxuXHRhd2FpdCBmb2N1c0FkbWluVGFiKClcblx0YXdhaXQgbm90aWZ5U3RhdGUoY2FuY2VsbGVkKVxuXHRyZXR1cm4gY2FuY2VsbGVkXG59XG5cbmFzeW5jIGZ1bmN0aW9uIGZhaWxSdW4obWVzc2FnZTogc3RyaW5nKTogUHJvbWlzZTxSdW5TdGF0ZT4ge1xuXHRzdG9wS2VlcGFsaXZlKClcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGNvbnN0IGZhaWxlZDogUnVuU3RhdGUgPSB7XG5cdFx0Li4uc3RhdGUsXG5cdFx0c3RhdHVzOiAnZXJyb3InLFxuXHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRmaW5pc2hlZEF0OiBEYXRlLm5vdygpLFxuXHRcdG1lc3NhZ2UsXG5cdH1cblx0YXdhaXQgc2V0UnVuU3RhdGUoZmFpbGVkKVxuXHRhd2FpdCBzZXRCYWRnZSgnIScpXG5cdGF3YWl0IG5vdGlmeVN0YXRlKGZhaWxlZClcblx0cmV0dXJuIGZhaWxlZFxufVxuXG4vLyDilIDilIAgTW92aW5nIHRocm91Z2ggdGhlIHF1ZXVlIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKiogTmF2aWdhdGUgdG8gdGhlIG5leHQgcGVuZGluZyBpdGVtLCBvciBmaW5pc2ggaWYgdGhlcmUgYXJlIG5vbmUgbGVmdC4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhZHZhbmNlKCk6IFByb21pc2U8UnVuU3RhdGU+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuIHN0YXRlXG5cblx0Y29uc3QgbmV4dCA9IHN0YXRlLml0ZW1zLmZpbmQoKGl0ZW0pID0+IGl0ZW0uc3RhdHVzID09PSAncGVuZGluZycpXG5cblx0aWYgKCFuZXh0KSB7XG5cdFx0Ly8gQXRobGV0ZSBwYWdlcyBhcmUgZG9uZSDigJQgaXMgdGhlcmUgY291cnNlIHdvcmsgdG8gYWRkIGJlZm9yZSBmaW5pc2hpbmc/XG5cdFx0Y29uc3QgcXVldWVkID0gYXdhaXQgcXVldWVOZXdDb3Vyc2VzKClcblx0XHRpZiAocXVldWVkKSByZXR1cm4gYWR2YW5jZSgpXG5cdFx0cmV0dXJuIGZpbmlzaFJ1bigpXG5cdH1cblxuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkID09PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gZmFpbFJ1bignVGhlIHNjcmFwZSB0YWIgaXMgZ29uZS4nKVxuXHR9XG5cblx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRhd2FpdCB1cGRhdGVTZXNzaW9uKChzKSA9PiAoeyAuLi5zLCBhdHRlbXB0czogMCB9KSlcblx0YXdhaXQgY2xlYXJMYXN0RG9jdW1lbnQoc2Vzc2lvbi5zY3JhcGVUYWJJZClcblxuXHRjb25zdCBydW5uaW5nOiBSdW5TdGF0ZSA9IHtcblx0XHQuLi5zdGF0ZSxcblx0XHRjdXJyZW50S2V5OiBuZXh0LmtleSxcblx0XHRpdGVtczogc3RhdGUuaXRlbXMubWFwKChpdGVtKSA9PlxuXHRcdFx0aXRlbS5rZXkgPT09IG5leHQua2V5XG5cdFx0XHRcdD8ge1xuXHRcdFx0XHRcdFx0Li4uaXRlbSxcblx0XHRcdFx0XHRcdHN0YXR1czogJ2FjdGl2ZScsXG5cdFx0XHRcdFx0XHRkZXRhaWw6ICdMb2FkaW5n4oCmJyxcblx0XHRcdFx0XHRcdGF0dGVtcHRzOiAwLFxuXHRcdFx0XHRcdFx0dXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdH1cblx0XHRcdFx0OiBpdGVtLFxuXHRcdCksXG5cdFx0bWVzc2FnZTogdW5kZWZpbmVkLFxuXHR9XG5cdGF3YWl0IHNldFJ1blN0YXRlKHJ1bm5pbmcpXG5cdGF3YWl0IG5vdGlmeVN0YXRlKHJ1bm5pbmcpXG5cblx0bG9nKGDihpIgJHtuZXh0LmxhYmVsfTogJHtuZXh0LnVybH1gKVxuXG5cdHRyeSB7XG5cdFx0YXdhaXQgZW5zdXJlQXR0YWNoZWQoc2Vzc2lvbi5zY3JhcGVUYWJJZClcblx0XHRhd2FpdCBjaHJvbWUudGFicy51cGRhdGUoc2Vzc2lvbi5zY3JhcGVUYWJJZCwgeyB1cmw6IG5leHQudXJsIH0pXG5cdH0gY2F0Y2ggKGVycm9yKSB7XG5cdFx0cmV0dXJuIGZhaWxSdW4oZGVzY3JpYmVFcnJvcihlcnJvcikpXG5cdH1cblxuXHRyZXR1cm4gcnVubmluZ1xufVxuXG4vKipcbiAqIENhbGxlZCBmb3IgZXZlcnkgZmluaXNoZWQgbWFpbi1mcmFtZSBkb2N1bWVudCBpbiB0aGUgc2NyYXBlIHRhYi5cbiAqXG4gKiBJZ25vcmVzIGFueXRoaW5nIHRoYXQgaXNuJ3QgdGhlIHBhZ2UgdGhlIGN1cnJlbnQgaXRlbSBhc2tlZCBmb3Ig4oCUIHBhcmtydW5cbiAqIHJlZGlyZWN0cywgYW5kIGEgY2hhbGxlbmdlIHBhZ2UgY2FuIG5hdmlnYXRlIGEgZmV3IHRpbWVzIGJlZm9yZSBzZXR0bGluZy5cbiAqL1xuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZURvY3VtZW50TG9hZGVkKHRhYklkOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJyB8fCAhc3RhdGUuY3VycmVudEtleSkgcmV0dXJuXG5cblx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRpZiAoc2Vzc2lvbi5zY3JhcGVUYWJJZCAhPT0gdGFiSWQpIHJldHVyblxuXG5cdGNvbnN0IGl0ZW0gPSBzdGF0ZS5pdGVtcy5maW5kKChpKSA9PiBpLmtleSA9PT0gc3RhdGUuY3VycmVudEtleSlcblx0aWYgKCFpdGVtKSByZXR1cm5cblxuXHQvLyBEZWxpYmVyYXRlbHkgbm90IHJlcXVpcmluZyBgZmluaXNoZWRgOiB0aGlzIHJ1bnMgZnJvbSB0aGUgZGVidWdnZXInc1xuXHQvLyBsb2FkaW5nRmluaXNoZWQgZXZlbnQgKmFuZCogZnJvbSB0YWJzLm9uVXBkYXRlZCwgYmVjYXVzZSB0aGUgZGVidWdnZXIgZXZlbnRzXG5cdC8vIGFyZSBub3QgcmVsaWFibHkgZGVsaXZlcmVkIOKAlCBhIHJ1biB3b3VsZCBvdGhlcndpc2Ugc2l0IG9uIFwiTG9hZGluZ+KAplwiIHVudGlsXG5cdC8vIHRoZSB3YXRjaGRvZyBub3RpY2VkLiBXaGljaGV2ZXIgdHJpZ2dlciBhcnJpdmVzIGZpcnN0IHdpdGggYSByZWFkYWJsZSBib2R5XG5cdC8vIHdpbnMsIGFuZCBhIGJvZHkgdGhhdCBpc24ndCByZWFkeSB5ZXQgaXMgc2ltcGx5IHdhaXRlZCBvdXQuXG5cdGNvbnN0IGRvY3VtZW50ID0gYXdhaXQgZ2V0TGFzdERvY3VtZW50KHRhYklkKVxuXHRpZiAoIWRvY3VtZW50IHx8IGRvY3VtZW50LmNvbnN1bWVkKSByZXR1cm5cblxuXHRsZXQgY2FwdHVyZWQ6IEF3YWl0ZWQ8UmV0dXJuVHlwZTx0eXBlb2YgcmVhZEJvZHk+PlxuXHR0cnkge1xuXHRcdGNhcHR1cmVkID0gYXdhaXQgcmVhZEJvZHkodGFiSWQsIGRvY3VtZW50KVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGlmIChpc0JvZHlOb3RSZWFkeShlcnJvcikpIHJldHVyblxuXG5cdFx0Y29uc3QgYXR0ZW1wdHMgPSAoXG5cdFx0XHRhd2FpdCB1cGRhdGVTZXNzaW9uKChzKSA9PiAoeyAuLi5zLCBhdHRlbXB0czogcy5hdHRlbXB0cyArIDEgfSkpXG5cdFx0KS5hdHRlbXB0c1xuXHRcdGxvZyhgJHtpdGVtLmxhYmVsfTogY291bGQgbm90IHJlYWQgYm9keSDigJQgJHtkZXNjcmliZUVycm9yKGVycm9yKX1gKVxuXHRcdGlmIChhdHRlbXB0cyA+PSBNQVhfQVRURU1QVFMpIHtcblx0XHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoaXRlbS5rZXksICdmYWlsZWQnLCBkZXNjcmliZUVycm9yKGVycm9yKSwgYXR0ZW1wdHMpXG5cdFx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0fVxuXHRcdHJldHVyblxuXHR9XG5cblx0Y29uc3QgYXR0ZW1wdHMgPSAoXG5cdFx0YXdhaXQgdXBkYXRlU2Vzc2lvbigocykgPT4gKHsgLi4ucywgYXR0ZW1wdHM6IHMuYXR0ZW1wdHMgKyAxIH0pKVxuXHQpLmF0dGVtcHRzXG5cblx0Y29uc3QgdmVyZGljdCA9IHZhbGlkYXRlKGl0ZW0ua2luZCwgaXRlbS5rZXksIGNhcHR1cmVkLnN0YXR1cywgY2FwdHVyZWQuYm9keSlcblx0bG9nKFxuXHRcdGAke2l0ZW0ubGFiZWx9OiBIVFRQICR7Y2FwdHVyZWQuc3RhdHVzfSwgJHtjYXB0dXJlZC5ib2R5Lmxlbmd0aH0gYnl0ZXMg4oaSICR7dmVyZGljdC5vdXRjb21lfSAoJHt2ZXJkaWN0LmRldGFpbH0pYCxcblx0KVxuXG5cdGlmICh2ZXJkaWN0Lm91dGNvbWUgPT09ICdibG9ja2VkJykge1xuXHRcdC8vIEEgY2hhbGxlbmdlIHdpdGggc29tZXRoaW5nIG9uIHNjcmVlbiB0byBzb2x2ZTogd2FpdCBpbmRlZmluaXRlbHksIGFuZFxuXHRcdC8vIGNydWNpYWxseSBkbyBOT1QgcmVsb2FkIOKAlCB0aGF0IHdvdWxkIHdpcGUgb3V0IGEgaGFsZi1maW5pc2hlZCBjYXB0Y2hhLlxuXHRcdC8vIFNvbHZpbmcgaXQgbmF2aWdhdGVzIHRoZSBwYWdlLCB3aGljaCBicmluZ3MgdXMgYmFjayBoZXJlIGJ5IGl0c2VsZi5cblx0XHRpZiAodmVyZGljdC5hd2FpdFVzZXIpIHtcblx0XHRcdGxvZyhgJHtpdGVtLmxhYmVsfTogd2FpdGluZyBmb3IgdGhlIHVzZXIgdG8gY2xlYXIgYSBjaGFsbGVuZ2VgKVxuXHRcdFx0YXdhaXQgY2FuY2VsU2NoZWR1bGVkUmV0cnkoKVxuXHRcdFx0YXdhaXQgdXBkYXRlUnVuU3RhdGUoKGN1cnJlbnQpID0+ICh7XG5cdFx0XHRcdC4uLmN1cnJlbnQsXG5cdFx0XHRcdGl0ZW1zOiBjdXJyZW50Lml0ZW1zLm1hcCgoaSkgPT5cblx0XHRcdFx0XHRpLmtleSA9PT0gaXRlbS5rZXlcblx0XHRcdFx0XHRcdD8ge1xuXHRcdFx0XHRcdFx0XHRcdC4uLmksXG5cdFx0XHRcdFx0XHRcdFx0c3RhdHVzOiAnYmxvY2tlZCcgYXMgY29uc3QsXG5cdFx0XHRcdFx0XHRcdFx0ZGV0YWlsOiB2ZXJkaWN0LmRldGFpbCxcblx0XHRcdFx0XHRcdFx0XHRhdHRlbXB0cyxcblx0XHRcdFx0XHRcdFx0XHRhd2FpdFVzZXI6IHRydWUsXG5cdFx0XHRcdFx0XHRcdFx0dXBkYXRlZEF0OiBEYXRlLm5vdygpLFxuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHQ6IGksXG5cdFx0XHRcdCksXG5cdFx0XHR9KSlcblx0XHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHRpZiAoYXR0ZW1wdHMgPj0gTUFYX0FUVEVNUFRTKSB7XG5cdFx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0XHRpdGVtLmtleSxcblx0XHRcdFx0J2ZhaWxlZCcsXG5cdFx0XHRcdGAke3ZlcmRpY3QuZGV0YWlsfSBHYXZlIHVwIGFmdGVyICR7YXR0ZW1wdHN9IGF0dGVtcHRzLmAsXG5cdFx0XHQpXG5cdFx0XHRhd2FpdCBub3RpZnlTdGF0ZShhd2FpdCBnZXRSdW5TdGF0ZSgpKVxuXHRcdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhcblx0XHRcdGl0ZW0ua2V5LFxuXHRcdFx0J2Jsb2NrZWQnLFxuXHRcdFx0YCR7dmVyZGljdC5kZXRhaWx9IChhdHRlbXB0ICR7YXR0ZW1wdHN9IG9mICR7TUFYX0FUVEVNUFRTfTsgcmV0cnlpbmcgYXV0b21hdGljYWxseSlgLFxuXHRcdFx0YXR0ZW1wdHMsXG5cdFx0KVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgc2NoZWR1bGVSZXRyeSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHRpZiAodmVyZGljdC5vdXRjb21lID09PSAndW51c2FibGUnKSB7XG5cdFx0YXdhaXQgc2V0SXRlbVN0YXR1cyhpdGVtLmtleSwgJ2ZhaWxlZCcsIHZlcmRpY3QuZGV0YWlsKVxuXHRcdGF3YWl0IG5vdGlmeVN0YXRlKGF3YWl0IGdldFJ1blN0YXRlKCkpXG5cdFx0YXdhaXQgYWR2YW5jZSgpXG5cdFx0cmV0dXJuXG5cdH1cblxuXHQvLyAtLS0gQ2FwdHVyZWQgc29tZXRoaW5nIHVzYWJsZSAtLS1cblxuXHQvLyBDbGFpbSBpdCBiZWZvcmUgZG9pbmcgYW55dGhpbmcgZWxzZSwgc28gdGhlIG90aGVyIHRyaWdnZXIgYm93cyBvdXQuXG5cdGF3YWl0IG1hcmtEb2N1bWVudENvbnN1bWVkKHRhYklkLCBkb2N1bWVudClcblxuXHRpZiAoaXRlbS5raW5kID09PSAnY291cnNlJykge1xuXHRcdGF3YWl0IGhhbmRsZUNvdXJzZVBhZ2UoaXRlbSwgY2FwdHVyZWQuYm9keSlcblx0fSBlbHNlIHtcblx0XHRhd2FpdCBkZWxpdmVyKHtcblx0XHRcdGtpbmQ6IGl0ZW0ua2luZCxcblx0XHRcdGtleTogaXRlbS5rZXksXG5cdFx0XHRuYW1lOiBmaWxlTmFtZUZvcihpdGVtLmtpbmQsIGl0ZW0ua2V5KSxcblx0XHRcdHRleHQ6IGNhcHR1cmVkLmJvZHksXG5cdFx0fSlcblx0XHRpZiAoaXRlbS5raW5kID09PSAnYXRobGV0ZScpIGF3YWl0IHJlY29yZEV2ZW50cyhjYXB0dXJlZC5ib2R5KVxuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoaXRlbS5rZXksICdjYXB0dXJlZCcsIHZlcmRpY3QuZGV0YWlsKVxuXHR9XG5cblx0YXdhaXQgbm90aWZ5U3RhdGUoYXdhaXQgZ2V0UnVuU3RhdGUoKSlcblx0YXdhaXQgYWR2YW5jZSgpXG59XG5cbi8vIOKUgOKUgCBDb3Vyc2VzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIEEgY291cnNlIHBhZ2Ugb25seSB0ZWxscyB1cyB0aGUgbWFwIGlkOyB0aGUgS01aIGNvbWVzIGZyb20gR29vZ2xlLCB3aGljaFxuICogc2VydmVzIGl0IHRvIGEgcGxhaW4gZmV0Y2gg4oCUIG5vIG5hdmlnYXRpb24sIG5vIGNvb2tpZXMuXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZUNvdXJzZVBhZ2UoaXRlbTogSXRlbVN0YXRlLCBodG1sOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgbWlkID0gZXh0cmFjdE1hcE1pZChodG1sKVxuXHRpZiAoIW1pZCkge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoaXRlbS5rZXksICdmYWlsZWQnLCAnTm8gbWFwIGlkIG9uIHRoZSBjb3Vyc2UgcGFnZS4nKVxuXHRcdHJldHVyblxuXHR9XG5cblx0dHJ5IHtcblx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGNvdXJzZUttelVybChtaWQpKVxuXHRcdGlmICghcmVzcG9uc2Uub2spIHRocm93IG5ldyBFcnJvcihgR29vZ2xlIHJlcGxpZWQgJHtyZXNwb25zZS5zdGF0dXN9YClcblxuXHRcdGNvbnN0IGJ5dGVzID0gbmV3IFVpbnQ4QXJyYXkoYXdhaXQgcmVzcG9uc2UuYXJyYXlCdWZmZXIoKSlcblx0XHRpZiAoYnl0ZXNbMF0gIT09IDB4NTAgfHwgYnl0ZXNbMV0gIT09IDB4NGIpIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcignRG93bmxvYWRlZCBmaWxlIGlzIG5vdCBhIEtNWiBhcmNoaXZlJylcblx0XHR9XG5cblx0XHRhd2FpdCBkZWxpdmVyKHtcblx0XHRcdGtpbmQ6ICdjb3Vyc2UnLFxuXHRcdFx0a2V5OiBpdGVtLmtleSxcblx0XHRcdG5hbWU6IGAke2l0ZW0ua2V5fS5rbXpgLFxuXHRcdFx0YmFzZTY0OiB0b0Jhc2U2NChieXRlcyksXG5cdFx0fSlcblx0XHRhd2FpdCBzZXRJdGVtU3RhdHVzKFxuXHRcdFx0aXRlbS5rZXksXG5cdFx0XHQnY2FwdHVyZWQnLFxuXHRcdFx0YEtNWiBkb3dubG9hZGVkICgke01hdGgucm91bmQoYnl0ZXMubGVuZ3RoIC8gMTAyNCl9IEtCKWAsXG5cdFx0KVxuXHR9IGNhdGNoIChlcnJvcikge1xuXHRcdGF3YWl0IHNldEl0ZW1TdGF0dXMoXG5cdFx0XHRpdGVtLmtleSxcblx0XHRcdCdmYWlsZWQnLFxuXHRcdFx0YENvdWxkbid0IGRvd25sb2FkIHRoZSBLTVo6ICR7ZGVzY3JpYmVFcnJvcihlcnJvcil9YCxcblx0XHQpXG5cdH1cbn1cblxuLyoqIFJlbWVtYmVyIGV2ZXJ5IGV2ZW50IGFuIGF0aGxldGUgcGFnZSBtZW50aW9ucywgZm9yIHRoZSBjb3Vyc2UgaHVudC4gKi9cbmFzeW5jIGZ1bmN0aW9uIHJlY29yZEV2ZW50cyhodG1sOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgZXZlbnRzID0gZXh0cmFjdEV2ZW50cyhwYXJzZVJ1blJlc3VsdHMoaHRtbCkpXG5cdGlmIChldmVudHMubGVuZ3RoID09PSAwKSByZXR1cm5cblxuXHRhd2FpdCB1cGRhdGVTZXNzaW9uKChzZXNzaW9uKSA9PiB7XG5cdFx0Y29uc3QgZGlzY292ZXJlZCA9IHsgLi4uc2Vzc2lvbi5kaXNjb3ZlcmVkRXZlbnRzIH1cblx0XHRmb3IgKGNvbnN0IGV2ZW50IG9mIGV2ZW50cykge1xuXHRcdFx0aWYgKCFkaXNjb3ZlcmVkW2V2ZW50LmV2ZW50SWRdKSB7XG5cdFx0XHRcdGRpc2NvdmVyZWRbZXZlbnQuZXZlbnRJZF0gPSB7IG5hbWU6IGV2ZW50Lm5hbWUsIHVybDogZXZlbnQudXJsIH1cblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHsgLi4uc2Vzc2lvbiwgZGlzY292ZXJlZEV2ZW50czogZGlzY292ZXJlZCB9XG5cdH0pXG59XG5cbi8qKlxuICogRXh0ZW5kIHRoZSBxdWV1ZSB3aXRoIGEgY291cnNlIHBhZ2UgcGVyIGV2ZW50IHRoYXQgaGFzIG5vIG1hcCB5ZXQuIFJ1bnMgb25jZSxcbiAqIGFmdGVyIHRoZSBhdGhsZXRlIHBhZ2VzLCBzaW5jZSB0aGF0J3Mgd2hlbiB3ZSBrbm93IHdoaWNoIGV2ZW50cyBleGlzdC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gcXVldWVOZXdDb3Vyc2VzKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLmNvdXJzZXNRdWV1ZWQgfHwgc2Vzc2lvbi5za2lwQ291cnNlcykgcmV0dXJuIGZhbHNlXG5cblx0YXdhaXQgdXBkYXRlU2Vzc2lvbigocykgPT4gKHsgLi4ucywgY291cnNlc1F1ZXVlZDogdHJ1ZSB9KSlcblxuXHRjb25zdCBrbm93biA9IG5ldyBTZXQoc2Vzc2lvbi5rbm93bkNvdXJzZUV2ZW50SWRzKVxuXHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0Y29uc3QgYWxyZWFkeVF1ZXVlZCA9IG5ldyBTZXQoXG5cdFx0c3RhdGUuaXRlbXMuZmlsdGVyKChpKSA9PiBpLmtpbmQgPT09ICdjb3Vyc2UnKS5tYXAoKGkpID0+IGkua2V5KSxcblx0KVxuXG5cdGNvbnN0IGl0ZW1zOiBJdGVtU3RhdGVbXSA9IE9iamVjdC5lbnRyaWVzKHNlc3Npb24uZGlzY292ZXJlZEV2ZW50cylcblx0XHQuZmlsdGVyKChbZXZlbnRJZF0pID0+ICFrbm93bi5oYXMoZXZlbnRJZCkgJiYgIWFscmVhZHlRdWV1ZWQuaGFzKGV2ZW50SWQpKVxuXHRcdC5tYXAoKFtldmVudElkLCBldmVudF0pID0+ICh7XG5cdFx0XHRraW5kOiAnY291cnNlJyBhcyBjb25zdCxcblx0XHRcdGtleTogZXZlbnRJZCxcblx0XHRcdGxhYmVsOiBgJHtldmVudC5uYW1lfSBjb3Vyc2UgbWFwYCxcblx0XHRcdHVybDogY291cnNlUGFnZVVybChldmVudC51cmwpLFxuXHRcdFx0c3RhdHVzOiAncGVuZGluZycgYXMgY29uc3QsXG5cdFx0fSkpXG5cdFx0LnNvcnQoKGEsIGIpID0+IGEubGFiZWwubG9jYWxlQ29tcGFyZShiLmxhYmVsKSlcblxuXHRpZiAoaXRlbXMubGVuZ3RoID09PSAwKSByZXR1cm4gZmFsc2VcblxuXHRjb25zdCBuZXh0ID0gYXdhaXQgYXBwZW5kSXRlbXMoaXRlbXMpXG5cdGF3YWl0IG5vdGlmeVN0YXRlKG5leHQpXG5cdHJldHVybiB0cnVlXG59XG5cbi8vIOKUgOKUgCBGaW5pc2hpbmcg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbmFzeW5jIGZ1bmN0aW9uIGZpbmlzaFJ1bigpOiBQcm9taXNlPFJ1blN0YXRlPiB7XG5cdGF3YWl0IGNhbmNlbFNjaGVkdWxlZFJldHJ5KClcblx0c3RvcEtlZXBhbGl2ZSgpXG5cdGF3YWl0IGNocm9tZS5hbGFybXMuY2xlYXIoV0FUQ0hET0dfQUxBUk0pLmNhdGNoKCgpID0+IHt9KVxuXG5cdC8vIEFueXRoaW5nIG5vdCBpbiBhIHRlcm1pbmFsIHN0YXRlIGF0IHRoaXMgcG9pbnQgbmV2ZXIgY29tcGxldGVkOyBjYWxsIGl0IGFcblx0Ly8gZmFpbHVyZSByYXRoZXIgdGhhbiBxdWlldGx5IHJlcG9ydGluZyBzdWNjZXNzIGZvciBhIHBhZ2Ugd2UgbmV2ZXIgZ290LlxuXHRjb25zdCBzZXR0bGVkID0gYXdhaXQgdXBkYXRlUnVuU3RhdGUoKGN1cnJlbnQpID0+ICh7XG5cdFx0Li4uY3VycmVudCxcblx0XHRpdGVtczogY3VycmVudC5pdGVtcy5tYXAoKGl0ZW0pID0+XG5cdFx0XHRpdGVtLnN0YXR1cyA9PT0gJ2NhcHR1cmVkJyB8fFxuXHRcdFx0aXRlbS5zdGF0dXMgPT09ICdmYWlsZWQnIHx8XG5cdFx0XHRpdGVtLnN0YXR1cyA9PT0gJ3NraXBwZWQnXG5cdFx0XHRcdD8gaXRlbVxuXHRcdFx0XHQ6IHtcblx0XHRcdFx0XHRcdC4uLml0ZW0sXG5cdFx0XHRcdFx0XHRzdGF0dXM6ICdmYWlsZWQnIGFzIGNvbnN0LFxuXHRcdFx0XHRcdFx0ZGV0YWlsOiBpdGVtLmRldGFpbCA/PyAnTmV2ZXIgY29tcGxldGVkLicsXG5cdFx0XHRcdFx0fSxcblx0XHQpLFxuXHR9KSlcblxuXHRjb25zdCBzdGF0ZSA9IHNldHRsZWRcblx0Y29uc3QgY2FwdHVyZWQgPSBzdGF0ZS5pdGVtcy5maWx0ZXIoKGkpID0+IGkuc3RhdHVzID09PSAnY2FwdHVyZWQnKS5sZW5ndGhcblx0Y29uc3QgZmFpbGVkID0gc3RhdGUuaXRlbXMuZmlsdGVyKChpKSA9PiBpLnN0YXR1cyA9PT0gJ2ZhaWxlZCcpLmxlbmd0aFxuXG5cdGNvbnN0IGRvbmU6IFJ1blN0YXRlID0ge1xuXHRcdC4uLnN0YXRlLFxuXHRcdHN0YXR1czogJ2RvbmUnLFxuXHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRmaW5pc2hlZEF0OiBEYXRlLm5vdygpLFxuXHRcdG1lc3NhZ2U6IGZhaWxlZFxuXHRcdFx0PyBgQ2FwdHVyZWQgJHtjYXB0dXJlZH0gb2YgJHtzdGF0ZS5pdGVtcy5sZW5ndGh9OyAke2ZhaWxlZH0gZmFpbGVkLmBcblx0XHRcdDogYENhcHR1cmVkIGFsbCAke2NhcHR1cmVkfSBwYWdlcy5gLFxuXHR9XG5cdC8vIFRoZSB0ZXJtaW5hbCBzdGF0dXMgaXMgd3JpdHRlbiAqYmVmb3JlKiB0aGUgdGFiIGlzIGNsb3NlZC4gQ2xvc2luZyBpdCBmaXJzdFxuXHQvLyBmaXJlcyB0YWJzLm9uUmVtb3ZlZCB3aGlsZSB0aGUgcnVuIHN0aWxsIHJlYWRzIGFzIFwicnVubmluZ1wiLCBhbmQgdGhhdCBoYW5kbGVyXG5cdC8vIHdvdWxkIG92ZXJ3cml0ZSB0aGlzIHdpdGggXCJ0aGUgc2NyYXBlIHRhYiB3YXMgY2xvc2VkXCIg4oCUIHJlcG9ydGluZyBhIGZpbmlzaGVkXG5cdC8vIHNjcmFwZSBhcyBjYW5jZWxsZWQuXG5cdGF3YWl0IHNldFJ1blN0YXRlKGRvbmUpXG5cdGF3YWl0IGNsb3NlU2NyYXBlVGFiKClcblx0YXdhaXQgc2V0QmFkZ2UoZmFpbGVkID8gU3RyaW5nKGZhaWxlZCkgOiAnJylcblx0YXdhaXQgZm9jdXNBZG1pblRhYigpXG5cdGF3YWl0IG5vdGlmeVN0YXRlKGRvbmUpXG5cdGF3YWl0IG5vdGlmeUZpbmlzaGVkKGRvbmUpXG5cdHJldHVybiBkb25lXG59XG5cbi8qKiBEZXRhY2ggYW5kIGNsb3NlIHRoZSBzY3JhcGUgdGFiLiBPbmx5IGNhbGwgb25jZSBhIHRlcm1pbmFsIHN0YXR1cyBpcyBzdG9yZWQuICovXG5hc3luYyBmdW5jdGlvbiBjbG9zZVNjcmFwZVRhYigpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgeyBzY3JhcGVUYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzY3JhcGVUYWJJZCA9PT0gdW5kZWZpbmVkKSByZXR1cm5cblx0YXdhaXQgZGV0YWNoKHNjcmFwZVRhYklkKVxuXHRhd2FpdCBjbGVhckxhc3REb2N1bWVudChzY3JhcGVUYWJJZClcblx0YXdhaXQgY2hyb21lLnRhYnMucmVtb3ZlKHNjcmFwZVRhYklkKS5jYXRjaCgoKSA9PiB7fSlcblx0Ly8gRm9yZ2V0IHRoZSBpZCBhbG9uZyB3aXRoIHRoZSB0YWI6IGl0J3Mgd2hhdCBkZWNpZGVzIHdoZXRoZXIgYSBwYWdlIGdldHMgdGhlXG5cdC8vIG92ZXJsYXksIGFuZCBub3RoaW5nIHNob3VsZCBpbmhlcml0IHRoYXQgYnkgb3BlbmluZyBhIHRhYiBsYXRlci5cblx0YXdhaXQgdXBkYXRlU2Vzc2lvbigoc2Vzc2lvbikgPT4gKHsgLi4uc2Vzc2lvbiwgc2NyYXBlVGFiSWQ6IHVuZGVmaW5lZCB9KSlcbn1cblxuLyoqIFRoZSBydW4gaXMgb3ZlciDigJQgaGFuZCB0aGUgYWRtaW4gcGFnZSBmb2N1cyBiYWNrLiAqL1xuYXN5bmMgZnVuY3Rpb24gZm9jdXNBZG1pblRhYigpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgeyBhZG1pblRhYklkIH0gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKGFkbWluVGFiSWQgPT09IHVuZGVmaW5lZCkgcmV0dXJuXG5cdHRyeSB7XG5cdFx0Y29uc3QgdGFiID0gYXdhaXQgY2hyb21lLnRhYnMuZ2V0KGFkbWluVGFiSWQpXG5cdFx0YXdhaXQgY2hyb21lLnRhYnMudXBkYXRlKGFkbWluVGFiSWQsIHsgYWN0aXZlOiB0cnVlIH0pXG5cdFx0aWYgKHRhYi53aW5kb3dJZCAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRhd2FpdCBjaHJvbWUud2luZG93cy51cGRhdGUodGFiLndpbmRvd0lkLCB7IGZvY3VzZWQ6IHRydWUgfSlcblx0XHR9XG5cdH0gY2F0Y2gge1xuXHRcdC8vIFRoZSBhZG1pbiB0YWIgd2FzIGNsb3NlZDsgZmlsZXMgc3RheSBpbiBzdG9yYWdlIGZvciB0aGUgbmV4dCB2aXNpdC5cblx0fVxufVxuXG5hc3luYyBmdW5jdGlvbiBub3RpZnlGaW5pc2hlZChzdGF0ZTogUnVuU3RhdGUpOiBQcm9taXNlPHZvaWQ+IHtcblx0Y29uc3QgeyBhZG1pblRhYklkIH0gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0aWYgKGFkbWluVGFiSWQgPT09IHVuZGVmaW5lZCkgcmV0dXJuXG5cdGF3YWl0IGNocm9tZS50YWJzXG5cdFx0LnNlbmRNZXNzYWdlKGFkbWluVGFiSWQsIHsgdHlwZTogJ2ZpbmlzaGVkJywgc3RhdGUgfSlcblx0XHQuY2F0Y2goKCkgPT4ge30pXG59XG5cbi8vIOKUgOKUgCBEZWxpdmVyeSDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuLyoqIFBlcnNpc3QgYSBjYXB0dXJlZCBmaWxlIGFuZCBwdXNoIGl0IHRvIHRoZSBhZG1pbiBwYWdlIHN0cmFpZ2h0IGF3YXkuICovXG5hc3luYyBmdW5jdGlvbiBkZWxpdmVyKGZpbGU6IENhcHR1cmVkRmlsZSk6IFByb21pc2U8dm9pZD4ge1xuXHRhd2FpdCBwdXRGaWxlKGZpbGUpXG5cdGF3YWl0IG5vdGlmeUZpbGUoZmlsZSlcbn1cblxuLyoqIFJlLXNlbmQgZXZlcnl0aGluZyBjYXB0dXJlZCBzbyBmYXIsIGUuZy4gYWZ0ZXIgdGhlIGFkbWluIHBhZ2UgcmVsb2FkZWQuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gcmVzZW5kRmlsZXMoKTogUHJvbWlzZTx2b2lkPiB7XG5cdGZvciAoY29uc3QgZmlsZSBvZiBhd2FpdCBnZXRGaWxlcygpKSBhd2FpdCBub3RpZnlGaWxlKGZpbGUpXG59XG5cbmZ1bmN0aW9uIGZpbGVOYW1lRm9yKGtpbmQ6IENhcHR1cmVkRmlsZVsna2luZCddLCBrZXk6IHN0cmluZyk6IHN0cmluZyB7XG5cdHN3aXRjaCAoa2luZCkge1xuXHRcdGNhc2UgJ2F0aGxldGUnOlxuXHRcdFx0cmV0dXJuIGBhdGhsZXRlLSR7a2V5fS5odG1sYFxuXHRcdGNhc2UgJ2V2ZW50Jzpcblx0XHRcdHJldHVybiBgJHtrZXl9LWxhdGVzdC1yZXN1bHRzLmh0bWxgXG5cdFx0Y2FzZSAnY2x1YnMnOlxuXHRcdFx0cmV0dXJuICdsYXJnZXN0LWNsdWJzLmh0bWwnXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiBgJHtrZXl9LmttemBcblx0fVxufVxuXG5mdW5jdGlvbiB0b0Jhc2U2NChieXRlczogVWludDhBcnJheSk6IHN0cmluZyB7XG5cdGxldCBiaW5hcnkgPSAnJ1xuXHQvLyBDaHVua2VkIHRvIHN0YXkgd2VsbCBjbGVhciBvZiB0aGUgYXJndW1lbnQgbGltaXQgb24gbGFyZ2UgYXJjaGl2ZXMuXG5cdGZvciAobGV0IGkgPSAwOyBpIDwgYnl0ZXMubGVuZ3RoOyBpICs9IDB4ODAwMCkge1xuXHRcdGJpbmFyeSArPSBTdHJpbmcuZnJvbUNoYXJDb2RlKC4uLmJ5dGVzLnN1YmFycmF5KGksIGkgKyAweDgwMDApKVxuXHR9XG5cdHJldHVybiBidG9hKGJpbmFyeSlcbn1cblxuYXN5bmMgZnVuY3Rpb24gc2V0QmFkZ2UodGV4dDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG5cdGF3YWl0IGNocm9tZS5hY3Rpb24uc2V0QmFkZ2VUZXh0KHsgdGV4dCB9KS5jYXRjaCgoKSA9PiB7fSlcbn1cbiIsIi8qKlxuICogQSBvbmUtYXQtYS10aW1lIHF1ZXVlLlxuICpcbiAqIENhcHR1cmVzIGFyZSB0cmlnZ2VyZWQgZnJvbSB0d28gcGxhY2VzIOKAlCB0aGUgZGVidWdnZXIncyBgbG9hZGluZ0ZpbmlzaGVkYCBhbmRcbiAqIGB0YWJzLm9uVXBkYXRlZGAg4oCUIGJlY2F1c2UgbmVpdGhlciBpcyByZWxpYWJsZSBlbm91Z2ggYWxvbmUuIFRoYXQgbWVhbnMgYm90aFxuICogY2FuIGZpcmUgZm9yIHRoZSBzYW1lIHBhZ2UgbG9hZCwgYW5kIGlmIHRoZXkgaW50ZXJsZWF2ZSB0aGV5IGVhY2ggY2FwdHVyZSBhbmRcbiAqIGVhY2ggY2FsbCBgYWR2YW5jZSgpYCwgd2hpY2ggd2Fsa3MgdGhlIHF1ZXVlIHR3aWNlIGFuZCBzaWxlbnRseSBza2lwcyBhbiBpdGVtLlxuICpcbiAqIEV2ZXJ5dGhpbmcgdGhhdCByZWFkcy10aGVuLXdyaXRlcyBydW4gc3RhdGUgZ29lcyB0aHJvdWdoIGhlcmUgc28gdGhhdCBjYW4ndFxuICogaGFwcGVuLiBUaGUgY2hhaW4gbGl2ZXMgaW4gbW9kdWxlIHNjb3BlLCB3aGljaCByZXNldHMgd2hlbiB0aGUgc2VydmljZSB3b3JrZXJcbiAqIHJlc3RhcnRzIOKAlCBmaW5lLCBiZWNhdXNlIG9yZGVyaW5nIG9ubHkgbWF0dGVycyB3aXRoaW4gYSBidXJzdCBvZiBldmVudHMuXG4gKi9cbmxldCBjaGFpbjogUHJvbWlzZTx1bmtub3duPiA9IFByb21pc2UucmVzb2x2ZSgpXG5cbmV4cG9ydCBmdW5jdGlvbiBzZXJpYWw8VD4od29yazogKCkgPT4gUHJvbWlzZTxUPik6IFByb21pc2U8VD4ge1xuXHRjb25zdCBuZXh0ID0gY2hhaW4udGhlbih3b3JrLCB3b3JrKVxuXHQvLyBTd2FsbG93IHJlamVjdGlvbnMgb24gdGhlIGNoYWluIGl0c2VsZiBzbyBvbmUgZmFpbHVyZSBjYW4ndCBwb2lzb24gdGhlIHF1ZXVlO1xuXHQvLyB0aGUgcmV0dXJuZWQgcHJvbWlzZSBzdGlsbCByZWplY3RzIGZvciB0aGUgY2FsbGVyLlxuXHRjaGFpbiA9IG5leHQuY2F0Y2goKCkgPT4gdW5kZWZpbmVkKVxuXHRyZXR1cm4gbmV4dFxufVxuIiwiLyoqXG4gKiBTZXJ2aWNlIHdvcmtlcjogdGhlIGV4dGVuc2lvbidzIG9ubHkgbG9uZy1saXZlZCBsb2dpYywgZXhjZXB0IGl0IGlzbid0XG4gKiBsb25nLWxpdmVkIGF0IGFsbCDigJQgQ2hyb21lIHRlcm1pbmF0ZXMgaXQgd2hlbmV2ZXIgaXQgZ29lcyBpZGxlLlxuICpcbiAqIEV2ZXJ5IGxpc3RlbmVyIGJlbG93IGlzIHJlZ2lzdGVyZWQgc3luY2hyb25vdXNseSBhdCB0aGUgdG9wIGxldmVsLiBUaGF0J3Mgd2hhdFxuICogbWFrZXMgdGhlIHJ1biBzdXJ2aXZlOiBhIHJlZ2lzdGVyZWQgbGlzdGVuZXIgY2F1c2VzIENocm9tZSB0byAqc3RhcnQqIHRoZVxuICogd29ya2VyIHRvIGRlbGl2ZXIgaXRzIGV2ZW50LCBzbyB0aGUgZGVidWdnZXIgZXZlbnRzIGFuZCBtZXNzYWdlcyB0aGF0IGRyaXZlIGFcbiAqIHJ1biB3YWtlIGl0IGJhY2sgdXAuIEFsbCBzdGF0ZSBsaXZlcyBpbiBjaHJvbWUuc3RvcmFnZSAoc2VlIHN0YXRlLnRzKSwgbmV2ZXJcbiAqIGluIG1vZHVsZSBzY29wZS5cbiAqL1xuaW1wb3J0IHtcblx0dHlwZSBQYWdlTWVzc2FnZSxcblx0U0NSQVBFUl9QUk9UT0NPTF9WRVJTSU9OLFxuXHRlbXB0eVJ1blN0YXRlLFxufSBmcm9tICdAc2hhcmVkL3NjcmFwZXItcHJvdG9jb2wnXG5pbXBvcnQgeyBkZXRhY2gsIG5vdGVEb2N1bWVudFJlc3BvbnNlLCBub3RlTG9hZGluZ0ZpbmlzaGVkIH0gZnJvbSAnLi9jYXB0dXJlJ1xuaW1wb3J0IHtcblx0aXNGcm9tQWRtaW5QYWdlLFxuXHRvcGVuQWRtaW5QYWdlLFxuXHRyZW1lbWJlckFkbWluT3JpZ2luLFxufSBmcm9tICcuL29wZW5BZG1pbidcbmltcG9ydCB7XG5cdGFkdmFuY2UsXG5cdGNhbmNlbFJ1bixcblx0Y2hlY2tGb3JTdGFsbCxcblx0Zm9yZ2V0UnVuLFxuXHRoYW5kbGVEb2N1bWVudExvYWRlZCxcblx0cmVjb3Zlck1pc3NlZENhcHR1cmUsXG5cdHJlc2VuZEZpbGVzLFxuXHRyZXN1bWVSdW4sXG5cdHJldHJ5Q3VycmVudCxcblx0cmV0cnlJZlN0aWxsQmxvY2tlZCxcblx0c2tpcEN1cnJlbnQsXG5cdHN0YXJ0UnVuLFxufSBmcm9tICcuL3J1bidcbmltcG9ydCB7IHNlcmlhbCB9IGZyb20gJy4vc2VyaWFsJ1xuaW1wb3J0IHsgZ2V0UnVuU3RhdGUsIGdldFNlc3Npb24sIHNldFJ1blN0YXRlIH0gZnJvbSAnLi9zdGF0ZSdcblxuLy8g4pSA4pSAIE1lc3NhZ2VzIGZyb20gY29udGVudCBzY3JpcHRzIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKG1lc3NhZ2UsIHNlbmRlciwgc2VuZFJlc3BvbnNlKSA9PiB7XG5cdC8vIE5vdGUgd2hlcmUgdGhlIGFkbWluIHBhZ2UgbGl2ZXMsIHNvIHRoZSB0b29sYmFyIGljb24gY2FuIHJlb3BlbiBpdC4gQnJpZGdlXG5cdC8vIHRyYWZmaWMgb25seSDigJQgdGhlIG92ZXJsYXkncyBtZXNzYWdlcyBjb21lIGZyb20gcGFya3J1biBwYWdlcy5cblx0aWYgKGlzRnJvbUFkbWluUGFnZShtZXNzYWdlKSkge1xuXHRcdHZvaWQgcmVtZW1iZXJBZG1pbk9yaWdpbihzZW5kZXIudXJsID8/IHNlbmRlci5vcmlnaW4pXG5cdH1cblxuXHQvLyBSZXR1cm5pbmcgdHJ1ZSBrZWVwcyB0aGUgcmVzcG9uc2UgY2hhbm5lbCBvcGVuIGZvciB0aGUgYXN5bmMgd29yayBiZWxvdy5cblx0aGFuZGxlTWVzc2FnZShtZXNzYWdlIGFzIFBhZ2VNZXNzYWdlIHwgeyB0eXBlOiBzdHJpbmcgfSwgc2VuZGVyKVxuXHRcdC50aGVuKHNlbmRSZXNwb25zZSlcblx0XHQuY2F0Y2goKGVycm9yKSA9PiBzZW5kUmVzcG9uc2UoeyBlcnJvcjogU3RyaW5nKGVycm9yKSB9KSlcblx0cmV0dXJuIHRydWVcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZU1lc3NhZ2UoXG5cdG1lc3NhZ2U6IFBhZ2VNZXNzYWdlIHwgeyB0eXBlOiBzdHJpbmcgfSxcblx0c2VuZGVyOiB7IHRhYj86IHsgaWQ/OiBudW1iZXIgfSB9LFxuKTogUHJvbWlzZTx1bmtub3duPiB7XG5cdHN3aXRjaCAobWVzc2FnZS50eXBlKSB7XG5cdFx0Y2FzZSAncGluZyc6XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR0eXBlOiAnaGVsbG8nLFxuXHRcdFx0XHR2ZXJzaW9uOiBTQ1JBUEVSX1BST1RPQ09MX1ZFUlNJT04sXG5cdFx0XHRcdHN0YXRlOiBhd2FpdCBnZXRSdW5TdGF0ZSgpLFxuXHRcdFx0fVxuXG5cdFx0LyoqXG5cdFx0ICogQXNrZWQgYnkgdGhlIG92ZXJsYXksIHdoaWNoIGlzIGluamVjdGVkIGludG8gZXZlcnkgcGFya3J1biBwYWdlIOKAlCBidXRcblx0XHQgKiBvbmx5IHRoZSBzY3JhcGUgdGFiIGlzIHBhcnQgb2YgYSBydW4uIEEgcnVuJ3Mgc3RhdGUgb3V0bGl2ZXMgdGhlIHJ1blxuXHRcdCAqICh0aGUgYWRtaW4gcGFnZSBjYW4gc3RpbGwgYXNrIGZvciBpdHMgZmlsZXMpLCBzbyBhbnN3ZXJpbmcgZXZlcnkgdGFiXG5cdFx0ICogbWVhbnQgYSBwYWdlIG9wZW5lZCBieSBoYW5kIGRheXMgbGF0ZXIgc3RpbGwgZ290IFwiU2NyYXBlIGNvbXBsZXRlXCIuXG5cdFx0ICovXG5cdFx0Y2FzZSAnc3RhdGU/Jzoge1xuXHRcdFx0Y29uc3QgeyBzY3JhcGVUYWJJZCB9ID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdFx0XHRjb25zdCBpblNjcmFwZVRhYiA9XG5cdFx0XHRcdHNlbmRlci50YWI/LmlkICE9PSB1bmRlZmluZWQgJiYgc2VuZGVyLnRhYi5pZCA9PT0gc2NyYXBlVGFiSWRcblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdHR5cGU6ICdzdGF0ZScsXG5cdFx0XHRcdHN0YXRlOiBpblNjcmFwZVRhYiA/IGF3YWl0IGdldFJ1blN0YXRlKCkgOiBlbXB0eVJ1blN0YXRlKCksXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Y2FzZSAnc3RhcnQnOiB7XG5cdFx0XHRjb25zdCBhZG1pblRhYklkID0gc2VuZGVyLnRhYj8uaWRcblx0XHRcdGlmIChhZG1pblRhYklkID09PSB1bmRlZmluZWQpIHJldHVybiB7IGVycm9yOiAnTm8gY2FsbGluZyB0YWInIH1cblx0XHRcdGNvbnN0IHJlcXVlc3QgPSAobWVzc2FnZSBhcyBFeHRyYWN0PFBhZ2VNZXNzYWdlLCB7IHR5cGU6ICdzdGFydCcgfT4pXG5cdFx0XHRcdC5yZXF1ZXN0XG5cdFx0XHRjb25zdCBzdGF0ZSA9IGF3YWl0IHN0YXJ0UnVuKHJlcXVlc3QsIGFkbWluVGFiSWQpXG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZSB9XG5cdFx0fVxuXG5cdFx0Y2FzZSAncmVzdW1lJzoge1xuXHRcdFx0Y29uc3QgYWRtaW5UYWJJZCA9IHNlbmRlci50YWI/LmlkXG5cdFx0XHRpZiAoYWRtaW5UYWJJZCA9PT0gdW5kZWZpbmVkKSByZXR1cm4geyBlcnJvcjogJ05vIGNhbGxpbmcgdGFiJyB9XG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZTogYXdhaXQgcmVzdW1lUnVuKGFkbWluVGFiSWQpIH1cblx0XHR9XG5cblx0XHRjYXNlICdjYW5jZWwnOlxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGNhbmNlbFJ1bigpIH1cblxuXHRcdGNhc2UgJ3JldHJ5Jzpcblx0XHRcdHJldHVybiB7IHR5cGU6ICdzdGF0ZScsIHN0YXRlOiBhd2FpdCByZXRyeUN1cnJlbnQoKSB9XG5cblx0XHRjYXNlICdza2lwJzpcblx0XHRcdHJldHVybiB7IHR5cGU6ICdzdGF0ZScsIHN0YXRlOiBhd2FpdCBza2lwQ3VycmVudCgpIH1cblxuXHRcdGNhc2UgJ3Jlc2VuZCc6XG5cdFx0XHRhd2FpdCByZXNlbmRGaWxlcygpXG5cdFx0XHRyZXR1cm4geyB0eXBlOiAnc3RhdGUnLCBzdGF0ZTogYXdhaXQgZ2V0UnVuU3RhdGUoKSB9XG5cblx0XHRjYXNlICdjbGVhcic6XG5cdFx0XHRhd2FpdCBmb3JnZXRSdW4oKVxuXHRcdFx0cmV0dXJuIHsgdHlwZTogJ3N0YXRlJywgc3RhdGU6IGF3YWl0IGdldFJ1blN0YXRlKCkgfVxuXG5cdFx0ZGVmYXVsdDpcblx0XHRcdHJldHVybiB7IGVycm9yOiBgVW5rbm93biBtZXNzYWdlOiAke21lc3NhZ2UudHlwZX1gIH1cblx0fVxufVxuXG4vLyDilIDilIAgRGVidWdnZXIgZXZlbnRzOiBob3cgcGFnZXMgZ2V0IGNhcHR1cmVkIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgFxuXG4vKipcbiAqIERlYnVnZ2VyIGV2ZW50cyBhcmUgaGFuZGxlZCBzdHJpY3RseSBvbmUgYXQgYSB0aW1lLlxuICpcbiAqIGByZXNwb25zZVJlY2VpdmVkYCByZWNvcmRzIHRoZSBtYWluIGRvY3VtZW50J3MgcmVxdWVzdCBJRCBhbmRcbiAqIGBsb2FkaW5nRmluaXNoZWRgIGxvb2tzIGl0IHVwLCBib3RoIHZpYSBhc3luYyBzdG9yYWdlLiBIYW5kbGVkIGNvbmN1cnJlbnRseSxcbiAqIHRoZSBsb29rdXAgY2FuIHJ1biBiZWZvcmUgdGhlIHdyaXRlIGxhbmRzIOKAlCBhbmQgYmVjYXVzZSBvbmx5IHRoZSBtYWluXG4gKiBkb2N1bWVudCdzIGBsb2FkaW5nRmluaXNoZWRgIHRyaWdnZXJzIGEgY2FwdHVyZSwgbWlzc2luZyB0aGF0IG9uZSBldmVudCBzdGFsbHNcbiAqIHRoZSBydW4gcGVybWFuZW50bHkgd2l0aCBub3RoaW5nIHRvIHNob3cgd2h5LiBUaGUgdHdvIGV2ZW50cyBhcnJpdmUgd2l0aGluXG4gKiBtaWNyb3NlY29uZHMgb2YgZWFjaCBvdGhlciBvbiBhIGZhc3QgcGFnZSwgc28gdGhpcyB3YXMgbG9zaW5nIHJhY2VzLlxuICovXG5jaHJvbWUuZGVidWdnZXIub25FdmVudC5hZGRMaXN0ZW5lcigoc291cmNlLCBtZXRob2QsIHBhcmFtcykgPT4ge1xuXHRpZiAoc291cmNlLnRhYklkID09PSB1bmRlZmluZWQgfHwgIXBhcmFtcykgcmV0dXJuXG5cdGNvbnN0IHRhYklkID0gc291cmNlLnRhYklkXG5cdHZvaWQgc2VyaWFsKCgpID0+IGhhbmRsZURlYnVnZ2VyRXZlbnQodGFiSWQsIG1ldGhvZCwgcGFyYW1zKSkuY2F0Y2goXG5cdFx0KGVycm9yKSA9PiB7XG5cdFx0XHRjb25zb2xlLmVycm9yKCdbcmVzdWx0cy1zY3JhcGVyXSBldmVudCBoYW5kbGluZyBmYWlsZWQnLCBtZXRob2QsIGVycm9yKVxuXHRcdH0sXG5cdClcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURlYnVnZ2VyRXZlbnQoXG5cdHRhYklkOiBudW1iZXIsXG5cdG1ldGhvZDogc3RyaW5nLFxuXHRwYXJhbXM6IFJlY29yZDxzdHJpbmcsIHVua25vd24+LFxuKTogUHJvbWlzZTx2b2lkPiB7XG5cdGlmIChtZXRob2QgPT09ICdOZXR3b3JrLnJlc3BvbnNlUmVjZWl2ZWQnKSB7XG5cdFx0YXdhaXQgbm90ZURvY3VtZW50UmVzcG9uc2UodGFiSWQsIHBhcmFtcylcblx0XHRyZXR1cm5cblx0fVxuXG5cdGlmIChtZXRob2QgPT09ICdOZXR3b3JrLmxvYWRpbmdGaW5pc2hlZCcpIHtcblx0XHRjb25zdCBkb2N1bWVudCA9IGF3YWl0IG5vdGVMb2FkaW5nRmluaXNoZWQodGFiSWQsIHBhcmFtcylcblx0XHQvLyBPbmx5IHRoZSBtYWluLWZyYW1lIGRvY3VtZW50IHByb2R1Y2VzIGEgbWF0Y2ggaGVyZTsgZXZlcnl0aGluZyBlbHNlIG9uXG5cdFx0Ly8gdGhlIHBhZ2UgZmluaXNoZXMgbG9hZGluZyB0b28gYW5kIGlzIGlnbm9yZWQuXG5cdFx0aWYgKGRvY3VtZW50KSBhd2FpdCBoYW5kbGVEb2N1bWVudExvYWRlZCh0YWJJZClcblx0fVxufVxuXG4vKipcbiAqIENocm9tZSBkZXRhY2hlcyB1cyBpZiB0aGUgdXNlciBvcGVucyBEZXZUb29scyBvbiB0aGUgc2NyYXBlIHRhYiwgb3IgY2xpY2tzXG4gKiBcImNhbmNlbFwiIG9uIHRoZSBkZWJ1Z2dpbmcgbm90aWNlLiBXaXRob3V0IHRoZSBkZWJ1Z2dlciB0aGVyZSdzIG5vIHdheSB0byByZWFkXG4gKiByYXcgSFRNTCwgc28gdGhlIHJ1biBjYW4ndCBjb250aW51ZS5cbiAqL1xuY2hyb21lLmRlYnVnZ2VyLm9uRGV0YWNoLmFkZExpc3RlbmVyKChzb3VyY2UsIHJlYXNvbikgPT4ge1xuXHR2b2lkIGhhbmRsZURldGFjaChzb3VyY2UudGFiSWQsIHJlYXNvbilcbn0pXG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZURldGFjaCh0YWJJZDogbnVtYmVyLCByZWFzb246IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuXHRjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbigpXG5cdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuXG5cblx0YXdhaXQgc2V0UnVuU3RhdGUoe1xuXHRcdC4uLnN0YXRlLFxuXHRcdHN0YXR1czogJ2Vycm9yJyxcblx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0ZmluaXNoZWRBdDogRGF0ZS5ub3coKSxcblx0XHRtZXNzYWdlOiBgTG9zdCB0aGUgZGVidWdnZXIgY29ubmVjdGlvbiAoJHtyZWFzb259KS5gLFxuXHR9KVxuXHRhd2FpdCBjaHJvbWUuYWN0aW9uLnNldEJhZGdlVGV4dCh7IHRleHQ6ICchJyB9KS5jYXRjaCgoKSA9PiB7fSlcbn1cblxuLy8g4pSA4pSAIFRhYiBjbG9zZWQgbWlkLXJ1biDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcblxuY2hyb21lLnRhYnMub25SZW1vdmVkLmFkZExpc3RlbmVyKCh0YWJJZCkgPT4ge1xuXHQvLyBTZXJpYWxpc2VkIHdpdGggdGhlIHJlc3Qgb2YgdGhlIHN0YXRlIG1hY2hpbmU6IHRoaXMgdXNlZCB0byByYWNlIGZpbmlzaFJ1blxuXHQvLyBhbmQgY2xvYmJlciBhIGNvbXBsZXRlZCBydW4ncyBzdGF0dXMuXG5cdHZvaWQgc2VyaWFsKCgpID0+IGhhbmRsZVRhYlJlbW92ZWQodGFiSWQpKVxufSlcblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlVGFiUmVtb3ZlZCh0YWJJZDogbnVtYmVyKTogUHJvbWlzZTx2b2lkPiB7XG5cdGNvbnN0IHNlc3Npb24gPSBhd2FpdCBnZXRTZXNzaW9uKClcblx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdGlmIChzdGF0ZS5zdGF0dXMgIT09ICdydW5uaW5nJykgcmV0dXJuXG5cblx0aWYgKHNlc3Npb24uc2NyYXBlVGFiSWQgPT09IHRhYklkKSB7XG5cdFx0YXdhaXQgZGV0YWNoKHRhYklkKVxuXHRcdGF3YWl0IHNldFJ1blN0YXRlKHtcblx0XHRcdC4uLnN0YXRlLFxuXHRcdFx0c3RhdHVzOiAnY2FuY2VsbGVkJyxcblx0XHRcdGN1cnJlbnRLZXk6IHVuZGVmaW5lZCxcblx0XHRcdGZpbmlzaGVkQXQ6IERhdGUubm93KCksXG5cdFx0XHRtZXNzYWdlOiAnVGhlIHNjcmFwZSB0YWIgd2FzIGNsb3NlZC4nLFxuXHRcdH0pXG5cdFx0YXdhaXQgY2hyb21lLmFjdGlvbi5zZXRCYWRnZVRleHQoeyB0ZXh0OiAnJyB9KS5jYXRjaCgoKSA9PiB7fSlcblx0fVxufVxuXG4vLyDilIDilIAgUmVjb3Zlcnkg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAXG5cbi8qKlxuICogSWYgdGhlIGJyb3dzZXIgcmVzdGFydGVkIG1pZC1ydW4gdGhlcmUncyBubyB0YWIgYW5kIG5vIGRlYnVnZ2VyIGxlZnQsIHNvIHRoZVxuICogcnVuIGNhbid0IGJlIHJlc3VtZWQg4oCUIGJ1dCB3aGF0ZXZlciB3YXMgY2FwdHVyZWQgaXMgc3RpbGwgaW4gc3RvcmFnZSBhbmQgdGhlXG4gKiBhZG1pbiBwYWdlIGNhbiBzdGlsbCBhc2sgZm9yIGl0LlxuICovXG5jaHJvbWUucnVudGltZS5vblN0YXJ0dXAuYWRkTGlzdGVuZXIoKCkgPT4ge1xuXHR2b2lkIChhc3luYyAoKSA9PiB7XG5cdFx0Y29uc3Qgc3RhdGUgPSBhd2FpdCBnZXRSdW5TdGF0ZSgpXG5cdFx0aWYgKHN0YXRlLnN0YXR1cyAhPT0gJ3J1bm5pbmcnKSByZXR1cm5cblx0XHRhd2FpdCBzZXRSdW5TdGF0ZSh7XG5cdFx0XHQuLi5zdGF0ZSxcblx0XHRcdHN0YXR1czogJ2NhbmNlbGxlZCcsXG5cdFx0XHRjdXJyZW50S2V5OiB1bmRlZmluZWQsXG5cdFx0XHRtZXNzYWdlOiAnSW50ZXJydXB0ZWQgd2hlbiB0aGUgYnJvd3NlciBjbG9zZWQuJyxcblx0XHR9KVxuXHR9KSgpXG59KVxuXG4vKipcbiAqIFRoZSBzY3JhcGUgdGFiIGZpbmlzaGVkIGxvYWRpbmcuXG4gKlxuICogVGhpcyBpcyB0aGUgZGVwZW5kYWJsZSB0cmlnZ2VyIOKAlCB1bmxpa2UgY2hyb21lLmRlYnVnZ2VyIGV2ZW50cywgdGFicy5vblVwZGF0ZWRcbiAqIGlzIGFsd2F5cyBkZWxpdmVyZWQgYW5kIGFsd2F5cyB3YWtlcyB0aGUgd29ya2VyLiBJdCBydW5zIHRoZSBzYW1lIGNhcHR1cmUgcGF0aCxcbiAqIHNvIHdoaWNoZXZlciBzaWduYWwgYXJyaXZlcyBmaXJzdCB3aXRoIGEgcmVhZGFibGUgYm9keSB3aW5zLlxuICovXG5jaHJvbWUudGFicy5vblVwZGF0ZWQuYWRkTGlzdGVuZXIoKHRhYklkLCBpbmZvKSA9PiB7XG5cdGlmIChpbmZvLnN0YXR1cyAhPT0gJ2NvbXBsZXRlJykgcmV0dXJuXG5cdHZvaWQgKGFzeW5jICgpID0+IHtcblx0XHRjb25zdCBzdGF0ZSA9IGF3YWl0IGdldFJ1blN0YXRlKClcblx0XHRpZiAoc3RhdGUuc3RhdHVzICE9PSAncnVubmluZycpIHJldHVyblxuXG5cdFx0Y29uc3Qgc2Vzc2lvbiA9IGF3YWl0IGdldFNlc3Npb24oKVxuXHRcdGlmIChzZXNzaW9uLnNjcmFwZVRhYklkICE9PSB0YWJJZCkgcmV0dXJuXG5cblx0XHQvLyBObyBjdXJyZW50IGl0ZW0gbWVhbnMgdGhlIHdvcmtlciBkaWVkIGJldHdlZW4gaXRlbXM7IHBpY2sgdGhlIHF1ZXVlIGJhY2sgdXAuXG5cdFx0aWYgKCFzdGF0ZS5jdXJyZW50S2V5KSB7XG5cdFx0XHRhd2FpdCBzZXJpYWwoKCkgPT4gYWR2YW5jZSgpKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0YXdhaXQgc2VyaWFsKCgpID0+IGhhbmRsZURvY3VtZW50TG9hZGVkKHRhYklkKSlcblxuXHRcdC8vIFRoZSBwYWdlIGlzIGxvYWRlZC4gSWYgdGhhdCBkaWRuJ3QgcHJvZHVjZSBhIGNhcHR1cmUsIGl0cyBOZXR3b3JrIGV2ZW50c1xuXHRcdC8vIHdlcmUgbG9zdCBhbmQgbm8gYW1vdW50IG9mIHdhaXRpbmcgd2lsbCBicmluZyB0aGVtIGJhY2sg4oCUIHJlbG9hZCBub3dcblx0XHQvLyByYXRoZXIgdGhhbiBsZXR0aW5nIHRoZSB3YXRjaGRvZyBub3RpY2UgaW4gMjAgc2Vjb25kcy5cblx0XHRhd2FpdCBzZXJpYWwoKCkgPT4gcmVjb3Zlck1pc3NlZENhcHR1cmUodGFiSWQpKVxuXHR9KSgpXG59KVxuXG4vKipcbiAqIEEgYmxvY2tlZCBwYWdlIHRoYXQgbm9ib2R5IGhhcyBjbGVhcmVkLiBSZWxvYWQgaXQg4oCUIGEgZmxhdCA0MDMgb2Z0ZW4gcGFzc2VzIG9uXG4gKiBhIHNlY29uZCB0cnksIGFuZCBhIGNoYWxsZW5nZSB0aGUgdXNlciBhbHJlYWR5IHNvbHZlZCB3aWxsIGhhdmUgbmF2aWdhdGVkIGF3YXlcbiAqIGJ5IG5vdywgaW4gd2hpY2ggY2FzZSB0aGlzIGRvZXMgbm90aGluZy5cbiAqL1xuY2hyb21lLmFsYXJtcy5vbkFsYXJtLmFkZExpc3RlbmVyKChhbGFybSkgPT4ge1xuXHRpZiAoYWxhcm0ubmFtZSA9PT0gJ3JldHJ5LWJsb2NrZWQnKSB7XG5cdFx0dm9pZCBzZXJpYWwoKCkgPT4gcmV0cnlJZlN0aWxsQmxvY2tlZCgpKVxuXHRcdHJldHVyblxuXHR9XG5cdC8vIFRoZSB3YXRjaGRvZzogY2F0Y2hlcyBhIHBhZ2Ugd2hvc2UgbG9hZCBldmVudHMgbmV2ZXIgYXJyaXZlZCwgd2hpY2ggd291bGRcblx0Ly8gb3RoZXJ3aXNlIGxlYXZlIHRoZSBydW4gc2l0dGluZyBvbiBcIkxvYWRpbmfigKZcIiBmb3JldmVyLlxuXHRpZiAoYWxhcm0ubmFtZSA9PT0gJ3dhdGNoZG9nJykge1xuXHRcdHZvaWQgc2VyaWFsKCgpID0+IGNoZWNrRm9yU3RhbGwoKSlcblx0fVxufSlcblxuLy8gTm8gZGVmYXVsdF9wb3B1cCBpbiB0aGUgbWFuaWZlc3QsIHNvIHRoZSBpY29uIGNsaWNrIGNvbWVzIGhlcmUuXG5jaHJvbWUuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcigoKSA9PiB7XG5cdHZvaWQgb3BlbkFkbWluUGFnZSgpXG59KVxuXG5jaHJvbWUuYWN0aW9uLnNldEJhZGdlQmFja2dyb3VuZENvbG9yKHsgY29sb3I6ICcjM2Y2ZDNhJyB9KS5jYXRjaCgoKSA9PiB7fSlcbiJdLCJuYW1lcyI6WyJvcmlnaW4iLCJzdGF0ZSIsImF0dGVtcHRzIl0sIm1hcHBpbmdzIjoiQUFlTyxNQUFNLDJCQUEyQjtBQXVFakMsU0FBUyxnQkFBMEI7QUFDekMsU0FBTyxFQUFFLFFBQVEsUUFBUSxPQUFPLENBQUEsRUFBQztBQUNsQztBQ25FQSxNQUFNLG1CQUFtQjtBQUV6QixNQUFNLFVBQVU7QUFvQ2hCLGVBQXNCLE9BQU8sT0FBOEI7QUFDMUQsTUFBSTtBQUNILFVBQU0sT0FBTyxTQUFTLE9BQU8sRUFBRSxNQUFBLEdBQVMsZ0JBQWdCO0FBQUEsRUFDekQsU0FBUyxPQUFPO0FBRWYsUUFBSSxDQUFDLG9CQUFvQixLQUFLLGNBQWMsS0FBSyxDQUFDLEVBQUcsT0FBTTtBQUFBLEVBQzVEO0FBSUEsUUFBTSxPQUFPLFNBQVMsWUFBWSxFQUFFLE1BQUEsR0FBUyxnQkFBZ0I7QUFDOUQ7QUFFQSxlQUFzQixPQUFPLE9BQThCO0FBQzFELE1BQUk7QUFDSCxVQUFNLE9BQU8sU0FBUyxPQUFPLEVBQUUsT0FBTztBQUFBLEVBQ3ZDLFFBQVE7QUFBQSxFQUVSO0FBQ0Q7QUFHQSxlQUFzQixlQUFlLE9BQThCO0FBQ2xFLE1BQUk7QUFDSCxVQUFNLE9BQU8sS0FBSztBQUFBLEVBQ25CLFNBQVMsT0FBTztBQUNmLFVBQU0sSUFBSTtBQUFBLE1BQ1QsbURBQW1ELGNBQWMsS0FBSyxDQUFDO0FBQUEsSUFBQTtBQUFBLEVBRXpFO0FBQ0Q7QUFRQSxlQUFzQixxQkFDckIsT0FDQSxRQUNnQjtBQUNoQixNQUFJLE9BQU8sU0FBUyxXQUFZO0FBRWhDLFFBQU0sV0FBVyxPQUFPO0FBQ3hCLFFBQU0sWUFBWSxPQUFPO0FBQ3pCLE1BQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxJQUFLO0FBUWxDLE1BQUksT0FBTyxZQUFZLE9BQU8sYUFBYSxVQUFXO0FBRXRELFFBQU0sZ0JBQWdCLE9BQU87QUFBQSxJQUM1QjtBQUFBLElBQ0EsS0FBSyxTQUFTO0FBQUEsSUFDZCxRQUFRLFNBQVMsVUFBVTtBQUFBLElBQzNCLFVBQVU7QUFBQSxFQUFBLENBQ1Y7QUFDRjtBQUVBLGVBQXNCLG9CQUNyQixPQUNBLFFBQ21DO0FBQ25DLFFBQU0sT0FBTyxNQUFNLGdCQUFnQixLQUFLO0FBQ3hDLE1BQUksQ0FBQyxRQUFRLEtBQUssY0FBYyxPQUFPLFVBQVcsUUFBTztBQUV6RCxRQUFNLFdBQVcsRUFBRSxHQUFHLE1BQU0sVUFBVSxLQUFBO0FBQ3RDLFFBQU0sZ0JBQWdCLE9BQU8sUUFBUTtBQUNyQyxTQUFPO0FBQ1I7QUFVTyxTQUFTLGVBQWUsT0FBeUI7QUFDdkQsU0FBTyxtREFBbUQ7QUFBQSxJQUN6RCxjQUFjLEtBQUs7QUFBQSxFQUFBO0FBRXJCO0FBRUEsZUFBc0IsZ0JBQ3JCLE9BQ21DO0FBQ25DLFFBQU0sU0FBUyxNQUFNLE9BQU8sUUFBUSxNQUFNLElBRXhDLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRTtBQUN2QixTQUFPLE9BQU8sR0FBRyxPQUFPLElBQUksS0FBSyxFQUFFLEtBQUs7QUFDekM7QUFFQSxlQUFlLGdCQUNkLE9BQ0EsT0FDZ0I7QUFDaEIsUUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxHQUFHLE9BQU8sSUFBSSxLQUFLLEVBQUUsR0FBRyxPQUFPO0FBQ2xFO0FBR0EsZUFBc0IscUJBQ3JCLE9BQ0EsVUFDZ0I7QUFDaEIsUUFBTSxnQkFBZ0IsT0FBTyxFQUFFLEdBQUcsVUFBVSxVQUFVLE1BQU07QUFDN0Q7QUFFQSxlQUFzQixrQkFBa0IsT0FBOEI7QUFDckUsUUFBTSxPQUFPLFFBQVEsTUFBTSxPQUFPLEdBQUcsT0FBTyxJQUFJLEtBQUssRUFBRTtBQUN4RDtBQUlBLGVBQXNCLFNBQ3JCLE9BQ0EsVUFDd0I7QUFDeEIsUUFBTSxTQUFTLE1BQU0sT0FBTyxTQUFTLFlBR2xDLEVBQUUsTUFBQSxHQUFTLDJCQUEyQixFQUFFLFdBQVcsU0FBUyxXQUFXO0FBRTFFLFNBQU87QUFBQSxJQUNOLEtBQUssU0FBUztBQUFBLElBQ2QsUUFBUSxTQUFTO0FBQUEsSUFDakIsTUFBTSxPQUFPLGdCQUFnQixhQUFhLE9BQU8sSUFBSSxJQUFJLE9BQU87QUFBQSxJQUNoRSxlQUFlLE9BQU87QUFBQSxFQUFBO0FBRXhCO0FBR0EsU0FBUyxhQUFhLFFBQXdCO0FBQzdDLFFBQU0sU0FBUyxLQUFLLE1BQU07QUFDMUIsUUFBTSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU07QUFDMUMsV0FBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsSUFBSyxPQUFNLENBQUMsSUFBSSxPQUFPLFdBQVcsQ0FBQztBQUN0RSxTQUFPLElBQUksWUFBQSxFQUFjLE9BQU8sS0FBSztBQUN0QztBQUVPLFNBQVMsY0FBYyxPQUF3QjtBQUNyRCxNQUFJLGlCQUFpQixNQUFPLFFBQU8sTUFBTTtBQUN6QyxNQUFJLE9BQU8sVUFBVSxTQUFVLFFBQU87QUFDdEMsU0FBTyxLQUFLLFVBQVUsS0FBSztBQUM1QjtBQ3ZNQSxNQUFNLGFBQWE7QUFDbkIsTUFBTSxZQUFZO0FBeUJYLFNBQVMsZ0JBQWdCLFNBQTJCO0FBQzFELFNBQ0MsT0FBTyxZQUFZLFlBQ25CLFlBQVksUUFDWCxRQUF5QixrQkFBa0I7QUFFOUM7QUFTQSxNQUFNLG1CQUFtQixDQUFDLHdCQUF3Qix1QkFBdUI7QUFTekUsZUFBc0Isb0JBQ3JCLFdBQ2dCO0FBQ2hCLE1BQUksQ0FBQyxVQUFXO0FBQ2hCLE1BQUk7QUFDSCxVQUFNLEVBQUUsT0FBQSxJQUFXLElBQUksSUFBSSxTQUFTO0FBQ3BDLFVBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsVUFBVSxHQUFHLFFBQVE7QUFBQSxFQUN4RCxRQUFRO0FBQUEsRUFFUjtBQUNEO0FBRUEsZUFBZSxtQkFBMkM7QUFDekQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxJQUN6QztBQUFBLEVBQUE7QUFFRCxTQUFPLE9BQU8sbUJBQW1CO0FBQ2xDO0FBUUEsZUFBc0IsZ0JBQStCO0FBQ3BELFFBQU0sVUFBVSxDQUFDLE1BQU0sb0JBQW9CLEdBQUcsZ0JBQWdCLEVBQUU7QUFBQSxJQUMvRCxDQUFDQSxZQUE2QixDQUFDLENBQUNBO0FBQUFBLEVBQUE7QUFHakMsYUFBV0EsV0FBVSxTQUFTO0FBQzdCLFVBQU0sV0FBVyxNQUFNLE9BQU8sS0FDNUIsTUFBTSxFQUFFLEtBQUssR0FBR0EsT0FBTSxHQUFHLFNBQVMsSUFBQSxDQUFLLEVBQ3ZDLE1BQU0sTUFBTSxFQUFFO0FBRWhCLFVBQU0sTUFBTSxTQUFTLEtBQUssQ0FBQyxjQUFjLFVBQVUsT0FBTyxNQUFTO0FBQ25FLFFBQUksS0FBSyxPQUFPLFFBQVc7QUFDMUIsWUFBTSxPQUFPLEtBQUssT0FBTyxJQUFJLElBQUksRUFBRSxRQUFRLE1BQU07QUFDakQsVUFBSSxJQUFJLGFBQWEsUUFBVztBQUMvQixjQUFNLE9BQU8sUUFBUSxPQUFPLElBQUksVUFBVSxFQUFFLFNBQVMsTUFBTTtBQUFBLE1BQzVEO0FBQ0E7QUFBQSxJQUNEO0FBQUEsRUFDRDtBQUVBLFFBQU0sU0FBUyxRQUFRLENBQUM7QUFDeEIsUUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssR0FBRyxNQUFNLEdBQUcsU0FBUyxJQUFJLFFBQVEsS0FBQSxDQUFNO0FBQ3hFO0FDaEVBLE1BQU0saUJBQWlCLG9CQUFJLElBQUksQ0FBQyxhQUFhLFlBQVksWUFBWSxDQUFDO0FBRS9ELE1BQU0sb0JBQTRDO0FBQUEsRUFDeEQsa0JBQWtCO0FBQUEsRUFDbEIsaUJBQWlCO0FBQUEsRUFDakIsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2Qsa0JBQWtCO0FBQUEsRUFDbEIsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsaUJBQWlCO0FBQUEsRUFDakIsaUJBQWlCO0FBQUEsRUFDakIsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsY0FBYztBQUFBLEVBQ2QsaUJBQWlCO0FBQUEsRUFDakIsY0FBYztBQUFBLEVBQ2Qsa0JBQWtCO0FBQUEsRUFDbEIsY0FBYztBQUNmO0FBRUEsU0FBUyxrQkFBa0IsS0FBYSxTQUF5QjtBQUNoRSxNQUFJO0FBQ0gsVUFBTSxXQUFXLElBQUksSUFBSSxHQUFHLEVBQUUsU0FBUyxRQUFRLFVBQVUsRUFBRTtBQUMzRCxRQUFJLGFBQWEsbUJBQW1CLGVBQWUsSUFBSSxPQUFPLEdBQUc7QUFDaEUsYUFBTztBQUFBLElBQ1I7QUFDQSxXQUFPLGtCQUFrQixRQUFRLEtBQUs7QUFBQSxFQUN2QyxRQUFRO0FBQ1AsV0FBTztBQUFBLEVBQ1I7QUFDRDtBQU1PLFNBQVMsY0FBYyxZQUFzQztBQUNuRSxRQUFNLDJCQUFXLElBQUE7QUFFakIsYUFBVyxVQUFVLFlBQVk7QUFDaEMsUUFBSSxDQUFDLE9BQU8sWUFBWSxDQUFDLE9BQU8sTUFBTztBQUN2QyxRQUFJLEtBQUssSUFBSSxPQUFPLEtBQUssRUFBRztBQUk1QixVQUFNLFdBQVcsT0FBTyxTQUFTO0FBQUEsTUFDaEM7QUFBQSxJQUFBO0FBRUQsUUFBSSxDQUFDLFNBQVU7QUFFZixVQUFNLFVBQVUsR0FBRyxTQUFTLENBQUMsQ0FBQztBQUU5QixTQUFLLElBQUksT0FBTyxPQUFPO0FBQUEsTUFDdEIsU0FBUyxPQUFPO0FBQUEsTUFDaEIsTUFBTSxPQUFPO0FBQUEsTUFDYixLQUFLO0FBQUEsTUFDTCxTQUFTLGtCQUFrQixPQUFPLFVBQVUsT0FBTyxLQUFLO0FBQUEsSUFBQSxDQUN4RDtBQUFBLEVBQ0Y7QUFFQSxTQUFPLE1BQU0sS0FBSyxLQUFLLE9BQUEsQ0FBUTtBQUNoQztBQUlBLFNBQVMsVUFBVSxNQUFzQjtBQUN4QyxTQUFPLEtBQUssUUFBUSxZQUFZLEVBQUUsRUFBRSxLQUFBO0FBQ3JDO0FBSUEsTUFBTSxXQUFtQztBQUFBLEVBQ3hDLFNBQVM7QUFBQSxFQUNULFFBQVE7QUFBQSxFQUNSLFFBQVE7QUFBQSxFQUNSLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFBQSxFQUNWLFVBQVU7QUFDWDtBQUVBLFNBQVMsZUFBZSxNQUFzQjtBQUM3QyxTQUFPLEtBQ0wsUUFBUSx3Q0FBd0MsQ0FBQyxNQUFNLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFDdkU7QUFBQSxJQUFRO0FBQUEsSUFBYSxDQUFDLEdBQUcsU0FDekIsT0FBTyxjQUFjLE9BQU8sU0FBUyxNQUFNLEVBQUUsQ0FBQztBQUFBLEVBQUEsRUFFOUMsUUFBUSxXQUFXLEdBQUc7QUFDekI7QUFJTyxTQUFTLGdCQUFnQixNQUEwQjtBQUt6RCxRQUFNLFVBQVUsS0FBSyxNQUFNLHNCQUFzQixJQUFJLENBQUMsS0FBSztBQUMzRCxRQUFNLFVBQVUsUUFBUSxNQUFNLG1CQUFtQjtBQUNqRCxRQUFNLGNBQWMsZUFBZSxVQUFVLE9BQU8sQ0FBQyxFQUNuRCxRQUFRLG1CQUFtQixFQUFFLEVBQzdCLEtBQUE7QUFDRixRQUFNLE9BQU8sV0FBVyxjQUFjLGNBQWM7QUFJcEQsUUFBTSxhQUFhLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQUE7QUFFRCxRQUFNLFlBQVksYUFBYSxPQUFPLFNBQVMsV0FBVyxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQ3BFLFFBQU0sa0JBQWtCLGFBQWEsQ0FBQyxJQUNuQyxPQUFPLFNBQVMsV0FBVyxDQUFDLEdBQUcsRUFBRSxJQUNqQztBQUVILFNBQU87QUFBQSxJQUNOO0FBQUEsSUFDQSxXQUFXLFVBQVUsUUFBUSxDQUFDLElBQUk7QUFBQSxJQUNsQztBQUFBLElBQ0E7QUFBQSxFQUFBO0FBRUY7QUFZQSxTQUFTLGtCQUFrQixNQUF3QjtBQUNsRCxRQUFNLGFBQXVCLENBQUE7QUFFN0IsUUFBTSxlQUFlLEtBQUs7QUFBQSxJQUN6QjtBQUFBLEVBQUE7QUFFRCxNQUFJLGFBQWMsWUFBVyxLQUFLLGFBQWEsQ0FBQyxDQUFDO0FBRWpELFFBQU0sU0FBUztBQUFBLElBQ2QsR0FBRyxLQUFLLFNBQVMsb0RBQW9EO0FBQUEsRUFBQTtBQUV0RSxhQUFXLFNBQVMsT0FBTyxXQUFXO0FBQ3JDLFVBQU0sUUFBUSxNQUFNLENBQUMsRUFBRSxNQUFNLGtDQUFrQztBQUMvRCxlQUFXLEtBQUssUUFBUSxNQUFNLENBQUMsSUFBSSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQzVDO0FBRUEsU0FBTztBQUNSO0FBRU8sU0FBUyxnQkFBZ0IsTUFBMkI7QUFDMUQsYUFBVyxTQUFTLGtCQUFrQixJQUFJLEdBQUc7QUFDNUMsVUFBTSxVQUFVLGdCQUFnQixLQUFLO0FBQ3JDLFFBQUksUUFBUSxTQUFTLEVBQUcsUUFBTztBQUFBLEVBQ2hDO0FBQ0EsU0FBTyxDQUFBO0FBQ1I7QUFFQSxTQUFTLGdCQUFnQixPQUE0QjtBQUNwRCxRQUFNLFVBQXVCLENBQUE7QUFHN0IsUUFBTSxXQUFXO0FBRWpCLGFBQVcsWUFBWSxNQUFNLFNBQVMsUUFBUSxHQUFHO0FBQ2hELFVBQU0sTUFBTSxTQUFTLENBQUM7QUFHdEIsVUFBTSxZQUFZO0FBQ2xCLFVBQU0sUUFBa0IsQ0FBQTtBQUN4QixlQUFXLGFBQWEsSUFBSSxTQUFTLFNBQVMsR0FBRztBQUNoRCxZQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFBQSxJQUN4QjtBQUdBLFFBQUksTUFBTSxTQUFTLEVBQUc7QUFHdEIsVUFBTSxpQkFBaUIsTUFBTSxDQUFDLEVBQUU7QUFBQSxNQUMvQjtBQUFBLElBQUE7QUFFRCxVQUFNLFdBQVcsaUJBQWlCLGVBQWUsQ0FBQyxFQUFFLFNBQVM7QUFDN0QsVUFBTSxZQUFZLGlCQUNmLGVBQWUsZUFBZSxDQUFDLENBQUMsRUFBRSxLQUFBLElBQ2xDLGVBQWUsVUFBVSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBSXJDLFFBQUksQ0FBQyxjQUFjLEtBQUssUUFBUSxFQUFHO0FBR25DLFVBQU0sZUFBZSxTQUFTLE1BQU0sc0JBQXNCO0FBQzFELFVBQU0sUUFBUSxlQUNYLGFBQWEsQ0FBQyxJQUNkLFVBQVUsY0FBYyxRQUFRLGNBQWMsRUFBRTtBQUtuRCxVQUFNLE9BQU8sZ0JBQWdCLE1BQU0sQ0FBQyxDQUFDO0FBR3JDLFVBQU0sY0FBYyxPQUFPLFNBQVMsVUFBVSxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUUsS0FBSztBQUdoRSxVQUFNLFdBQVcsT0FBTyxTQUFTLFVBQVUsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEtBQUs7QUFHN0QsVUFBTSxPQUFPLFVBQVUsTUFBTSxDQUFDLENBQUM7QUFHL0IsVUFBTSxXQUFXLFVBQVUsTUFBTSxDQUFDLENBQUM7QUFFbkMsUUFBSSxhQUFhLE1BQU07QUFDdEIsY0FBUSxLQUFLO0FBQUEsUUFDWjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxNQUFBLENBQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRDtBQUVBLFNBQU87QUFDUjtBQUdBLFNBQVMsZ0JBQWdCLE1BQXNCO0FBQzlDLFFBQU0sTUFBTSxLQUFLLE1BQU0sNkJBQTZCO0FBQ3BELE1BQUksSUFBSyxRQUFPLEdBQUcsSUFBSSxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDO0FBRTdDLFFBQU0sTUFBTSxLQUFLLE1BQU0sdUJBQXVCO0FBQzlDLE1BQUksSUFBSyxRQUFPLElBQUksQ0FBQztBQUVyQixTQUFPLFVBQVUsSUFBSTtBQUN0QjtBQWdCTyxTQUFTLGtCQUFrQixNQUFrQztBQUNuRSxRQUFNLFVBQThCLENBQUE7QUFFcEMsUUFBTSxhQUFhLEtBQUs7QUFBQSxJQUN2QjtBQUFBLEVBQUE7QUFFRCxNQUFJLENBQUMsV0FBWSxRQUFPO0FBRXhCLFFBQU0sUUFBUSxXQUFXLENBQUM7QUFFMUIsYUFBVyxZQUFZLE1BQU0sU0FBUyw2QkFBNkIsR0FBRztBQUNyRSxVQUFNLFFBQWtCLENBQUE7QUFDeEIsZUFBVyxhQUFhLFNBQVMsQ0FBQyxFQUFFO0FBQUEsTUFDbkM7QUFBQSxJQUFBLEdBQ0U7QUFDRixZQUFNLEtBQUssVUFBVSxDQUFDLENBQUM7QUFBQSxJQUN4QjtBQUVBLFFBQUksTUFBTSxTQUFTLEVBQUc7QUFFdEIsVUFBTSxPQUFPLGVBQWUsVUFBVSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQy9DLFFBQUksQ0FBQyxLQUFNO0FBRVgsVUFBTSxjQUFjLE1BQU0sQ0FBQyxFQUFFLE1BQU0sb0JBQW9CO0FBQ3ZELFVBQU0sVUFBVSxPQUFPLFNBQVMsVUFBVSxNQUFNLENBQUMsQ0FBQyxHQUFHLEVBQUU7QUFDdkQsVUFBTSxTQUFTLE9BQU8sU0FBUyxVQUFVLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRTtBQUV0RCxRQUFJLE9BQU8sTUFBTSxPQUFPLEtBQUssT0FBTyxNQUFNLE1BQU0sRUFBRztBQUVuRCxZQUFRLEtBQUs7QUFBQSxNQUNaLFFBQVEsY0FBYyxZQUFZLENBQUMsSUFBSTtBQUFBLE1BQ3ZDO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUFBLENBQ0E7QUFBQSxFQUNGO0FBRUEsU0FBTztBQUNSO0FBdUNPLFNBQVMsZUFBZSxNQUFzQjtBQUNwRCxRQUFNLFFBQVEsS0FBSztBQUFBLElBQ2xCO0FBQUEsRUFBQTtBQUVELFNBQU8sUUFBUSxNQUFNLENBQUMsSUFBSTtBQUMzQjtBQW9CTyxTQUFTLG1CQUFtQixNQUE2QjtBQUMvRCxRQUFNLFFBQVE7QUFBQSxJQUNiLFVBQVUsS0FBSyxNQUFNLDJCQUEyQixJQUFJLENBQUMsS0FBSyxFQUFFO0FBQUEsRUFBQTtBQUk3RCxRQUFNLFVBQVUsS0FBSyxNQUFNLGdDQUFnQyxJQUFJLENBQUMsS0FBSztBQUVyRSxRQUFNLGNBQWMsS0FBSyxNQUFNLDRCQUE0QjtBQUUzRCxTQUFPO0FBQUEsSUFDTjtBQUFBLElBQ0E7QUFBQSxJQUNBLGFBQWEsY0FBYyxPQUFPLFNBQVMsWUFBWSxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQUEsSUFDakUsTUFBTSxlQUFlLElBQUk7QUFBQSxFQUFBO0FBRTNCO0FDN1dPLFNBQVMsY0FBYyxjQUE4QjtBQUMzRCxTQUFPLEdBQUcsVUFBVSxZQUFZLENBQUM7QUFDbEM7QUFHTyxTQUFTLGFBQWEsS0FBcUI7QUFDakQsU0FBTyx5Q0FBeUMsR0FBRztBQUNwRDtBQVVBLFNBQVMsVUFBVSxLQUFxQjtBQUN2QyxTQUFPLElBQUksUUFBUSxPQUFPLEVBQUU7QUFDN0I7QUFTcUMsT0FBTyxLQUFLLGlCQUFpQixFQUFFO0FBQUEsRUFDbkUsQ0FBQyxXQUFXLENBQUMsT0FBTyxNQUFNLE1BQU0sU0FBUyxNQUFNLElBQUk7QUFDcEQ7QUNyRUEsTUFBTSxtQkFBbUI7QUFFekIsSUFBSSxRQUErQztBQUU1QyxTQUFTLGlCQUF1QjtBQUN0QyxNQUFJLE1BQU87QUFDWCxVQUFRLFlBQVksTUFBTTtBQUV6QixTQUFLLE9BQU8sUUFBUSxnQkFBQSxFQUFrQixNQUFNLE1BQU0sTUFBUztBQUFBLEVBQzVELEdBQUcsZ0JBQWdCO0FBQ3BCO0FBRU8sU0FBUyxnQkFBc0I7QUFDckMsTUFBSSxDQUFDLE1BQU87QUFDWixnQkFBYyxLQUFLO0FBQ25CLFVBQVE7QUFDVDtBQ2RBLE1BQU0sVUFBVTtBQUNoQixNQUFNLFlBQVk7QUFDbEIsTUFBTSxjQUFjO0FBaUJwQixTQUFTLGVBQTJCO0FBQ25DLFNBQU87QUFBQSxJQUNOLHFCQUFxQixDQUFBO0FBQUEsSUFDckIsa0JBQWtCLENBQUE7QUFBQSxJQUNsQixlQUFlO0FBQUEsSUFDZixhQUFhO0FBQUEsSUFDYixVQUFVO0FBQUEsRUFBQTtBQUVaO0FBSUEsZUFBc0IsY0FBaUM7QUFDdEQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU0sSUFBd0IsT0FBTztBQUN6RSxTQUFPLE9BQU8sT0FBTyxjQUFBO0FBQ3RCO0FBRUEsZUFBc0IsWUFBWSxPQUFnQztBQUNqRSxRQUFNLE9BQU8sUUFBUSxNQUFNLElBQUksRUFBRSxDQUFDLE9BQU8sR0FBRyxPQUFPO0FBQ3BEO0FBR0EsZUFBc0IsZUFDckIsUUFDb0I7QUFDcEIsUUFBTSxPQUFPLE9BQU8sTUFBTSxhQUFhO0FBQ3ZDLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFNBQU87QUFDUjtBQUVBLGVBQXNCLGNBQ3JCLEtBQ0EsUUFDQSxRQUNBLFVBQ29CO0FBQ3BCLFNBQU8sZUFBZSxDQUFDLFdBQVc7QUFBQSxJQUNqQyxHQUFHO0FBQUEsSUFDSCxPQUFPLE1BQU0sTUFBTTtBQUFBLE1BQUksQ0FBQyxTQUN2QixLQUFLLFFBQVEsTUFDVjtBQUFBLFFBQ0EsR0FBRztBQUFBLFFBQ0g7QUFBQSxRQUNBO0FBQUEsUUFDQSxVQUFVLFlBQVksS0FBSztBQUFBLFFBQzNCLFdBQVcsS0FBSyxJQUFBO0FBQUEsTUFBSSxJQUVwQjtBQUFBLElBQUE7QUFBQSxFQUNKLEVBQ0M7QUFDSDtBQUVBLGVBQXNCLFlBQVksT0FBdUM7QUFDeEUsU0FBTyxlQUFlLENBQUMsV0FBVztBQUFBLElBQ2pDLEdBQUc7QUFBQSxJQUNILE9BQU8sQ0FBQyxHQUFHLE1BQU0sT0FBTyxHQUFHLEtBQUs7QUFBQSxFQUFBLEVBQy9CO0FBQ0g7QUFJQSxlQUFzQixhQUFrQztBQUN2RCxRQUFNLFNBQVMsTUFBTSxPQUFPLFFBQVEsTUFBTTtBQUFBLElBQ3pDO0FBQUEsRUFBQTtBQUVELFNBQU8sT0FBTyxXQUFXLGFBQUE7QUFDMUI7QUFFQSxlQUFzQixXQUFXLFNBQW9DO0FBQ3BFLFFBQU0sT0FBTyxRQUFRLE1BQU0sSUFBSSxFQUFFLENBQUMsV0FBVyxHQUFHLFNBQVM7QUFDMUQ7QUFFQSxlQUFzQixjQUNyQixRQUNzQjtBQUN0QixRQUFNLE9BQU8sT0FBTyxNQUFNLFlBQVk7QUFDdEMsUUFBTSxXQUFXLElBQUk7QUFDckIsU0FBTztBQUNSO0FBSUEsZUFBc0IsV0FBb0M7QUFDekQsUUFBTSxTQUFTLE1BQU0sT0FBTyxRQUFRLE1BQU07QUFBQSxJQUN6QztBQUFBLEVBQUE7QUFFRCxTQUFPLE9BQU8sU0FBUyxDQUFBO0FBQ3hCO0FBR0EsZUFBc0IsUUFBUSxNQUFtQztBQUNoRSxRQUFNLFFBQVEsTUFBTSxTQUFBO0FBQ3BCLFFBQU0sV0FBVyxNQUFNO0FBQUEsSUFDdEIsQ0FBQyxNQUFNLEVBQUUsU0FBUyxLQUFLLFFBQVEsRUFBRSxRQUFRLEtBQUs7QUFBQSxFQUFBO0FBRS9DLE1BQUksYUFBYSxHQUFJLE9BQU0sS0FBSyxJQUFJO0FBQUEsTUFDL0IsT0FBTSxRQUFRLElBQUk7QUFDdkIsUUFBTSxPQUFPLFFBQVEsTUFBTSxJQUFJLEVBQUUsQ0FBQyxTQUFTLEdBQUcsT0FBTztBQUN0RDtBQUlBLGVBQXNCLFdBQTBCO0FBQy9DLFFBQU0sT0FBTyxRQUFRLE1BQU0sT0FBTyxDQUFDLFNBQVMsV0FBVyxXQUFXLENBQUM7QUFDcEU7QUNsSUEsZUFBc0IsWUFBWSxPQUFnQztBQUNqRSxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLFFBQU0sVUFBVSxFQUFFLE1BQU0sU0FBa0IsTUFBQTtBQUUxQyxhQUFXLFNBQVMsQ0FBQyxRQUFRLFlBQVksUUFBUSxXQUFXLEdBQUc7QUFDOUQsUUFBSSxVQUFVLE9BQVc7QUFDekIsVUFBTSxPQUFPLEtBQUssWUFBWSxPQUFPLE9BQU8sRUFBRSxNQUFNLE1BQU07QUFBQSxJQUFDLENBQUM7QUFBQSxFQUM3RDtBQUNEO0FBRUEsZUFBc0IsV0FBVyxNQUFtQztBQUNuRSxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsUUFBTSxPQUFPLEtBQ1gsWUFBWSxZQUFZLEVBQUUsTUFBTSxRQUFpQixLQUFBLENBQU0sRUFDdkQsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2pCO0FDVUEsTUFBTSxvQkFBb0I7QUFBQSxFQUN6QjtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUNBO0FBQUEsRUFDQTtBQUNEO0FBRUEsU0FBUyxtQkFBbUIsTUFBdUI7QUFDbEQsUUFBTSxXQUFXLEtBQUssTUFBTSxHQUFHLEdBQU8sRUFBRSxZQUFBO0FBQ3hDLFNBQU8sa0JBQWtCLEtBQUssQ0FBQyxXQUFXLFNBQVMsU0FBUyxNQUFNLENBQUM7QUFDcEU7QUFFTyxTQUFTLFNBQ2YsTUFDQSxLQUNBLFFBQ0EsTUFDVTtBQUtWLE1BQUksVUFBVSxLQUFLO0FBQ2xCLFVBQU0sWUFBWSxtQkFBbUIsSUFBSTtBQUN6QyxXQUFPO0FBQUEsTUFDTixTQUFTO0FBQUEsTUFDVCxXQUFXO0FBQUEsTUFDWCxRQUFRLFlBQ0wsbUJBQW1CLE1BQU0sa0dBQ3pCLG1CQUFtQixNQUFNO0FBQUEsSUFBQTtBQUFBLEVBRTlCO0FBR0EsTUFBSSxtQkFBbUIsSUFBSSxLQUFLLENBQUMsaUJBQWlCLE1BQU0sS0FBSyxJQUFJLEdBQUc7QUFDbkUsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsV0FBVztBQUFBLE1BQ1gsUUFDQztBQUFBLElBQUE7QUFBQSxFQUVIO0FBRUEsVUFBUSxNQUFBO0FBQUEsSUFDUCxLQUFLO0FBQ0osYUFBTyxnQkFBZ0IsS0FBSyxJQUFJO0FBQUEsSUFDakMsS0FBSztBQUNKLGFBQU8sY0FBYyxLQUFLLElBQUk7QUFBQSxJQUMvQixLQUFLO0FBQ0osYUFBTyxjQUFjLElBQUk7QUFBQSxJQUMxQixLQUFLO0FBQ0osYUFBTyxlQUFlLElBQUk7QUFBQSxFQUFBO0FBRTdCO0FBTUEsU0FBUyxpQkFDUixNQUNBLEtBQ0EsTUFDVTtBQUNWLFVBQVEsTUFBQTtBQUFBLElBQ1AsS0FBSztBQUNKLGFBQU8sZ0JBQWdCLElBQUksRUFBRSxTQUFTO0FBQUEsSUFDdkMsS0FBSztBQUNKLGFBQU8sbUJBQW1CLElBQUksRUFBRSxjQUFjO0FBQUEsSUFDL0MsS0FBSztBQUNKLGFBQU8sa0JBQWtCLElBQUksRUFBRSxTQUFTO0FBQUEsSUFDekMsS0FBSztBQUNKLGFBQU8sY0FBYyxJQUFJLE1BQU07QUFBQSxFQUFBO0FBRWxDO0FBRUEsU0FBUyxnQkFBZ0IsV0FBbUIsTUFBdUI7QUFDbEUsUUFBTSxTQUFTLGdCQUFnQixJQUFJO0FBQ25DLFFBQU0sVUFBVSxnQkFBZ0IsSUFBSTtBQUVwQyxNQUFJLE9BQU8sU0FBUyxhQUFhLFFBQVEsV0FBVyxHQUFHO0FBQ3RELFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVE7QUFBQSxJQUFBO0FBQUEsRUFFVjtBQUNBLE1BQUksT0FBTyxhQUFhLE9BQU8sY0FBYyxXQUFXO0FBQ3ZELFdBQU87QUFBQSxNQUNOLFNBQVM7QUFBQSxNQUNULFFBQVEsdUJBQXVCLE9BQU8sU0FBUyxjQUFjLFNBQVM7QUFBQSxJQUFBO0FBQUEsRUFFeEU7QUFDQSxNQUFJLFFBQVEsV0FBVyxHQUFHO0FBQ3pCLFdBQU8sRUFBRSxTQUFTLFlBQVksUUFBUSxvQ0FBQTtBQUFBLEVBQ3ZDO0FBRUEsU0FBTztBQUFBLElBQ04sU0FBUztBQUFBLElBQ1QsUUFBUSxHQUFHLE9BQU8sSUFBSSxNQUFNLFFBQVEsTUFBTTtBQUFBLEVBQUE7QUFFNUM7QUFFQSxTQUFTLGNBQWMsU0FBaUIsTUFBdUI7QUFDOUQsUUFBTSxPQUFPLG1CQUFtQixJQUFJO0FBRXBDLE1BQUksQ0FBQyxLQUFLLGVBQWUsQ0FBQyxLQUFLLE1BQU07QUFDcEMsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsUUFBUTtBQUFBLElBQUE7QUFBQSxFQUVWO0FBQ0EsTUFBSSxLQUFLLFdBQVcsS0FBSyxZQUFZLFNBQVM7QUFDN0MsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsUUFBUSxnQkFBZ0IsS0FBSyxPQUFPLGdCQUFnQixPQUFPO0FBQUEsSUFBQTtBQUFBLEVBRTdEO0FBSUEsU0FBTyxFQUFFLFNBQVMsTUFBTSxRQUFRLElBQUksS0FBSyxXQUFXLE1BQU0sS0FBSyxJQUFJLEdBQUE7QUFDcEU7QUFFQSxTQUFTLGNBQWMsTUFBdUI7QUFDN0MsUUFBTSxRQUFRLGtCQUFrQixJQUFJO0FBQ3BDLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdkIsV0FBTztBQUFBLE1BQ04sU0FBUztBQUFBLE1BQ1QsUUFBUTtBQUFBLElBQUE7QUFBQSxFQUVWO0FBQ0EsU0FBTyxFQUFFLFNBQVMsTUFBTSxRQUFRLEdBQUcsTUFBTSxNQUFNLFNBQUE7QUFDaEQ7QUFNTyxTQUFTLGNBQWMsTUFBNkI7QUFDMUQsUUFBTSxRQUFRLEtBQUs7QUFBQSxJQUNsQjtBQUFBLEVBQUE7QUFFRCxTQUFPLFFBQVEsTUFBTSxDQUFDLElBQUk7QUFDM0I7QUFFQSxTQUFTLGVBQWUsTUFBdUI7QUFDOUMsTUFBSSxjQUFjLElBQUksR0FBRztBQUN4QixXQUFPLEVBQUUsU0FBUyxNQUFNLFFBQVEseUJBQUE7QUFBQSxFQUNqQztBQUdBLFFBQU0sbUJBQW1CLFdBQVcsS0FBSyxJQUFJLEtBQUssS0FBSyxTQUFTO0FBQ2hFLFNBQU8sbUJBQ0o7QUFBQSxJQUNBLFNBQVM7QUFBQSxJQUNULFFBQVE7QUFBQSxFQUFBLElBRVI7QUFBQSxJQUNBLFNBQVM7QUFBQSxJQUNULFFBQVE7QUFBQSxFQUFBO0FBRVo7QUNoS0EsTUFBTSxlQUFlO0FBTXJCLE1BQU0sbUJBQW1CO0FBR3pCLE1BQU0saUJBQWlCO0FBQ3ZCLE1BQU0sMEJBQTBCO0FBRWhDLFNBQVMsT0FBTyxNQUF1QjtBQUN0QyxVQUFRLElBQUkscUJBQXFCLEdBQUcsSUFBSTtBQUN6QztBQVNBLE1BQU0sY0FBYztBQUNwQixNQUFNLHNCQUFzQjtBQUU1QixlQUFlLGdCQUErQjtBQUM3QyxRQUFNLE9BQU8sT0FDWCxPQUFPLGFBQWEsRUFBRSxnQkFBZ0Isb0JBQUEsQ0FBcUIsRUFDM0QsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ2pCO0FBRUEsZUFBZSx1QkFBc0M7QUFDcEQsUUFBTSxPQUFPLE9BQU8sTUFBTSxXQUFXLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ3REO0FBR0EsZUFBc0IsZUFBa0M7QUFDdkQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZLFFBQU87QUFFNUQsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVO0FBQy9ELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxDQUFDLFFBQVEsUUFBUSxnQkFBZ0IsT0FBVyxRQUFPO0FBRXZELFFBQU0scUJBQUE7QUFDTixRQUFNLGtCQUFrQixRQUFRLFdBQVc7QUFFM0MsTUFBSTtBQUNILFVBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsVUFBTSxPQUFPLEtBQUssT0FBTyxRQUFRLGFBQWEsRUFBRSxLQUFLLEtBQUssS0FBSztBQUFBLEVBQ2hFLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBQ0EsU0FBTztBQUNSO0FBR0EsZUFBc0IsY0FBaUM7QUFDdEQsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZLFFBQU87QUFFNUQsUUFBTSxxQkFBQTtBQUNOLFFBQU0sY0FBYyxNQUFNLFlBQVksV0FBVyxVQUFVO0FBQzNELFFBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsU0FBTyxRQUFBO0FBQ1I7QUFXQSxlQUFzQixxQkFBcUIsT0FBOEI7QUFDeEUsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxhQUFhLENBQUMsTUFBTSxXQUFZO0FBRXJELFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRLE1BQU0sVUFBVTtBQUMvRCxNQUFJLE1BQU0sV0FBVyxTQUFVO0FBRy9CLFFBQU0sV0FBVyxNQUFNLGdCQUFnQixLQUFLO0FBQzVDLE1BQUksWUFBWSxDQUFDLFNBQVMsU0FBVTtBQUVwQyxRQUFNLFlBQVksS0FBSyxZQUFZLEtBQUs7QUFDeEMsTUFBSSxXQUFXLGNBQWM7QUFDNUIsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLDBEQUEwRCxRQUFRO0FBQUEsTUFDbEU7QUFBQSxJQUFBO0FBRUQsVUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFNLFFBQUE7QUFDTjtBQUFBLEVBQ0Q7QUFFQTtBQUFBLElBQ0MsR0FBRyxLQUFLLEtBQUssMERBQTBELFFBQVE7QUFBQSxFQUFBO0FBRWhGLFFBQU07QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxFQUFBO0FBRUQsUUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxRQUFNLGFBQUE7QUFDUDtBQUdBLGVBQXNCLHNCQUFxQztBQUMxRCxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLE1BQUksTUFBTSxXQUFXLGFBQWEsQ0FBQyxNQUFNLFdBQVk7QUFFckQsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVO0FBQy9ELE1BQUksTUFBTSxXQUFXLFVBQVc7QUFHaEMsTUFBSSxLQUFLLFdBQVc7QUFDbkIsUUFBSSxHQUFHLEtBQUssS0FBSyw2Q0FBNkM7QUFDOUQ7QUFBQSxFQUNEO0FBRUEsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsWUFBWSxjQUFjO0FBQ3JDLFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxHQUFHLEtBQUssVUFBVSxVQUFVLGtCQUFrQixRQUFRLFFBQVE7QUFBQSxJQUFBO0FBRS9ELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxRQUFBO0FBQ047QUFBQSxFQUNEO0FBRUEsUUFBTSxhQUFBO0FBQ1A7QUFJQSxlQUFzQixTQUNyQixTQUNBLFlBQ29CO0FBQ3BCLFFBQU0sU0FBQTtBQUVOLFFBQU0sUUFBcUIsUUFBUSxNQUFNLElBQUksQ0FBQyxVQUFVO0FBQUEsSUFDdkQsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLEVBQUEsRUFDUDtBQUVGLE1BQUksTUFBTSxXQUFXLEdBQUc7QUFDdkIsVUFBTUMsU0FBa0I7QUFBQSxNQUN2QixRQUFRO0FBQUEsTUFDUixPQUFPLENBQUE7QUFBQSxNQUNQLFNBQVM7QUFBQSxJQUFBO0FBRVYsVUFBTSxZQUFZQSxNQUFLO0FBQ3ZCLFdBQU9BO0FBQUFBLEVBQ1I7QUFJQSxRQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssZUFBZSxRQUFRLE1BQU07QUFDekUsTUFBSSxJQUFJLE9BQU8sT0FBVyxPQUFNLElBQUksTUFBTSw2QkFBNkI7QUFFdkUsUUFBTSxXQUFXO0FBQUEsSUFDaEI7QUFBQSxJQUNBLGFBQWEsSUFBSTtBQUFBLElBQ2pCLHFCQUFxQixRQUFRO0FBQUEsSUFDN0Isa0JBQWtCLENBQUE7QUFBQSxJQUNsQixlQUFlO0FBQUEsSUFDZixhQUFhLFFBQVEsZUFBZTtBQUFBLElBQ3BDLFVBQVU7QUFBQSxFQUFBLENBQ1Y7QUFFRCxRQUFNLFFBQWtCO0FBQUEsSUFDdkIsUUFBUTtBQUFBLElBQ1I7QUFBQSxJQUNBLFdBQVcsS0FBSyxJQUFBO0FBQUEsRUFBSTtBQUVyQixRQUFNLFlBQVksS0FBSztBQUV2QixNQUFJO0FBQ0gsVUFBTSxlQUFlLElBQUksRUFBRTtBQUFBLEVBQzVCLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEsUUFBTSxTQUFTLEdBQUc7QUFDbEIsaUJBQUE7QUFDQSxRQUFNLE9BQU8sT0FDWCxPQUFPLGdCQUFnQixFQUFFLGlCQUFpQix3QkFBQSxDQUF5QixFQUNuRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDaEIsTUFBSSxnQkFBZ0IsTUFBTSxNQUFNLHNCQUFzQixJQUFJLEVBQUUsRUFBRTtBQUM5RCxTQUFPLFFBQUE7QUFDUjtBQVNBLGVBQXNCLGdCQUErQjtBQUNwRCxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLE1BQUksTUFBTSxXQUFXLGFBQWEsQ0FBQyxNQUFNLFdBQVk7QUFFckQsUUFBTSxPQUFPLE1BQU0sTUFBTSxLQUFLLENBQUMsTUFBTSxFQUFFLFFBQVEsTUFBTSxVQUFVO0FBQy9ELE1BQUksTUFBTSxXQUFXLFNBQVU7QUFFL0IsUUFBTSxNQUFNLEtBQUssSUFBQSxLQUFTLEtBQUssYUFBYTtBQUM1QyxNQUFJLE1BQU0saUJBQWtCO0FBRTVCLFFBQU0sWUFBWSxLQUFLLFlBQVksS0FBSztBQUN4QyxNQUFJLFdBQVcsY0FBYztBQUM1QixRQUFJLGdCQUFnQixLQUFLLEtBQUssVUFBVSxRQUFRLFdBQVc7QUFDM0QsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLHFCQUFxQixRQUFRO0FBQUEsTUFDN0I7QUFBQSxJQUFBO0FBRUQsVUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxVQUFNLFFBQUE7QUFDTjtBQUFBLEVBQ0Q7QUFFQTtBQUFBLElBQ0MsR0FBRyxLQUFLLEtBQUssZ0JBQWdCLEtBQUssTUFBTSxNQUFNLEdBQUksQ0FBQywwQkFBMEIsUUFBUTtBQUFBLEVBQUE7QUFFdEYsUUFBTTtBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0w7QUFBQSxJQUNBLHFCQUFxQixLQUFLLE1BQU0sTUFBTSxHQUFJLENBQUMsMEJBQTBCLFFBQVE7QUFBQSxJQUM3RTtBQUFBLEVBQUE7QUFFRCxRQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDLFFBQU0sYUFBQTtBQUNQO0FBUUEsZUFBc0IsWUFBMkI7QUFDaEQsUUFBTSxxQkFBQTtBQUNOLGdCQUFBO0FBQ0EsUUFBTSxPQUFPLE9BQU8sTUFBTSxjQUFjLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBQ3hELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxRQUFRLGdCQUFnQixRQUFXO0FBQ3RDLFVBQU0sT0FBTyxRQUFRLFdBQVc7QUFDaEMsVUFBTSxrQkFBa0IsUUFBUSxXQUFXO0FBQUEsRUFDNUM7QUFDQSxRQUFNLFNBQUE7QUFDTixRQUFNLFNBQVMsRUFBRTtBQUNqQixNQUFJLGFBQWE7QUFDbEI7QUFXQSxlQUFzQixVQUFVLFlBQXVDO0FBQ3RFLFFBQU0sV0FBVyxNQUFNLFlBQUE7QUFDdkIsTUFBSSxTQUFTLE1BQU0sV0FBVyxHQUFHO0FBQ2hDLFdBQU8sUUFBUSw0QkFBNEI7QUFBQSxFQUM1QztBQUVBLFFBQU0sUUFBcUIsU0FBUyxNQUFNO0FBQUEsSUFBSSxDQUFDLFNBQzlDLEtBQUssV0FBVyxjQUFjLEtBQUssV0FBVyxZQUMzQyxPQUNBO0FBQUEsTUFDQSxHQUFHO0FBQUEsTUFDSCxRQUFRO0FBQUEsTUFDUixRQUFRO0FBQUEsTUFDUixVQUFVO0FBQUEsTUFDVixXQUFXO0FBQUEsTUFDWCxXQUFXLEtBQUssSUFBQTtBQUFBLElBQUk7QUFBQSxFQUNyQjtBQUdILFFBQU0sY0FBYyxNQUFNLE9BQU8sQ0FBQyxTQUFTLEtBQUssV0FBVyxTQUFTLEVBQUU7QUFDdEUsTUFBSSxnQkFBZ0IsR0FBRztBQUN0QixXQUFPLFFBQVEsd0RBQXdEO0FBQUEsRUFDeEU7QUFFQSxRQUFNLE1BQU0sTUFBTSxPQUFPLEtBQUssT0FBTyxFQUFFLEtBQUssZUFBZSxRQUFRLE1BQU07QUFDekUsTUFBSSxJQUFJLE9BQU8sT0FBVyxPQUFNLElBQUksTUFBTSw2QkFBNkI7QUFJdkUsUUFBTSxjQUFjLENBQUMsYUFBYTtBQUFBLElBQ2pDLEdBQUc7QUFBQSxJQUNIO0FBQUEsSUFDQSxhQUFhLElBQUk7QUFBQSxJQUNqQixVQUFVO0FBQUEsRUFBQSxFQUNUO0FBRUYsUUFBTSxZQUFZO0FBQUEsSUFDakIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1o7QUFBQSxJQUNBLFNBQVM7QUFBQSxJQUNULFlBQVk7QUFBQSxFQUFBLENBQ1o7QUFFRCxNQUFJO0FBQ0gsVUFBTSxlQUFlLElBQUksRUFBRTtBQUFBLEVBQzVCLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEsUUFBTSxTQUFTLEdBQUc7QUFDbEIsaUJBQUE7QUFDQSxRQUFNLE9BQU8sT0FDWCxPQUFPLGdCQUFnQixFQUFFLGlCQUFpQix3QkFBQSxDQUF5QixFQUNuRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDaEIsTUFBSSxhQUFhLFdBQVcsT0FBTyxNQUFNLE1BQU0scUJBQXFCO0FBQ3BFLFNBQU8sUUFBQTtBQUNSO0FBRUEsZUFBc0IsWUFBK0I7QUFDcEQsUUFBTSxxQkFBQTtBQUNOLGdCQUFBO0FBQ0EsUUFBTSxPQUFPLE9BQU8sTUFBTSxjQUFjLEVBQUUsTUFBTSxNQUFNO0FBQUEsRUFBQyxDQUFDO0FBRXhELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsUUFBTSxZQUFzQjtBQUFBLElBQzNCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFlBQVksS0FBSyxJQUFBO0FBQUEsSUFDakIsU0FBUztBQUFBLEVBQUE7QUFHVixRQUFNLFlBQVksU0FBUztBQUMzQixRQUFNLGVBQUE7QUFDTixRQUFNLFNBQVMsRUFBRTtBQUNqQixRQUFNLGNBQUE7QUFDTixRQUFNLFlBQVksU0FBUztBQUMzQixTQUFPO0FBQ1I7QUFFQSxlQUFlLFFBQVEsU0FBb0M7QUFDMUQsZ0JBQUE7QUFDQSxRQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLFFBQU0sU0FBbUI7QUFBQSxJQUN4QixHQUFHO0FBQUEsSUFDSCxRQUFRO0FBQUEsSUFDUixZQUFZO0FBQUEsSUFDWixZQUFZLEtBQUssSUFBQTtBQUFBLElBQ2pCO0FBQUEsRUFBQTtBQUVELFFBQU0sWUFBWSxNQUFNO0FBQ3hCLFFBQU0sU0FBUyxHQUFHO0FBQ2xCLFFBQU0sWUFBWSxNQUFNO0FBQ3hCLFNBQU87QUFDUjtBQUtBLGVBQXNCLFVBQTZCO0FBQ2xELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsVUFBVyxRQUFPO0FBRXZDLFFBQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxDQUFDLFNBQVMsS0FBSyxXQUFXLFNBQVM7QUFFakUsTUFBSSxDQUFDLE1BQU07QUFFVixVQUFNLFNBQVMsTUFBTSxnQkFBQTtBQUNyQixRQUFJLGVBQWUsUUFBQTtBQUNuQixXQUFPLFVBQUE7QUFBQSxFQUNSO0FBRUEsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsZ0JBQWdCLFFBQVc7QUFDdEMsV0FBTyxRQUFRLHlCQUF5QjtBQUFBLEVBQ3pDO0FBRUEsUUFBTSxxQkFBQTtBQUNOLFFBQU0sY0FBYyxDQUFDLE9BQU8sRUFBRSxHQUFHLEdBQUcsVUFBVSxJQUFJO0FBQ2xELFFBQU0sa0JBQWtCLFFBQVEsV0FBVztBQUUzQyxRQUFNLFVBQW9CO0FBQUEsSUFDekIsR0FBRztBQUFBLElBQ0gsWUFBWSxLQUFLO0FBQUEsSUFDakIsT0FBTyxNQUFNLE1BQU07QUFBQSxNQUFJLENBQUMsU0FDdkIsS0FBSyxRQUFRLEtBQUssTUFDZjtBQUFBLFFBQ0EsR0FBRztBQUFBLFFBQ0gsUUFBUTtBQUFBLFFBQ1IsUUFBUTtBQUFBLFFBQ1IsVUFBVTtBQUFBLFFBQ1YsV0FBVyxLQUFLLElBQUE7QUFBQSxNQUFJLElBRXBCO0FBQUEsSUFBQTtBQUFBLElBRUosU0FBUztBQUFBLEVBQUE7QUFFVixRQUFNLFlBQVksT0FBTztBQUN6QixRQUFNLFlBQVksT0FBTztBQUV6QixNQUFJLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxHQUFHLEVBQUU7QUFFbEMsTUFBSTtBQUNILFVBQU0sZUFBZSxRQUFRLFdBQVc7QUFDeEMsVUFBTSxPQUFPLEtBQUssT0FBTyxRQUFRLGFBQWEsRUFBRSxLQUFLLEtBQUssS0FBSztBQUFBLEVBQ2hFLFNBQVMsT0FBTztBQUNmLFdBQU8sUUFBUSxjQUFjLEtBQUssQ0FBQztBQUFBLEVBQ3BDO0FBRUEsU0FBTztBQUNSO0FBUUEsZUFBc0IscUJBQXFCLE9BQThCO0FBQ3hFLFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsYUFBYSxDQUFDLE1BQU0sV0FBWTtBQUVyRCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLE1BQUksUUFBUSxnQkFBZ0IsTUFBTztBQUVuQyxRQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUSxNQUFNLFVBQVU7QUFDL0QsTUFBSSxDQUFDLEtBQU07QUFPWCxRQUFNLFdBQVcsTUFBTSxnQkFBZ0IsS0FBSztBQUM1QyxNQUFJLENBQUMsWUFBWSxTQUFTLFNBQVU7QUFFcEMsTUFBSTtBQUNKLE1BQUk7QUFDSCxlQUFXLE1BQU0sU0FBUyxPQUFPLFFBQVE7QUFBQSxFQUMxQyxTQUFTLE9BQU87QUFDZixRQUFJLGVBQWUsS0FBSyxFQUFHO0FBRTNCLFVBQU1DLGFBQ0wsTUFBTSxjQUFjLENBQUMsT0FBTyxFQUFFLEdBQUcsR0FBRyxVQUFVLEVBQUUsV0FBVyxFQUFBLEVBQUksR0FDOUQ7QUFDRixRQUFJLEdBQUcsS0FBSyxLQUFLLDJCQUEyQixjQUFjLEtBQUssQ0FBQyxFQUFFO0FBQ2xFLFFBQUlBLGFBQVksY0FBYztBQUM3QixZQUFNLGNBQWMsS0FBSyxLQUFLLFVBQVUsY0FBYyxLQUFLLEdBQUdBLFNBQVE7QUFDdEUsWUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxZQUFNLFFBQUE7QUFBQSxJQUNQO0FBQ0E7QUFBQSxFQUNEO0FBRUEsUUFBTSxZQUNMLE1BQU0sY0FBYyxDQUFDLE9BQU8sRUFBRSxHQUFHLEdBQUcsVUFBVSxFQUFFLFdBQVcsRUFBQSxFQUFJLEdBQzlEO0FBRUYsUUFBTSxVQUFVLFNBQVMsS0FBSyxNQUFNLEtBQUssS0FBSyxTQUFTLFFBQVEsU0FBUyxJQUFJO0FBQzVFO0FBQUEsSUFDQyxHQUFHLEtBQUssS0FBSyxVQUFVLFNBQVMsTUFBTSxLQUFLLFNBQVMsS0FBSyxNQUFNLFlBQVksUUFBUSxPQUFPLEtBQUssUUFBUSxNQUFNO0FBQUEsRUFBQTtBQUc5RyxNQUFJLFFBQVEsWUFBWSxXQUFXO0FBSWxDLFFBQUksUUFBUSxXQUFXO0FBQ3RCLFVBQUksR0FBRyxLQUFLLEtBQUssNkNBQTZDO0FBQzlELFlBQU0scUJBQUE7QUFDTixZQUFNLGVBQWUsQ0FBQyxhQUFhO0FBQUEsUUFDbEMsR0FBRztBQUFBLFFBQ0gsT0FBTyxRQUFRLE1BQU07QUFBQSxVQUFJLENBQUMsTUFDekIsRUFBRSxRQUFRLEtBQUssTUFDWjtBQUFBLFlBQ0EsR0FBRztBQUFBLFlBQ0gsUUFBUTtBQUFBLFlBQ1IsUUFBUSxRQUFRO0FBQUEsWUFDaEI7QUFBQSxZQUNBLFdBQVc7QUFBQSxZQUNYLFdBQVcsS0FBSyxJQUFBO0FBQUEsVUFBSSxJQUVwQjtBQUFBLFFBQUE7QUFBQSxNQUNKLEVBQ0M7QUFDRixZQUFNLFlBQVksTUFBTSxhQUFhO0FBQ3JDO0FBQUEsSUFDRDtBQUVBLFFBQUksWUFBWSxjQUFjO0FBQzdCLFlBQU07QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMO0FBQUEsUUFDQSxHQUFHLFFBQVEsTUFBTSxrQkFBa0IsUUFBUTtBQUFBLE1BQUE7QUFFNUMsWUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxZQUFNLFFBQUE7QUFDTjtBQUFBLElBQ0Q7QUFDQSxVQUFNO0FBQUEsTUFDTCxLQUFLO0FBQUEsTUFDTDtBQUFBLE1BQ0EsR0FBRyxRQUFRLE1BQU0sYUFBYSxRQUFRLE9BQU8sWUFBWTtBQUFBLE1BQ3pEO0FBQUEsSUFBQTtBQUVELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxjQUFBO0FBQ047QUFBQSxFQUNEO0FBRUEsTUFBSSxRQUFRLFlBQVksWUFBWTtBQUNuQyxVQUFNLGNBQWMsS0FBSyxLQUFLLFVBQVUsUUFBUSxNQUFNO0FBQ3RELFVBQU0sWUFBWSxNQUFNLGFBQWE7QUFDckMsVUFBTSxRQUFBO0FBQ047QUFBQSxFQUNEO0FBS0EsUUFBTSxxQkFBcUIsT0FBTyxRQUFRO0FBRTFDLE1BQUksS0FBSyxTQUFTLFVBQVU7QUFDM0IsVUFBTSxpQkFBaUIsTUFBTSxTQUFTLElBQUk7QUFBQSxFQUMzQyxPQUFPO0FBQ04sVUFBTSxRQUFRO0FBQUEsTUFDYixNQUFNLEtBQUs7QUFBQSxNQUNYLEtBQUssS0FBSztBQUFBLE1BQ1YsTUFBTSxZQUFZLEtBQUssTUFBTSxLQUFLLEdBQUc7QUFBQSxNQUNyQyxNQUFNLFNBQVM7QUFBQSxJQUFBLENBQ2Y7QUFDRCxRQUFJLEtBQUssU0FBUyxVQUFXLE9BQU0sYUFBYSxTQUFTLElBQUk7QUFDN0QsVUFBTSxjQUFjLEtBQUssS0FBSyxZQUFZLFFBQVEsTUFBTTtBQUFBLEVBQ3pEO0FBRUEsUUFBTSxZQUFZLE1BQU0sYUFBYTtBQUNyQyxRQUFNLFFBQUE7QUFDUDtBQVFBLGVBQWUsaUJBQWlCLE1BQWlCLE1BQTZCO0FBQzdFLFFBQU0sTUFBTSxjQUFjLElBQUk7QUFDOUIsTUFBSSxDQUFDLEtBQUs7QUFDVCxVQUFNLGNBQWMsS0FBSyxLQUFLLFVBQVUsK0JBQStCO0FBQ3ZFO0FBQUEsRUFDRDtBQUVBLE1BQUk7QUFDSCxVQUFNLFdBQVcsTUFBTSxNQUFNLGFBQWEsR0FBRyxDQUFDO0FBQzlDLFFBQUksQ0FBQyxTQUFTLEdBQUksT0FBTSxJQUFJLE1BQU0sa0JBQWtCLFNBQVMsTUFBTSxFQUFFO0FBRXJFLFVBQU0sUUFBUSxJQUFJLFdBQVcsTUFBTSxTQUFTLGFBQWE7QUFDekQsUUFBSSxNQUFNLENBQUMsTUFBTSxNQUFRLE1BQU0sQ0FBQyxNQUFNLElBQU07QUFDM0MsWUFBTSxJQUFJLE1BQU0sc0NBQXNDO0FBQUEsSUFDdkQ7QUFFQSxVQUFNLFFBQVE7QUFBQSxNQUNiLE1BQU07QUFBQSxNQUNOLEtBQUssS0FBSztBQUFBLE1BQ1YsTUFBTSxHQUFHLEtBQUssR0FBRztBQUFBLE1BQ2pCLFFBQVEsU0FBUyxLQUFLO0FBQUEsSUFBQSxDQUN0QjtBQUNELFVBQU07QUFBQSxNQUNMLEtBQUs7QUFBQSxNQUNMO0FBQUEsTUFDQSxtQkFBbUIsS0FBSyxNQUFNLE1BQU0sU0FBUyxJQUFJLENBQUM7QUFBQSxJQUFBO0FBQUEsRUFFcEQsU0FBUyxPQUFPO0FBQ2YsVUFBTTtBQUFBLE1BQ0wsS0FBSztBQUFBLE1BQ0w7QUFBQSxNQUNBLDhCQUE4QixjQUFjLEtBQUssQ0FBQztBQUFBLElBQUE7QUFBQSxFQUVwRDtBQUNEO0FBR0EsZUFBZSxhQUFhLE1BQTZCO0FBQ3hELFFBQU0sU0FBUyxjQUFjLGdCQUFnQixJQUFJLENBQUM7QUFDbEQsTUFBSSxPQUFPLFdBQVcsRUFBRztBQUV6QixRQUFNLGNBQWMsQ0FBQyxZQUFZO0FBQ2hDLFVBQU0sYUFBYSxFQUFFLEdBQUcsUUFBUSxpQkFBQTtBQUNoQyxlQUFXLFNBQVMsUUFBUTtBQUMzQixVQUFJLENBQUMsV0FBVyxNQUFNLE9BQU8sR0FBRztBQUMvQixtQkFBVyxNQUFNLE9BQU8sSUFBSSxFQUFFLE1BQU0sTUFBTSxNQUFNLEtBQUssTUFBTSxJQUFBO0FBQUEsTUFDNUQ7QUFBQSxJQUNEO0FBQ0EsV0FBTyxFQUFFLEdBQUcsU0FBUyxrQkFBa0IsV0FBQTtBQUFBLEVBQ3hDLENBQUM7QUFDRjtBQU1BLGVBQWUsa0JBQW9DO0FBQ2xELFFBQU0sVUFBVSxNQUFNLFdBQUE7QUFDdEIsTUFBSSxRQUFRLGlCQUFpQixRQUFRLFlBQWEsUUFBTztBQUV6RCxRQUFNLGNBQWMsQ0FBQyxPQUFPLEVBQUUsR0FBRyxHQUFHLGVBQWUsT0FBTztBQUUxRCxRQUFNLFFBQVEsSUFBSSxJQUFJLFFBQVEsbUJBQW1CO0FBQ2pELFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsUUFBTSxnQkFBZ0IsSUFBSTtBQUFBLElBQ3pCLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxFQUFFLFNBQVMsUUFBUSxFQUFFLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRztBQUFBLEVBQUE7QUFHaEUsUUFBTSxRQUFxQixPQUFPLFFBQVEsUUFBUSxnQkFBZ0IsRUFDaEUsT0FBTyxDQUFDLENBQUMsT0FBTyxNQUFNLENBQUMsTUFBTSxJQUFJLE9BQU8sS0FBSyxDQUFDLGNBQWMsSUFBSSxPQUFPLENBQUMsRUFDeEUsSUFBSSxDQUFDLENBQUMsU0FBUyxLQUFLLE9BQU87QUFBQSxJQUMzQixNQUFNO0FBQUEsSUFDTixLQUFLO0FBQUEsSUFDTCxPQUFPLEdBQUcsTUFBTSxJQUFJO0FBQUEsSUFDcEIsS0FBSyxjQUFjLE1BQU0sR0FBRztBQUFBLElBQzVCLFFBQVE7QUFBQSxFQUFBLEVBQ1AsRUFDRCxLQUFLLENBQUMsR0FBRyxNQUFNLEVBQUUsTUFBTSxjQUFjLEVBQUUsS0FBSyxDQUFDO0FBRS9DLE1BQUksTUFBTSxXQUFXLEVBQUcsUUFBTztBQUUvQixRQUFNLE9BQU8sTUFBTSxZQUFZLEtBQUs7QUFDcEMsUUFBTSxZQUFZLElBQUk7QUFDdEIsU0FBTztBQUNSO0FBSUEsZUFBZSxZQUErQjtBQUM3QyxRQUFNLHFCQUFBO0FBQ04sZ0JBQUE7QUFDQSxRQUFNLE9BQU8sT0FBTyxNQUFNLGNBQWMsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFJeEQsUUFBTSxVQUFVLE1BQU0sZUFBZSxDQUFDLGFBQWE7QUFBQSxJQUNsRCxHQUFHO0FBQUEsSUFDSCxPQUFPLFFBQVEsTUFBTTtBQUFBLE1BQUksQ0FBQyxTQUN6QixLQUFLLFdBQVcsY0FDaEIsS0FBSyxXQUFXLFlBQ2hCLEtBQUssV0FBVyxZQUNiLE9BQ0E7QUFBQSxRQUNBLEdBQUc7QUFBQSxRQUNILFFBQVE7QUFBQSxRQUNSLFFBQVEsS0FBSyxVQUFVO0FBQUEsTUFBQTtBQUFBLElBQ3hCO0FBQUEsRUFDSCxFQUNDO0FBRUYsUUFBTSxRQUFRO0FBQ2QsUUFBTSxXQUFXLE1BQU0sTUFBTSxPQUFPLENBQUMsTUFBTSxFQUFFLFdBQVcsVUFBVSxFQUFFO0FBQ3BFLFFBQU0sU0FBUyxNQUFNLE1BQU0sT0FBTyxDQUFDLE1BQU0sRUFBRSxXQUFXLFFBQVEsRUFBRTtBQUVoRSxRQUFNLE9BQWlCO0FBQUEsSUFDdEIsR0FBRztBQUFBLElBQ0gsUUFBUTtBQUFBLElBQ1IsWUFBWTtBQUFBLElBQ1osWUFBWSxLQUFLLElBQUE7QUFBQSxJQUNqQixTQUFTLFNBQ04sWUFBWSxRQUFRLE9BQU8sTUFBTSxNQUFNLE1BQU0sS0FBSyxNQUFNLGFBQ3hELGdCQUFnQixRQUFRO0FBQUEsRUFBQTtBQU01QixRQUFNLFlBQVksSUFBSTtBQUN0QixRQUFNLGVBQUE7QUFDTixRQUFNLFNBQVMsU0FBUyxPQUFPLE1BQU0sSUFBSSxFQUFFO0FBQzNDLFFBQU0sY0FBQTtBQUNOLFFBQU0sWUFBWSxJQUFJO0FBQ3RCLFFBQU0sZUFBZSxJQUFJO0FBQ3pCLFNBQU87QUFDUjtBQUdBLGVBQWUsaUJBQWdDO0FBQzlDLFFBQU0sRUFBRSxnQkFBZ0IsTUFBTSxXQUFBO0FBQzlCLE1BQUksZ0JBQWdCLE9BQVc7QUFDL0IsUUFBTSxPQUFPLFdBQVc7QUFDeEIsUUFBTSxrQkFBa0IsV0FBVztBQUNuQyxRQUFNLE9BQU8sS0FBSyxPQUFPLFdBQVcsRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFHcEQsUUFBTSxjQUFjLENBQUMsYUFBYSxFQUFFLEdBQUcsU0FBUyxhQUFhLFNBQVk7QUFDMUU7QUFHQSxlQUFlLGdCQUErQjtBQUM3QyxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsTUFBSTtBQUNILFVBQU0sTUFBTSxNQUFNLE9BQU8sS0FBSyxJQUFJLFVBQVU7QUFDNUMsVUFBTSxPQUFPLEtBQUssT0FBTyxZQUFZLEVBQUUsUUFBUSxNQUFNO0FBQ3JELFFBQUksSUFBSSxhQUFhLFFBQVc7QUFDL0IsWUFBTSxPQUFPLFFBQVEsT0FBTyxJQUFJLFVBQVUsRUFBRSxTQUFTLE1BQU07QUFBQSxJQUM1RDtBQUFBLEVBQ0QsUUFBUTtBQUFBLEVBRVI7QUFDRDtBQUVBLGVBQWUsZUFBZSxPQUFnQztBQUM3RCxRQUFNLEVBQUUsZUFBZSxNQUFNLFdBQUE7QUFDN0IsTUFBSSxlQUFlLE9BQVc7QUFDOUIsUUFBTSxPQUFPLEtBQ1gsWUFBWSxZQUFZLEVBQUUsTUFBTSxZQUFZLE1BQUEsQ0FBTyxFQUNuRCxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDakI7QUFLQSxlQUFlLFFBQVEsTUFBbUM7QUFDekQsUUFBTSxRQUFRLElBQUk7QUFDbEIsUUFBTSxXQUFXLElBQUk7QUFDdEI7QUFHQSxlQUFzQixjQUE2QjtBQUNsRCxhQUFXLFFBQVEsTUFBTSxTQUFBLEVBQVksT0FBTSxXQUFXLElBQUk7QUFDM0Q7QUFFQSxTQUFTLFlBQVksTUFBNEIsS0FBcUI7QUFDckUsVUFBUSxNQUFBO0FBQUEsSUFDUCxLQUFLO0FBQ0osYUFBTyxXQUFXLEdBQUc7QUFBQSxJQUN0QixLQUFLO0FBQ0osYUFBTyxHQUFHLEdBQUc7QUFBQSxJQUNkLEtBQUs7QUFDSixhQUFPO0FBQUEsSUFDUjtBQUNDLGFBQU8sR0FBRyxHQUFHO0FBQUEsRUFBQTtBQUVoQjtBQUVBLFNBQVMsU0FBUyxPQUEyQjtBQUM1QyxNQUFJLFNBQVM7QUFFYixXQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxLQUFLLE9BQVE7QUFDOUMsY0FBVSxPQUFPLGFBQWEsR0FBRyxNQUFNLFNBQVMsR0FBRyxJQUFJLEtBQU0sQ0FBQztBQUFBLEVBQy9EO0FBQ0EsU0FBTyxLQUFLLE1BQU07QUFDbkI7QUFFQSxlQUFlLFNBQVMsTUFBNkI7QUFDcEQsUUFBTSxPQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDMUQ7QUNweUJBLElBQUksUUFBMEIsUUFBUSxRQUFBO0FBRS9CLFNBQVMsT0FBVSxNQUFvQztBQUM3RCxRQUFNLE9BQU8sTUFBTSxLQUFLLE1BQU0sSUFBSTtBQUdsQyxVQUFRLEtBQUssTUFBTSxNQUFNLE1BQVM7QUFDbEMsU0FBTztBQUNSO0FDb0JBLE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFFBQVEsaUJBQWlCO0FBR3ZFLE1BQUksZ0JBQWdCLE9BQU8sR0FBRztBQUM3QixTQUFLLG9CQUFvQixPQUFPLE9BQU8sT0FBTyxNQUFNO0FBQUEsRUFDckQ7QUFHQSxnQkFBYyxTQUEyQyxNQUFNLEVBQzdELEtBQUssWUFBWSxFQUNqQixNQUFNLENBQUMsVUFBVSxhQUFhLEVBQUUsT0FBTyxPQUFPLEtBQUssRUFBQSxDQUFHLENBQUM7QUFDekQsU0FBTztBQUNSLENBQUM7QUFFRCxlQUFlLGNBQ2QsU0FDQSxRQUNtQjtBQUNuQixVQUFRLFFBQVEsTUFBQTtBQUFBLElBQ2YsS0FBSztBQUNKLGFBQU87QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLFNBQVM7QUFBQSxRQUNULE9BQU8sTUFBTSxZQUFBO0FBQUEsTUFBWTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBUzNCLEtBQUssVUFBVTtBQUNkLFlBQU0sRUFBRSxnQkFBZ0IsTUFBTSxXQUFBO0FBQzlCLFlBQU0sY0FDTCxPQUFPLEtBQUssT0FBTyxVQUFhLE9BQU8sSUFBSSxPQUFPO0FBQ25ELGFBQU87QUFBQSxRQUNOLE1BQU07QUFBQSxRQUNOLE9BQU8sY0FBYyxNQUFNLFlBQUEsSUFBZ0IsY0FBQTtBQUFBLE1BQWM7QUFBQSxJQUUzRDtBQUFBLElBRUEsS0FBSyxTQUFTO0FBQ2IsWUFBTSxhQUFhLE9BQU8sS0FBSztBQUMvQixVQUFJLGVBQWUsT0FBVyxRQUFPLEVBQUUsT0FBTyxpQkFBQTtBQUM5QyxZQUFNLFVBQVcsUUFDZjtBQUNGLFlBQU0sUUFBUSxNQUFNLFNBQVMsU0FBUyxVQUFVO0FBQ2hELGFBQU8sRUFBRSxNQUFNLFNBQVMsTUFBQTtBQUFBLElBQ3pCO0FBQUEsSUFFQSxLQUFLLFVBQVU7QUFDZCxZQUFNLGFBQWEsT0FBTyxLQUFLO0FBQy9CLFVBQUksZUFBZSxPQUFXLFFBQU8sRUFBRSxPQUFPLGlCQUFBO0FBQzlDLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLFVBQVUsVUFBVSxFQUFBO0FBQUEsSUFDMUQ7QUFBQSxJQUVBLEtBQUs7QUFDSixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxZQUFVO0FBQUEsSUFFaEQsS0FBSztBQUNKLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLGVBQWE7QUFBQSxJQUVuRCxLQUFLO0FBQ0osYUFBTyxFQUFFLE1BQU0sU0FBUyxPQUFPLE1BQU0sY0FBWTtBQUFBLElBRWxELEtBQUs7QUFDSixZQUFNLFlBQUE7QUFDTixhQUFPLEVBQUUsTUFBTSxTQUFTLE9BQU8sTUFBTSxjQUFZO0FBQUEsSUFFbEQsS0FBSztBQUNKLFlBQU0sVUFBQTtBQUNOLGFBQU8sRUFBRSxNQUFNLFNBQVMsT0FBTyxNQUFNLGNBQVk7QUFBQSxJQUVsRDtBQUNDLGFBQU8sRUFBRSxPQUFPLG9CQUFvQixRQUFRLElBQUksR0FBQTtBQUFBLEVBQUc7QUFFdEQ7QUFjQSxPQUFPLFNBQVMsUUFBUSxZQUFZLENBQUMsUUFBUSxRQUFRLFdBQVc7QUFDL0QsTUFBSSxPQUFPLFVBQVUsVUFBYSxDQUFDLE9BQVE7QUFDM0MsUUFBTSxRQUFRLE9BQU87QUFDckIsT0FBSyxPQUFPLE1BQU0sb0JBQW9CLE9BQU8sUUFBUSxNQUFNLENBQUMsRUFBRTtBQUFBLElBQzdELENBQUMsVUFBVTtBQUNWLGNBQVEsTUFBTSwyQ0FBMkMsUUFBUSxLQUFLO0FBQUEsSUFDdkU7QUFBQSxFQUFBO0FBRUYsQ0FBQztBQUVELGVBQWUsb0JBQ2QsT0FDQSxRQUNBLFFBQ2dCO0FBQ2hCLE1BQUksV0FBVyw0QkFBNEI7QUFDMUMsVUFBTSxxQkFBcUIsT0FBTyxNQUFNO0FBQ3hDO0FBQUEsRUFDRDtBQUVBLE1BQUksV0FBVywyQkFBMkI7QUFDekMsVUFBTSxXQUFXLE1BQU0sb0JBQW9CLE9BQU8sTUFBTTtBQUd4RCxRQUFJLFNBQVUsT0FBTSxxQkFBcUIsS0FBSztBQUFBLEVBQy9DO0FBQ0Q7QUFPQSxPQUFPLFNBQVMsU0FBUyxZQUFZLENBQUMsUUFBUSxXQUFXO0FBQ3hELE9BQUssYUFBYSxPQUFPLE9BQU8sTUFBTTtBQUN2QyxDQUFDO0FBRUQsZUFBZSxhQUFhLE9BQWUsUUFBK0I7QUFDekUsUUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixNQUFJLFFBQVEsZ0JBQWdCLE1BQU87QUFFbkMsUUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixNQUFJLE1BQU0sV0FBVyxVQUFXO0FBRWhDLFFBQU0sWUFBWTtBQUFBLElBQ2pCLEdBQUc7QUFBQSxJQUNILFFBQVE7QUFBQSxJQUNSLFlBQVk7QUFBQSxJQUNaLFlBQVksS0FBSyxJQUFBO0FBQUEsSUFDakIsU0FBUyxpQ0FBaUMsTUFBTTtBQUFBLEVBQUEsQ0FDaEQ7QUFDRCxRQUFNLE9BQU8sT0FBTyxhQUFhLEVBQUUsTUFBTSxJQUFBLENBQUssRUFBRSxNQUFNLE1BQU07QUFBQSxFQUFDLENBQUM7QUFDL0Q7QUFJQSxPQUFPLEtBQUssVUFBVSxZQUFZLENBQUMsVUFBVTtBQUc1QyxPQUFLLE9BQU8sTUFBTSxpQkFBaUIsS0FBSyxDQUFDO0FBQzFDLENBQUM7QUFFRCxlQUFlLGlCQUFpQixPQUE4QjtBQUM3RCxRQUFNLFVBQVUsTUFBTSxXQUFBO0FBQ3RCLFFBQU0sUUFBUSxNQUFNLFlBQUE7QUFDcEIsTUFBSSxNQUFNLFdBQVcsVUFBVztBQUVoQyxNQUFJLFFBQVEsZ0JBQWdCLE9BQU87QUFDbEMsVUFBTSxPQUFPLEtBQUs7QUFDbEIsVUFBTSxZQUFZO0FBQUEsTUFDakIsR0FBRztBQUFBLE1BQ0gsUUFBUTtBQUFBLE1BQ1IsWUFBWTtBQUFBLE1BQ1osWUFBWSxLQUFLLElBQUE7QUFBQSxNQUNqQixTQUFTO0FBQUEsSUFBQSxDQUNUO0FBQ0QsVUFBTSxPQUFPLE9BQU8sYUFBYSxFQUFFLE1BQU0sR0FBQSxDQUFJLEVBQUUsTUFBTSxNQUFNO0FBQUEsSUFBQyxDQUFDO0FBQUEsRUFDOUQ7QUFDRDtBQVNBLE9BQU8sUUFBUSxVQUFVLFlBQVksTUFBTTtBQUMxQyxRQUFNLFlBQVk7QUFDakIsVUFBTSxRQUFRLE1BQU0sWUFBQTtBQUNwQixRQUFJLE1BQU0sV0FBVyxVQUFXO0FBQ2hDLFVBQU0sWUFBWTtBQUFBLE1BQ2pCLEdBQUc7QUFBQSxNQUNILFFBQVE7QUFBQSxNQUNSLFlBQVk7QUFBQSxNQUNaLFNBQVM7QUFBQSxJQUFBLENBQ1Q7QUFBQSxFQUNGLEdBQUE7QUFDRCxDQUFDO0FBU0QsT0FBTyxLQUFLLFVBQVUsWUFBWSxDQUFDLE9BQU8sU0FBUztBQUNsRCxNQUFJLEtBQUssV0FBVyxXQUFZO0FBQ2hDLFFBQU0sWUFBWTtBQUNqQixVQUFNLFFBQVEsTUFBTSxZQUFBO0FBQ3BCLFFBQUksTUFBTSxXQUFXLFVBQVc7QUFFaEMsVUFBTSxVQUFVLE1BQU0sV0FBQTtBQUN0QixRQUFJLFFBQVEsZ0JBQWdCLE1BQU87QUFHbkMsUUFBSSxDQUFDLE1BQU0sWUFBWTtBQUN0QixZQUFNLE9BQU8sTUFBTSxTQUFTO0FBQzVCO0FBQUEsSUFDRDtBQUVBLFVBQU0sT0FBTyxNQUFNLHFCQUFxQixLQUFLLENBQUM7QUFLOUMsVUFBTSxPQUFPLE1BQU0scUJBQXFCLEtBQUssQ0FBQztBQUFBLEVBQy9DLEdBQUE7QUFDRCxDQUFDO0FBT0QsT0FBTyxPQUFPLFFBQVEsWUFBWSxDQUFDLFVBQVU7QUFDNUMsTUFBSSxNQUFNLFNBQVMsaUJBQWlCO0FBQ25DLFNBQUssT0FBTyxNQUFNLHFCQUFxQjtBQUN2QztBQUFBLEVBQ0Q7QUFHQSxNQUFJLE1BQU0sU0FBUyxZQUFZO0FBQzlCLFNBQUssT0FBTyxNQUFNLGVBQWU7QUFBQSxFQUNsQztBQUNELENBQUM7QUFHRCxPQUFPLE9BQU8sVUFBVSxZQUFZLE1BQU07QUFDekMsT0FBSyxjQUFBO0FBQ04sQ0FBQztBQUVELE9BQU8sT0FBTyx3QkFBd0IsRUFBRSxPQUFPLFdBQVcsRUFBRSxNQUFNLE1BQU07QUFBQyxDQUFDOyJ9
